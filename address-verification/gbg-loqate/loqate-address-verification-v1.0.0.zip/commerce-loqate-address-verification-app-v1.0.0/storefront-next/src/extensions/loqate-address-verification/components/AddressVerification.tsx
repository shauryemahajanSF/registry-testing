/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
'use client';

import { useState, useEffect, useRef, useCallback, type ReactElement } from 'react';
import { useTranslation } from 'react-i18next';
import { useFetcher } from 'react-router';
import { Loader2, MapPin, CheckCircle2 } from 'lucide-react';
import { useBasket } from '@/providers/basket';
import { Button } from '@/components/ui/button';
import { Alert, AlertTitle } from '@/components/ui/alert';
import { useLoqateVerification, type AddressSuggestion, type VerifiedAddress } from '../hooks/useLoqateVerification';
import { useLoqateContext } from '../providers/LoqateProvider';
import AddressSuggestions from './AddressSuggestions';
import VerificationStatus from './VerificationStatus';

export interface AddressVerificationProps {
    className?: string;
}

function AddressVerification({ className = '' }: AddressVerificationProps): ReactElement {
    const { t } = useTranslation('extLoqateAddressVerification');
    const { config } = useLoqateContext();
    const basket = useBasket();
    const fetcher = useFetcher({ key: 'loqate-apply-address' });
    const [showSuggestions, setShowSuggestions] = useState(false);
    const [applied, setApplied] = useState(false);
    const prevFetcherState = useRef(fetcher.state);
    const autoAppliedRef = useRef(false);

    const shippingAddress = basket?.shipments?.[0]?.shippingAddress;

    const buildKey = (...parts: (string | undefined | null)[]) => parts.map((p) => p ?? '').join('|');

    const addressKey = buildKey(
        shippingAddress?.address1,
        shippingAddress?.address2,
        shippingAddress?.city,
        shippingAddress?.stateCode,
        shippingAddress?.postalCode
    );
    const appliedAddressKey = useRef<string | null>(null);
    const verifiedAddressKey = useRef<string | null>(null);

    const { status, suggestions, verifiedAddress, error, verifyAddress, selectAddress, reset } = useLoqateVerification({
        apiKey: config.apiKey,
        enabled: config.enabled,
    });

    const submitVerifiedAddress = useCallback(
        (addr: VerifiedAddress) => {
            // Pre-set the keys to the address we're about to apply so the
            // address-change detection doesn't treat the basket update as a user edit.
            const expectedKey = buildKey(addr.address1, addr.address2, addr.city, addr.stateCode, addr.postalCode);
            verifiedAddressKey.current = expectedKey;
            appliedAddressKey.current = expectedKey;

            const formData = new FormData();
            formData.append('intent', 'shippingAddress');
            formData.append('firstName', shippingAddress?.firstName || '');
            formData.append('lastName', shippingAddress?.lastName || '');
            formData.append('address1', addr.address1);
            if (addr.address2) formData.append('address2', addr.address2);
            formData.append('city', addr.city);
            formData.append('stateCode', addr.stateCode);
            formData.append('postalCode', addr.postalCode);
            formData.append('countryCode', addr.countryCode);
            if (shippingAddress?.phone) formData.append('phone', shippingAddress.phone);
            void fetcher.submit(formData, { method: 'post' });
        },
        [fetcher, shippingAddress]
    );

    // Auto-apply high confidence matches (V44 + matchscore >= 95)
    useEffect(() => {
        if (verifiedAddress?.confidence === 'high' && !autoAppliedRef.current && !applied) {
            autoAppliedRef.current = true;
            submitVerifiedAddress(verifiedAddress);
        }
    }, [verifiedAddress, applied, submitVerifiedAddress]);

    // Track fetcher completion to set applied state.
    // React Router fetcher transitions: idle → submitting → loading → idle
    useEffect(() => {
        if (prevFetcherState.current !== 'idle' && fetcher.state === 'idle') {
            setApplied(true);
        }
        prevFetcherState.current = fetcher.state;
    }, [fetcher.state]);

    // Capture the address key once when verification completes.
    // Guard on `=== null` so that subsequent basket/addressKey changes
    // don't overwrite the snapshot — the reset effect needs the original
    // key to detect when the user edits the address.
    useEffect(() => {
        if (
            (status === 'verified' || status === 'partiallyVerified' || status === 'unverified') &&
            verifiedAddressKey.current === null
        ) {
            verifiedAddressKey.current = addressKey;
        }
    }, [status, addressKey]);

    // Reset when address changes after any verification result or after applying
    useEffect(() => {
        if (verifiedAddressKey.current !== null && addressKey !== verifiedAddressKey.current) {
            setApplied(false);
            appliedAddressKey.current = null;
            verifiedAddressKey.current = null;
            autoAppliedRef.current = false;
            reset();
        }
    }, [addressKey, reset]);

    useEffect(() => {
        if (status === 'verified' || status === 'partiallyVerified') {
            setShowSuggestions(false);
        }
    }, [status]);

    const handleVerify = () => {
        if (!shippingAddress) return;
        autoAppliedRef.current = false;
        reset();
        void verifyAddress({
            address1: shippingAddress.address1 || '',
            address2: shippingAddress.address2 || '',
            city: shippingAddress.city || '',
            stateCode: shippingAddress.stateCode || '',
            postalCode: shippingAddress.postalCode || '',
            countryCode: shippingAddress.countryCode || 'US',
        });
    };

    const handleApplyAddress = () => {
        if (!verifiedAddress) return;
        submitVerifiedAddress(verifiedAddress);
    };

    const handleSelectSuggestion = (suggestion: AddressSuggestion) => {
        selectAddress(suggestion);
        setShowSuggestions(false);
    };

    const handleCancel = () => {
        setShowSuggestions(false);
        reset();
    };

    useEffect(() => {
        if (status === 'ambiguous' && suggestions.length > 0) {
            setShowSuggestions(true);
        }
    }, [status, suggestions]);

    if (!config.enabled) {
        return <></>;
    }

    const hasAddress = !!(shippingAddress?.address1 && shippingAddress?.city && shippingAddress?.postalCode);
    const isApplying = fetcher.state === 'submitting';
    const confidence = verifiedAddress?.confidence;

    // Collapsed applied state
    if (applied) {
        return (
            <div className={className}>
                <Alert>
                    <CheckCircle2 className="size-4" />
                    <AlertTitle>{t('loqateAddressVerification.message.addressApplied')}</AlertTitle>
                </Alert>
            </div>
        );
    }

    // High confidence being auto-applied — show spinner
    if (confidence === 'high' && isApplying) {
        return (
            <div className={className}>
                <Alert>
                    <Loader2 className="size-4 animate-spin" />
                    <AlertTitle>{t('loqateAddressVerification.message.autoApplying')}</AlertTitle>
                </Alert>
            </div>
        );
    }

    const showResults =
        status === 'verified' || status === 'partiallyVerified' || status === 'unverified' || status === 'error';
    const canApply = verifiedAddress && (confidence === 'medium' || confidence === 'low');

    // For e-commerce: P/U prefix addresses (confidence=none) should be rejected.
    // Downgrade the display status to 'unverified' so the UI clearly tells the
    // user to edit their address instead of showing a misleading "partially verified".
    const displayStatus =
        showResults && confidence === 'none' && status === 'partiallyVerified' ? 'unverified' : status;

    return (
        <div className={className}>
            {showResults && (
                <VerificationStatus
                    status={displayStatus}
                    verifiedAddress={confidence !== 'none' ? verifiedAddress : null}
                    originalAddress={shippingAddress}
                    error={error}
                />
            )}

            {showSuggestions && suggestions.length > 0 && (
                <AddressSuggestions
                    suggestions={suggestions}
                    onSelect={handleSelectSuggestion}
                    onCancel={handleCancel}
                />
            )}

            {status === 'verifying' ? (
                <Button type="button" disabled className="w-full">
                    <Loader2 className="animate-spin" />
                    {t('loqateAddressVerification.message.verifying')}
                </Button>
            ) : status === 'idle' || status === 'ambiguous' ? (
                <Button type="button" onClick={handleVerify} disabled={!hasAddress} className="w-full">
                    {t('loqateAddressVerification.button.verify')}
                </Button>
            ) : canApply ? (
                <Button type="button" onClick={handleApplyAddress} disabled={isApplying} className="w-full">
                    {isApplying ? <Loader2 className="animate-spin" /> : <MapPin />}
                    {t('loqateAddressVerification.button.applyAddress')}
                </Button>
            ) : null}
        </div>
    );
}

export default AddressVerification;
