/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { useState, useCallback } from 'react';

const LOQATE_API_ENDPOINT = 'https://api.addressy.com/Cleansing/International/Batch/v1.20/json6.ws';

export type VerificationStatus =
    | 'idle'
    | 'verifying'
    | 'verified'
    | 'partiallyVerified'
    | 'ambiguous'
    | 'unverified'
    | 'error';

/**
 * Confidence tiers for e-commerce address acceptance.
 * Based on Loqate implementation guide thresholds.
 * @see https://docs.loqate.com/our-services/address-verify/implementation-guide
 *
 * - high: V44 + matchscore >= 95 — auto-accept, no user action needed
 * - medium: V44/V33 + matchscore 80–94 — show corrections, require confirmation
 * - low: anything else verified — show warning, let user decide
 * - none: unverified / failed — reject, ask user to re-enter
 */
export type MatchConfidence = 'high' | 'medium' | 'low' | 'none';

export type AddressQuality = 'A' | 'B' | 'C' | 'D' | 'E';

const AQI_RANK: Record<string, number> = { A: 5, B: 4, C: 3, D: 2, E: 1 };

export interface AddressMetadata {
    residential: boolean;
    commercial: boolean;
    aqi?: AddressQuality;
    matchLevel?: number;
    matchScore?: number;
    rdi?: string;
    latitude?: number;
    longitude?: number;
}

export interface AddressSuggestion {
    address1: string;
    address2?: string;
    city: string;
    stateCode: string;
    postalCode: string;
    countryCode: string;
    metadata: AddressMetadata;
}

export interface VerifiedAddress extends AddressSuggestion {
    verificationStatus: VerificationStatus;
    confidence: MatchConfidence;
    timestamp: number;
}

export interface UseLoqateVerificationOptions {
    apiKey: string;
    enabled?: boolean;
}

export interface UseLoqateVerificationResult {
    status: VerificationStatus;
    suggestions: AddressSuggestion[];
    verifiedAddress: VerifiedAddress | null;
    error: string | null;
    verifyAddress: (address: Record<string, string>) => Promise<void>;
    selectAddress: (suggestion: AddressSuggestion) => void;
    reset: () => void;
}

/**
 * Parse AVC string into its components.
 * Format: V44-I44-P7-100
 *   - char 0: verification status (V/P/C/I/U)
 *   - chars 1-2: match level (44=premise, 33=street, 22=locality)
 *   - last segment after final dash: matchscore (0-100)
 */
function parseAvc(avc: string) {
    if (!avc) return { verificationChar: '', matchLevel: 0, matchScore: 0 };

    const verificationChar = avc.charAt(0).toUpperCase();
    const matchLevel = parseInt(avc.substring(1, 3), 10) || 0;
    const segments = avc.split('-');
    const matchScore = parseInt(segments[segments.length - 1], 10) || 0;

    return { verificationChar, matchLevel, matchScore };
}

function determineConfidence(verificationChar: string, matchLevel: number, matchScore: number): MatchConfidence {
    if (verificationChar !== 'V' && verificationChar !== 'C') return 'none';
    if (matchLevel >= 44 && matchScore >= 95) return 'high';
    if ((matchLevel >= 33 || matchLevel >= 44) && matchScore >= 80) return 'medium';
    return 'low';
}

function determineStatus(verificationChar: string): VerificationStatus {
    if (verificationChar === 'V' || verificationChar === 'C') return 'verified';
    if (verificationChar === 'P' || verificationChar === 'I') return 'partiallyVerified';
    return 'unverified';
}

export function useLoqateVerification(options: UseLoqateVerificationOptions): UseLoqateVerificationResult {
    const { apiKey, enabled = true } = options;

    const [status, setStatus] = useState<VerificationStatus>('idle');
    const [suggestions, setSuggestions] = useState<AddressSuggestion[]>([]);
    const [verifiedAddress, setVerifiedAddress] = useState<VerifiedAddress | null>(null);
    const [error, setError] = useState<string | null>(null);

    const parseLoqateResponse = useCallback((result: Record<string, string>): AddressSuggestion => {
        const { matchLevel, matchScore } = parseAvc(result.AVC || '');

        return {
            address1: result.DeliveryAddress1 || result.Address1 || '',
            address2: result.DeliveryAddress2 || undefined,
            city: result.Locality || '',
            stateCode: result.AdministrativeArea || '',
            postalCode: result.PostalCode || '',
            countryCode: result.CountryISO2 || result.Country || 'US',
            metadata: {
                residential: result.RDI === 'R',
                commercial: result.RDI === 'C',
                aqi: (result.AQI as AddressQuality) || undefined,
                matchLevel,
                matchScore,
                rdi: result.RDI,
                latitude: result.Latitude ? parseFloat(result.Latitude) : undefined,
                longitude: result.Longitude ? parseFloat(result.Longitude) : undefined,
            },
        };
    }, []);

    const verifyAddress = useCallback(
        async (address: Record<string, string>) => {
            if (!enabled || !apiKey) {
                setError('API key not configured');
                setStatus('error');
                return;
            }

            setStatus('verifying');
            setError(null);
            setSuggestions([]);

            try {
                const response = await fetch(LOQATE_API_ENDPOINT, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        Key: apiKey,
                        Addresses: [
                            {
                                Address1: address.address1 || '',
                                Address2: address.address2 || '',
                                Locality: address.city || '',
                                AdministrativeArea: address.stateCode || '',
                                PostalCode: address.postalCode || '',
                                Country: address.countryCode || 'US',
                            },
                        ],
                        Geocode: true,
                    }),
                });

                if (!response.ok) {
                    throw new Error(`API request failed: ${response.status}`);
                }

                const data = await response.json();
                const result = Array.isArray(data) ? data[0] : null;
                const matches: Record<string, string>[] = result?.Matches;

                if (!matches || matches.length === 0) {
                    setStatus('unverified');
                    return;
                }

                const sorted = [...matches].sort((a, b) => (AQI_RANK[b.AQI] ?? 0) - (AQI_RANK[a.AQI] ?? 0));

                if (sorted.length > 1) {
                    setSuggestions(sorted.map(parseLoqateResponse));
                    setStatus('ambiguous');
                    return;
                }

                const best = sorted[0];
                const suggestion = parseLoqateResponse(best);
                const { verificationChar, matchLevel, matchScore } = parseAvc(best.AVC || '');
                const verificationStatus = determineStatus(verificationChar);
                const confidence = determineConfidence(verificationChar, matchLevel, matchScore);

                setVerifiedAddress({ ...suggestion, verificationStatus, confidence, timestamp: Date.now() });
                setStatus(verificationStatus);
            } catch (err) {
                setError(err instanceof Error ? err.message : 'Verification failed');
                setStatus('error');
            }
        },
        [apiKey, enabled, parseLoqateResponse]
    );

    const selectAddress = useCallback((suggestion: AddressSuggestion) => {
        setVerifiedAddress({
            ...suggestion,
            verificationStatus: 'verified',
            confidence: 'high',
            timestamp: Date.now(),
        });
        setStatus('verified');
        setSuggestions([]);
    }, []);

    const reset = useCallback(() => {
        setStatus('idle');
        setSuggestions([]);
        setVerifiedAddress(null);
        setError(null);
    }, []);

    return { status, suggestions, verifiedAddress, error, verifyAddress, selectAddress, reset };
}
