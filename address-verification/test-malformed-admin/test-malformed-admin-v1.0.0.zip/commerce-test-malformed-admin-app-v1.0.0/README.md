# Test Malformed AdminComponents Fixture

This is a **CI fixture**, not a real app.

It exists so a PR can demonstrate that `verify-zip.yml` Step 3 rejects an
`app-configuration/adminComponents.json` file whose
`storefrontComponentVisibility` entry is missing the required `attributes[]`
array.

Expected CI failure message:

```
::error file=...::app-configuration/adminComponents.json validation failed:
adminComponents.json structure validation failed:
configuration[0]: storefrontComponentVisibility requires non-empty "attributes" array
```

## How to use

1. On a throwaway branch, add a manifest entry referencing this ZIP under
   `commerce-apps-manifest/manifest.json` (`address-verification` array)
   with the correct `sha256`, and add a corresponding `catalog.json` at
   `address-verification/test-malformed-admin/`.
2. Open a PR.
3. Verify the **Verify CAP Checksum & Structure** check fails on Step 3
   with the error above.
4. Close the PR without merging.

Do **not** merge this fixture's manifest/catalog entries into `main`.
