# Loqate Address Verification

Address Verification Application with GBG Loqate

## Overview

The Loqate Address Verification app validates and corrects shipping addresses during checkout, ensuring accurate delivery and reducing failed shipments. It integrates with GBG Loqate's global address database covering 250+ countries.

## Features

- Real-time address verification during checkout
- Automatic correction of typos and formatting issues
- Address quality scoring with match percentages
- Standardized address formatting for improved delivery rates
- Support for 250+ countries worldwide
- Seamless integration after shipping address entry

## Prerequisites

- Salesforce Commerce Cloud B2C Commerce instance with Storefront Next
- Loqate API key ([sign up at loqate.com](https://www.loqate.com/))
- Node.js and npm (for development)

## Installation

1. Download the app from the Commerce App Registry
2. Import the app into your Commerce Cloud instance
3. The app will automatically appear in the checkout flow after the shipping address form

## Configuration

### API Key Setup

Configure your Loqate API key using environment variables in your .env file:

```bash
LOQATE_API_KEY=YOUR_LOQATE_API_KEY
```

and in your MRT project (https://runtime.commercecloud.com/).

### Customization

The app can be customized by modifying:
- Styling for address verification components under /components
- Verification behavior in the `lib/loqate-client.server.ts` hook
- Translation strings in `locales/` directories

## Post-Installation Checklist

- [ ] Create a Loqate Account
- [ ] Create a Loqate API Key
- [ ] Configure Loqate API Key
- [ ] Verify Address Verification Works
- [ ] Secure the API Key (Optional)

## Local Development (Storefront Next)

```bash
cd src/extensions/loqate-address-verification
pnpm build
pnpm dev
```

## Support

For questions or issues:
- Loqate Documentation: https://docs.loqate.com/
- Loqate Support: https://www.loqate.com/

## License

Copyright 2026 GBG Loqate. All rights reserved.
