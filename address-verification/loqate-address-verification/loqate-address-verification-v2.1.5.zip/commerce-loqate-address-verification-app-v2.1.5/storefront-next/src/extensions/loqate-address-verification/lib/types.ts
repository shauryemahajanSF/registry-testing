/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

export interface AddressInput {
    address1: string;
    address2?: string;
    city: string;
    stateCode: string;
    postalCode: string;
    countryCode: string;
}

/** AVC confidence level derived from Loqate match score + AVC. */
export type LoqateConfidence = 'high' | 'medium' | 'low' | 'none';

/** Outcome status derived from confidence + suggestion count. */
export type LoqateStatus = 'verified' | 'partiallyVerified' | 'ambiguous' | 'unverified' | 'error';

/** Address Quality Index — Loqate's letter-grade rating of the match. */
export type LoqateAqi = 'A' | 'B' | 'C' | 'D' | 'E';

export interface LoqateSuggestion extends AddressInput {
    matchScore?: number;
    avc?: string;
    aqi?: LoqateAqi;
    confidence: LoqateConfidence;
    residential?: boolean;
    commercial?: boolean;
}

/** Verification result cached server-side, keyed by basketId. */
export interface CachedVerification {
    /**
     * The address the shopper just submitted. Cached server-side because
     * `useBasket()` on the client may not reflect this entry yet — when the
     * action returns 400 (e.g. step `addressVerification`), the core
     * checkout-actions hook skips its `updateBasket(...)` call, so the
     * BasketProvider still holds the *previous* basket. The modal pulls the
     * shopper's actual entry from this field instead.
     */
    submittedAddress: AddressInput;
    /** Personal fields that travel with the address but aren't part of AddressInput. */
    submittedFirstName?: string;
    submittedLastName?: string;
    submittedPhone?: string;
    /** First/best Loqate match. */
    suggestion?: LoqateSuggestion;
    /** Additional matches when ambiguous. */
    suggestions: LoqateSuggestion[];
    status: LoqateStatus;
    /** When the user explicitly accepts as-entered, we suppress re-prompt for this basket+address. */
    acceptedAsEntered?: boolean;
    createdAt: number;
}
