# Loqate Address Verification Extension

This extension provides real-time address verification using the [Loqate API](https://www.loqate.com/) during checkout.

## Features

- **Server-side API key protection**: API key is stored securely on the server and never exposed to the client
- **Plug-and-play integration**: Registers via `target-config.json` only — no edits to core checkout files required
- **Confidence-based handling**: Different UI treatments based on match quality
  - **High confidence** (V44 + matchscore ≥95) with no corrections: silently passes through
  - **High confidence** with corrections: prompts shopper to confirm the corrected address
  - **Medium confidence** (matchscore 80–94): shows corrected version, requires confirmation
  - **Low confidence**: shows warnings, lets the shopper decide
  - **Multiple matches**: shows suggestions to choose from
  - **Unverified**: lets the shopper edit or proceed as entered
- **Address suggestions**: Multiple matches ranked by Loqate's Address Quality Index (AQI)
- **Server-side caching**: One Loqate call per shipping submit; the modal pulls cached results without re-calling the API

## Architecture

### How it plugs in

The extension wires into checkout via the action-hook framework and the UI-target system. Core files are not modified.

| Surface | Mechanism | Purpose |
| --- | --- | --- |
| Submit-shipping action | Action hook `sfcc.checkout.addressVerification.afterSubmitShippingAddress` | Calls Loqate after the basket is updated. Caches the result and aborts the action with `step: 'addressVerification'` whenever shopper confirmation is needed. |
| `sfcc.checkout.shippingAddress` UI target | Wrapper component | Force-remounts the core `<ShippingAddress>` form when the basket's shipping address changes, so the form re-reads `defaultValues` after a correction is applied. |
| `sfcc.checkout.shippingAddress.after` UI target | Modal component | Watches the `shipping-address-form` fetcher; on the action error it loads the cached verification and renders the confirmation modal. |
| `/action/loqate-fetch-verification` | Extension loader route | Returns the cached verification for the current basket. |
| `/action/loqate-accept-as-entered` | Extension action route | Marks the cache so the next shipping submit bypasses the modal. |

### Flow

```
Continue to Shipping Method  (shopper submits shipping address)
        │
        ▼
core action.submit-shipping-address  (writes basket via SCAPI)
        │
        ▼
hook: sfcc.checkout.addressVerification.afterSubmitShippingAddress
        │
        ├─ exact high-confidence match  ─►  return; action succeeds; advance step
        │
        └─ shopper confirmation required
                │  cache suggestions by basketId
                │  throw ActionHookError(step: 'addressVerification')
                ▼
        action returns 400 { step: 'addressVerification', error: '…' }
                │
                ▼
        Modal in sfcc.checkout.shippingAddress.after
        sees the fetcher error, loads cached result, prompts shopper:
        ├─ Use Verified Address  → re-submit shipping form with the suggestion
        ├─ Use Address as Entered → POST /action/loqate-accept-as-entered, then re-submit
        ├─ Pick a suggestion (ambiguous) → re-submit with the picked match
        └─ Edit address           → re-open the form
```

The re-submission re-runs the same action and hook. On the second pass, either
the resubmitted address now matches a high-confidence Loqate result (suggestion
path) or the hook sees `acceptedAsEntered` for that basket+address and skips
Loqate (use-as-entered path). Either way the action succeeds and the shopper
advances to the shipping-options step.

### Files

```
src/extensions/loqate-address-verification/
├── README.md                                  ← you are here
├── target-config.json                         ← UITarget + actionHook registration
├── hooks/
│   └── verify-address-after-shipping.server.ts  # Action hook handler
├── lib/
│   ├── loqate-client.server.ts                # Loqate AddressVerify call + parsing
│   ├── verification-cache.server.ts           # In-memory cache, keyed by basketId
│   └── types.ts                               # Shared types (AddressInput, CachedVerification, …)
├── components/
│   ├── address-verification-modal.tsx         # Confirmation modal (status, diff, suggestions)
│   └── shipping-address-remount-wrapper.tsx   # Re-keys the form after corrections land
├── routes/
│   ├── action.loqate-fetch-verification.ts    # GET cached verification for the modal
│   └── action.loqate-accept-as-entered.ts     # Flip the accepted-as-entered flag
└── locales/
    ├── en-US/translations.json
    ├── en-GB/translations.json
    └── it-IT/translations.json
```

## Setup

### 1. Set environment variable

Add your Loqate API key as a **server-only** environment variable:

```bash
# .env (server-only, NOT prefixed with PUBLIC__)
LOQATE_API_KEY=your-loqate-api-key-here
```

⚠️ **Important**: Do NOT use the `PUBLIC__` prefix — that would expose the key to the client.

Optional override for local testing or self-hosted mocks:

```bash
LOQATE_VERIFY_URL=https://your-mock-endpoint/json6.ws
```

### 2. Configure extension

The extension is enabled by default when the API key is present. No client-side configuration needed. If `LOQATE_API_KEY` is unset, the hook silently no-ops and checkout works exactly as the unmodified storefront.

### 3. Deploy

When deploying to Commerce Cloud Managed Runtime:

```bash
# Set the environment variable in MRT Runtime Admin
LOQATE_API_KEY=your-loqate-api-key-here

pnpm build
pnpm push
```

## Usage

After setup, the extension automatically engages on the checkout shipping-address step. The shopper experience is:

1. Customer enters shipping address and clicks **Continue to Shipping Method**
2. Server saves the address to the basket and calls Loqate
3. Based on match quality:
   - **Verified, exact match** → step advances silently, no modal
   - **Verified or partially verified, with corrections** → modal shows the corrected address with a side-by-side diff and AQI / match-score badges. Shopper picks **Use Verified Address** or **Keep Original**.
   - **Multiple matches** → modal lists candidates with quality badges. Shopper picks one.
   - **Unverified** → modal shows the entered address. Shopper picks **Use Address as Entered** or **Edit Address**.
4. After a confirmation, the form re-submits, the basket is updated with the chosen address, and the shopper advances to shipping options.

## Testing

### Local development

```bash
# Set API key in .env
echo "LOQATE_API_KEY=your-key" >> .env

# Start dev server
pnpm dev
```

### Sample addresses (US)

**High confidence — exact match (no modal)**:
```
Address: 1600 Amphitheatre Parkway
City: Mountain View
State: CA
Zip: 94043
```

**Medium confidence (modal, manual confirmation)**:
```
Address: 123 main st
City: Springfield
State: IL
Zip: 62701
```

**Unverified (modal, "Use as Entered" path)**:
```
Address: asdfghjkl
City: nowhere
State: XX
Zip: 00000
```

## API reference

### Action hook handler

**Hook ID**: `sfcc.checkout.addressVerification.afterSubmitShippingAddress`
**Handler**: `hooks/verify-address-after-shipping.server.ts`

Receives `ActionHookContext<{ basket, address }>`. On any non-exact-match outcome, caches a `CachedVerification` keyed by `basketId` and throws `ActionHookError` with step `addressVerification`.

### Extension routes

#### `GET /action/loqate-fetch-verification`

Returns the cached verification for the current basket (or `null`).

```ts
// Response
{ verification: CachedVerification | null }
```

#### `POST /action/loqate-accept-as-entered`

Marks the cached verification as accepted-as-entered so the next shipping submit bypasses Loqate.

**Body** (FormData, all optional — when omitted, the existing cached `submittedAddress` is kept):

```ts
{
  address1?: string
  address2?: string
  city?: string
  stateCode?: string
  postalCode?: string
  countryCode?: string
}
```

```ts
// Response
{ success: boolean }
```

### Shared types

```ts
type LoqateConfidence = 'high' | 'medium' | 'low' | 'none';
type LoqateStatus = 'verified' | 'partiallyVerified' | 'ambiguous' | 'unverified' | 'error';
type LoqateAqi = 'A' | 'B' | 'C' | 'D' | 'E';

interface LoqateSuggestion {
  address1: string;
  address2?: string;
  city: string;
  stateCode: string;
  postalCode: string;
  countryCode: string;
  matchScore?: number;   // 0-100
  avc?: string;          // e.g. "V44-I44-P7-100"
  aqi?: LoqateAqi;
  confidence: LoqateConfidence;
  residential?: boolean;
  commercial?: boolean;
}
```

## Confidence rules

Match-score thresholds align with Loqate's published guidance:

| AVC verification level | Match score | Confidence | Treatment |
| --- | --- | --- | --- |
| `V`/`C` + level ≥ 44 | ≥ 95 | high | Pass-through if exact match; modal-confirm otherwise |
| `V`/`C` + level ≥ 33 | ≥ 80 | medium | Modal-confirm |
| `V`/`C` + lower | any | low | Modal-confirm |
| `P`/`I`/`U` or no match | any | none / unverified | Modal — edit or use-as-entered |

## Security

- ✅ API key stored server-side only (no `PUBLIC__` prefix)
- ✅ No client-side API key exposure
- ✅ All Loqate calls happen inside the action hook on the server
- ✅ The `accepted-as-entered` flag lives server-side, so a hostile client can't suppress verification by lying about it

## Troubleshooting

### Modal never opens

**Cause**: `LOQATE_API_KEY` environment variable not set, so the hook no-ops.

**Solution**: Add the key to your `.env` file or MRT environment variables and restart the dev server.

### "Use Verified Address" or "Use Address as Entered" reopens the modal

**Cause**: The cached verification key is out of sync with what the resubmit actually sends (e.g. a change in field casing or whitespace).

**Solution**: The hook compares case- and whitespace-insensitively, but if Loqate normalizes a field in a way that bypasses that comparison, file an issue with the AVC / matchscore in question. As a workaround, use **Edit Address** and re-enter.

### Form on Edit shows pre-correction values

**Cause**: The basket's shipping address didn't make it back into `BasketProvider`. Usually this means the post-correction loader revalidation didn't fire, or the wrapper's remount key didn't change.

**Solution**: Confirm `target-config.json` includes the wrapper component on `sfcc.checkout.shippingAddress`. If a different extension also wraps that target, ensure their `order` values are distinct so both wrappers run.

### API calls failing

**Cause**: Invalid API key or network issues.

**Solution**:
1. Verify the API key is correct
2. Check server logs for the detailed error message thrown by the Loqate client
3. Ensure the server can reach `api.addressy.com` (or your `LOQATE_VERIFY_URL` override)

## Implementation notes

- **Caching layer**: The verification cache lives in module memory keyed by `basketId`, with a per-entry TTL and an LRU size bound to prevent unbounded growth. This is sufficient for a single-replica dev environment but should be replaced by a shared store (Redis, basket custom property) before production use across multiple MRT replicas.
- **Form remount**: The core `<ShippingAddress>` component initializes its `react-hook-form` instance once and doesn't re-read basket values on subsequent edits. The wrapper at `sfcc.checkout.shippingAddress` works around this by re-keying the subtree on basket-address change, forcing `useForm` to re-initialize.
- **Submission attribution**: When the core action returns 400 (`step: 'addressVerification'`), the core checkout-actions hook does not push the basket update into `BasketProvider`. The extension caches the shopper's submitted address (including first/last/phone) on the server so the modal can resubmit those values without depending on stale client state.

## Resources

- [Loqate API Documentation](https://docs.loqate.com/)
- [Loqate Implementation Guide](https://docs.loqate.com/our-services/address-verify/implementation-guide)
- [AVC (Address Verification Code) Reference](https://docs.loqate.com/our-services/address-verify/avc-codes)
