/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { Route } from './+types/action.loqate-accept-as-entered';
import { ensureBasketId } from '@/middlewares/basket.server';
import {
    getCachedVerification,
    setCachedVerification,
} from '@/extensions/loqate-address-verification/lib/verification-cache.server';
import type { AddressInput } from '@/extensions/loqate-address-verification/lib/types';

/**
 * Marks the current basket's cached verification as accepted-as-entered so the
 * next shipping-address submission bypasses the modal.
 *
 * Two flows feed this route:
 *
 * 1. **"Keep original / Use as entered"** — no form fields. The cache's
 *    existing `submittedAddress` (what the shopper originally typed) is
 *    flagged. The modal then re-submits the shipping form with the same
 *    address; the hook sees the flag and skips Loqate.
 *
 * 2. **"Use Verified Address"** — the suggestion fields are POSTed. We
 *    overwrite `submittedAddress` with the suggestion and flag it. This
 *    handles the case where Loqate's own normalized form (e.g. abbreviation
 *    expansion) would otherwise re-trigger the modal in an infinite loop.
 */
export async function action({ request, context }: Route.ActionArgs) {
    const basketId = await ensureBasketId(context);
    if (!basketId) {
        return Response.json({ success: false }, { status: 400 });
    }
    const cached = getCachedVerification(basketId);
    if (!cached) {
        return Response.json({ success: true });
    }

    const formData = await request.formData();
    const overrideAddress = parseAddressFromFormData(formData);

    setCachedVerification(basketId, {
        ...cached,
        submittedAddress: overrideAddress ?? cached.submittedAddress,
        acceptedAsEntered: true,
    });
    return Response.json({ success: true });
}

function parseAddressFromFormData(fd: FormData): AddressInput | undefined {
    const address1 = fd.get('address1');
    if (typeof address1 !== 'string' || !address1) return undefined;
    return {
        address1,
        address2: (fd.get('address2') as string | null) ?? '',
        city: ((fd.get('city') as string | null) ?? '').toString(),
        stateCode: ((fd.get('stateCode') as string | null) ?? '').toString(),
        postalCode: ((fd.get('postalCode') as string | null) ?? '').toString(),
        countryCode: ((fd.get('countryCode') as string | null) ?? 'US').toString(),
    };
}
