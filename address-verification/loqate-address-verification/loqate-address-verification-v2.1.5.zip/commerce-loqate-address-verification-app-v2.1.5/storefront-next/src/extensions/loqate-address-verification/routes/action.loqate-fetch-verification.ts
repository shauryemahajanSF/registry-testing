/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { Route } from './+types/action.loqate-fetch-verification';
import { ensureBasketId } from '@/middlewares/basket.server';
import { getCachedVerification } from '@/extensions/loqate-address-verification/lib/verification-cache.server';

/**
 * Returns the cached Loqate verification result for the current basket.
 *
 * The shipping action hook stashes the latest verification keyed by basketId
 * and aborts the action with `step: 'addressVerification'` whenever shopper
 * input is needed. This route is how the modal component pulls those
 * suggestions back without re-calling Loqate.
 */
export async function loader({ context }: Route.LoaderArgs) {
    const basketId = await ensureBasketId(context);
    if (!basketId) {
        return Response.json({ verification: null });
    }
    const verification = getCachedVerification(basketId);
    return Response.json({ verification: verification ?? null });
}
