/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * Loqate Address Verification — server-side action hook.
 *
 * Registered for hook ID `sfcc.checkout.addressVerification.afterSubmitShippingAddress`
 * which fires from `submit-shipping-address.server.ts` *after* the basket has
 * been updated via SCAPI. This hook:
 *
 *   1. Calls Loqate with the address that was just saved.
 *   2. On HIGH confidence with the user's input matching a Loqate match
 *      exactly, lets the action proceed unchanged.
 *   3. On any actionable result (high with correction, medium, low,
 *      ambiguous, unverified) caches the suggestions keyed by basketId and
 *      throws ActionHookError. The core action wrapper turns this into a 400
 *      response with `{ step: 'addressVerification', error: '...' }`. The
 *      client modal fetches the cached suggestions and lets the shopper
 *      pick a suggestion, accept-as-entered, or edit and re-submit.
 *
 * Note on auto-apply: the address hook's return value is currently NOT
 * consumed by the core action (only the methods hook reads `result.data`).
 * That means a hook returning a corrected basket would race against the
 * pre-correction basket the action already captured, producing a flash of
 * stale UI. Until the framework honors the address hook's return, we route
 * all corrections through the modal for visual correctness. Swapping in
 * silent auto-apply once the framework supports it is a one-line change
 * here plus a small core change to consume `result.data.basket`.
 *
 * Reads from environment:
 *  - `LOQATE_API_KEY` (required to enable verification — without it the hook
 *    no-ops and the shipping flow continues unchanged).
 */

import type { ActionFunctionArgs } from 'react-router';
import type { ShopperBasketsV2 } from '@salesforce/storefront-next-runtime/scapi';
import { ActionHookError, type ActionHookContext } from '@/targets/action-hook.server';
import { getLogger } from '@/lib/logger.server';
import { verifyAddressWithLoqate } from '../lib/loqate-client.server';
import {
    setCachedVerification,
    getCachedVerification,
    clearCachedVerification,
} from '../lib/verification-cache.server';
import type { AddressInput } from '../lib/types';

interface ShippingHookData {
    basket: ShopperBasketsV2.schemas['Basket'];
    address: AddressInput & {
        firstName?: string;
        lastName?: string;
        phone?: string;
    };
}

const HOOK_ID = 'sfcc.checkout.addressVerification.afterSubmitShippingAddress';
const STEP = 'addressVerification';

function normalizeField(v: string | undefined | null): string {
    return (v ?? '').trim().toUpperCase();
}

function suggestionDiffersFromSubmitted(
    submitted: { address1?: string; address2?: string; city?: string; stateCode?: string; postalCode?: string },
    suggested: { address1?: string; address2?: string; city?: string; stateCode?: string; postalCode?: string }
): boolean {
    return (
        normalizeField(submitted.address1) !== normalizeField(suggested.address1) ||
        normalizeField(submitted.address2) !== normalizeField(suggested.address2) ||
        normalizeField(submitted.city) !== normalizeField(suggested.city) ||
        normalizeField(submitted.stateCode) !== normalizeField(suggested.stateCode) ||
        normalizeField(submitted.postalCode) !== normalizeField(suggested.postalCode)
    );
}

export default async function verifyAddressAfterShipping(
    hookContext: ActionHookContext<ShippingHookData>
): Promise<ActionHookContext<ShippingHookData>> {
    const { data, actionContext } = hookContext;
    const routerContext = actionContext as ActionFunctionArgs['context'];
    const logger = getLogger(routerContext);
    const { basket, address } = data;
    const basketId = basket.basketId;

    if (!basketId) return hookContext;

    // If the user previously chose "use as entered" for this same basket+address,
    // skip re-verification.
    const prior = getCachedVerification(basketId);
    if (prior?.acceptedAsEntered && !suggestionDiffersFromSubmitted(prior.submittedAddress, address)) {
        return hookContext;
    }

    let result;
    try {
        result = await verifyAddressWithLoqate(address);
    } catch (error) {
        // Non-blocking hook — log and let the action continue.
        logger.error('[loqate] verifyAddressWithLoqate failed', { error });
        return hookContext;
    }

    // No API key configured: graceful no-op (e.g. local dev without a key).
    if (!result) return hookContext;

    const submittedAddress: AddressInput = {
        address1: address.address1,
        address2: address.address2 || '',
        city: address.city,
        stateCode: address.stateCode,
        postalCode: address.postalCode,
        countryCode: address.countryCode || 'US',
    };

    const top = result.suggestions[0];

    // High-confidence exact match: nothing to do, clear any stale cache.
    if (
        result.status === 'verified' &&
        top &&
        top.confidence === 'high' &&
        !suggestionDiffersFromSubmitted(submittedAddress, top)
    ) {
        clearCachedVerification(basketId);
        logger.info('[loqate] address verified exactly — proceeding', { basketId });
        return hookContext;
    }

    // Anything else needs the shopper. Cache and throw to abort the action with
    // a structured error the UI can react to.
    setCachedVerification(basketId, {
        submittedAddress,
        submittedFirstName: address.firstName,
        submittedLastName: address.lastName,
        submittedPhone: address.phone,
        suggestion: top,
        suggestions: result.suggestions,
        status: result.status,
        createdAt: Date.now(),
    });

    // The basket was updated by the core action with the user's entered address
    // before this hook ran. We still abort the action so the client doesn't
    // advance to the shipping-options step. The basket is left as-is — the
    // shopper can either accept it as-entered, pick a suggestion, or edit.
    const message =
        result.status === 'ambiguous'
            ? 'Multiple address matches were found. Please confirm your shipping address.'
            : result.status === 'unverified'
              ? "We couldn't verify your shipping address. Please review."
              : 'Please confirm your shipping address.';

    throw new ActionHookError(message, HOOK_ID, STEP);
}
