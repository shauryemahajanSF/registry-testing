/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import type { CachedVerification } from './types';

/**
 * In-memory verification cache keyed by basketId.
 *
 * Trade-off: module-scoped, not shared across MRT replicas. Production
 * usage would persist in Redis or as a basket custom property.
 *
 * Eviction: per-entry TTL on read, plus an LRU bound on total size. Map's
 * insertion order is converted to LRU by delete-and-reset on read/write.
 */
const TTL_MS = 5 * 60 * 1000;
const MAX_CACHE_SIZE = 1000;
const cache = new Map<string, CachedVerification>();

export function setCachedVerification(basketId: string, value: CachedVerification): void {
    if (cache.has(basketId)) {
        cache.delete(basketId);
    } else if (cache.size >= MAX_CACHE_SIZE) {
        const oldest = cache.keys().next().value;
        if (oldest !== undefined) cache.delete(oldest);
    }
    cache.set(basketId, value);
}

export function getCachedVerification(basketId: string): CachedVerification | undefined {
    const entry = cache.get(basketId);
    if (!entry) return undefined;
    if (Date.now() - entry.createdAt > TTL_MS) {
        cache.delete(basketId);
        return undefined;
    }
    cache.delete(basketId);
    cache.set(basketId, entry);
    return entry;
}

export function clearCachedVerification(basketId: string): void {
    cache.delete(basketId);
}
