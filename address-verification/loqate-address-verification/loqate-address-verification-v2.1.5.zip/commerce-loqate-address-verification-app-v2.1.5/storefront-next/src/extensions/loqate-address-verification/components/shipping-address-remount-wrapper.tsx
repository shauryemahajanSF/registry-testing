/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { Fragment, type ReactNode } from 'react';
import { useBasket } from '@/providers/basket';

interface Props {
    children: ReactNode;
}

/**
 * Force-remount wrapper for the core `<ShippingAddress>` component.
 *
 * The core form uses `react-hook-form`'s `useForm({ defaultValues })`, which
 * only consumes `defaultValues` on mount. The component itself stays mounted
 * across edit/summary toggles (only its DOM is conditionally rendered by
 * `ToggleCardEdit`), so `useForm` is initialized once with whatever the
 * basket held at first render. When this extension applies a corrected
 * shipping address, the basket updates but the form state doesn't — Edit
 * shows the pre-correction address.
 *
 * Fixing that without modifying core would require calling `form.reset()`
 * inside `<ShippingAddress>`. Since the form instance isn't exposed, we
 * instead change the React `key` on the entire subtree whenever the basket's
 * shipping address changes. React unmounts and remounts `<ShippingAddress>`,
 * which causes `useForm` to re-initialize from the now-corrected basket.
 */
export default function ShippingAddressRemountWrapper({ children }: Props) {
    const basket = useBasket();
    const addr = basket?.shipments?.[0]?.shippingAddress;
    const remountKey = [
        addr?.address1 ?? '',
        addr?.address2 ?? '',
        addr?.city ?? '',
        addr?.stateCode ?? '',
        addr?.postalCode ?? '',
        addr?.countryCode ?? '',
    ].join('|');

    return <Fragment key={remountKey}>{children}</Fragment>;
}
