/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { useEffect, useRef, useState, type ReactElement } from 'react';
import { useFetcher } from 'react-router';
import { useTranslation } from 'react-i18next';
import { AlertTriangle, CheckCircle2, Loader2, MapPin, XCircle } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from '@/components/ui/dialog';
import { useBasket } from '@/providers/basket';
import { useCheckoutContext } from '@/hooks/use-checkout';
import { CHECKOUT_STEPS } from '@/components/checkout/utils/checkout-context-types';
import type { AddressInput, CachedVerification, LoqateConfidence, LoqateStatus, LoqateSuggestion } from '../lib/types';

const FETCH_ROUTE = '/action/loqate-fetch-verification';
const ACCEPT_ROUTE = '/action/loqate-accept-as-entered';
const SHIPPING_FORM_KEY = 'shipping-address-form';

interface FetchData {
    verification: CachedVerification | null;
}

interface ShippingFormData {
    success?: boolean;
    error?: string;
    step?: string;
}

interface ResubmitAddress {
    firstName?: string;
    lastName?: string;
    address1?: string;
    address2?: string;
    city?: string;
    stateCode?: string;
    postalCode?: string;
    countryCode?: string;
    phone?: string;
}

type AlertVariant = 'default' | 'destructive';
type BadgeVariant = 'default' | 'secondary' | 'outline' | 'destructive' | 'success' | 'warning' | 'info';

const STATUS_VISUALS: Record<
    LoqateStatus,
    { Icon: typeof CheckCircle2; alertVariant: AlertVariant; aqiBadge: BadgeVariant }
> = {
    verified: { Icon: CheckCircle2, alertVariant: 'default', aqiBadge: 'success' },
    partiallyVerified: { Icon: AlertTriangle, alertVariant: 'default', aqiBadge: 'warning' },
    ambiguous: { Icon: AlertTriangle, alertVariant: 'default', aqiBadge: 'warning' },
    unverified: { Icon: XCircle, alertVariant: 'destructive', aqiBadge: 'destructive' },
    error: { Icon: XCircle, alertVariant: 'destructive', aqiBadge: 'destructive' },
};

function formatAddressLines(addr: AddressInput | LoqateSuggestion): string[] {
    const street = [addr.address1, addr.address2].filter(Boolean).join(', ');
    const locality = [addr.city, addr.stateCode, addr.postalCode].filter(Boolean).join(', ');
    return [street, locality].filter(Boolean);
}

function addressesEqual(a: AddressInput | LoqateSuggestion, b: AddressInput | LoqateSuggestion) {
    return (
        (a.address1 || '') === (b.address1 || '') &&
        (a.address2 || '') === (b.address2 || '') &&
        (a.city || '') === (b.city || '') &&
        (a.stateCode || '') === (b.stateCode || '') &&
        (a.postalCode || '') === (b.postalCode || '')
    );
}

interface VerificationStatusBlockProps {
    status: LoqateStatus;
    suggestion: LoqateSuggestion | undefined;
    submitted: AddressInput | undefined;
    error?: string;
}

/** Mirrors the original POC's `VerificationStatus` component. */
function VerificationStatusBlock({ status, suggestion, submitted, error }: VerificationStatusBlockProps): ReactElement {
    const { t } = useTranslation('extLoqateAddressVerification');
    const visuals = STATUS_VISUALS[status];
    const StatusIcon = visuals.Icon;

    const confidence = suggestion?.confidence;
    const aqi = suggestion?.aqi;
    const matchScore = suggestion?.matchScore;
    const isVerified = status === 'verified' || status === 'partiallyVerified';
    const hasCorrections = isVerified && submitted && suggestion && !addressesEqual(submitted, suggestion);

    const fallbackDescKey = `loqateAddressVerification.status.${status}.description`;
    const descriptionKey =
        confidence === 'medium'
            ? 'loqateAddressVerification.confidence.medium'
            : confidence === 'low'
              ? 'loqateAddressVerification.confidence.low'
              : fallbackDescKey;

    return (
        <Alert variant={visuals.alertVariant} className="mb-3">
            <StatusIcon />
            <AlertTitle className="flex flex-wrap items-center gap-2">
                {t(
                    `loqateAddressVerification.status.${status}.title` as 'loqateAddressVerification.status.verified.title'
                )}
                {aqi && (
                    <Badge variant={visuals.aqiBadge} className="text-[10px] leading-none">
                        {t(`loqateAddressVerification.aqi.${aqi}` as 'loqateAddressVerification.aqi.A')}
                    </Badge>
                )}
                {matchScore != null && matchScore > 0 && (
                    <Badge variant="outline" className="text-[10px] leading-none">
                        {matchScore}%
                    </Badge>
                )}
            </AlertTitle>
            <AlertDescription>
                <p>{error || t(descriptionKey as 'loqateAddressVerification.status.verified.description')}</p>

                {hasCorrections && submitted && suggestion ? (
                    <div className="mt-2 grid grid-cols-2 gap-2 text-sm">
                        <div className="rounded-md bg-muted/50 px-3 py-2">
                            <p className="mb-1 text-xs font-medium text-muted-foreground">
                                {t('loqateAddressVerification.comparison.original')}
                            </p>
                            {formatAddressLines(submitted).map((line) => (
                                <p key={`orig-${line}`} className="text-muted-foreground line-through">
                                    {line}
                                </p>
                            ))}
                        </div>
                        <div className="rounded-md bg-muted/50 px-3 py-2">
                            <p className="mb-1 text-xs font-medium text-muted-foreground">
                                {t('loqateAddressVerification.comparison.corrected')}
                            </p>
                            {formatAddressLines(suggestion).map((line) => (
                                <p key={`corr-${line}`} className="font-medium text-foreground">
                                    {line}
                                </p>
                            ))}
                        </div>
                    </div>
                ) : null}

                {isVerified && !hasCorrections && suggestion ? (
                    <div className="mt-2 rounded-md bg-muted/50 px-3 py-2 text-sm">
                        <p className="mb-1 text-xs font-medium text-muted-foreground">
                            {t('loqateAddressVerification.message.suggestedAddress')}
                        </p>
                        {formatAddressLines(suggestion).map((line) => (
                            <p key={`single-${line}`} className="font-medium text-foreground">
                                {line}
                            </p>
                        ))}
                    </div>
                ) : null}

                {isVerified && suggestion ? (
                    <div className="mt-2 flex flex-wrap gap-1.5">
                        {suggestion.residential ? (
                            <Badge variant="secondary">{t('loqateAddressVerification.metadata.residential')}</Badge>
                        ) : null}
                        {suggestion.commercial ? (
                            <Badge variant="secondary">{t('loqateAddressVerification.metadata.commercial')}</Badge>
                        ) : null}
                    </div>
                ) : null}
            </AlertDescription>
        </Alert>
    );
}

interface AddressSuggestionsBlockProps {
    suggestions: LoqateSuggestion[];
    onSelect: (suggestion: LoqateSuggestion) => void;
    onCancel: () => void;
    disabled?: boolean;
}

/** Mirrors the original POC's `AddressSuggestions` component. */
function AddressSuggestionsBlock({
    suggestions,
    onSelect,
    onCancel,
    disabled,
}: AddressSuggestionsBlockProps): ReactElement {
    const { t } = useTranslation('extLoqateAddressVerification');
    const formatAddress = (s: LoqateSuggestion) =>
        [s.address1, s.address2, s.city, s.stateCode, s.postalCode].filter(Boolean).join(', ');

    return (
        <div className="mb-2 rounded-lg border bg-card p-3">
            <p className="mb-1 text-sm font-medium">{t('loqateAddressVerification.status.ambiguous.title')}</p>
            <p className="mb-2 text-xs text-muted-foreground">
                {t('loqateAddressVerification.message.selectSuggestion')}
            </p>

            <ul className="space-y-1">
                {suggestions.map((suggestion) => (
                    <li
                        key={`${suggestion.address1}|${suggestion.address2 ?? ''}|${suggestion.city}|${suggestion.stateCode}|${suggestion.postalCode}`}>
                        <button
                            type="button"
                            disabled={disabled}
                            onClick={() => onSelect(suggestion)}
                            className="flex w-full items-center justify-between rounded-md px-3 py-2 text-left text-sm hover:bg-accent disabled:cursor-not-allowed disabled:opacity-60">
                            <span>{formatAddress(suggestion)}</span>
                            <span className="ml-2 flex shrink-0 gap-1">
                                {suggestion.residential ? (
                                    <Badge variant="secondary">
                                        {t('loqateAddressVerification.metadata.residential')}
                                    </Badge>
                                ) : null}
                                {suggestion.commercial ? (
                                    <Badge variant="secondary">
                                        {t('loqateAddressVerification.metadata.commercial')}
                                    </Badge>
                                ) : null}
                            </span>
                        </button>
                    </li>
                ))}
            </ul>

            <div className="mt-2">
                <Button type="button" variant="ghost" size="sm" onClick={onCancel} disabled={disabled}>
                    {t('loqateAddressVerification.button.cancel')}
                </Button>
            </div>
        </div>
    );
}

/**
 * AddressVerificationModal — drops into `sfcc.checkout.shippingAddress.after`.
 *
 * Visually matches the previous POC ([PR #1399](https://github.com/commerce-emu/storefront-next/pull/1399)):
 * the same Alert-with-diff `VerificationStatus` block, the same
 * `AddressSuggestions` list for ambiguous matches, and the same button sets
 * per status (Keep Original + Use Verified Address for medium/low confidence;
 * Edit Address + Use Address as Entered for unverified/error). The data
 * pipeline is different — server-side action hook + cache instead of a
 * client-side fetcher — but the shopper-facing UI is the same.
 */
function deriveDisplayStatus(verification: CachedVerification | null): LoqateStatus {
    if (!verification) return 'error';
    const confidence = verification.suggestion?.confidence;
    // Match the original POC: a partiallyVerified result with no real
    // confidence collapses to "unverified" so messaging is unambiguous.
    if (verification.status === 'partiallyVerified' && confidence === 'none') return 'unverified';
    return verification.status;
}

export default function AddressVerificationModal() {
    const { t } = useTranslation('extLoqateAddressVerification');
    const basket = useBasket();
    const { goToStep } = useCheckoutContext();

    const shippingFormFetcher = useFetcher<ShippingFormData>({ key: SHIPPING_FORM_KEY });
    const fetchVerification = useFetcher<FetchData>({ key: 'loqate-fetch-verification' });
    const acceptFetcher = useFetcher<{ success: boolean }>({ key: 'loqate-accept-as-entered' });

    const [open, setOpen] = useState(false);
    const [verification, setVerification] = useState<CachedVerification | null>(null);
    const pendingResubmitAddrRef = useRef<ResubmitAddress | null>(null);
    const acceptFetcherSeenRef = useRef<unknown>(null);
    const lastHandledData = useRef<unknown>(null);

    const shippingAddress = basket?.shipments?.[0]?.shippingAddress;

    useEffect(() => {
        const data = shippingFormFetcher.data;
        if (!data || lastHandledData.current === data) return;
        if (shippingFormFetcher.state !== 'idle') return;

        if (data.success === false && data.step === 'addressVerification') {
            lastHandledData.current = data;
            void fetchVerification.load(FETCH_ROUTE);
            setOpen(true);
        } else if (data.success) {
            lastHandledData.current = data;
            setOpen(false);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps -- fetchVerification is a new ref each render
    }, [shippingFormFetcher.data, shippingFormFetcher.state]);

    useEffect(() => {
        if (fetchVerification.data && fetchVerification.state === 'idle') {
            setVerification(fetchVerification.data.verification);
        }
    }, [fetchVerification.data, fetchVerification.state]);

    // After the accept-as-entered server route flips the cache flag, resubmit
    // the shipping form with whichever address the shopper confirmed (their
    // original or the Loqate suggestion). The hook will see the flag and skip.
    useEffect(() => {
        if (!pendingResubmitAddrRef.current) return;
        if (acceptFetcher.state !== 'idle' || !acceptFetcher.data?.success) return;
        if (acceptFetcherSeenRef.current === acceptFetcher.data) return;
        acceptFetcherSeenRef.current = acceptFetcher.data;
        const addr = pendingResubmitAddrRef.current;
        pendingResubmitAddrRef.current = null;
        resubmitShippingForm(addr);
    }, [acceptFetcher.state, acceptFetcher.data]); // eslint-disable-line react-hooks/exhaustive-deps

    function resubmitShippingForm(addr: ResubmitAddress) {
        const fd = new FormData();
        fd.append('intent', 'shippingAddress');
        fd.append('firstName', addr.firstName || shippingAddress?.firstName || '');
        fd.append('lastName', addr.lastName || shippingAddress?.lastName || '');
        fd.append('address1', addr.address1 || '');
        if (addr.address2) fd.append('address2', addr.address2);
        fd.append('city', addr.city || '');
        fd.append('stateCode', addr.stateCode || '');
        fd.append('postalCode', addr.postalCode || '');
        fd.append('countryCode', addr.countryCode || 'US');
        if (addr.phone || shippingAddress?.phone) fd.append('phone', addr.phone || shippingAddress?.phone || '');
        void shippingFormFetcher.submit(fd, { method: 'post' });
        setOpen(false);
    }

    /**
     * Pre-flag the cache with the address the shopper just confirmed, then
     * resubmit the shipping form. The hook sees `acceptedAsEntered === true`
     * for this exact address and skips Loqate, so the action succeeds and the
     * step advances. Without the pre-flag, Loqate's response could differ
     * slightly from the suggestion we sent (different casing, expanded
     * abbreviations) and re-trigger the modal in a loop.
     */
    function flagAndResubmit(addr: ResubmitAddress) {
        pendingResubmitAddrRef.current = addr;
        const fd = new FormData();
        if (addr.address1) fd.append('address1', addr.address1);
        if (addr.address2) fd.append('address2', addr.address2);
        if (addr.city) fd.append('city', addr.city);
        if (addr.stateCode) fd.append('stateCode', addr.stateCode);
        if (addr.postalCode) fd.append('postalCode', addr.postalCode);
        if (addr.countryCode) fd.append('countryCode', addr.countryCode);
        void acceptFetcher.submit(fd, { method: 'post', action: ACCEPT_ROUTE });
    }

    const suggestionToAddr = (s: LoqateSuggestion): ResubmitAddress => ({
        // Personal fields come from the verification cache (the address
        // hook saved what the shopper just submitted). `useBasket()` reflects
        // the *previous* basket here, since the action errored.
        firstName: verification?.submittedFirstName ?? shippingAddress?.firstName,
        lastName: verification?.submittedLastName ?? shippingAddress?.lastName,
        address1: s.address1,
        address2: s.address2,
        city: s.city,
        stateCode: s.stateCode,
        postalCode: s.postalCode,
        countryCode: s.countryCode || 'US',
        phone: verification?.submittedPhone ?? shippingAddress?.phone,
    });

    const handleApplyAddress = () => {
        const top = verification?.suggestion;
        if (!top) return;
        flagAndResubmit(suggestionToAddr(top));
    };

    const handleSelectSuggestion = (suggestion: LoqateSuggestion) => {
        flagAndResubmit(suggestionToAddr(suggestion));
    };

    const handleClose = () => {
        // "Keep original / Use as entered" — resubmit with the address the
        // shopper actually typed. We pull everything from the verification
        // cache (the action hook stored it under the basketId) rather than
        // from `useBasket()`, because BasketProvider holds the *previous*
        // basket: the first submit returned a 400 (`step: 'addressVerification'`),
        // and `useCheckoutActions` only pushes basket updates into the
        // provider on success. Using `useBasket()` here would wipe the
        // shopper's entry.
        const submitted = verification?.submittedAddress;
        if (!submitted) return;
        flagAndResubmit({
            firstName: verification?.submittedFirstName ?? shippingAddress?.firstName,
            lastName: verification?.submittedLastName ?? shippingAddress?.lastName,
            address1: submitted.address1,
            address2: submitted.address2,
            city: submitted.city,
            stateCode: submitted.stateCode,
            postalCode: submitted.postalCode,
            countryCode: submitted.countryCode || 'US',
            phone: verification?.submittedPhone ?? shippingAddress?.phone,
        });
    };

    const handleContinueAsEntered = () => {
        handleClose();
    };

    const handleEditAddress = () => {
        setOpen(false);
        goToStep(CHECKOUT_STEPS.SHIPPING_ADDRESS);
    };

    if (!open) return null;

    const isLoading = fetchVerification.state !== 'idle' && !verification;
    const isApplying = shippingFormFetcher.state !== 'idle' || acceptFetcher.state !== 'idle';
    const displayStatus = deriveDisplayStatus(verification);
    const suggestions = verification?.suggestions ?? [];
    const submitted = verification?.submittedAddress;
    const top = verification?.suggestion;
    const confidence: LoqateConfidence | undefined = top?.confidence;

    const showResults =
        displayStatus === 'verified' ||
        displayStatus === 'partiallyVerified' ||
        displayStatus === 'unverified' ||
        displayStatus === 'error';
    // Show "Use Verified Address" whenever Loqate produced a usable correction.
    // The original POC silently auto-applied high+corrections; we surface it
    // because the address hook's return value isn't currently propagated to
    // the action response — see hook JSDoc.
    const canApply = !!top && confidence !== 'none' && !!submitted && !addressesEqual(submitted, top);
    const isAmbiguous = displayStatus === 'ambiguous' && suggestions.length > 0;

    return (
        <Dialog
            open={open}
            onOpenChange={(next) => {
                if (!next) handleClose();
            }}>
            <DialogContent showCloseButton={!isApplying}>
                <DialogHeader>
                    <DialogTitle>{t('loqateAddressVerification.modal.title')}</DialogTitle>
                    <DialogDescription>{t('loqateAddressVerification.modal.description')}</DialogDescription>
                </DialogHeader>

                <div className="py-2">
                    {isLoading ? (
                        <div className="flex flex-col items-center gap-3 py-6">
                            <Loader2 className="size-8 animate-spin text-muted-foreground" />
                            <p className="text-sm text-muted-foreground">
                                {t('loqateAddressVerification.message.verifying')}
                            </p>
                        </div>
                    ) : null}

                    {!isLoading && showResults ? (
                        <VerificationStatusBlock
                            status={displayStatus}
                            suggestion={confidence !== 'none' ? top : undefined}
                            submitted={submitted}
                        />
                    ) : null}

                    {!isLoading && isAmbiguous ? (
                        <AddressSuggestionsBlock
                            suggestions={suggestions}
                            onSelect={handleSelectSuggestion}
                            onCancel={handleClose}
                            disabled={isApplying}
                        />
                    ) : null}
                </div>

                {!isLoading && (canApply || showResults) ? (
                    <DialogFooter>
                        {canApply ? (
                            <>
                                <Button type="button" variant="outline" onClick={handleClose} disabled={isApplying}>
                                    {t('loqateAddressVerification.button.keepOriginal')}
                                </Button>
                                <Button type="button" onClick={handleApplyAddress} disabled={isApplying}>
                                    {isApplying ? <Loader2 className="animate-spin" /> : <MapPin />}
                                    {t('loqateAddressVerification.button.applyAddress')}
                                </Button>
                            </>
                        ) : displayStatus === 'unverified' || displayStatus === 'error' ? (
                            <>
                                <Button
                                    type="button"
                                    variant="outline"
                                    onClick={handleEditAddress}
                                    disabled={isApplying}>
                                    {t('loqateAddressVerification.button.editAddress')}
                                </Button>
                                <Button type="button" onClick={handleContinueAsEntered} disabled={isApplying}>
                                    {isApplying ? <Loader2 className="mr-2 animate-spin" /> : null}
                                    {t('loqateAddressVerification.button.continueAsEntered')}
                                </Button>
                            </>
                        ) : null}
                    </DialogFooter>
                ) : null}
            </DialogContent>
        </Dialog>
    );
}
