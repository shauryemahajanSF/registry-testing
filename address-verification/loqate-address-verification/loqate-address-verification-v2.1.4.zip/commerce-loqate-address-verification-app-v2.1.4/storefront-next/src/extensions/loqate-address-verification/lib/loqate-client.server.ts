/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import type { AddressInput, LoqateAqi, LoqateConfidence, LoqateStatus, LoqateSuggestion } from './types';

/**
 * Server-side Loqate AddressVerify client.
 *
 * Reads from environment:
 *  - `LOQATE_API_KEY` (required) — Loqate AddressVerify API key. Server-only;
 *    do NOT prefix with `PUBLIC__`.
 *  - `LOQATE_VERIFY_URL` (optional) — endpoint override for testing /
 *    self-hosted mocks.
 *
 * Returns `null` when no API key is set so the action hook can no-op
 * (graceful degradation in dev).
 *
 * The response shape is `[{ Matches: [...] }]` — a one-element array whose
 * first item carries the matches array. Each match exposes:
 *  - `AVC` — Address Verification Code, e.g. `V44-I44-P7-100`. Format:
 *      char 0     verification status (V/C/P/I/U)
 *      chars 1-2  match level (44=premise, 33=street, 22=locality)
 *      last seg   match score (0-100)
 *  - `AQI`  — letter-grade match quality (A/B/C/D/E)
 *  - `RDI`  — Residential Delivery Indicator (`R`/`C`)
 *  - delivery-line fields (`DeliveryAddress1`, etc.) — preferred over the
 *    raw `Address1` because they reflect Loqate's normalized form.
 */

const DEFAULT_ENDPOINT = 'https://api.addressy.com/Cleansing/International/Batch/v1.20/json6.ws';

interface LoqateRawMatch {
    AVC?: string;
    AQI?: string;
    RDI?: 'R' | 'C' | string;
    /**
     * Formatted printing lines — Loqate splits the address for postal labels.
     * Used as a last-resort fallback because for US delivery points
     * `Address1` / `DeliveryAddress1` often contain the *entire* delivery
     * line ("123 MAIN ST APT 4B") instead of just the street.
     */
    Address1?: string;
    Address2?: string;
    DeliveryAddress1?: string;
    DeliveryAddress2?: string;
    /** Granular components — preferred for populating address1 / address2. */
    Premise?: string;
    SubBuilding?: string;
    Thoroughfare?: string;
    Locality?: string;
    AdministrativeArea?: string;
    PostalCode?: string;
    CountryISO2?: string;
    Country?: string;
}

interface LoqateRawResponseItem {
    Matches?: LoqateRawMatch[];
}

export interface LoqateVerifyResult {
    status: LoqateStatus;
    suggestions: LoqateSuggestion[];
}

const AQI_RANK: Record<string, number> = { A: 5, B: 4, C: 3, D: 2, E: 1 };

interface ParsedAvc {
    verificationChar: string;
    matchLevel: number;
    matchScore: number;
}

function parseAvc(avc: string | undefined): ParsedAvc {
    if (!avc) return { verificationChar: '', matchLevel: 0, matchScore: 0 };
    const verificationChar = avc.charAt(0).toUpperCase();
    const matchLevel = parseInt(avc.substring(1, 3), 10) || 0;
    const segments = avc.split('-');
    const matchScore = parseInt(segments[segments.length - 1], 10) || 0;
    return { verificationChar, matchLevel, matchScore };
}

function deriveConfidence({ verificationChar, matchLevel, matchScore }: ParsedAvc): LoqateConfidence {
    // V = Verified, C = Corrected — both authoritative.
    // P = Partial, I = Interaction required, U = Unverified — not authoritative.
    if (verificationChar !== 'V' && verificationChar !== 'C') return 'none';
    if (matchLevel >= 44 && matchScore >= 95) return 'high';
    if (matchLevel >= 33 && matchScore >= 80) return 'medium';
    return 'low';
}

function deriveMatchStatus(verificationChar: string): LoqateStatus {
    if (verificationChar === 'V' || verificationChar === 'C') return 'verified';
    if (verificationChar === 'P' || verificationChar === 'I') return 'partiallyVerified';
    return 'unverified';
}

function normalizeAqi(raw: string | undefined): LoqateAqi | undefined {
    if (!raw) return undefined;
    const letter = raw.charAt(0).toUpperCase();
    return ['A', 'B', 'C', 'D', 'E'].includes(letter) ? (letter as LoqateAqi) : undefined;
}

/**
 * Build the street + unit lines from Loqate's granular components.
 *
 * Loqate's flat fields (`DeliveryAddress1`, `Address1`) often pack everything
 * into one string — e.g. `"123 MAIN ST APT 4B"` — which would dump into the
 * shopper's address1 and leave address2 empty. The granular components
 * (`Premise`, `Thoroughfare`, `SubBuilding`) let us split that cleanly:
 *   - address1 = `<Premise> <Thoroughfare>` ("123 Main Street")
 *   - address2 = `<SubBuilding>` ("Apt 4B")
 *
 * Falls back to the flat `Address1`/`Address2` fields when the granular
 * components aren't returned (some country/match-level combinations).
 */
function deriveAddressLines(match: LoqateRawMatch): { address1: string; address2: string } {
    const premise = (match.Premise || '').trim();
    const thoroughfare = (match.Thoroughfare || '').trim();
    const subBuilding = (match.SubBuilding || '').trim();

    if (premise || thoroughfare) {
        const address1 = [premise, thoroughfare].filter(Boolean).join(' ');
        const address2 = subBuilding;
        return { address1, address2 };
    }
    return {
        address1: (match.DeliveryAddress1 || match.Address1 || '').trim(),
        address2: (match.DeliveryAddress2 || match.Address2 || '').trim(),
    };
}

function normalizeMatch(match: LoqateRawMatch): LoqateSuggestion {
    const parsed = parseAvc(match.AVC);
    const { address1, address2 } = deriveAddressLines(match);
    return {
        address1,
        address2,
        city: match.Locality ?? '',
        stateCode: match.AdministrativeArea ?? '',
        postalCode: match.PostalCode ?? '',
        countryCode: match.CountryISO2 || match.Country || 'US',
        avc: match.AVC,
        aqi: normalizeAqi(match.AQI),
        matchScore: parsed.matchScore || undefined,
        confidence: deriveConfidence(parsed),
        residential: match.RDI === 'R',
        commercial: match.RDI === 'C',
    };
}

function deriveStatusForResult(matches: LoqateRawMatch[], suggestions: LoqateSuggestion[]): LoqateStatus {
    if (suggestions.length === 0) return 'unverified';
    if (suggestions.length > 1) return 'ambiguous';
    const top = matches[0];
    return deriveMatchStatus(parseAvc(top.AVC).verificationChar);
}

export async function verifyAddressWithLoqate(address: AddressInput): Promise<LoqateVerifyResult | null> {
    const apiKey = process.env.LOQATE_API_KEY;
    if (!apiKey) return null;
    const endpoint = process.env.LOQATE_VERIFY_URL || DEFAULT_ENDPOINT;

    const body = {
        Key: apiKey,
        Addresses: [
            {
                Address1: address.address1,
                Address2: address.address2 || '',
                Locality: address.city,
                AdministrativeArea: address.stateCode,
                PostalCode: address.postalCode,
                Country: address.countryCode || 'US',
            },
        ],
        Geocode: false,
    };

    const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
    });

    if (!response.ok) {
        throw new Error(`Loqate verify failed: ${response.status} ${response.statusText}`);
    }

    // v1.20 returns a one-element array; the actual matches live in the first
    // entry's `Matches` field.
    const raw = (await response.json()) as LoqateRawResponseItem[] | LoqateRawResponseItem;
    const first = Array.isArray(raw) ? raw[0] : raw;
    const matches = first?.Matches ?? [];
    if (matches.length === 0) {
        return { status: 'unverified', suggestions: [] };
    }

    // Sort by AQI so the best match is at index 0 (matches the original POC).
    const sortedMatches = [...matches].sort((a, b) => (AQI_RANK[b.AQI ?? ''] ?? 0) - (AQI_RANK[a.AQI ?? ''] ?? 0));
    const suggestions = sortedMatches.map(normalizeMatch);
    return { status: deriveStatusForResult(sortedMatches, suggestions), suggestions };
}
