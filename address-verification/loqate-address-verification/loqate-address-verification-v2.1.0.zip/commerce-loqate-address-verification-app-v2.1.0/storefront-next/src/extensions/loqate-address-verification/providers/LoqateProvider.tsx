/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
'use client';

import { createContext, useContext, useState, useCallback, type ReactNode, type ReactElement } from 'react';
import type { VerifiedAddress } from '../hooks/useLoqateVerification';

export interface LoqateConfig {
    enabled: boolean;
    cacheTTL: number;
}

export interface LoqateContextType {
    config: LoqateConfig;
    verifiedAddresses: Map<string, VerifiedAddress>;
    cacheVerifiedAddress: (addressKey: string, address: VerifiedAddress) => void;
    getVerifiedAddress: (addressKey: string) => VerifiedAddress | null;
    clearCache: () => void;
}

const LoqateContext = createContext<LoqateContextType | undefined>(undefined);

export interface LoqateProviderProps {
    children: ReactNode;
}

const CACHE_TTL = 15 * 60 * 1000; // 15 minutes

/**
 * Context provider for Loqate Address Verification
 * Manages verified address cache (API key is server-only via LOQATE_API_KEY env var)
 */
function LoqateProvider({ children }: LoqateProviderProps): ReactElement {
    const [verifiedAddresses] = useState<Map<string, VerifiedAddress>>(new Map());

    const config: LoqateConfig = {
        // API key is now server-only (via LOQATE_API_KEY environment variable)
        // Client-side can always attempt verification; server validates availability
        enabled: true,
        cacheTTL: CACHE_TTL,
    };

    /**
     * Cache a verified address with TTL
     */
    const cacheVerifiedAddress = useCallback(
        (addressKey: string, address: VerifiedAddress) => {
            verifiedAddresses.set(addressKey, address);
        },
        [verifiedAddresses]
    );

    /**
     * Retrieve verified address from cache if still valid
     */
    const getVerifiedAddress = useCallback(
        (addressKey: string): VerifiedAddress | null => {
            const cached = verifiedAddresses.get(addressKey);
            if (!cached) return null;

            const age = Date.now() - cached.timestamp;
            if (age > CACHE_TTL) {
                verifiedAddresses.delete(addressKey);
                return null;
            }

            return cached;
        },
        [verifiedAddresses]
    );

    /**
     * Clear all cached addresses
     */
    const clearCache = useCallback(() => {
        verifiedAddresses.clear();
    }, [verifiedAddresses]);

    const contextValue: LoqateContextType = {
        config,
        verifiedAddresses,
        cacheVerifiedAddress,
        getVerifiedAddress,
        clearCache,
    };

    return <LoqateContext.Provider value={contextValue}>{children}</LoqateContext.Provider>;
}

/**
 * Hook to access Loqate context
 */
export function useLoqateContext(): LoqateContextType {
    const context = useContext(LoqateContext);
    if (!context) {
        throw new Error('useLoqateContext must be used within LoqateProvider');
    }
    return context;
}

export default LoqateProvider;
