/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { describe, it, expect, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import VerificationStatus from '../components/VerificationStatus';
import type { VerifiedAddress } from '../hooks/useLoqateVerification';

vi.mock('react-i18next', () => ({
    useTranslation: () => ({ t: (key: string) => key }),
}));

vi.mock('lucide-react', () => ({
    CheckCircle2: ({ className }: { className?: string }) => <span data-testid="check-icon" className={className} />,
    AlertTriangle: ({ className }: { className?: string }) => <span data-testid="warning-icon" className={className} />,
    XCircle: ({ className }: { className?: string }) => <span data-testid="error-icon" className={className} />,
}));

vi.mock('@/components/ui/alert', () => ({
    Alert: ({ children, variant }: { children: React.ReactNode; variant?: string }) => (
        <div data-testid="alert" data-variant={variant}>
            {children}
        </div>
    ),
    AlertTitle: ({ children }: { children: React.ReactNode }) => <div data-testid="alert-title">{children}</div>,
    AlertDescription: ({ children }: { children: React.ReactNode }) => (
        <div data-testid="alert-description">{children}</div>
    ),
}));

vi.mock('@/components/ui/badge', () => ({
    Badge: ({ children, variant }: { children: React.ReactNode; variant?: string }) => (
        <span data-testid="badge" data-variant={variant}>
            {children}
        </span>
    ),
}));

const makeVerifiedAddress = (overrides?: Partial<VerifiedAddress>): VerifiedAddress => ({
    address1: '123 Main St',
    city: 'New York',
    stateCode: 'NY',
    postalCode: '10001',
    countryCode: 'US',
    verificationStatus: 'verified',
    confidence: 'high',
    timestamp: Date.now(),
    metadata: {
        residential: true,
        commercial: false,
        aqi: 'A',
        matchLevel: 44,
        matchScore: 100,
    },
    ...overrides,
});

describe('VerificationStatus', () => {
    it('renders verified status with correct title and description', () => {
        render(<VerificationStatus status="verified" verifiedAddress={makeVerifiedAddress()} />);

        expect(screen.getByText('loqateAddressVerification.status.verified.title')).toBeInTheDocument();
        expect(screen.getByText('loqateAddressVerification.status.verified.description')).toBeInTheDocument();
    });

    it('renders partially verified status', () => {
        render(
            <VerificationStatus
                status="partiallyVerified"
                verifiedAddress={makeVerifiedAddress({ verificationStatus: 'partiallyVerified', confidence: 'medium' })}
            />
        );

        expect(screen.getByText('loqateAddressVerification.status.partiallyVerified.title')).toBeInTheDocument();
    });

    it('renders unverified status', () => {
        render(<VerificationStatus status="unverified" />);

        expect(screen.getByText('loqateAddressVerification.status.unverified.title')).toBeInTheDocument();
    });

    it('renders error status with custom error message', () => {
        render(<VerificationStatus status="error" error="API request failed" />);

        expect(screen.getByText('loqateAddressVerification.status.error.title')).toBeInTheDocument();
        expect(screen.getByText('API request failed')).toBeInTheDocument();
    });

    it('uses destructive alert variant for unverified status', () => {
        render(<VerificationStatus status="unverified" />);

        expect(screen.getByTestId('alert')).toHaveAttribute('data-variant', 'destructive');
    });

    it('displays AQI badge when verified address has AQI', () => {
        render(<VerificationStatus status="verified" verifiedAddress={makeVerifiedAddress()} />);

        expect(screen.getByText('loqateAddressVerification.aqi.A')).toBeInTheDocument();
    });

    it('displays match score badge when verified address has a score', () => {
        render(<VerificationStatus status="verified" verifiedAddress={makeVerifiedAddress()} />);

        expect(screen.getByText('100%')).toBeInTheDocument();
    });

    it('displays residential badge when metadata indicates residential', () => {
        render(<VerificationStatus status="verified" verifiedAddress={makeVerifiedAddress()} />);

        expect(screen.getByText('loqateAddressVerification.metadata.residential')).toBeInTheDocument();
    });

    it('displays commercial badge when metadata indicates commercial', () => {
        const addr = makeVerifiedAddress({
            metadata: { residential: false, commercial: true, aqi: 'B', matchLevel: 44, matchScore: 95 },
        });
        render(<VerificationStatus status="verified" verifiedAddress={addr} />);

        expect(screen.getByText('loqateAddressVerification.metadata.commercial')).toBeInTheDocument();
    });

    it('does not display metadata badges for unverified status', () => {
        render(<VerificationStatus status="unverified" />);

        expect(screen.queryByText('loqateAddressVerification.metadata.residential')).not.toBeInTheDocument();
        expect(screen.queryByText('loqateAddressVerification.metadata.commercial')).not.toBeInTheDocument();
    });

    it('shows before/after comparison when verified address differs from original', () => {
        const original = { address1: '123 Main St', city: 'New York', stateCode: 'NY', postalCode: '10001' };
        const verified = makeVerifiedAddress({ postalCode: '10001-1234' });

        render(<VerificationStatus status="verified" verifiedAddress={verified} originalAddress={original} />);

        expect(screen.getByText('loqateAddressVerification.comparison.original')).toBeInTheDocument();
        expect(screen.getByText('loqateAddressVerification.comparison.corrected')).toBeInTheDocument();
    });

    it('shows suggested address block when verified matches original', () => {
        const original = { address1: '123 Main St', city: 'New York', stateCode: 'NY', postalCode: '10001' };
        const verified = makeVerifiedAddress({ postalCode: '10001' });

        render(<VerificationStatus status="verified" verifiedAddress={verified} originalAddress={original} />);

        expect(screen.getByText('loqateAddressVerification.message.suggestedAddress')).toBeInTheDocument();
        expect(screen.queryByText('loqateAddressVerification.comparison.original')).not.toBeInTheDocument();
    });

    it('uses medium confidence description when confidence is medium', () => {
        const verified = makeVerifiedAddress({ confidence: 'medium' });
        render(<VerificationStatus status="verified" verifiedAddress={verified} />);

        expect(screen.getByText('loqateAddressVerification.confidence.medium')).toBeInTheDocument();
    });

    it('uses low confidence description when confidence is low', () => {
        const verified = makeVerifiedAddress({ confidence: 'low' });
        render(<VerificationStatus status="verified" verifiedAddress={verified} />);

        expect(screen.getByText('loqateAddressVerification.confidence.low')).toBeInTheDocument();
    });

    it('renders nothing for idle status', () => {
        const { container } = render(<VerificationStatus status="idle" />);

        expect(container.innerHTML).toBe('');
    });
});
