/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import AddressSuggestions from '../components/AddressSuggestions';
import type { AddressSuggestion } from '../hooks/useLoqateVerification';

vi.mock('react-i18next', () => ({
    useTranslation: () => ({ t: (key: string) => key }),
}));

vi.mock('@/components/ui/badge', () => ({
    Badge: ({ children, variant }: { children: React.ReactNode; variant?: string }) => (
        <span data-testid="badge" data-variant={variant}>
            {children}
        </span>
    ),
}));

vi.mock('@/components/ui/button', () => ({
    Button: ({ children, ...props }: React.ComponentProps<'button'>) => <button {...props}>{children}</button>,
}));

const mockSuggestions: AddressSuggestion[] = [
    {
        address1: '123 Main St',
        city: 'New York',
        stateCode: 'NY',
        postalCode: '10001',
        countryCode: 'US',
        metadata: {
            residential: true,
            commercial: false,
            aqi: 'A',
            matchLevel: 44,
            matchScore: 100,
        },
    },
    {
        address1: '123 Main Street',
        address2: 'Apt 4B',
        city: 'New York',
        stateCode: 'NY',
        postalCode: '10001',
        countryCode: 'US',
        metadata: {
            residential: false,
            commercial: true,
            aqi: 'B',
            matchLevel: 33,
            matchScore: 88,
        },
    },
];

describe('AddressSuggestions', () => {
    it('renders all suggestions', () => {
        render(<AddressSuggestions suggestions={mockSuggestions} onSelect={vi.fn()} onCancel={vi.fn()} />);

        expect(screen.getByText(/123 Main St,/)).toBeInTheDocument();
        expect(screen.getByText(/123 Main Street/)).toBeInTheDocument();
    });

    it('renders the title and subtitle', () => {
        render(<AddressSuggestions suggestions={mockSuggestions} onSelect={vi.fn()} onCancel={vi.fn()} />);

        expect(screen.getByText('loqateAddressVerification.status.ambiguous.title')).toBeInTheDocument();
        expect(screen.getByText('loqateAddressVerification.message.selectSuggestion')).toBeInTheDocument();
    });

    it('calls onSelect with the correct suggestion when clicked', () => {
        const mockOnSelect = vi.fn();
        render(<AddressSuggestions suggestions={mockSuggestions} onSelect={mockOnSelect} onCancel={vi.fn()} />);

        fireEvent.click(screen.getByText(/123 Main St,/));
        expect(mockOnSelect).toHaveBeenCalledWith(mockSuggestions[0]);
    });

    it('calls onCancel when cancel button clicked', () => {
        const mockOnCancel = vi.fn();
        render(<AddressSuggestions suggestions={mockSuggestions} onSelect={vi.fn()} onCancel={mockOnCancel} />);

        fireEvent.click(screen.getByText('loqateAddressVerification.button.cancel'));
        expect(mockOnCancel).toHaveBeenCalled();
    });

    it('displays residential badge for residential addresses', () => {
        render(<AddressSuggestions suggestions={mockSuggestions} onSelect={vi.fn()} onCancel={vi.fn()} />);

        expect(screen.getByText('loqateAddressVerification.metadata.residential')).toBeInTheDocument();
    });

    it('displays commercial badge for commercial addresses', () => {
        render(<AddressSuggestions suggestions={mockSuggestions} onSelect={vi.fn()} onCancel={vi.fn()} />);

        expect(screen.getByText('loqateAddressVerification.metadata.commercial')).toBeInTheDocument();
    });

    it('handles suggestions without address2', () => {
        const singleSuggestion: AddressSuggestion[] = [
            {
                address1: '456 Oak Ave',
                city: 'Boston',
                stateCode: 'MA',
                postalCode: '02101',
                countryCode: 'US',
                metadata: { residential: false, commercial: false },
            },
        ];

        render(<AddressSuggestions suggestions={singleSuggestion} onSelect={vi.fn()} onCancel={vi.fn()} />);

        expect(screen.getByText(/456 Oak Ave/)).toBeInTheDocument();
    });
});
