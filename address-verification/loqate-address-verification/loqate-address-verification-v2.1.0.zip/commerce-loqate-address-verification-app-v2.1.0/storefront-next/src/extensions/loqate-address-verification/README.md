# Loqate Address Verification Extension

This extension provides real-time address verification using the [Loqate API](https://www.loqate.com/) during checkout.

## Features

- **Server-side API key protection**: API key is stored securely on the server and never exposed to the client
- **Real-time verification**: Validates addresses as customers enter them during checkout
- **Confidence-based handling**: Different UI treatments based on match quality
  - **High confidence** (V44 + matchscore ≥95): Auto-apply corrections
  - **Medium confidence** (matchscore 80-94): Show suggestions, require confirmation
  - **Low confidence**: Show warnings, let user decide
  - **Unverified**: Reject, ask user to re-enter
- **Address suggestions**: Multiple matches ranked by quality
- **Client-side caching**: Reduces redundant API calls

## Architecture

### Server-Side Implementation

The extension uses a **server action** to proxy address verification requests:

```
Client Component → Server Action → Loqate API
                    (/action/verify-address)
```

**Benefits:**
- ✅ API key never exposed to browser
- ✅ Prevents unauthorized usage
- ✅ Server-side request logging
- ✅ Rate limiting possible at server level

### Files

```
src/extensions/loqate-address-verification/
├── routes/
│   └── action.verify-address.ts      # Server action for API calls
├── components/
│   ├── AddressVerification.tsx       # Main verification UI
│   ├── AddressSuggestions.tsx        # Multiple match selection
│   └── VerificationStatus.tsx        # Confidence indicator
├── hooks/
│   └── useLoqateVerification.ts      # Client-side verification logic
├── providers/
│   └── LoqateProvider.tsx            # Context for caching
└── locales/                          # i18n translations
```

## Setup

### 1. Set Environment Variable

Add your Loqate API key as a **server-only** environment variable:

```bash
# .env (server-only, NOT prefixed with PUBLIC__)
LOQATE_API_KEY=your-loqate-api-key-here
```

⚠️ **Important**: Do NOT use `PUBLIC__` prefix — this would expose the key to the client.

### 2. Configure Extension

The extension is enabled by default when the API key is present. No client-side configuration needed.

### 3. Deploy

When deploying to Commerce Cloud Managed Runtime:

```bash
# Set the environment variable in MRT Runtime Admin
LOQATE_API_KEY=your-loqate-api-key-here

pnpm build
pnpm push
```

## Usage

The extension automatically appears on the checkout shipping address form when:
1. The `LOQATE_API_KEY` environment variable is set
2. A shipping address has been entered

### User Flow

1. Customer enters shipping address
2. Customer clicks "Verify Address" button
3. Server validates address via Loqate API
4. Based on match confidence:
   - **High**: Address auto-corrects (if needed)
   - **Medium/Low**: Shows corrected version, asks for confirmation
   - **Multiple matches**: Shows suggestions to choose from
   - **Unverified**: Shows error, asks to re-enter

## Testing

### Local Development

```bash
# Set API key in .env
echo "LOQATE_API_KEY=your-key" >> .env

# Start dev server
pnpm dev
```

### Test Different Confidence Levels

Use these test addresses (for US):

**High confidence** (auto-apply):
```
Address: 1600 Amphitheatre Parkway
City: Mountain View
State: CA
Zip: 94043
```

**Medium confidence** (manual confirmation):
```
Address: 123 Main St
City: Springfield
State: IL
Zip: 62701
```

**Unverified** (rejection):
```
Address: asdfghjkl
City: nowhere
State: XX
Zip: 00000
```

## API Reference

### Server Action: `/action/verify-address`

**Method**: POST

**Body** (FormData):
```typescript
{
  address: string // JSON-encoded address object
}
```

**Address object shape**:
```typescript
{
  address1: string
  address2?: string
  city: string
  stateCode: string
  postalCode: string
  countryCode?: string // default: 'US'
}
```

**Response**:
```typescript
{
  success: boolean
  data?: LoqateResponse // Array of matches
  error?: string
}
```

## Security

- ✅ API key stored server-side only
- ✅ No client-side API key exposure
- ✅ Server validates all requests
- ✅ Rate limiting possible via middleware
- ✅ Request logging for audit trail

## Troubleshooting

### "Address verification service not configured"

**Cause**: `LOQATE_API_KEY` environment variable not set

**Solution**: Add the key to your `.env` file or MRT environment variables

### Verification button doesn't appear

**Cause**: Extension may not be enabled or no address entered

**Solution**: 
1. Check that you have a valid address in the shipping form
2. Verify `LOQATE_API_KEY` is set
3. Check browser console for errors

### API calls failing

**Cause**: Invalid API key or network issues

**Solution**:
1. Verify API key is correct
2. Check server logs for detailed error messages
3. Ensure server can reach `api.addressy.com`

## Resources

- [Loqate API Documentation](https://docs.loqate.com/)
- [Loqate Implementation Guide](https://docs.loqate.com/our-services/address-verify/implementation-guide)
- [AVC (Address Verification Code) Reference](https://docs.loqate.com/our-services/address-verify/avc-codes)
