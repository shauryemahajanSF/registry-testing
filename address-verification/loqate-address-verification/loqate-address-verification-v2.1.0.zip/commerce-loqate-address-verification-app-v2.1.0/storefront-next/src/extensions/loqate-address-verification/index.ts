/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
export { default as AddressVerification } from './components/AddressVerification';
export { default as AddressSuggestions } from './components/AddressSuggestions';
export { default as VerificationStatus } from './components/VerificationStatus';

export { useLoqateVerification } from './hooks/useLoqateVerification';

export type { AddressVerificationProps } from './components/AddressVerification';
export type { AddressSuggestionsProps } from './components/AddressSuggestions';
export type { VerificationStatusProps } from './components/VerificationStatus';
export type {
    UseLoqateVerificationOptions,
    UseLoqateVerificationResult,
    VerificationStatus as VerificationStatusType,
    AddressMetadata,
    AddressSuggestion,
    VerifiedAddress,
} from './hooks/useLoqateVerification';

export { default as LoqateProvider, useLoqateContext } from './providers/LoqateProvider';
export type { LoqateContextType, LoqateConfig } from './providers/LoqateProvider';
