/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
'use client';

import { useState, useEffect, useRef, useCallback, type ReactElement } from 'react';
import { useTranslation } from 'react-i18next';
import { useFetcher } from 'react-router';
import { Loader2, MapPin } from 'lucide-react';
import { useBasket } from '@/providers/basket';
import { Button } from '@/components/ui/button';
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from '@/components/ui/dialog';
import { useCheckoutContext } from '@/hooks/use-checkout';
import { CHECKOUT_STEPS } from '@/components/checkout/utils/checkout-context-types';
import { useLoqateVerification, type AddressSuggestion, type VerifiedAddress } from '../hooks/useLoqateVerification';
import { useLoqateContext } from '../providers/LoqateProvider';
import AddressSuggestions from './AddressSuggestions';
import VerificationStatus from './VerificationStatus';

export interface AddressVerificationProps {
    className?: string;
}

function AddressVerification({ className = '' }: AddressVerificationProps): ReactElement {
    const { t } = useTranslation('extLoqateAddressVerification');
    const { config } = useLoqateContext();
    const basket = useBasket();
    const { goToStep } = useCheckoutContext();

    // Observe the shipping-address-form fetcher to detect when the user
    // clicks "Continue to Shipping Method". This shares the same fetcher
    // instance used by the checkout form (read-only observation).
    const shippingFormFetcher = useFetcher({ key: 'shipping-address-form' });
    const prevShippingFormState = useRef(shippingFormFetcher.state);

    const fetcher = useFetcher({ key: 'loqate-apply-address' });
    const [modalOpen, setModalOpen] = useState(false);
    const [applied, setApplied] = useState(false);
    const prevFetcherState = useRef(fetcher.state);
    const autoAppliedRef = useRef(false);
    const pendingVerifyRef = useRef(false);

    const shippingAddress = basket?.shipments?.[0]?.shippingAddress;

    const buildKey = (...parts: (string | undefined | null)[]) => parts.map((p) => p ?? '').join('|');

    const addressKey = buildKey(
        shippingAddress?.address1,
        shippingAddress?.address2,
        shippingAddress?.city,
        shippingAddress?.stateCode,
        shippingAddress?.postalCode
    );
    const appliedAddressKey = useRef<string | null>(null);
    const verifiedAddressKey = useRef<string | null>(null);

    const { status, suggestions, verifiedAddress, error, verifyAddress, selectAddress, reset } = useLoqateVerification({
        enabled: config.enabled,
    });

    const triggerVerification = useCallback(() => {
        if (!shippingAddress?.address1 || !shippingAddress?.city || !shippingAddress?.postalCode) return;
        autoAppliedRef.current = false;
        reset();
        setModalOpen(true);
        void verifyAddress({
            address1: shippingAddress.address1 || '',
            address2: shippingAddress.address2 || '',
            city: shippingAddress.city || '',
            stateCode: shippingAddress.stateCode || '',
            postalCode: shippingAddress.postalCode || '',
            countryCode: shippingAddress.countryCode || 'US',
        });
    }, [shippingAddress, reset, verifyAddress]);

    // Step 1: When the shipping-address-form fetcher completes (idle after
    // submitting/loading), flag that we need to verify once the basket updates.
    useEffect(() => {
        if (prevShippingFormState.current !== 'idle' && shippingFormFetcher.state === 'idle') {
            pendingVerifyRef.current = true;
        }
        prevShippingFormState.current = shippingFormFetcher.state;
    }, [shippingFormFetcher.state]);

    // Step 2: When the basket address changes while a verify is pending,
    // trigger verification. This two-step approach handles the timing gap
    // between the fetcher completing and the basket context updating.
    useEffect(() => {
        if (pendingVerifyRef.current && addressKey !== appliedAddressKey.current) {
            pendingVerifyRef.current = false;
            triggerVerification();
        }
    }, [addressKey, triggerVerification]);

    const submitVerifiedAddress = useCallback(
        (addr: VerifiedAddress) => {
            const expectedKey = buildKey(addr.address1, addr.address2, addr.city, addr.stateCode, addr.postalCode);
            verifiedAddressKey.current = expectedKey;
            appliedAddressKey.current = expectedKey;

            const formData = new FormData();
            formData.append('intent', 'shippingAddress');
            formData.append('firstName', shippingAddress?.firstName || '');
            formData.append('lastName', shippingAddress?.lastName || '');
            formData.append('address1', addr.address1);
            if (addr.address2) formData.append('address2', addr.address2);
            formData.append('city', addr.city);
            formData.append('stateCode', addr.stateCode);
            formData.append('postalCode', addr.postalCode);
            formData.append('countryCode', addr.countryCode);
            if (shippingAddress?.phone) formData.append('phone', shippingAddress.phone);
            void fetcher.submit(formData, { method: 'post' });
        },
        [fetcher, shippingAddress]
    );

    // Auto-apply high confidence matches (V44 + matchscore >= 95)
    useEffect(() => {
        if (verifiedAddress?.confidence === 'high' && !autoAppliedRef.current && !applied) {
            autoAppliedRef.current = true;
            submitVerifiedAddress(verifiedAddress);
        }
    }, [verifiedAddress, applied, submitVerifiedAddress]);

    // Track our correction fetcher completion to set applied state and close modal.
    useEffect(() => {
        if (prevFetcherState.current !== 'idle' && fetcher.state === 'idle') {
            setApplied(true);
            setModalOpen(false);
        }
        prevFetcherState.current = fetcher.state;
    }, [fetcher.state]);

    // Capture the address key once when verification completes.
    useEffect(() => {
        if (
            (status === 'verified' || status === 'partiallyVerified' || status === 'unverified') &&
            verifiedAddressKey.current === null
        ) {
            verifiedAddressKey.current = addressKey;
        }
    }, [status, addressKey]);

    // Reset when address changes after any verification result or after applying
    useEffect(() => {
        if (verifiedAddressKey.current !== null && addressKey !== verifiedAddressKey.current) {
            setApplied(false);
            appliedAddressKey.current = null;
            verifiedAddressKey.current = null;
            autoAppliedRef.current = false;
            reset();
        }
    }, [addressKey, reset]);

    const handleApplyAddress = () => {
        if (!verifiedAddress) return;
        submitVerifiedAddress(verifiedAddress);
    };

    const handleSelectSuggestion = (suggestion: AddressSuggestion) => {
        selectAddress(suggestion);
    };

    const handleClose = () => {
        setModalOpen(false);
        reset();
    };

    const handleContinueAsEntered = () => {
        // Accept the current address despite verification failure.
        // Mark it so the auto-trigger doesn't re-fire for this address.
        appliedAddressKey.current = addressKey;
        verifiedAddressKey.current = addressKey;
        setModalOpen(false);
        reset();
    };

    const handleEditAddress = () => {
        setModalOpen(false);
        appliedAddressKey.current = null;
        verifiedAddressKey.current = null;
        reset();
        goToStep(CHECKOUT_STEPS.SHIPPING_ADDRESS);
    };

    if (!config.enabled) {
        return <></>;
    }

    const isApplying = fetcher.state === 'submitting';
    const confidence = verifiedAddress?.confidence;

    const showResults =
        status === 'verified' || status === 'partiallyVerified' || status === 'unverified' || status === 'error';
    const canApply = verifiedAddress && (confidence === 'medium' || confidence === 'low');
    const isAmbiguous = status === 'ambiguous' && suggestions.length > 0;

    const displayStatus =
        showResults && confidence === 'none' && status === 'partiallyVerified' ? 'unverified' : status;

    const modalDescription =
        status === 'verifying'
            ? t('loqateAddressVerification.modal.verifyingDescription')
            : t('loqateAddressVerification.modal.description');

    return (
        <div className={className}>
            <Dialog open={modalOpen} onOpenChange={(open) => !open && handleClose()}>
                <DialogContent showCloseButton={status !== 'verifying' && !isApplying}>
                    <DialogHeader>
                        <DialogTitle>{t('loqateAddressVerification.modal.title')}</DialogTitle>
                        <DialogDescription>{modalDescription}</DialogDescription>
                    </DialogHeader>

                    <div className="py-2">
                        {status === 'verifying' && (
                            <div className="flex flex-col items-center gap-3 py-6">
                                <Loader2 className="size-8 animate-spin text-muted-foreground" />
                                <p className="text-sm text-muted-foreground">
                                    {t('loqateAddressVerification.message.verifying')}
                                </p>
                            </div>
                        )}

                        {confidence === 'high' && isApplying && (
                            <div className="flex flex-col items-center gap-3 py-6">
                                <Loader2 className="size-8 animate-spin text-muted-foreground" />
                                <p className="text-sm text-muted-foreground">
                                    {t('loqateAddressVerification.message.autoApplying')}
                                </p>
                            </div>
                        )}

                        {showResults && (
                            <VerificationStatus
                                status={displayStatus}
                                verifiedAddress={confidence !== 'none' ? verifiedAddress : null}
                                originalAddress={shippingAddress}
                                error={error}
                            />
                        )}

                        {isAmbiguous && (
                            <AddressSuggestions
                                suggestions={suggestions}
                                onSelect={handleSelectSuggestion}
                                onCancel={handleClose}
                            />
                        )}
                    </div>

                    {(canApply || showResults || isAmbiguous) && status !== 'verifying' && (
                        <DialogFooter>
                            {canApply ? (
                                <>
                                    <Button type="button" variant="outline" onClick={handleClose}>
                                        {t('loqateAddressVerification.button.keepOriginal')}
                                    </Button>
                                    <Button type="button" onClick={handleApplyAddress} disabled={isApplying}>
                                        {isApplying ? <Loader2 className="animate-spin" /> : <MapPin />}
                                        {t('loqateAddressVerification.button.applyAddress')}
                                    </Button>
                                </>
                            ) : displayStatus === 'unverified' || displayStatus === 'error' ? (
                                <>
                                    <Button type="button" variant="outline" onClick={handleEditAddress}>
                                        {t('loqateAddressVerification.button.editAddress')}
                                    </Button>
                                    <Button type="button" onClick={handleContinueAsEntered}>
                                        {t('loqateAddressVerification.button.continueAsEntered')}
                                    </Button>
                                </>
                            ) : null}
                        </DialogFooter>
                    )}
                </DialogContent>
            </Dialog>
        </div>
    );
}

export default AddressVerification;
