'use strict';

var Status = require('dw/system/Status');
var PaymentTransaction = require('dw/order/PaymentTransaction');
var GiftCardTransactionDetails = require('dw/extensions/payments/GiftCardTransactionDetails');

/**
 * Capture the gift card and record the captured payment-transaction status.
 * This mock does not call Givex. On success it writes transaction details and
 * sets STATUS_CAPTURED so the platform does not treat the instrument as pending.
 * @param {dw.order.Order} order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument
 * @returns {dw.system.Status}
 */
exports.capture = function (order, paymentInstrument) {
    try {
        void order;
        persistGiftCardTransactionDetails(paymentInstrument, 'GC-CAP-OK', 'Gift card captured');
        paymentInstrument.getPaymentTransaction().setStatus(PaymentTransaction.STATUS_CAPTURED);
        return new Status(Status.OK);
    } catch (e) {
        var Logger = require('dw/system/Logger');
        Logger.error('givex capture failed: {0}', e.message);
        return new Status(Status.ERROR, 'CAPTURE_ERROR', e.message || 'Gift card capture failed');
    }
};

function persistGiftCardTransactionDetails(paymentInstrument, approvalCode, processorResponseText) {
    var details = new GiftCardTransactionDetails();
    details.setApprovalCode(approvalCode);
    details.setProcessorResponseText(processorResponseText);
    paymentInstrument.getPaymentTransaction().setTransactionDetails(details);
}
