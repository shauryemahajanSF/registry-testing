'use strict';

var Status = require('dw/system/Status');
var PaymentTransaction = require('dw/order/PaymentTransaction');
var GiftCardTransactionDetails = require('dw/extensions/payments/GiftCardTransactionDetails');

/**
 * Refund the gift card and record that the capture was voided.
 * This mock does not call Givex. On success it replaces capture forensics with
 * refund transaction details and sets STATUS_CAPTUREVOIDED.
 * @param {dw.order.Order} order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument
 * @returns {dw.system.Status}
 */
exports.refund = function (order, paymentInstrument) {
    try {
        void order;
        persistGiftCardTransactionDetails(paymentInstrument, 'GC-REF-OK', 'Gift card refunded');
        paymentInstrument.getPaymentTransaction().setStatus(PaymentTransaction.STATUS_CAPTUREVOIDED);
        return new Status(Status.OK);
    } catch (e) {
        var Logger = require('dw/system/Logger');
        Logger.error('givex refund failed: {0}', e.message);
        return new Status(Status.ERROR, 'REFUND_ERROR', e.message || 'Gift card refund failed');
    }
};

function persistGiftCardTransactionDetails(paymentInstrument, approvalCode, processorResponseText) {
    var details = new GiftCardTransactionDetails();
    details.setApprovalCode(approvalCode);
    details.setProcessorResponseText(processorResponseText);
    paymentInstrument.getPaymentTransaction().setTransactionDetails(details);
}
