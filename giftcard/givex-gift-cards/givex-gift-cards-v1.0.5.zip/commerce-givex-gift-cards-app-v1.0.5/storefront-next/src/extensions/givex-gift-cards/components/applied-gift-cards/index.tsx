/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_GIVEX_GIFT_CARDS */

'use client';

import { useCallback, useEffect, type ReactElement } from 'react';
import { useFetcher } from 'react-router';
import { useTranslation } from 'react-i18next';
import { X as CloseIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/toast';
import { formatCurrency } from '@/lib/currency';
import { FETCHER_STATES } from '@/lib/fetcher-states';
import { useBasket, useBasketUpdater } from '@/providers/basket';
import { useSite } from '@salesforce/storefront-next-runtime/site-context';
import { REMOVE_GIFT_CARD_ACTION } from '../../lib/constants';
import { englishDefault } from '../../lib/english-defaults';
import { getAppliedGiftCards, getGiftCardLastFour } from '../../lib/gift-card-utils';
import type { RemoveGiftCardActionResult } from '../../routes/action.givex-gift-cards-remove';

type Translate = (key: string, options?: Record<string, unknown>) => string;

function tWithDefault(t: Translate, key: string, options?: Record<string, unknown>): string {
    return t(key, { ...options, defaultValue: englishDefault(key) });
}

/**
 * Applied gift cards for `sfcc.orderSummary.giftCards.applied`.
 * Renders dt/dd rows that participate in the order-summary grid via `display: contents`.
 */
export default function AppliedGiftCards(): ReactElement | null {
    const { t: translate, i18n } = useTranslation('extGivexGiftCards');
    const t = useCallback<Translate>(
        (key, options) => tWithDefault(translate, key, options),
        [translate]
    );
    const basket = useBasket();
    const updateBasket = useBasketUpdater();
    const { addToast } = useToast();
    const { currency: siteCurrency } = useSite();
    const fetcher = useFetcher<RemoveGiftCardActionResult>();

    const giftCards = getAppliedGiftCards(basket);
    const currency = basket?.currency ?? siteCurrency;
    const isRemoving = fetcher.state === FETCHER_STATES.SUBMITTING;

    useEffect(() => {
        if (!fetcher.data || fetcher.state !== FETCHER_STATES.IDLE) {
            return;
        }

        if (fetcher.data.success && fetcher.data.basket) {
            updateBasket(fetcher.data.basket);
            return;
        }

        if (!fetcher.data.success) {
            addToast(fetcher.data.error || t('givexGiftCards.applied.removeFailed'), 'error');
        }
    }, [fetcher.data, fetcher.state, updateBasket, addToast, t]);

    if (giftCards.length === 0) {
        return null;
    }

    const removeCard = (paymentInstrumentId: string | undefined) => {
        if (!basket?.basketId || !paymentInstrumentId || isRemoving) {
            return;
        }

        void fetcher.submit(
            {
                basketId: basket.basketId,
                paymentInstrumentId,
            },
            { method: 'POST', action: REMOVE_GIFT_CARD_ACTION }
        );
    };

    return (
        <div className="contents" data-testid="givex-applied-gift-cards">
            {giftCards.map((instrument) => {
                const lastFour = getGiftCardLastFour(instrument);
                const amount = instrument.amount ?? 0;
                return (
                    <div key={instrument.paymentInstrumentId} className="contents">
                        <dt className="flex min-w-0 items-center gap-2">
                            <span className="truncate">
                                {t('givexGiftCards.applied.label', { lastFour })}
                            </span>
                            <Button
                                type="button"
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6 shrink-0 cursor-pointer"
                                disabled={isRemoving}
                                aria-label={t('givexGiftCards.applied.remove', { lastFour })}
                                onClick={() => removeCard(instrument.paymentInstrumentId)}>
                                <CloseIcon className="h-3.5 w-3.5" aria-hidden="true" />
                            </Button>
                        </dt>
                        <dd className="justify-self-end text-sm font-normal leading-5 text-muted-foreground">
                            {formatCurrency(-Math.abs(amount), i18n.language, currency)}
                        </dd>
                    </div>
                );
            })}
        </div>
    );
}
