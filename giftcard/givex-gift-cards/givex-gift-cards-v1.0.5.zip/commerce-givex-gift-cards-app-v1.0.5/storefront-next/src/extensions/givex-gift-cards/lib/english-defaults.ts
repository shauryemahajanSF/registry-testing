/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_GIVEX_GIFT_CARDS */

import enUS from '../locales/en-US/translations.json';

/**
 * Resolve an English default string for a givexGiftCards.* key.
 * Used as react-i18next `defaultValue` when the extGivexGiftCards
 * namespace is missing from the MRT build (otherwise raw keys render).
 */
export function englishDefault(key: string): string {
    const parts = key.split('.');
    let node: unknown = enUS;
    for (const part of parts) {
        if (!node || typeof node !== 'object' || !(part in node)) {
            return key;
        }
        node = (node as Record<string, unknown>)[part];
    }
    return typeof node === 'string' ? node : key;
}
