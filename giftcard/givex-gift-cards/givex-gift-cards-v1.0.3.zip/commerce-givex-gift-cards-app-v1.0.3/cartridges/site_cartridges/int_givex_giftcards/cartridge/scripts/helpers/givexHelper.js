'use strict';

/**
 * Shared helpers for Givex gift-card Commerce App hooks.
 */

var Site = require('dw/system/Site');
var Logger = require('dw/system/Logger');

var logger = Logger.getLogger('givex-gift-cards', 'helper');

var METHOD_SECURE_BALANCE = '994';
var METHOD_REDEMPTION = '901';
var METHOD_CANCEL = '909';

/**
 * @param {string} key - Custom site preference ID
 * @param {*} defaultValue - Fallback
 * @returns {*}
 */
function getPreference(key, defaultValue) {
    try {
        var value = Site.getCurrent().getCustomPreferenceValue(key);
        if (value === null || typeof value === 'undefined' || value === '') {
            return defaultValue;
        }
        return value;
    } catch (e) {
        return defaultValue;
    }
}

/**
 * @param {string} prefix - Short operation prefix
 * @param {string} seed - Order / card seed
 * @returns {string}
 */
function buildTransactionCode(prefix, seed) {
    var safeSeed = String(seed || Date.now()).replace(/[^a-zA-Z0-9_-]/g, '').slice(-24);
    return [prefix, safeSeed, Date.now().toString(36)].join('-').slice(0, 40);
}

/**
 * Extracts credentials from Balance API or Apply request documents.
 * @param {Object} request - Hook request
 * @returns {{cardNumber: string|null, pin: string, currencyCode: string|null}}
 */
function extractCredentials(request) {
    var cardNumber = null;
    var pin = '';
    var currencyCode = null;

    if (!request) {
        return { cardNumber: null, pin: '', currencyCode: null };
    }

    var providerProperties = request.providerProperties;
    if (!providerProperties && typeof request.getProviderProperties === 'function') {
        providerProperties = request.getProviderProperties();
    }

    if (providerProperties) {
        if (typeof providerProperties.get === 'function') {
            cardNumber = providerProperties.get('cardNumber')
                || providerProperties.get('number')
                || providerProperties.get('giftCardNumber');
            pin = providerProperties.get('cvc')
                || providerProperties.get('pin')
                || providerProperties.get('securityCode')
                || '';
            currencyCode = providerProperties.get('currency')
                || providerProperties.get('currencyCode')
                || null;
        } else {
            cardNumber = providerProperties.cardNumber
                || providerProperties.number
                || providerProperties.giftCardNumber
                || null;
            pin = providerProperties.cvc
                || providerProperties.pin
                || providerProperties.securityCode
                || '';
            currencyCode = providerProperties.currency
                || providerProperties.currencyCode
                || null;
        }
    }

    if (!cardNumber) {
        var card = request.paymentCard;
        if (!card && typeof request.getPaymentCard === 'function') {
            card = request.getPaymentCard();
        }
        if (card) {
            cardNumber = typeof card.getNumber === 'function' ? card.getNumber() : card.number;
            pin = (typeof card.getSecurityCode === 'function'
                ? card.getSecurityCode()
                : card.securityCode) || '';
        }
    }

    return {
        cardNumber: cardNumber ? String(cardNumber).replace(/\s|-/g, '') : null,
        pin: pin ? String(pin) : '',
        currencyCode: currencyCode
    };
}

/**
 * Reads credentials from an order payment instrument for capture/refund.
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument - Gift-card PI
 * @returns {{cardNumber: string|null, pin: string}}
 */
function extractInstrumentCredentials(paymentInstrument) {
    var cardNumber = null;
    var pin = '';

    if (!paymentInstrument) {
        return { cardNumber: null, pin: '' };
    }

    try {
        if (typeof paymentInstrument.getCreditCardNumber === 'function') {
            cardNumber = paymentInstrument.getCreditCardNumber();
        }
    } catch (e) {
        logger.warn('Unable to read gift card number from payment instrument');
    }

    try {
        if (paymentInstrument.custom && paymentInstrument.custom.givexGiftCardsPin) {
            pin = String(paymentInstrument.custom.givexGiftCardsPin);
        }
    } catch (e2) {
        // optional
    }

    if (cardNumber) {
        cardNumber = String(cardNumber).replace(/\s|-/g, '');
        if (cardNumber.indexOf('*') >= 0) {
            cardNumber = null;
        }
    }

    return { cardNumber: cardNumber, pin: pin };
}

/**
 * Parses a Givex JSON-RPC payload into a normalized result.
 * @param {Object} rpcResponse - Parsed JSON-RPC body
 * @returns {{ok: boolean, resultCode: string|null, balance: number|null, currency: string|null, transactionReference: string|null, message: string|null}}
 */
function parseRpcResult(rpcResponse) {
    if (!rpcResponse || rpcResponse.error || rpcResponse.parseError) {
        return {
            ok: false,
            resultCode: null,
            balance: null,
            currency: null,
            transactionReference: null,
            message: (rpcResponse && rpcResponse.error && rpcResponse.error.message)
                || 'Invalid Givex response'
        };
    }

    var result = rpcResponse.result;
    if (Object.prototype.toString.call(result) !== '[object Array]') {
        return {
            ok: false,
            resultCode: null,
            balance: null,
            currency: null,
            transactionReference: null,
            message: 'Unexpected Givex result shape'
        };
    }

    var resultCode = result.length > 0 ? String(result[0]) : null;
    var ok = resultCode === '0' || resultCode === '00';
    var balance = null;
    var currency = null;
    var transactionReference = null;
    var message = null;

    if (result.length > 2 && !isNaN(parseFloat(result[2]))) {
        balance = parseFloat(result[2]);
    }
    if (result.length > 3 && typeof result[3] === 'string' && result[3].length === 3) {
        currency = result[3];
    }
    if (result.length > 4 && result[4] != null) {
        transactionReference = String(result[4]);
    }
    if (result.length > 5 && result[5] != null) {
        message = String(result[5]);
    }
    if (!transactionReference && result.length > 1 && result[1] != null && ok) {
        transactionReference = String(result[1]);
    }

    return {
        ok: ok,
        resultCode: resultCode,
        balance: balance,
        currency: currency,
        transactionReference: transactionReference,
        message: message || (ok ? 'OK' : 'Givex declined the request')
    };
}

/**
 * @returns {Array}
 */
function buildBalanceParams(cardNumber, pin, userId, password) {
    return [
        getPreference('givexGiftCardsLanguage', 'en'),
        buildTransactionCode('bal', cardNumber),
        userId,
        password,
        cardNumber,
        pin || ''
    ];
}

/**
 * @returns {Array}
 */
function buildCaptureParams(cardNumber, pin, amount, currencyCode, userId, password, orderNo) {
    return [
        getPreference('givexGiftCardsLanguage', 'en'),
        buildTransactionCode('cap', orderNo),
        userId,
        password,
        cardNumber,
        pin || '',
        String(amount),
        currencyCode || getPreference('givexGiftCardsCurrency', 'USD')
    ];
}

/**
 * @returns {Array}
 */
function buildRefundParams(cardNumber, pin, captureReference, amount, currencyCode, userId, password, orderNo) {
    return [
        getPreference('givexGiftCardsLanguage', 'en'),
        buildTransactionCode('ref', orderNo),
        userId,
        password,
        cardNumber,
        pin || '',
        String(amount),
        currencyCode || getPreference('givexGiftCardsCurrency', 'USD'),
        captureReference || ''
    ];
}

module.exports = {
    METHOD_SECURE_BALANCE: METHOD_SECURE_BALANCE,
    METHOD_REDEMPTION: METHOD_REDEMPTION,
    METHOD_CANCEL: METHOD_CANCEL,
    getPreference: getPreference,
    buildTransactionCode: buildTransactionCode,
    extractCredentials: extractCredentials,
    extractInstrumentCredentials: extractInstrumentCredentials,
    parseRpcResult: parseRpcResult,
    buildBalanceParams: buildBalanceParams,
    buildCaptureParams: buildCaptureParams,
    buildRefundParams: buildRefundParams
};
