/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_GIVEX_GIFT_CARDS */

import { type ActionFunctionArgs, data } from 'react-router';
import { ApiError, type ShopperBasketsV2 } from '@/scapi';
import { addPaymentInstrumentToBasket } from '@/lib/api/basket.server';
import { getLogger } from '@/lib/logger.server';
import { withRevalidateTags } from '@/lib/revalidation/tags';
import {
    COMMERCE_APP_GIFT_CARD_PAYMENT_METHOD_ID,
    GIFT_CARD_BASKET_TAG,
    GIVEX_CARD_TYPE,
} from '../lib/constants';
import { maskPan, normalizePan } from '../lib/gift-card-utils';

type Basket = ShopperBasketsV2.schemas['Basket'];

export type ApplyGiftCardActionResult = {
    success: boolean;
    basket?: Basket;
    error?: string;
};

/**
 * Apply a Givex gift card to the shopper basket.
 *
 * Platform owns allocation (`min(balance, remaining total)`). This action only
 * creates the COMMERCE_APP_GIFT_CARD payment instrument — no amount is sent.
 *
 * POST FormData fields:
 *   basketId: string (required)
 *   cardNumber: string (required)
 *   pin: string (optional)
 */
export async function action({ request, context }: ActionFunctionArgs) {
    if (request.method !== 'POST') {
        return data<ApplyGiftCardActionResult>(
            { success: false, error: 'Method not allowed' },
            { status: 405 }
        );
    }

    const logger = getLogger(context);
    let basketId: string | undefined;

    try {
        const formData = await request.formData();
        basketId = formData.get('basketId')?.toString();
        const cardNumber = normalizePan(formData.get('cardNumber')?.toString() ?? '');
        const pin = formData.get('pin')?.toString() ?? '';

        if (!basketId || !cardNumber) {
            return data<ApplyGiftCardActionResult>(
                { success: false, error: 'basketId and cardNumber are required' },
                { status: 400 }
            );
        }

        // OrderPaymentCardRequest typings omit `number` / `securityCode`, but SCAPI
        // gift-card apply accepts them (see platform gift-card integration tests).
        const paymentInstrument = {
            paymentMethodId: COMMERCE_APP_GIFT_CARD_PAYMENT_METHOD_ID,
            paymentCard: {
                number: cardNumber,
                maskedNumber: maskPan(cardNumber),
                cardType: GIVEX_CARD_TYPE,
                ...(pin ? { securityCode: pin } : {}),
            },
        } as ShopperBasketsV2.schemas['OrderPaymentInstrument'];

        const updated = await addPaymentInstrumentToBasket(context, basketId, paymentInstrument);
        return withRevalidateTags({ success: true, basket: updated } satisfies ApplyGiftCardActionResult, [
            GIFT_CARD_BASKET_TAG,
        ]);
    } catch (error) {
        const isApiError = error instanceof ApiError;
        logger.error('[givex-gift-cards] apply failed', {
            basketId,
            ...(isApiError ? error.toJSON() : { message: String(error) }),
        });
        return data<ApplyGiftCardActionResult>(
            {
                success: false,
                error: isApiError ? error.message : 'Unable to apply gift card',
            },
            { status: isApiError ? (error.status ?? 500) : 500 }
        );
    }
}
