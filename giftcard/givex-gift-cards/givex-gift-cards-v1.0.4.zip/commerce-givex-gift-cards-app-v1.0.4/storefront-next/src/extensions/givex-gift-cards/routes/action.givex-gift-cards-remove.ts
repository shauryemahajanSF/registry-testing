/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_GIVEX_GIFT_CARDS */

import { type ActionFunctionArgs, data } from 'react-router';
import { ApiError, type ShopperBasketsV2 } from '@/scapi';
import { removePaymentInstrumentFromBasket } from '@/lib/api/basket.server';
import { getLogger } from '@/lib/logger.server';
import { withRevalidateTags } from '@/lib/revalidation/tags';
import { GIFT_CARD_BASKET_TAG } from '../lib/constants';

type Basket = ShopperBasketsV2.schemas['Basket'];

export type RemoveGiftCardActionResult = {
    success: boolean;
    basket?: Basket;
    error?: string;
};

/**
 * Remove a Givex gift card payment instrument from the shopper basket.
 *
 * POST FormData fields:
 *   basketId: string (required)
 *   paymentInstrumentId: string (required)
 */
export async function action({ request, context }: ActionFunctionArgs) {
    if (request.method !== 'POST') {
        return data<RemoveGiftCardActionResult>(
            { success: false, error: 'Method not allowed' },
            { status: 405 }
        );
    }

    const logger = getLogger(context);
    let basketId: string | undefined;
    let paymentInstrumentId: string | undefined;

    try {
        const formData = await request.formData();
        basketId = formData.get('basketId')?.toString();
        paymentInstrumentId = formData.get('paymentInstrumentId')?.toString();

        if (!basketId || !paymentInstrumentId) {
            return data<RemoveGiftCardActionResult>(
                { success: false, error: 'basketId and paymentInstrumentId are required' },
                { status: 400 }
            );
        }

        const updated = await removePaymentInstrumentFromBasket(context, basketId, paymentInstrumentId);
        return withRevalidateTags({ success: true, basket: updated } satisfies RemoveGiftCardActionResult, [
            GIFT_CARD_BASKET_TAG,
        ]);
    } catch (error) {
        const isApiError = error instanceof ApiError;
        logger.error('[givex-gift-cards] remove failed', {
            basketId,
            paymentInstrumentId,
            ...(isApiError ? error.toJSON() : { message: String(error) }),
        });
        return data<RemoveGiftCardActionResult>(
            {
                success: false,
                error: isApiError ? error.message : 'Unable to remove gift card',
            },
            { status: isApiError ? (error.status ?? 500) : 500 }
        );
    }
}
