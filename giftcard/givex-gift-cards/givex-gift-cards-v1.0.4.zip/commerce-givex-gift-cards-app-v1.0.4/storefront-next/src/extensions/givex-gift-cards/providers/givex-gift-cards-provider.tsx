/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_GIVEX_GIFT_CARDS */

'use client';

import { createContext, useContext, type ReactNode, type ReactElement } from 'react';
import { useConfig } from '@salesforce/storefront-next-runtime/config';
import type { PanValidationRules } from '../lib/pan-validation';

type GivexGiftCardsConfig = {
    panPattern?: string;
    panMinLength?: number;
    panMaxLength?: number;
    panLuhnEnabled?: boolean;
};

type AppConfig = {
    extension?: {
        givexGiftCards?: GivexGiftCardsConfig;
    };
};

type GivexGiftCardsContextValue = {
    panRules: PanValidationRules;
};

const GivexGiftCardsContext = createContext<GivexGiftCardsContextValue | undefined>(undefined);

export type GivexGiftCardsProviderProps = {
    children: ReactNode;
};

/**
 * Root provider for the Givex gift cards extension.
 * Registers in target-config.json contextProviders.
 */
export default function GivexGiftCardsProvider({ children }: GivexGiftCardsProviderProps): ReactElement {
    const appConfig = useConfig<AppConfig>();
    const extensionConfig = appConfig.extension?.givexGiftCards;

    const value: GivexGiftCardsContextValue = {
        panRules: {
            pattern: extensionConfig?.panPattern,
            minLength: extensionConfig?.panMinLength,
            maxLength: extensionConfig?.panMaxLength,
            luhnEnabled: extensionConfig?.panLuhnEnabled === true,
        },
    };

    return <GivexGiftCardsContext.Provider value={value}>{children}</GivexGiftCardsContext.Provider>;
}

/**
 * Access Givex gift card extension config (optional PAN validation rules).
 */
export function useGivexGiftCards(): GivexGiftCardsContextValue {
    const context = useContext(GivexGiftCardsContext);
    if (context === undefined) {
        // Targets can render before provider hydration in tests — fall back to empty rules.
        return { panRules: {} };
    }
    return context;
}
