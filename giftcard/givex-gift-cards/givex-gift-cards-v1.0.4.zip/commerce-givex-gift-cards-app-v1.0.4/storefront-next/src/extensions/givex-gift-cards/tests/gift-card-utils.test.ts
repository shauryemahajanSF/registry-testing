/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { describe, expect, it } from 'vitest';
import {
    getAppliedGiftCards,
    getGiftCardLastFour,
    isGiftCardPaymentInstrument,
    maskPan,
    normalizePan,
    passesLuhn,
} from '../lib/gift-card-utils';
import { validatePan } from '../lib/pan-validation';
import { COMMERCE_APP_GIFT_CARD_PAYMENT_METHOD_ID } from '../lib/constants';

describe('gift-card-utils', () => {
    it('normalizes and masks PANs', () => {
        expect(normalizePan('6036-2874 1234')).toBe('603628741234');
        expect(maskPan('603628741234')).toBe('********1234');
    });

    it('validates Luhn checksums', () => {
        expect(passesLuhn('4111111111111111')).toBe(true);
        expect(passesLuhn('4111111111111112')).toBe(false);
    });

    it('identifies gift-card payment instruments', () => {
        expect(
            isGiftCardPaymentInstrument({
                paymentMethodId: COMMERCE_APP_GIFT_CARD_PAYMENT_METHOD_ID,
                paymentInstrumentId: 'pi-1',
            })
        ).toBe(true);
        expect(isGiftCardPaymentInstrument({ paymentMethodId: 'CREDIT_CARD' })).toBe(false);
    });

    it('filters applied gift cards and reads last four', () => {
        const basket = {
            paymentInstruments: [
                {
                    paymentMethodId: COMMERCE_APP_GIFT_CARD_PAYMENT_METHOD_ID,
                    paymentInstrumentId: 'gc-1',
                    paymentCard: { numberLastDigits: '4321' },
                    amount: 25,
                },
                { paymentMethodId: 'CREDIT_CARD', paymentInstrumentId: 'cc-1' },
            ],
        };

        const giftCards = getAppliedGiftCards(basket);
        expect(giftCards).toHaveLength(1);
        expect(getGiftCardLastFour(giftCards[0])).toBe('4321');
    });
});

describe('validatePan', () => {
    it('requires a non-empty PAN', () => {
        expect(validatePan('')).toEqual({ valid: false, reason: 'required' });
    });

    it('enforces length and pattern rules', () => {
        expect(validatePan('123', { minLength: 8 })).toEqual({ valid: false, reason: 'minLength' });
        expect(validatePan('12345678901234567890', { maxLength: 16 })).toEqual({
            valid: false,
            reason: 'maxLength',
        });
        expect(validatePan('abcdef', { pattern: '^\\d+$' })).toEqual({
            valid: false,
            reason: 'pattern',
        });
    });

    it('optionally applies Luhn', () => {
        expect(validatePan('4111111111111112', { luhnEnabled: true })).toEqual({
            valid: false,
            reason: 'luhn',
        });
        expect(validatePan('4111111111111111', { luhnEnabled: true }).valid).toBe(true);
    });
});
