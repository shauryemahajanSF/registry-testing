/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_GIVEX_GIFT_CARDS */

'use client';

import { useEffect, useMemo, useState, type ReactElement } from 'react';
import { useFetcher } from 'react-router';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useTranslation } from 'react-i18next';
import { CircleCheck, Eye, EyeOff, Gift as GiftIcon, X as CloseIcon } from 'lucide-react';
import {
    Accordion,
    AccordionContent,
    AccordionItem,
    AccordionTrigger,
} from '@/components/ui/accordion';
import { Button } from '@/components/ui/button';
import {
    Form,
    FormField,
    FormItem,
    FormLabel,
    FormMessage,
} from '@/components/ui/form';
import { FormInput } from '@/components/form-fields';
import { useToast } from '@/components/toast';
import { formatCurrency } from '@/lib/currency';
import { FETCHER_STATES } from '@/lib/fetcher-states';
import { useBasket, useBasketUpdater } from '@/providers/basket';
import {
    APPLY_GIFT_CARD_ACTION,
    CHECK_GIFT_CARD_BALANCE_ACTION,
    REMOVE_GIFT_CARD_ACTION,
} from '../../lib/constants';
import { getAppliedGiftCards, getGiftCardLastFour } from '../../lib/gift-card-utils';
import { validatePan } from '../../lib/pan-validation';
import { useGivexGiftCards } from '../../providers/givex-gift-cards-provider';
import type { GiftCardScenario } from '../../lib/gift-card-scenarios';
import type { ApplyGiftCardActionResult } from '../../routes/action.givex-gift-cards-apply';
import type { CheckGiftCardBalanceActionResult } from '../../routes/action.givex-gift-cards-balance';
import type { RemoveGiftCardActionResult } from '../../routes/action.givex-gift-cards-remove';

const ACCORDION_VALUE = 'givex-gift-card';

function scenarioMessage(
    t: (key: string) => string,
    errorCode: GiftCardScenario | undefined,
    fallback: string | undefined
): string {
    if (errorCode) {
        return t(`givexGiftCards.apply.errors.${errorCode}`);
    }
    return fallback || t('givexGiftCards.apply.errorGeneric');
}

type GiftCardApplyFormValues = {
    cardNumber: string;
    pin: string;
};

/**
 * Gift card apply form for `sfcc.checkout.payment.paymentMethods.before`.
 * Creates a COMMERCE_APP_GIFT_CARD payment instrument; platform allocates amount.
 */
export default function GiftCardApply(): ReactElement {
    const { t, i18n } = useTranslation('extGivexGiftCards');
    const basket = useBasket();
    const updateBasket = useBasketUpdater();
    const { addToast } = useToast();
    const { panRules } = useGivexGiftCards();
    const fetcher = useFetcher<ApplyGiftCardActionResult>();
    const balanceFetcher = useFetcher<CheckGiftCardBalanceActionResult>();
    const removeFetcher = useFetcher<RemoveGiftCardActionResult>();
    const [isOpen, setIsOpen] = useState(true);
    const [isAdding, setIsAdding] = useState(true);
    const [showPin, setShowPin] = useState(false);
    const [balanceMessage, setBalanceMessage] = useState<string | null>(null);
    const giftCards = getAppliedGiftCards(basket);

    const schema = useMemo(
        () =>
            z.object({
                cardNumber: z.string().superRefine((value, ctx) => {
                    const result = validatePan(value, panRules);
                    if (!result.valid) {
                        ctx.addIssue({
                            code: z.ZodIssueCode.custom,
                            message: t(`givexGiftCards.apply.validation.${result.reason ?? 'required'}`),
                        });
                    }
                }),
                pin: z.string().optional().default(''),
            }),
        [panRules, t]
    );

    const form = useForm<GiftCardApplyFormValues>({
        resolver: zodResolver(schema),
        defaultValues: { cardNumber: '', pin: '' },
    });

    const isSubmitting = fetcher.state === FETCHER_STATES.SUBMITTING;
    const isCheckingBalance = balanceFetcher.state === FETCHER_STATES.SUBMITTING;
    const isRemoving = removeFetcher.state === FETCHER_STATES.SUBMITTING;

    useEffect(() => {
        if (!fetcher.data || fetcher.state !== FETCHER_STATES.IDLE) {
            return;
        }

        if (fetcher.data.success) {
            if (fetcher.data.basket) {
                updateBasket(fetcher.data.basket);
            }
            form.reset({ cardNumber: '', pin: '' });
            setBalanceMessage(null);
            setIsOpen(true);
            setIsAdding(false);
            addToast(t('givexGiftCards.apply.success'), 'success');
            return;
        }

        const message = scenarioMessage(t, fetcher.data.errorCode, fetcher.data.error);
        form.setError('cardNumber', {
            type: 'manual',
            message,
        });
        addToast(message, 'error');
    }, [fetcher.data, fetcher.state, updateBasket, form, addToast, t]);

    useEffect(() => {
        if (!balanceFetcher.data || balanceFetcher.state !== FETCHER_STATES.IDLE) {
            return;
        }

        if (balanceFetcher.data.success && balanceFetcher.data.amount !== undefined) {
            setBalanceMessage(
                t('givexGiftCards.apply.balance', {
                    amount: formatCurrency(
                        balanceFetcher.data.amount,
                        i18n.language,
                        balanceFetcher.data.currency ?? basket?.currency ?? 'USD'
                    ),
                })
            );
            return;
        }

        setBalanceMessage(null);
        const message = scenarioMessage(
            t,
            balanceFetcher.data.errorCode,
            balanceFetcher.data.error || t('givexGiftCards.apply.balanceError')
        );
        form.setError('cardNumber', { type: 'manual', message });
        addToast(message, 'error');
    }, [balanceFetcher.data, balanceFetcher.state, addToast, basket?.currency, form, i18n.language, t]);

    useEffect(() => {
        if (!removeFetcher.data || removeFetcher.state !== FETCHER_STATES.IDLE) {
            return;
        }

        if (removeFetcher.data.success && removeFetcher.data.basket) {
            updateBasket(removeFetcher.data.basket);
            return;
        }

        addToast(removeFetcher.data.error || t('givexGiftCards.applied.removeFailed'), 'error');
    }, [removeFetcher.data, removeFetcher.state, updateBasket, addToast, t]);

    const onSubmit = form.handleSubmit((values) => {
        if (!basket?.basketId) {
            form.setError('cardNumber', {
                type: 'manual',
                message: t('givexGiftCards.apply.errorNoBasket'),
            });
            return;
        }

        if (isSubmitting) {
            return;
        }

        void fetcher.submit(
            {
                basketId: basket.basketId,
                cardNumber: values.cardNumber,
                pin: values.pin ?? '',
            },
            { method: 'POST', action: APPLY_GIFT_CARD_ACTION }
        );
    });

    const checkBalance = () => {
        const { cardNumber, pin } = form.getValues();
        const validation = validatePan(cardNumber, panRules);
        if (!validation.valid) {
            form.setError('cardNumber', {
                type: 'manual',
                message: t(`givexGiftCards.apply.validation.${validation.reason ?? 'required'}`),
            });
            return;
        }

        setBalanceMessage(null);

        if (isCheckingBalance) {
            return;
        }

        void balanceFetcher.submit(
            { cardNumber, pin: pin ?? '' },
            { method: 'POST', action: CHECK_GIFT_CARD_BALANCE_ACTION }
        );
    };

    const removeCard = (paymentInstrumentId: string | undefined) => {
        if (!basket?.basketId || !paymentInstrumentId || isRemoving) {
            return;
        }

        void removeFetcher.submit(
            { basketId: basket.basketId, paymentInstrumentId },
            { method: 'POST', action: REMOVE_GIFT_CARD_ACTION }
        );
    };

    return (
        <div className="w-full" data-testid="givex-gift-card-apply">
            <Accordion
                type="single"
                collapsible
                value={isOpen ? ACCORDION_VALUE : ''}
                onValueChange={(value) => setIsOpen(value === ACCORDION_VALUE)}
                className="mb-0">
                <AccordionItem value={ACCORDION_VALUE}>
                    <AccordionTrigger className="justify-start gap-2 py-3" onClick={() => form.clearErrors()}>
                        <GiftIcon className="size-4 shrink-0" aria-hidden="true" />
                        <span className="text-left text-sm font-medium leading-5 text-card-foreground">
                            {t('givexGiftCards.apply.accordionTitle')}
                        </span>
                    </AccordionTrigger>
                    <AccordionContent className="px-0 pb-3">
                        {giftCards.length > 0 && (
                            <div className="mb-3 space-y-2">
                                {giftCards.map((instrument) => {
                                    const lastFour = getGiftCardLastFour(instrument);
                                    return (
                                        <div
                                            key={instrument.paymentInstrumentId}
                                            className="flex items-center justify-between border-b border-input pb-2 text-sm">
                                            <span>{t('givexGiftCards.applied.label', { lastFour })}</span>
                                            <div className="flex items-center gap-2">
                                                <span>
                                                    {formatCurrency(
                                                        -Math.abs(instrument.amount ?? 0),
                                                        i18n.language,
                                                        basket?.currency ?? 'USD'
                                                    )}
                                                </span>
                                                <Button
                                                    type="button"
                                                    variant="ghost"
                                                    size="icon"
                                                    className="size-6 cursor-pointer"
                                                    disabled={isRemoving}
                                                    aria-label={t('givexGiftCards.applied.remove', { lastFour })}
                                                    onClick={() => removeCard(instrument.paymentInstrumentId)}>
                                                    <CloseIcon className="size-3.5" aria-hidden="true" />
                                                </Button>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        )}
                        {giftCards.length > 0 && !isAdding ? (
                            <Button
                                type="button"
                                variant="outline"
                                className="w-full cursor-pointer"
                                onClick={() => setIsAdding(true)}>
                                {t('givexGiftCards.apply.addAnother')}
                            </Button>
                        ) : (
                        <Form {...form}>
                            <div className="space-y-3">
                                <FormField
                                    control={form.control}
                                    name="cardNumber"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>{t('givexGiftCards.apply.cardNumberLabel')}</FormLabel>
                                            <FormInput
                                                {...field}
                                                autoComplete="off"
                                                inputMode="numeric"
                                                placeholder={t('givexGiftCards.apply.cardNumberPlaceholder')}
                                                disabled={isSubmitting}
                                            />
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="pin"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>{t('givexGiftCards.apply.pinLabel')}</FormLabel>
                                            <div className="relative">
                                                <FormInput
                                                    {...field}
                                                    type={showPin ? 'text' : 'password'}
                                                    autoComplete="off"
                                                    placeholder={t('givexGiftCards.apply.pinPlaceholder')}
                                                    disabled={isSubmitting}
                                                    className="pr-10"
                                                />
                                                <Button
                                                    type="button"
                                                    variant="ghost"
                                                    size="icon"
                                                    className="absolute top-1/2 right-1 size-7 -translate-y-1/2 cursor-pointer"
                                                    aria-label={
                                                        showPin
                                                            ? t('givexGiftCards.apply.hidePin')
                                                            : t('givexGiftCards.apply.showPin')
                                                    }
                                                    onClick={() => setShowPin((current) => !current)}>
                                                    {showPin ? (
                                                        <EyeOff className="size-4" aria-hidden="true" />
                                                    ) : (
                                                        <Eye className="size-4" aria-hidden="true" />
                                                    )}
                                                </Button>
                                            </div>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                {balanceMessage && (
                                    <p
                                        className="flex items-center gap-2 text-sm text-success"
                                        role="status">
                                        <CircleCheck className="size-4 shrink-0" aria-hidden="true" />
                                        <span>{balanceMessage}</span>
                                    </p>
                                )}
                                <div className="flex items-center gap-3">
                                    <Button
                                        type="button"
                                        variant="ghost"
                                        disabled={isCheckingBalance}
                                        onClick={checkBalance}
                                        className="cursor-pointer px-2">
                                        {isCheckingBalance
                                            ? t('givexGiftCards.apply.checkingBalance')
                                            : t('givexGiftCards.apply.checkBalance')}
                                    </Button>
                                    <Button
                                        type="button"
                                        variant="secondary"
                                        disabled={isSubmitting}
                                        onClick={() => void onSubmit()}
                                        className="cursor-pointer">
                                        {isSubmitting
                                            ? t('givexGiftCards.apply.submitting')
                                            : t('givexGiftCards.apply.submit')}
                                    </Button>
                                </div>
                            </div>
                        </Form>
                        )}
                    </AccordionContent>
                </AccordionItem>
            </Accordion>
        </div>
    );
}
