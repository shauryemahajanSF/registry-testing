/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_GIVEX_GIFT_CARDS */

import { type ActionFunctionArgs, data } from 'react-router';
import { ApiError } from '@/scapi';
import { createApiClients } from '@/lib/api-clients.server';
import { getLogger } from '@/lib/logger.server';
import { COMMERCE_APP_GIFT_CARD_PAYMENT_METHOD_ID, GIVEX_CARD_TYPE } from '../lib/constants';
import { normalizePan } from '../lib/gift-card-utils';
import { scenarioForApiFault, type GiftCardScenario } from '../lib/gift-card-scenarios';

export type CheckGiftCardBalanceActionResult = {
    success: boolean;
    amount?: number;
    currency?: string;
    error?: string;
    errorCode?: GiftCardScenario;
};

/** Check a Givex gift card balance through the Shopper Payments API. */
export async function action({ request, context }: ActionFunctionArgs) {
    if (request.method !== 'POST') {
        return data<CheckGiftCardBalanceActionResult>(
            { success: false, error: 'Method not allowed' },
            { status: 405 }
        );
    }

    const logger = getLogger(context);

    try {
        const formData = await request.formData();
        const cardNumber = normalizePan(formData.get('cardNumber')?.toString() ?? '');
        const pin = formData.get('pin')?.toString() ?? '';

        if (!cardNumber) {
            return data<CheckGiftCardBalanceActionResult>(
                { success: false, error: 'cardNumber is required' },
                { status: 400 }
            );
        }

        const clients = createApiClients(context);
        const { data: balance } = await clients.shopperPayments.getPaymentInstrumentBalance({
            body: {
                paymentMethodId: COMMERCE_APP_GIFT_CARD_PAYMENT_METHOD_ID,
                provider: GIVEX_CARD_TYPE,
                providerProperties: {
                    cardNumber,
                    ...(pin ? { pin } : {}),
                },
            },
        });

        return data<CheckGiftCardBalanceActionResult>({
            success: true,
            amount: balance.amount,
            currency: balance.currency,
        });
    } catch (error) {
        const isApiError = error instanceof ApiError;
        logger.error('[givex-gift-cards] balance lookup failed', {
            ...(isApiError ? error.toJSON() : { message: String(error) }),
        });
        const errorCode = isApiError ? scenarioForApiFault(error.body, error.rawBody) : undefined;
        return data<CheckGiftCardBalanceActionResult>(
            {
                success: false,
                ...(errorCode ? { errorCode } : { error: isApiError ? error.body?.detail || error.message : 'Unable to check gift card balance' }),
            },
            { status: isApiError ? (error.status ?? 500) : 500 }
        );
    }
}
