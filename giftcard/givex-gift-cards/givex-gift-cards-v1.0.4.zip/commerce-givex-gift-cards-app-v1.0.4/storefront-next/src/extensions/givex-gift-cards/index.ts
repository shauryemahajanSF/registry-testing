/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_GIVEX_GIFT_CARDS */

export { default as GiftCardApply } from './components/gift-card-apply';
export { default as AppliedGiftCards } from './components/applied-gift-cards';
export { default as GivexGiftCardsProvider, useGivexGiftCards } from './providers/givex-gift-cards-provider';
export { validatePan } from './lib/pan-validation';
export type { PanValidationRules, PanValidationResult } from './lib/pan-validation';
export {
    getAppliedGiftCards,
    getGiftCardLastFour,
    isGiftCardPaymentInstrument,
    maskPan,
    normalizePan,
    passesLuhn,
} from './lib/gift-card-utils';
