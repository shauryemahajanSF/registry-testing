/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_GIVEX_GIFT_CARDS */

/** Platform payment method ID for Commerce App gift cards. */
export const COMMERCE_APP_GIFT_CARD_PAYMENT_METHOD_ID = 'COMMERCE_APP_GIFT_CARD';

/** Card type sent on the SCAPI payment instrument body. */
export const GIVEX_CARD_TYPE = 'givex';

/** Apply gift card action route. */
export const APPLY_GIFT_CARD_ACTION = '/action/givex-gift-cards-apply';

/** Check gift card balance action route. */
export const CHECK_GIFT_CARD_BALANCE_ACTION = '/action/givex-gift-cards-balance';

/** Remove gift card action route. */
export const REMOVE_GIFT_CARD_ACTION = '/action/givex-gift-cards-remove';

/**
 * Revalidation tag emitted after gift-card basket mutations so cart/checkout
 * summaries refresh applied tenders and totals.
 */
export const GIFT_CARD_BASKET_TAG = 'cart.paymentInstruments';
