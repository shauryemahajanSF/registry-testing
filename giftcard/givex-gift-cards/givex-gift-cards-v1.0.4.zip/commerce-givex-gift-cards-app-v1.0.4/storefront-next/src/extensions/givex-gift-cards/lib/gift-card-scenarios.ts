/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_GIVEX_GIFT_CARDS */

/** Shopper-facing decline reasons returned by the gift-card balance hook. */
export type GiftCardScenario = 'invalid' | 'expired' | 'inactive' | 'zero' | 'currency';

type ApiFault = {
    detail?: string;
    title?: string;
    reason?: string;
    message?: string;
};

/**
 * Read the decline reason from a Shopper API fault.
 *
 * Prefers an explicit `reason` (`INVALID`, `EXPIRED`, `INACTIVE`). Falls back
 * to the platform fault detail for zero balance and currency mismatch.
 */
export function scenarioForApiFault(fault: ApiFault | undefined, rawBody?: string): GiftCardScenario | undefined {
    const reason = fault?.reason?.trim().toUpperCase();
    if (reason === 'INVALID' || reason === 'EXPIRED' || reason === 'INACTIVE') {
        return reason.toLowerCase() as GiftCardScenario;
    }

    const text = [fault?.reason, fault?.detail, fault?.message, fault?.title, rawBody].filter(Boolean).join('\n');
    if (/\bEXPIRED\b/.test(text)) {
        return 'expired';
    }
    if (/\bINACTIVE\b/.test(text)) {
        return 'inactive';
    }
    if (/\bINVALID\b/.test(text)) {
        return 'invalid';
    }
    if (/greater than zero/i.test(text)) {
        return 'zero';
    }
    if (/currency/i.test(text) && /match/i.test(text)) {
        return 'currency';
    }
    return undefined;
}
