/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_GIVEX_GIFT_CARDS */

import type { ShopperBasketsV2 } from '@/scapi';
import { COMMERCE_APP_GIFT_CARD_PAYMENT_METHOD_ID } from './constants';

export type BasketPaymentInstrument = ShopperBasketsV2.schemas['OrderPaymentInstrument'];

/** Strip spaces and dashes from a gift-card PAN. */
export function normalizePan(value: string): string {
    return value.replace(/[\s-]/g, '');
}

/** Mask a PAN for display / SCAPI maskedNumber, keeping the last four digits. */
export function maskPan(pan: string): string {
    const digits = normalizePan(pan);
    if (digits.length <= 4) {
        return digits;
    }
    return `${'*'.repeat(Math.max(digits.length - 4, 4))}${digits.slice(-4)}`;
}

/** Luhn check for optional client-side PAN validation. */
export function passesLuhn(pan: string): boolean {
    const digits = normalizePan(pan);
    if (!/^\d+$/.test(digits)) {
        return false;
    }

    let sum = 0;
    let doubleDigit = false;
    for (let i = digits.length - 1; i >= 0; i -= 1) {
        let digit = Number(digits[i]);
        if (doubleDigit) {
            digit *= 2;
            if (digit > 9) {
                digit -= 9;
            }
        }
        sum += digit;
        doubleDigit = !doubleDigit;
    }
    return sum % 10 === 0;
}

/** True when the payment instrument is a Commerce App gift card. */
export function isGiftCardPaymentInstrument(instrument: BasketPaymentInstrument | undefined): boolean {
    return instrument?.paymentMethodId === COMMERCE_APP_GIFT_CARD_PAYMENT_METHOD_ID;
}

/** Gift-card instruments currently on the basket. */
export function getAppliedGiftCards(
    basket: ShopperBasketsV2.schemas['Basket'] | undefined
): BasketPaymentInstrument[] {
    return (basket?.paymentInstruments ?? []).filter(isGiftCardPaymentInstrument);
}

/** Last four digits for display. */
export function getGiftCardLastFour(instrument: BasketPaymentInstrument): string {
    const lastDigits = instrument.paymentCard?.numberLastDigits;
    if (lastDigits) {
        return String(lastDigits);
    }

    const masked = instrument.paymentCard?.maskedNumber ?? instrument.paymentCard?.number ?? '';
    const digits = String(masked).replace(/\D/g, '');
    return digits.slice(-4) || '••••';
}
