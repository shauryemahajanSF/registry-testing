/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_GIVEX_GIFT_CARDS */

import { normalizePan, passesLuhn } from './gift-card-utils';

export type PanValidationRules = {
    pattern?: string;
    minLength?: number;
    maxLength?: number;
    luhnEnabled?: boolean;
};

export type PanValidationResult = {
    valid: boolean;
    reason?: 'required' | 'pattern' | 'minLength' | 'maxLength' | 'luhn';
};

/**
 * Client-side PAN checks. Merchants can tighten rules via extension config
 * (mirrors optional BM site preferences for the checkout Payment component).
 */
export function validatePan(rawPan: string, rules: PanValidationRules = {}): PanValidationResult {
    const pan = normalizePan(rawPan);
    if (!pan) {
        return { valid: false, reason: 'required' };
    }

    if (rules.minLength != null && pan.length < rules.minLength) {
        return { valid: false, reason: 'minLength' };
    }

    if (rules.maxLength != null && pan.length > rules.maxLength) {
        return { valid: false, reason: 'maxLength' };
    }

    if (rules.pattern) {
        try {
            const re = new RegExp(rules.pattern);
            if (!re.test(pan)) {
                return { valid: false, reason: 'pattern' };
            }
        } catch {
            // Invalid merchant regex — skip pattern check rather than block apply.
        }
    }

    if (rules.luhnEnabled && !passesLuhn(pan)) {
        return { valid: false, reason: 'luhn' };
    }

    return { valid: true };
}
