'use strict';

var Money = require('dw/value/Money');
var givexHelper = require('*/cartridge/scripts/helpers/givexHelper');

/**
 * Stand-in for the currency code on a Givex DataConnect balance result.
 * The mock does not call Givex; this is the value parseRpcResult would return.
 * @returns {string}
 */
function givexBalanceCurrency() {
    var parsed = givexHelper.parseRpcResult({
        result: ['0', 'tx-mock', '0', 'USD']
    });
    return parsed.currency || 'USD';
}

exports.getBalance = function (request) {
    try {
        var cardNumber = givexHelper.extractCredentials(request).cardNumber;
        var currency = givexBalanceCurrency();
        var balances = {
            '7777111122223333': 20,
            '8888111122223333': 50,
            '9999111122223333': 250
        };

        if (cardNumber === '3333111122223333') {
            return new Money(0, currency);
        }
        // Kept as a currency-mismatch fixture. It stays EUR on purpose.
        if (cardNumber === '5555111122223333') {
            return new Money(50, 'EUR');
        }
        if (cardNumber && Object.prototype.hasOwnProperty.call(balances, cardNumber)) {
            return new Money(balances[cardNumber], currency);
        }

        return new Money(0, currency);
    } catch (e) {
        var Logger = require('dw/system/Logger');
        Logger.error('givex getBalance failed: {0}', e.message);
        return new Money(0, 'USD');
    }
};
