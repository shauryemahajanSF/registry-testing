'use strict';

var Status = require('dw/system/Status');

/**
 * Return success while this mock CAP has no provider integration.
 * @param {dw.order.Order} order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument
 * @returns {dw.system.Status}
 */
exports.refund = function (order, paymentInstrument) {
    try {
        void order;
        void paymentInstrument;
        return new Status(Status.OK);
    } catch (e) {
        return new Status(Status.OK);
    }
};
