'use strict';

/**
 * Givex DataConnect JSON-RPC service wrapper.
 *
 * Merchant credentials and base URL live on service credential
 * `givex.giftcards.credential` (user = Givex user ID, password = Givex
 * password, url = DataConnect endpoint). Auth values are placed in the
 * JSON-RPC params array, not HTTP headers.
 */

var LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');
var Logger = require('dw/system/Logger');

var logger = Logger.getLogger('givex-gift-cards', 'service');
var SERVICE_ID = 'givex.giftcards.api';

/**
 * Redacts card numbers, PINs, and passwords from log payloads.
 * @param {string} message - Raw log message
 * @returns {string} Filtered message
 */
function filterLogMessage(message) {
    if (!message) {
        return message;
    }
    return String(message)
        .replace(/("(?:card|gift[_-]?card)?[_-]?number"\s*:\s*")[^"]+/ig, '$1***')
        .replace(/("(?:pin|cvc|cvv|security[_-]?code)"\s*:\s*")[^"]+/ig, '$1***')
        .replace(/("password"\s*:\s*")[^"]+/ig, '$1***')
        .replace(/(\d{12,19})/g, '***');
}

/**
 * @returns {dw.svc.HTTPService} Configured service
 */
function getService() {
    return LocalServiceRegistry.createService(SERVICE_ID, {
        createRequest: function (svc, params) {
            svc.setRequestMethod('POST');
            svc.addHeader('Content-Type', 'application/json');
            svc.addHeader('Accept', 'application/json');
            return JSON.stringify(params);
        },
        parseResponse: function (svc, client) {
            var text = client && client.text ? client.text : '';
            try {
                return JSON.parse(text);
            } catch (e) {
                logger.error('Failed to parse Givex response: {0}', e.message);
                return {
                    error: { message: 'Invalid JSON from Givex', code: 'PARSE_ERROR' },
                    parseError: true,
                    raw: text
                };
            }
        },
        filterLogMessage: filterLogMessage,
        getRequestLogMessage: function (request) {
            return filterLogMessage(typeof request === 'string' ? request : JSON.stringify(request));
        },
        getResponseLogMessage: function (response) {
            return filterLogMessage(response && response.text ? response.text : '');
        }
    });
}

/**
 * @returns {{userId: string|null, password: string|null, url: string|null}}
 */
function getCredentials() {
    var credential = getService().getConfiguration().getCredential();
    if (!credential) {
        return { userId: null, password: null, url: null };
    }
    return {
        userId: credential.getUser() || null,
        password: credential.getPassword() || null,
        url: credential.getURL() || null
    };
}

/**
 * @param {string} method - Givex method code (for example "994")
 * @param {Array} rpcParams - Ordered JSON-RPC params
 * @returns {{success: boolean, data?: Object, error?: string, errorCode?: string}}
 */
function callMethod(method, rpcParams) {
    var credentials = getCredentials();
    if (!credentials.userId || !credentials.password) {
        return {
            success: false,
            errorCode: 'MISSING_CREDENTIALS',
            error: 'Givex service credentials are not configured'
        };
    }

    var payload = {
        jsonrpc: '2.0',
        id: String(Date.now()),
        method: String(method),
        params: rpcParams
    };

    var result = getService().call(payload);
    if (result.status !== 'OK') {
        return {
            success: false,
            errorCode: result.error || 'SERVICE_ERROR',
            error: result.errorMessage || 'Givex service call failed'
        };
    }

    return {
        success: true,
        data: result.object
    };
}

module.exports = {
    SERVICE_ID: SERVICE_ID,
    getCredentials: getCredentials,
    callMethod: callMethod,
    filterLogMessage: filterLogMessage
};
