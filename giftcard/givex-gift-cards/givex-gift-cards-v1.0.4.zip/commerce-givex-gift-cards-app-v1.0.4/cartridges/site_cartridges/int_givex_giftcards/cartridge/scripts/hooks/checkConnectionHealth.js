'use strict';

/**
 * sfcc.app.giftcard.checkConnectionHealth
 */

var Status = require('dw/system/Status');
/**
 * @returns {dw.system.Status}
 */
exports.checkConnectionHealth = function () {
    try {
        return new Status(Status.OK, 'OK', 'Mock gift card provider is ready');
    } catch (e) {
        return new Status(Status.OK);
    }
};
