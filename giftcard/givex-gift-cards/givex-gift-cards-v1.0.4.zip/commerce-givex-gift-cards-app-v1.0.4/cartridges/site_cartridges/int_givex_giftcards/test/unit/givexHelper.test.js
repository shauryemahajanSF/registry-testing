'use strict';

var assert = require('chai').assert;
var proxyquire = require('proxyquire').noCallThru();

describe('givexHelper', function () {
    var helper;

    beforeEach(function () {
        helper = proxyquire('../../cartridge/scripts/helpers/givexHelper', {
            'dw/system/Site': {
                getCurrent: function () {
                    return {
                        getCustomPreferenceValue: function (key) {
                            if (key === 'givexGiftCardsLanguage') {
                                return 'en';
                            }
                            if (key === 'givexGiftCardsCurrency') {
                                return 'USD';
                            }
                            return null;
                        }
                    };
                }
            },
            'dw/system/Logger': {
                getLogger: function () {
                    return {
                        warn: function () {},
                        error: function () {},
                        info: function () {}
                    };
                }
            }
        });
    });

    describe('extractCredentials', function () {
        it('reads providerProperties from the balance request shape', function () {
            var result = helper.extractCredentials({
                providerProperties: {
                    cardNumber: '6036-9900-1234-5678',
                    cvc: '1234',
                    currency: 'CAD'
                }
            });

            assert.strictEqual(result.cardNumber, '6036990012345678');
            assert.strictEqual(result.pin, '1234');
            assert.strictEqual(result.currencyCode, 'CAD');
        });

        it('reads giftCardRequest from the apply request shape', function () {
            var result = helper.extractCredentials({
                giftCardRequest: {
                    brand: 'givex',
                    cardNumber: '9999-1111-2222-3333',
                    cvc: '0000'
                }
            });

            assert.strictEqual(result.cardNumber, '9999111122223333');
            assert.strictEqual(result.pin, '0000');
        });

        it('reads giftCardRequest through record getters', function () {
            var result = helper.extractCredentials({
                getGiftCardRequest: function () {
                    return {
                        getCardNumber: function () {
                            return '7777111122223333';
                        },
                        getCvc: function () {
                            return '1234';
                        }
                    };
                }
            });

            assert.strictEqual(result.cardNumber, '7777111122223333');
            assert.strictEqual(result.pin, '1234');
        });

        it('reads providerProperties through Map.get when properties are absent', function () {
            var result = helper.extractCredentials({
                getProviderProperties: function () {
                    return {
                        get: function (key) {
                            var values = {
                                cardNumber: '8888111122223333',
                                pin: '4321'
                            };
                            return values[key];
                        }
                    };
                }
            });

            assert.strictEqual(result.cardNumber, '8888111122223333');
            assert.strictEqual(result.pin, '4321');
        });

        it('reads paymentCard from the apply request shape', function () {
            var result = helper.extractCredentials({
                paymentCard: {
                    number: '4111111111111111',
                    securityCode: '9999'
                }
            });

            assert.strictEqual(result.cardNumber, '4111111111111111');
            assert.strictEqual(result.pin, '9999');
        });
    });

    describe('parseRpcResult', function () {
        it('parses a successful balance payload', function () {
            var parsed = helper.parseRpcResult({
                result: ['0', 'tx-1', '42.50', 'USD', 'ref-99', 'OK']
            });

            assert.isTrue(parsed.ok);
            assert.strictEqual(parsed.balance, 42.5);
            assert.strictEqual(parsed.currency, 'USD');
            assert.strictEqual(parsed.transactionReference, 'ref-99');
        });

        it('marks provider declines as not ok', function () {
            var parsed = helper.parseRpcResult({
                result: ['2', 'tx-1', '0', 'USD', null, 'Card not found']
            });

            assert.isFalse(parsed.ok);
            assert.strictEqual(parsed.message, 'Card not found');
        });
    });

    describe('buildBalanceParams', function () {
        it('includes language, credentials, and card data', function () {
            var params = helper.buildBalanceParams('6036990012345678', '1234', 'user', 'pass');
            assert.strictEqual(params[0], 'en');
            assert.strictEqual(params[2], 'user');
            assert.strictEqual(params[3], 'pass');
            assert.strictEqual(params[4], '6036990012345678');
            assert.strictEqual(params[5], '1234');
        });
    });
});
