'use strict';

var sinon = require('sinon');

var preferences = {};

module.exports = {
    getCurrent: sinon.stub().returns({
        getCustomPreferenceValue: sinon.stub().callsFake(function (key) {
            return preferences[key] !== undefined ? preferences[key] : null;
        })
    }),
    // Test helper to set preferences
    _setPreferences: function (prefs) {
        preferences = prefs;
    },
    _reset: function () {
        preferences = {};
    }
};
