'use strict';

function ShippingLineItem() {}

module.exports = ShippingLineItem;
