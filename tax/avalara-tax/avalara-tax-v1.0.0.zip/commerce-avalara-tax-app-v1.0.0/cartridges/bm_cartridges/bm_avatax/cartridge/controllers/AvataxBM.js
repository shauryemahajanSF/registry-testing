/**
 * Description of the Controller and the logic it provides
 *
 * @module  controllers/Test
 */
'use strict';

/* Script Modules */
var app = require('~/cartridge/scripts/app');
var guard = require('~/cartridge/scripts/guard');
var isml = require('dw/template/ISML');
var OrderMgr = require('dw/order/OrderMgr');
var Site = require('dw/system/Site');
var dwsystem = require('dw/system');
var Status = require('dw/system/Status');
var dworder = require('dw/order');
var dwStringUtils = require("dw/util").StringUtils;
var dwutil = require("dw/util");
var dwvalue = require("dw/value");

//var CreateTransactionModel = require('int_avatax_svcclient/cartridge/models/createTransactionModel');
var avaTaxClient = require('int_avatax_svcclient/cartridge/scripts/avaTaxClient');

//Logger includes
var LOGGER = dw.system.Logger.getLogger('Avalara', 'AvaTax');

//Global variables
var atHelper = avataxHelper.prototype;
var companyCode = "";
var params = request.httpParameterMap;

function start() {
	let r = require('~/cartridge/scripts/util/Response');
	var currentMenuItemId = params.CurrentMenuItemId.value,
	menuname = request.httpParameterMap.menuname.value,
	mainmenuname = request.httpParameterMap.mainmenuname.value;
	session.custom.currentMenuItemId = currentMenuItemId;
	session.custom.menuname = menuname;
	session.custom.mainmenuname = mainmenuname;
	// Preserve the dates
	session.custom.fromdate = '';
	session.custom.todate = '';
	var viewObj  = {
			CurrentMenuItemId: currentMenuItemId,
			menuname: menuname,
			mainmenuname: mainmenuname
	}
	try {
		var siteInfo = getSiteInfo();
		viewObj.siteInfo = siteInfo;
		var avataxEnabled = Site.getCurrent().getCustomPreferenceValue('ATEnable');
		if (!avataxEnabled) {
			viewObj.errormsg = "AvaTax is not enabled in Custom Preferences. Please enable it by navigating to Custom Preferences > AvaTax, and try again."
		}
		else if (siteInfo.saveTransactionsToAvatax != 'Yes') {
			viewObj.errormsg = "Custom preference 'Save transactions to AvaTax' is not enabled. Please enable it by navigating to Custom Preferences > AvaTax, and try again."
		}
	} catch (e) {
		viewObj.errormsg = "No Site selected. Please select a site from the dropdown, and try again."
	}
	app.getView(viewObj).render('/avatax/ordersreconcile');
}

/**
 * Fetches order documents from SFCC and AvaTax
 * @param params - none
 */
function getOrders() {
	let r = require('~/cartridge/scripts/util/Response');
	var currentMenuItemId = session.custom.currentMenuItemId,
	menuname = session.custom.menuname,
	mainmenuname = session.custom.mainmenuname;
	var siteInfo = null,
	orders = null,
	ordersList = null,
	ordersOnAccount = null,
	reconcileResults = null,
	countReport = null,
	errormsg = null,
	reconciledOrders = null,
	viewObj = null;
	try {
		var avataxEnabled = Site.getCurrent().getCustomPreferenceValue('ATEnable');
		companyCode = dwsystem.Site.getCurrent().getCustomPreferenceValue("AtCompanyCode");
		if (!avataxEnabled) {
			viewObj = {
					errormsg: "AvaTax is not enabled in Custom Preferences. Please enable it at Custom Preferences > AvaTax, and try again.",
					CurrentMenuItemId: currentMenuItemId,
					menuname: menuname,
					mainmenuname: mainmenuname
			}
		} 
		else if (!(avataxHelper.prototype.saveTransactionsToAvatax())) {
			viewObj = {
					errormsg: "Custom preference 'Save transactions to AvaTax' is not enabled. Please enable it by navigating to Custom Preferences > AvaTax, and try again.",
					CurrentMenuItemId: currentMenuItemId,
					menuname: menuname,
					mainmenuname: mainmenuname
			}
		}
		else {
			siteInfo = getSiteInfo();
		}
	} catch (e) {
		viewObj = {
				errormsg: "No Site selected. Please select a site from the dropdown, and try again.",
				CurrentMenuItemId: currentMenuItemId,
				menuname: menuname,
				mainmenuname: mainmenuname
		}
	}
	if (siteInfo != null) {
		try {
			// Retrieve selected dates
			var fromdate = params.fromdate.value.toString(),
			todate = params.todate.value.toString();
			// save dates to make them accessible on ISML
			session.custom.fromdate = fromdate;
			session.custom.todate = todate;
			if (empty(fromdate) && empty(todate)) {
				orders = OrderMgr.queryOrders("orderNo != {0}", "creationDate desc", "*");
				ordersOnAccount = avaTaxClient.getTransactions(companyCode); // yyyy-mm-dd
				ordersList = orders.asList();
				orders.close();
				if (!ordersOnAccount.ERROR) {
					reconcileResults = reconcileTransactions(ordersList, ordersOnAccount.values);
					reconciledOrders = reconcileResults.orders;
					countReport = reconcileResults.countReport;
				} else {
					errormsg = "Error occured while contacting AvaTax services. If the problem persists, check service configuration settings and try again.";
				}
			} else if (empty(fromdate) || empty(todate)) {
				errormsg = "Please select appropriate date range and try again.";
			} else {
				var fromDateArray = [fromdate.split('/')[0], fromdate.split('/')[1], fromdate.split('/')[2]],
				toDateArray = [todate.split('/')[0], todate.split('/')[1], todate.split('/')[2]];
				var fdStr = fromDateArray[2] + '-' + fromDateArray[0] + '-' + fromDateArray[1],
				tdStr = toDateArray[2] + '-' + toDateArray[0] + '-' + toDateArray[1];
				var td1 = new Date((new Date(toDateArray[2], toDateArray[0], toDateArray[1])).getTime() + 1 * 24 * 60 * 60 * 1000);
				var tdStrSFCC = td1.getYear() + '-' + td1.getMonth() + '-' + td1.getDate();
				orders = OrderMgr.queryOrders("creationDate >= {0} AND creationDate <= {1}", "creationDate desc", fdStr, tdStrSFCC);
				ordersList = orders.asList();
				orders.close();
				ordersOnAccount = avaTaxClient.getTransactions(companyCode, fdStr, tdStr); // yyyy-mm-dd
				if (!ordersOnAccount.ERROR) {
					reconcileResults = reconcileTransactions(ordersList, ordersOnAccount.values);
					reconciledOrders = reconcileResults.orders;
					countReport = reconcileResults.countReport;
				} else {
					errormsg = "Error occured while contacting AvaTax services. If the problem persists, check service configuration settings and try again.";
				}
			}
			viewObj = {
					orders: reconciledOrders,
					siteInfo: siteInfo,
					CurrentMenuItemId: currentMenuItemId,
					menuname: menuname,
					mainmenuname: mainmenuname,
					countReport: countReport,
					errormsg: errormsg
			}
		} catch (e) {
			viewObj = {
					errormsg: "Problem while contacting AvaTax. Please check the logs for error details.",
					CurrentMenuItemId: currentMenuItemId,
					menuname: menuname,
					mainmenuname: mainmenuname
			}
		}
	}
	app.getView(viewObj).render('/avatax/ordersreconcile');
}

/** Reconciles the order documents from SFCC and AvaTax
 * @params param sfccOrders - orders collection from SFCC
 * @params param avaTax - orders collection from AvaTax  
 */
var amountMisMatch = 'Amount Mismatch';
var taxMisMatch = 'Tax Mismatch';
var missingInAvaTax = 'Missing In AvaTax';
var missingInSFCC = 'Missing In SFCC';

function reconcileTransactions(sfccOrders, avaTax) {
	let r = require('~/cartridge/scripts/util/Response');
	var countReport = {};
	var amountOrTaxMisMatchCount = 0,
	missingInAvaTaxCount = 0,
	missingInSFCCCount = 0;
	var result = [];
	var mapSFCCOrders = new dw.util.SortedMap();
	for (var i = 0; i < sfccOrders.size(); i++) {
		mapSFCCOrders.put(sfccOrders[i].orderNo, sfccOrders[i]);
		var avaTrans = avaTax.get(sfccOrders[i].orderNo);
		var rStatus = '',
		avTotalAmt, avTotalTax, avCurrency;
		if (avaTrans) {
			if (sfccOrders[i].totalNetPrice != avaTrans.totalAmount) {
				rStatus = amountMisMatch;
				amountOrTaxMisMatchCount++;
			} else if (sfccOrders[i].totalTax != avaTrans.totalTax) {
				rStatus = taxMisMatch;
				amountOrTaxMisMatchCount++;
			}
			avTotalAmt = avaTrans.totalAmount;
			avTotalTax = avaTrans.totalTax;
			avCurrency = avaTrans.currencyCode;
		} else {
			rStatus = missingInAvaTax;
			missingInAvaTaxCount++;
			avTotalAmt = '';
			avTotalTax = '';
		}
		if (rStatus != '') {
			result.push({
				orderNo: sfccOrders[i].orderNo,
				orderDate: sfccOrders[i].creationDate,
				orderStatus: sfccOrders[i].status,
				orderTotalAmt: sfccOrders[i].totalNetPrice,
				orderTax: sfccOrders[i].totalTax,
				avTotalAmt: avTotalAmt,
				avTotalTax: avTotalTax,
				avCurrencyCode : avCurrency,
				reconciliationStatus: rStatus
			});
		}
	}
	for (var i = 0; i < avaTax.keySet().toArray().length; i++) {
		var docCode = avaTax.keySet().toArray()[i];
		var avataxDoc = avaTax.get(docCode);
		var order = mapSFCCOrders.get(docCode);
		if (!order) {
			result.push({
				orderNo: avataxDoc.code,
				orderDate: avataxDoc.date,
				orderStatus: '-',
				orderTotalAmt: '-',
				orderTax: '-',
				avTotalAmt: avataxDoc.totalAmount,
				avTotalTax: avataxDoc.totalTax,
				avCurrencyCode: avataxDoc.currencyCode,
				reconciliationStatus: missingInSFCC
			});
			missingInSFCCCount++;
		}
	}
	countReport = {
			amountOrTaxMisMatchCount: amountOrTaxMisMatchCount,
			missingInAvaTaxCount: missingInAvaTaxCount,
			missingInSFCCCount: missingInSFCCCount
	};
	return {
		orders: result,
		countReport: countReport
	};
}

/**
 * Gets the site information and settings for the current site
 * @returns
 */
function getSiteInfo() {
	var siteInfoObj = {};
	var avataxEnabled = Site.getCurrent().getCustomPreferenceValue('ATEnable') ? "Enabled" : "Disabled",
			saveTransactionsToAvatax = avataxHelper.prototype.saveTransactionsToAvatax() ? "Yes" : "No",
					commitTransactionsToAvatax = avataxHelper.prototype.commitTransactionsToAvatax() ? "Yes" : "No",
							companyCode = avataxHelper.prototype.getCompanyCode(),
							defaultShippingMethodTaxCode = avataxHelper.prototype.getDefaultShippingMethodTaxCode(),
							siteName = Site.current.name,
							siteId = Site.current.ID;
	// Construct a shipFrom addressLocationInfo object from preferences
	var shipFromLocationCode = avataxHelper.prototype.getShipFromLocationCode(),
		shipFromLine1 = avataxHelper.prototype.getShipFromLine1(),
		shipFromLine2 = avataxHelper.prototype.getShipFromLine2(),
		shiFromLine3 = avataxHelper.prototype.getShipFromLine3(),
		shipFromCity = avataxHelper.prototype.getShipFromCity(),
		shipFromStateCode = avataxHelper.prototype.getShipFromStateCode(),
		shipFromZipCode = avataxHelper.prototype.getShipFromZipCode(),
		shipFromCountryCode = avataxHelper.prototype.getShipFromCountryCode(),
		shipFromLatitude = avataxHelper.prototype.getShipFromLatitude(),
		shipFromLongitude = avataxHelper.prototype.getShipFromLongitude();
	var aliShipFrom = {};
		aliShipFrom.locationCode = !empty(shipFromLocationCode) ? shipFromLocationCode : '';
		aliShipFrom.line1 = !empty(shipFromLine1) ? shipFromLine1 : '';
		aliShipFrom.line2 = !empty(shipFromLine2) ? shipFromLine2 : '';
		aliShipFrom.line3 = !empty(shiFromLine3) ? shiFromLine3 : '';
		aliShipFrom.city = !empty(shipFromCity) ? shipFromCity : '';
		aliShipFrom.region = !empty(shipFromStateCode) ? shipFromStateCode : '';
		aliShipFrom.postalCode = !empty(shipFromZipCode) ? shipFromZipCode : '';
		aliShipFrom.country = !empty(shipFromCountryCode) ? shipFromCountryCode : '';
		aliShipFrom.latitude = !empty(shipFromLatitude) ? shipFromLatitude : '';
		aliShipFrom.longitude = !empty(shipFromLongitude) ? shipFromLongitude : '';
	siteInfoObj = {
			avataxEnabled: avataxEnabled,
			siteName: siteName,
			siteId: siteId,
			shipFromAddress: aliShipFrom,
			saveTransactionsToAvatax: saveTransactionsToAvatax,
			commitTransactionsToAvatax: commitTransactionsToAvatax,
			companyCode: companyCode,
			defaultShippingMethodTaxCode: defaultShippingMethodTaxCode
	}
	return siteInfoObj;
}

function getSiteInfoAJAX() {
	let r = require('~/cartridge/scripts/util/Response');
	var siteInfo = getSiteInfo();
	r.renderJSON({
		siteInfo: siteInfo
	});
	return;
}

var AddressValidationInfo = require('int_avatax_svcclient/cartridge/models/addressValidationInfo');
var CreateTransactionModel = require('int_avatax_svcclient/cartridge/models/createTransactionModel');
var uuidLineNumbersMap = new dw.util.SortedMap(),
counter = 0;

function reconcile() {
	let r = require('~/cartridge/scripts/util/Response');
	var orderNo = params.orderno.value;
	if (!Site.getCurrent().getCustomPreferenceValue('ATEnable')) {
		LOGGER.warn('AvaTax | AvaTax not enabled for this site. File - avaTax.js~calculateTax');
		r.renderJSON({ 
			ERROR: true,
			fatalmsg: "AvaTax is disabled for this site."
		});
		return;
	}
	if (!orderNo) {
		r.renderJSON({
			ERROR: true
		});
		return;
	}
	try {
		var basket = OrderMgr.getOrder(orderNo.toString());
		uuidLineNumbersMap = new dw.util.SortedMap();
		counter = 0;
		var svcResponse = {},
		transactionModel = new CreateTransactionModel.CreateTransactionModel();
		var customerTaxId = !empty(customer.profile) ? customer.profile.taxID : null; // Tax ID of the customer
		var isSellerImporterOfRecord = !empty(customer.profile) ? customer.profile.custom.ATisSellerImporterOfRecord : false;
		// Lines array
		var lines = new Array();
		var defaultProductTaxCode = avataxHelper.prototype.getDefaultProductTaxCode();
		var defaultShippingMethodTaxCode = avataxHelper.prototype.getDefaultShippingMethodTaxCode();
		var taxIncluded = (dworder.TaxMgr.taxationPolicy == dworder.TaxMgr.TAX_POLICY_GROSS);
		// Save transaction preference in custom preferences
		var saveTransactionsToAvatax = avataxHelper.prototype.saveTransactionsToAvatax();
		// Commit transactions preference
		var commitTransactionsToAvatax = avataxHelper.prototype.commitTransactionsToAvatax();
		// Construct a shipFrom addressLocationInfo object from preferences
		var shipFromLocationCode = avataxHelper.prototype.getShipFromLocationCode(),
		shipFromLine1 = avataxHelper.prototype.getShipFromLine1(),
		shipFromLine2 = avataxHelper.prototype.getShipFromLine2(),
		shiFromLine3 = avataxHelper.prototype.getShipFromLine3(),
		shipFromCity = avataxHelper.prototype.getShipFromCity(),
		shipFromStateCode = avataxHelper.prototype.getShipFromStateCode(),
		shipFromZipCode = avataxHelper.prototype.getShipFromZipCode(),
		shipFromCountryCode = avataxHelper.prototype.getShipFromCountryCode(),
		shipFromLatitude = avataxHelper.prototype.getShipFromLatitude(),
		shipFromLongitude = avataxHelper.prototype.getShipFromLongitude();
		var aliShipFrom = new CreateTransactionModel.AddressLocationInfo();
		aliShipFrom.locationCode = !empty(shipFromLocationCode) ? shipFromLocationCode : '';
		aliShipFrom.line1 = !empty(shipFromLine1) ? shipFromLine1 : '';
		aliShipFrom.line2 = !empty(shipFromLine2) ? shipFromLine2 : '';
		aliShipFrom.line3 = !empty(shiFromLine3) ? shiFromLine3 : '';
		aliShipFrom.city = !empty(shipFromCity) ? shipFromCity : '';
		aliShipFrom.region = !empty(shipFromStateCode) ? shipFromStateCode : '';
		aliShipFrom.postalCode = !empty(shipFromZipCode) ? shipFromZipCode : '';
		aliShipFrom.country = !empty(shipFromCountryCode) ? shipFromCountryCode : '';
		aliShipFrom.latitude = !empty(shipFromLatitude) ? shipFromLatitude : '';
		aliShipFrom.longitude = !empty(shipFromLongitude) ? shipFromLongitude : '';
		var productLineItems = basket.productLineItems;
		var pliIterator = productLineItems.iterator();
		while (pliIterator.hasNext()) {
			var li = pliIterator.next();
			if (!empty(li.shipment.shippingAddress)) {
				// create a line item and push it to lines array
				var line = new CreateTransactionModel.LineItemModel();
				var shippingAddress = li.shipment.shippingAddress;
				var shipToAddress, shipFromAddress = aliShipFrom;
				// Construct a shipTo addressLocationInfo object from shippingAddress
				var aliShipTo = new CreateTransactionModel.AddressLocationInfo();
				aliShipTo.locationCode = '';
				aliShipTo.line1 = shippingAddress.address1;
				aliShipTo.line2 = shippingAddress.address2;
				aliShipTo.line3 = '';
				aliShipTo.city = shippingAddress.city;
				aliShipTo.region = shippingAddress.stateCode;
				aliShipTo.country = shippingAddress.countryCode.getDisplayValue().toString();
				aliShipTo.postalCode = shippingAddress.postalCode;
				aliShipTo.latitude = '';
				aliShipTo.longitude = '';
				shipToAddress = aliShipTo;
				// ------------------------ //
				uuidLineNumbersMap.put((++counter).toString(), li.UUID); // assign an integer value
				line.number = counter;
				line.quantity = li.quantityValue;
				line.amount = li.proratedPrice.value;
				// addresses model
				line.addresses = new CreateTransactionModel.AddressesModel();
				line.addresses.shipFrom = shipFromAddress;
				line.addresses.shipTo = shipToAddress;
				line.taxCode = !empty(li.getProduct().taxClassID) ? li.getProduct().taxClassID : defaultProductTaxCode;
				line.customerUsageType = null;
				line.itemCode = (!empty(li.product.UPC) ? ("UPC:" + li.product.UPC) : li.productName).substring(0, 50);
				line.exemptionCode = null;
				line.discounted = false;
				line.taxIncluded = taxIncluded;
				line.revenueAccount = null;
				line.ref1 = null;
				line.ref2 = null;
				line.description = li.productName;
				line.businessIdentificationNo = customerTaxId;
				line.taxOverride = null;
				line.parameters = null;
				lines.push(line);
				var oliIterator = li.optionProductLineItems.iterator();
				while (oliIterator.hasNext()) {
					// create a line item and push it to lines array
					var oli = oliIterator.next();
					var line = new CreateTransactionModel.LineItemModel();
					uuidLineNumbersMap.put((++counter).toString(), oli.UUID); // assign an integer value
					line.number = counter;
					line.quantity = oli.quantityValue;
					line.amount = oli.proratedPrice.value;
					// Addresses model
					line.addresses = new CreateTransactionModel.AddressesModel();
					line.addresses.shipFrom = shipFromAddress;
					line.addresses.shipTo = shipToAddress;
					line.taxCode = !empty(oli.taxClassID) ? oli.taxClassID : defaultProductTaxCode;
					line.customerUsageType = null;
					line.itemCode = oli.productName.substring(0, 50);
					line.exemptionCode = null;
					line.discounted = false;
					line.taxIncluded = taxIncluded;
					line.revenueAccount = null;
					line.ref1 = null;
					line.ref2 = null;
					line.description = oli.productName;
					line.businessIdentificationNo = customerTaxId;
					line.taxOverride = null;
					line.parameters = null;
					lines.push(line);
				}
				if (!empty(li.shippingLineItem)) {
					// create a line item and push it to lines array
					var sli = li.shippingLineItem;
					var line = new CreateTransactionModel.LineItemModel();
					uuidLineNumbersMap.put((++counter).toString(), sli.UUID); // assign an integer value
					line.number = counter;
					line.quantity = 1;
					line.amount = sli.adjustedPrice.value;
					// Addresse model
					line.addresses = new CreateTransactionModel.AddressesModel();
					line.addresses.shipFrom = shipFromAddress;
					line.addresses.shipTo = shipToAddress;
					line.taxCode = !empty(sli.taxClassID) ? sli.taxClassID : defaultShippingMethodTaxCode;
					line.customerUsageType = null;
					line.itemCode = sli.lineItemText.substring(0, 50);
					line.exemptionCode = null;
					line.discounted = false;
					line.taxIncluded = taxIncluded;
					line.revenueAccount = null;
					line.ref1 = null;
					line.ref2 = null;
					line.description = sli.lineItemText;
					line.businessIdentificationNo = customerTaxId;
					line.taxOverride = null;
					line.parameters = null;
					lines.push(line);
				}
			}
		}
		// Create shipping line items
		var shipmentsIterator = basket.shipments.iterator();
		while (shipmentsIterator.hasNext()) {
			var shipment = shipmentsIterator.next();
			if (!empty(shipment.shippingAddress)) {
				var shippingLineItemsIterator = shipment.shippingLineItems.iterator();
				while (shippingLineItemsIterator.hasNext()) {
					var li = shippingLineItemsIterator.next();
					var line = new CreateTransactionModel.LineItemModel();
					uuidLineNumbersMap.put((++counter).toString(), li.UUID); // assign an integer value
					line.number = counter;
					line.quantity = 1;
					line.amount = li.adjustedPrice.value;
					// Addresse model
					let shippingAddress = shipment.shippingAddress;
					line.addresses = new CreateTransactionModel.AddressesModel();
					line.addresses.shipFrom = aliShipFrom;
					// Construct a shipTo addressLocationInfo object from shippingAddress
					var aliShipTo = new CreateTransactionModel.AddressLocationInfo();
					aliShipTo.locationCode = '';
					aliShipTo.line1 = shippingAddress.address1;
					aliShipTo.line2 = shippingAddress.address2;
					aliShipTo.line3 = '';
					aliShipTo.city = shippingAddress.city;
					aliShipTo.region = shippingAddress.stateCode;
					aliShipTo.country = shippingAddress.countryCode.getDisplayValue().toString();
					aliShipTo.postalCode = shippingAddress.postalCode;
					aliShipTo.latitude = '';
					aliShipTo.longitude = '';
					line.addresses.shipTo = aliShipTo;
					line.taxCode = !empty(li.taxClassID) ? li.taxClassID : defaultShippingMethodTaxCode;
					line.customerUsageType = null;
					line.itemCode = li.ID.substring(0, 50);
					line.exemptionCode = null;
					line.discounted = false;
					line.taxIncluded = taxIncluded;
					line.revenueAccount = null;
					line.ref1 = null;
					line.ref2 = null;
					line.description = li.lineItemText;
					line.businessIdentificationNo = customerTaxId;
					line.taxOverride = null;
					line.parameters = null;
					lines.push(line);
				}
			}
		}
		// gift cert lines
		var giftCertLinesIterator = basket.giftCertificateLineItems.iterator();
		while (giftCertLinesIterator.hasNext()) {
			var giftCert = giftCertLinesIterator.next();
			var gs = giftCert.shipment;
			if (!empty(gs.shippingAddress)) {
				var line = new CreateTransactionModel.LineItemModel();
				uuidLineNumbersMap.put((++counter).toString(), giftCert.UUID); // assign an integer value
				line.number = counter;
				line.quantity = 1;
				line.amount = giftCert.getPriceValue();
				// Addresse model
				line.addresses = new CreateTransactionModel.AddressesModel();
				line.addresses.shipFrom = aliShipFrom;
				// Construct a shipTo addressLocationInfo object from shippingAddress
				var gsShipTo = new CreateTransactionModel.AddressLocationInfo();
				gsShipTo.locationCode = '';
				gsShipTo.line1 = gs.shippingAddress.address1;
				gsShipTo.line2 = gs.shippingAddress.address2;
				gsShipTo.line3 = '';
				gsShipTo.city = gs.shippingAddress.city;
				gsShipTo.region = gs.shippingAddress.stateCode;
				gsShipTo.country = gs.shippingAddress.countryCode.getDisplayValue().toString();
				gsShipTo.postalCode = gs.shippingAddress.postalCode;
				gsShipTo.latitude = '';
				gsShipTo.longitude = '';
				line.addresses.shipTo = gsShipTo;
				line.taxCode = !empty(giftCert.taxClassID) ? giftCert.taxClassID : "PG050000"; // PG050000
				line.customerUsageType = null;
				line.itemCode = giftCert.lineItemText.substring(0, 50);
				line.exemptionCode = null;
				line.discounted = false;
				line.taxIncluded = taxIncluded;
				line.revenueAccount = null;
				line.ref1 = null;
				line.ref2 = null;
				line.description = giftCert.lineItemText;
				line.businessIdentificationNo = customerTaxId;
				line.taxOverride = null;
				line.parameters = null;
				lines.push(line);
			} else {
				if (!empty(basket.billingAddress)) {
					var line = new CreateTransactionModel.LineItemModel();
					var shipToAddress = basket.billingAddress;
					uuidLineNumbersMap.put((++counter).toString(), giftCert.UUID); // assign an integer value
					line.number = counter;
					line.quantity = 1;
					line.amount = giftCert.getPriceValue();
					// Addresse model
					line.addresses = new CreateTransactionModel.AddressesModel();
					line.addresses.shipFrom = aliShipFrom;
					// Construct a shipTo addressLocationInfo object from shippingAddress
					var gsShipTo = new CreateTransactionModel.AddressLocationInfo();
					gsShipTo.locationCode = '';
					gsShipTo.line1 = shipToAddress.address1;
					gsShipTo.line2 = shipToAddress.address2;
					gsShipTo.line3 = '';
					gsShipTo.city = shipToAddress.city;
					gsShipTo.region = shipToAddress.stateCode;
					gsShipTo.country = shipToAddress.countryCode.getDisplayValue().toString();
					gsShipTo.postalCode = shipToAddress.postalCode;
					gsShipTo.latitude = '';
					gsShipTo.longitude = '';
					line.addresses.shipTo = gsShipTo;
					line.taxCode = !empty(giftCert.taxClassID) ? giftCert.taxClassID : "PG050000"; // PG050000
					line.customerUsageType = null;
					line.itemCode = giftCert.lineItemText.substring(0, 50);
					line.exemptionCode = null;
					line.discounted = false;
					line.taxIncluded = taxIncluded;
					line.revenueAccount = null;
					line.ref1 = null;
					line.ref2 = null;
					line.description = giftCert.lineItemText;
					line.businessIdentificationNo = customerTaxId;
					line.taxOverride = null;
					line.parameters = null;
					lines.push(line);
				}
			}
		}
		// Lines array - END
		// Construct a transaction object
		if (orderNo) {
			transactionModel.code = orderNo;
			//  If commit document not enabled in site preferences, type is SalesOrder
			if (saveTransactionsToAvatax) {
				transactionModel.type = transactionModel.type.C_SALESINVOICE;
			} else {
				transactionModel.type = transactionModel.type.C_SALESORDER;
			}
		} else {
			r.renderJSON({
				ERROR: true,
				msg: "Order number empty",
				orderno: orderNo,
			});
			return;
		}
		transactionModel.lines = lines;
		transactionModel.commit = (commitTransactionsToAvatax && orderNo) ? true : false;
		transactionModel.companyCode = avataxHelper.prototype.getCompanyCode();
		transactionModel.date = basket.creationDate;
		transactionModel.salespersonCode = null;
		transactionModel.customerCode = empty(basket.getCustomerEmail()) ? "so-cust-code" : basket.getCustomerEmail();
		transactionModel.debugLevel = transactionModel.debugLevel.C_NORMAL;
		transactionModel.serviceMode = transactionModel.serviceMode.C_AUTOMATIC;
		transactionModel.businessIdentificationNo = customerTaxId;
		transactionModel.currencyCode = basket.currencyCode;
		transactionModel.isSellerImporterOfRecord = isSellerImporterOfRecord;
		// ********* 	Call the tax adjustment service 	********** //
		svcResponse = avaTaxClient.createOrAdjustTransaction('', {
			"createTransactionModel": transactionModel
		});
		// If AvaTax returns error, set taxes to Zero
		if (svcResponse.statusCode == 'ERROR') {
			var errormsg = svcResponse.errorMessage.error.details[0].message + " Details - " + svcResponse.errorMessage.error.details[0].description;
			// If error code in response is 'missingline', update logs
			if (svcResponse.errorMessage.error.code && svcResponse.errorMessage.error.code == 'MissingLine') {
				LOGGER.warn("AvaTax | AvaTax couldn't calculate taxes. Empty basket or empty shippingaddress. Basket details - " + basket);
				errormsg = "Empty basket or empty shippingaddress";
			}
			r.renderJSON({
				ERROR: true,
				msg: errormsg,
				orderno: orderNo,
			});
			return;
		}
		// If taxes cannot be calculated
		if (svcResponse.errorMessage) {
			var errormsg = svcResponse.errorMessage.error.details[0].message + " Details - " + svcResponse.errorMessage.error.details[0].description;
			r.renderJSON({
				ERROR: true,
				msg: errormsg,
				orderno: orderNo,
			});
			return;
		}
		if (!svcResponse.statusCode) {
			r.renderJSON({
				ERROR: false,
				orderno: orderNo,
				taxAmt: svcResponse.totalTax,
				totalAmt: svcResponse.totalAmount
			});
			return;
		} else {
			var errormsg = svcResponse.errorMessage.error.details[0].message + " Details - " + svcResponse.errorMessage.error.details[0].description;
			r.renderJSON({
				ERROR: true,
				msg: errormsg,
				orderno: orderNo,
			});
			return;
		}
	} catch (e) {
		LOGGER.warn("[Avatax gettax failed - {0}. File - AvataxBM.js]", e.message);
		r.renderJSON({
			ERROR: true,
			msg: e.message
		});
		return;
	}
}

function avataxHelper() {}

avataxHelper.prototype = {
		// Get the Line item by its UUID
		getLineItemByUUID: function(basket, uuid) {
			var allLineItemsIterator = basket.allLineItems.iterator();
			while (allLineItemsIterator.hasNext()) {
				var li = allLineItemsIterator.next();
				if (li.UUID === uuid) {
					return li;
				} else if ("shippingLineItem" in li && !empty(li.shippingLineItem) && li.shippingLineItem.UUID === uuid) {
					return li.shippingLineItem;
				}
			}
			return null;
		},
		getCustomerCodePreference: function() {
			return dwsystem.Site.getCurrent().getCustomPreferenceValue("ATCustomerCode");
		},
		saveTransactionsToAvatax: function() {
			return dwsystem.Site.getCurrent().getCustomPreferenceValue("AtDocumentCommitAllowed");
		},
		commitTransactionsToAvatax: function() {
			return dwsystem.Site.getCurrent().getCustomPreferenceValue("AtCommitTransaction");
		},
		getDefaultShippingMethodTaxCode: function() {
			return dwsystem.Site.getCurrent().getCustomPreferenceValue("AtDefaultShippingMethodTaxCode");
		},
		getDefaultProductTaxCode: function() {
			// No longer being used. Hence returning an empty string.
			// return dwsystem.Site.getCurrent().getCustomPreferenceValue("AtDefaultProductTaxCode");
			return '';
		},
		getShipFromLocationCode: function() {
			return dwsystem.Site.getCurrent().getCustomPreferenceValue("AtShipFromLocationCode");
		},
		getShipFromLine1: function() {
			return dwsystem.Site.getCurrent().getCustomPreferenceValue("AtShipFromLine1");
		},
		getShipFromLine2: function() {
			return dwsystem.Site.getCurrent().getCustomPreferenceValue("AtShipFromLine2");
		},
		getShipFromLine3: function() {
			return dwsystem.Site.getCurrent().getCustomPreferenceValue("AtShipFromLine3");
		},
		getShipFromLatitude: function() {
			return dwsystem.Site.getCurrent().getCustomPreferenceValue("AtShipFromLatitude");
		},
		getShipFromLongitude: function() {
			return dwsystem.Site.getCurrent().getCustomPreferenceValue("AtShipFromLongitude");
		},
		getShipFromCity: function() {
			return dwsystem.Site.getCurrent().getCustomPreferenceValue("AtShipFromCity");
		},
		getShipFromStateCode: function() {
			return dwsystem.Site.getCurrent().getCustomPreferenceValue("AtShipFromStateCode");
		},
		getShipFromZipCode: function() {
			return dwsystem.Site.getCurrent().getCustomPreferenceValue("AtShipFromZipCode");
		},
		getShipFromCountryCode: function() {
			return dwsystem.Site.getCurrent().getCustomPreferenceValue("AtShipFromCountryCode");
		},
		getCompanyCode: function() {
			return dwsystem.Site.getCurrent().getCustomPreferenceValue("AtCompanyCode");
		},
		getFormattedDate: function() {
			var date = new Date();
			return dwStringUtils.format('{0}-{1}-{2}', date.getFullYear().toString(), this.insertLeadingZero(date.getMonth() + 1), this.insertLeadingZero(date.getDate()));
		},
		insertLeadingZero: function(nb) {
			if (nb < 10) {
				return "0" + nb;
			} else {
				return "" + nb;
			}
		}
};

exports.Start = guard.ensure(['https'], start);
exports.GetOrders = guard.ensure(['https'], getOrders);
exports.Reconcile = guard.ensure(['https', 'post'], reconcile);
exports.GetSiteInfoAJAX = guard.ensure(['https'], getSiteInfoAJAX);
