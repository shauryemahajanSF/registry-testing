'use strict';

function createOrAdjustTransactionModel() {
	this.createTransactionModel = null;
	
	return this;
}

module.exports.CreateOrAdjustTransactionModel = createOrAdjustTransactionModel;