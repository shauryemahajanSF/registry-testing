'use strict';

function commitTransactionModel() {
	this.commit = false;
	
	return this;
}



module.exports.CommitTransactionModel = commitTransactionModel;