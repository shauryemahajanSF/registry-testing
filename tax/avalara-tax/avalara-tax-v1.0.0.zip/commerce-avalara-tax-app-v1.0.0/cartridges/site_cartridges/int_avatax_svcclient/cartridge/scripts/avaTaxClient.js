/*
 * AvaTax REST service client
 */

'use strict';

//API includes
var dwsvc = require('dw/svc');

var LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');

//Custom logger
var LOGGER = dw.system.Logger.getLogger("Avalara", "AvaTax");

//Global service componentnts
var svc, config, credential, url, user, password, encodedAuthStr, clientHeaderStr;


/**
 * Initialize the service components
 */
function initservice() {
    //Create a service object
    svc = LocalServiceRegistry.createService("avatax.rest.all", {
        createRequest: function(svc, args) {
            if (args) {
                return JSON.stringify(args);
            } else {
                return null;
            }
        },
        parseResponse: function(svc, client) {
            return client.text;
        }
    });
    //Configure the service related parameters
    config = svc.getConfiguration();
    credential = config.getCredential();
    url = !empty(credential.getURL()) ? credential.getURL() : '';
    user = credential.getUser();
    password = credential.getPassword();
    encodedAuthStr = dw.util.StringUtils.encodeBase64(user + ':' + password);
    if (session.custom.sitesource && session.custom.sitesource == 'sgjc') {
        clientHeaderStr = "AvaTax for SFCC/SGJC || 19.1v2";
    } else {
        clientHeaderStr = "AvaTax for SFCC/SFRA || 3.0v2";
    }
    svc.addHeader('Accept', 'application/json');
    svc.addHeader('X-Avalara-Client', clientHeaderStr);
    svc.addHeader('Authorization', 'Basic ' + encodedAuthStr);
}


function getAuthInfo() {
    initservice();
    initLeService();
    return {
        url: url,
        user: user,
        le_url: le_url
    };
}


//Logentries variables
var le_svc, le_config, le_credential, le_url, le_svcresponse;
/**
 * Initialize the log entries service and retrieve the related configuration
 */
function initLeService() {
    // Logentries service
    le_svc = LocalServiceRegistry.createService("logentries.avatax.svc", {
        createRequest: function(svc, args) {
            if (args) {
                return JSON.stringify(args);
            } else {
                return null;
            }
        },
        parseResponse: function(svc, client) {
            return client.text;
        }
    });
    //Configure the service related parameters
    le_config = le_svc.getConfiguration();
    le_credential = le_config.getCredential();
    if (url.toLowerCase().indexOf('sandbox') == -1) {
        if (session.custom.sitesource && session.custom.sitesource == 'sgjc') {
            le_url = le_credential.getURL() + '1e91ee1e-5803-4190-82d6-7e20cd03300d'; // logentries sgjc production
        } else {
            le_url = le_credential.getURL() + 'd220e459-1119-46b8-8b3b-8aa4dee04245'; // logentries sfra production
        }
    } else {
        if (session.custom.sitesource && session.custom.sitesource == 'sgjc') {
            le_url = le_credential.getURL() + '6e7e8a4d-e107-43fc-ade7-90bd69f83856'; // logentries sgjc development
        } else {
            le_url = le_credential.getURL() + '78bf832b-72c4-4bf6-a062-39948937dcfb'; // logentries sfra development
        }
    }
    le_svc.setURL(le_url);
    le_svc.addHeader('Content-Type', 'application/json');
}


/**
 * Log the log details to logentries server using the logentries service call
 */
function leLog(jsonLog) {
    initLeService();
    le_svcresponse = le_svc.call(jsonLog);
    if (le_svcresponse.status != "OK") {
        LOGGER.warn('Got an error calling:' + le_url + '. The status code is: ' + le_svcresponse.status +
            ', and the text is: ' + le_svcresponse +
            ' and the error text is: ' + le_svcresponse.getErrorMessage());
        var errorResult = {
            statusCode: le_svcresponse.status,
            errorMessage: JSON.parse(le_svcresponse.getErrorMessage()),
            url: le_url
        };
        return errorResult;
    } else {
        // return a plain javascript object
        return {
            success: true
        };
    }
}


/**
 * Filters the service response object.
 * Returns error details if unsuccessful. Otherwise, the response JSON.
 */
function responseFilter(httpResponse) {
    if (httpResponse.status != "OK") {
        var errorResult = {
            statusCode: httpResponse.status,
            errorMessage: JSON.parse(httpResponse.getErrorMessage()),
            url: url
        };
        return errorResult;
    } else {
        // return a plain javascript object
        return JSON.parse(httpResponse.object);
    }
}


/**
 * Helps diagnose connectivity problems between the application and AvaTax.
 * @param params - N/A
 * @returns {Object} a response object that contains information about the authentication
 */
function testConnection() {
    initservice();
    url += "api/v2/utilities/ping";
    svc.setRequestMethod("GET");
    svc.setURL(url);
    // service call
    var httpResult = svc.call();
    return responseFilter(httpResult);
}


/**
 * Resolve an address against Avalara's address-validation system
 * @param params - addressValidationInfo object
 * @returns {Object} a response object that contains information about the validated address
 */
function resolveAddressPost(addressValidationInfo) {
    initservice();
    url += "api/v2/addresses/resolve";
    svc.setRequestMethod("POST");
    svc.setURL(url);
    // service call
    var httpResult = svc.call(addressValidationInfo);
    return responseFilter(httpResult);
}


/**
 * Records a new transaction in AvaTax.
 * @param params - createTransactionModel object - refer AvaTax documentation
 * @param params - include object - refer AvaTax documentation
 * @returns {Object} a response object that contains information about the taxes
 */
function createTransaction(createTransactionModel, include) {
    initservice();
    url += 'api/v2/transactions/create' + (!empty(include) ? '?$include=' + include : '');
    svc.setRequestMethod('POST');
    svc.setURL(url);
    // service call
    var httpResult = svc.call(createTransactionModel);
    return responseFilter(httpResult);
}


/**
 * Calls a service to get transaction details by transaction code and document type
 * @param params - companyCode - refer AvaTax documentation
 * @param params - transactionCode - Order number in SFCC - refer AvaTax documentation
 * @param params - documentType - Document type
 * @param params - include variable
 * @returns {Object} a response object that contains information about the transaction details
 */
function getTransactionByCodeAndType(companyCode, transactionCode, documentType, include) {
    initservice();
    url += 'api/v2/companies/' + companyCode + '/transactions/' + transactionCode + '/types/' + documentType + !empty(include) ? '?$include=' + include : '';
    svc.setRequestMethod('GET');
    svc.setURL(url);
    // service call
    var httpResult = svc.call(createTransactionModel);
    return responseFilter(httpResult);
}


/**
 * Marks a transaction by changing its status to 'Committed'
 * @param params - companyCode - refer AvaTax documentation
 * @param params - transactionCode - Order number in SFCC - refer AvaTax documentation
 * @param params - commitTransactionModel object
 * @param params - documentType string
 * @returns {Object} a response object that contains information about the transaction
 */
function commitTransaction(companyCode, transactionCode, commitTransactionModel, documentType) {
    initservice();
    url += 'api/v2/companies/' + companyCode + '/transactions/' + transactionCode + '/commit' + (!empty(documentType) ? '?documentType=' + documentType : '');
    svc.setRequestMethod('POST');
    svc.setURL(url);
    // service call
    var httpResult = svc.call(commitTransactionModel);
    return responseFilter(httpResult);
}


/**
 * Records a new transaction or adjust an existing transaction in AvaTax
 * @param params - include string
 * @param params - createOrAdjustTransactionModel object
 * @returns {Object} a response object that contains information about the transaction
 */
function createOrAdjustTransaction(include, createOrAdjustTransactionModel) {
    initservice();
    url += 'api/v2/transactions/createoradjust' + (!empty(include) ? '?$include=' + include : '');
    svc.setRequestMethod('POST');
    svc.setURL(url);
    // service call
    var httpResult = svc.call(createOrAdjustTransactionModel);
    return responseFilter(httpResult);
}


/**
 * Voids the current transaction uniquely identified by transactionCode.
 * @param params - companyCode string
 * @param params - transactionCode string
 * @param params - voidTransactionModel object
 * @returns {Object} a response object that contains information about the transaction being voided
 */
function voidTranaction(companyCode, transactionCode, voidTransactionModel) {
    initservice();
    url += 'api/v2/companies/' + companyCode + '/transactions/' + transactionCode + '/void';
    svc.setRequestMethod('POST');
    svc.setURL(url);
    // service call
    var httpResult = svc.call(voidTransactionModel);
    return responseFilter(httpResult);
}


/**
 * Replaces the current transaction uniquely identified by this URL with a new transaction.
 * @param params - companyCode string
 * @param params - transactionCode string
 * @param params - adjustTransactionModel object
 * @returns {Object} a response object that contains information about the transaction being adjusted
 */
function adjustTransaction(companyCode, transactionCode, adjustTransactionModel) {
    initservice();
    url += 'api/v2/companies/' + companyCode + '/transactions/' + transactionCode + '/adjust';
    svc.setRequestMethod('POST');
    svc.setURL(url);
    // service call
    var httpResult = svc.call(adjustTransactionModel);
    return responseFilter(httpResult);
}


/**
 * Renames a transaction uniquely identified by this URL by changing its code value.
 * @param params - companyCode string
 * @param params - transactionCode string
 * @param params - changeTransactionModel object
 * @returns {Object} a response object that contains information about the transaction being changed
 */
function changeTransactionCode(companyCode, transactionCode, changeTransactionModel) {
    initservice();
    url += 'api/v2/companies/' + companyCode + '/transactions/' + transactionCode + '/changecode';
    svc.setRequestMethod('POST');
    svc.setURL(url);
    // service call
    var httpResult = svc.call(changeTransactionModel);
    return responseFilter(httpResult);
}


/**
 * Gets all transactions for specified company
 * @param params - companyCode string
 * @returns {Object} a colletion object that contains information about the transactions
 */
function getTransactions(companyCode) {
    initservice();
    url += 'api/v2/companies/' + companyCode + '/transactions';
    url = encodeURI(url);
    svc.setRequestMethod('GET');
    svc.setURL(url);
    // service call
    var httpResult = svc.call();
    return responseFilter(httpResult);
}

/**
 * Gets all transactions for specified company for specified date range
 * @param params - companyCode string
 * @returns {Object} a colletion object that contains information about the transactions
 */
function getTransactions(companyCode, fromDate, toDate) {
    initservice();
    if (empty(fromDate) || empty(toDate)) {
        url += 'api/v2/companies/' + companyCode + '/transactions';
    } else {
        url += 'api/v2/companies/' + companyCode + '/transactions?$filter=date between \'' + fromDate + '\' and \'' + toDate + '\' AND status <> Adjusted';
    }
    url = encodeURI(url);
    svc.setRequestMethod('GET');
    svc.setURL(url);
    // service call
    var httpResult = svc.call();
    var result = null;
    var records;
    if (httpResult.status != "OK") {
        result = {
            status: 'error',
            values: null,
            errorMessage: JSON.parse(httpResponse.getErrorMessage()),
        }
    } else {
        // return a plain javascript object
        records = JSON.parse((httpResult.object).replace('@nextLink', 'nextLink'));
    }
    var sm = new dw.util.SortedMap();
    if (records.value) {
        for (var i = 0; i < records.value.length; i++) {
            sm.put(records.value[i].code, records.value[i]);
        }
        while (records.nextLink) {
            initservice(); //
            url += records.nextLink;
            url = encodeURI(url);
            svc.setRequestMethod('GET');
            svc.setURL(url);
            // service call
            var httpResult1 = svc.call();
            var record1;
            if (httpResult1.status != "OK") {
                result = {
                    status: 'error',
                    values: null,
                    errorMessage: JSON.parse(httpResponse.getErrorMessage()),
                }
            } else {
                // return a plain javascript object
                record1 = JSON.parse((httpResult1.object).replace('@nextLink', 'nextLink'));
                if (record1.value) {
                    for (var i = 0; i < record1.value.length; i++) {
                        sm.put(record1.value[i].code, record1.value[i]);
                    }
                }
            }
        }
        result = {
            ERROR: false,
            values: sm
        }
    } else {
        result = {
            ERROR: true,
            values: null
        }
    }
    return result;
}
//Module exports
module.exports = {
    testConnection: testConnection,
    resolveAddressPost: resolveAddressPost,
    createTransaction: createTransaction,
    getTransactionByCodeAndType: getTransactionByCodeAndType,
    commitTransaction: commitTransaction,
    createOrAdjustTransaction: createOrAdjustTransaction,
    voidTranaction: voidTranaction,
    adjustTransaction: adjustTransaction,
    changeTransactionCode: changeTransactionCode,
    getAuthInfo: getAuthInfo,
    leLog: leLog,
    getTransactions: getTransactions
};
