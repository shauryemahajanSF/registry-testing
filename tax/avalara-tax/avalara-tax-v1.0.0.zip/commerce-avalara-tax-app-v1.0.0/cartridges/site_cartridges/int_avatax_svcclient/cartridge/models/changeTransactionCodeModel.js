'use strict';

function changeTransactionCodeModel() {
	this.newCode = '';
	
	return this;
}



module.exports.ChangeTransactionCodeModel = changeTransactionCodeModel;