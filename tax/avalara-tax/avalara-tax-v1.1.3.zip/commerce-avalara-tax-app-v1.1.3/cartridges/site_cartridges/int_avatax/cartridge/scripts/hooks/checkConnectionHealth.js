'use strict';

var Status = require('dw/system/Status');
var avataxService = require('*/cartridge/scripts/services/avataxService');

/**
 * Connection health check hook for the Avalara Tax app.
 * Pings the AvaTax /api/v2/utilities/ping endpoint to verify connectivity.
 *
 * @returns {dw.system.Status} Health status with message and remediation details
 */
exports.checkConnectionHealth = function () {
    try {
        var result = avataxService.call('GET', '/api/v2/utilities/ping', null);

        if (result.success && result.data && result.data.authenticated === true) {
            var status = new Status(Status.OK, 'HEALTHY');
            status.addDetail('message', 'Avalara service responded in ' + result.latency + 'ms');
            return status;
        }

        if (result.success && result.data && result.data.authenticated === false) {
            var degraded = new Status(Status.ERROR, 'DEGRADED');
            degraded.addDetail('message', 'Avalara service is reachable but credentials are not authenticated');
            degraded.addDetail('remediation', 'Verify your Avalara API credentials in Administration > Operations > Services > avatax.rest.all');
            return degraded;
        }

        var unhealthy = new Status(Status.ERROR, 'UNHEALTHY');
        unhealthy.addDetail('message', 'Unable to reach Avalara service' + (result.error ? ': ' + result.error : ''));
        unhealthy.addDetail('remediation', 'Check that the Avalara service URL and credentials are configured correctly in Administration > Operations > Services > avatax.rest.all');
        return unhealthy;
    } catch (e) {
        var errorStatus = new Status(Status.ERROR, 'UNHEALTHY');
        errorStatus.addDetail('message', 'Unexpected error during health check: ' + e.message);
        errorStatus.addDetail('remediation', 'Check that the Avalara service URL and credentials are configured correctly in Administration > Operations > Services > avatax.rest.all');
        return errorStatus;
    }
};
