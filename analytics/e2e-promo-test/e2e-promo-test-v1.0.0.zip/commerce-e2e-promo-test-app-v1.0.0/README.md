# E2E Promo Test

Disposable Commerce App Package used to validate the forward-integration
(auto-promotion) workflow across release branches. Not a real integration.
