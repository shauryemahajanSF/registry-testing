# E2E Promo Test

Disposable UI-only app used to exercise the forward-integration
auto-promotion workflow (release/26.8 -> release/26.9 -> main).
Not a real integration. Safe to delete after the test completes.
