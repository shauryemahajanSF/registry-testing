'use strict';

/**
 * sfcc.app.fraud.beforePayment
 *
 * Logs every basket payment instrument (method, paymentDetails type, last4,
 * brand, walletType) so Express / Salesforce Payments pre-auth can be verified.
 * Last-4 still drives APPROVED / CHALLENGE / DECLINED.
 */

var Status = require('dw/system/Status');
var Logger = require('dw/system/Logger');
var helper = require('*/cartridge/scripts/helpers/mockFraudHelper');

var logger = Logger.getLogger('mock-fraud', 'beforePayment');

/**
 * @param {dw.order.Basket} basket
 * @returns {dw.system.Status}
 */
exports.beforePayment = function (basket) {
    try {
        var instruments = helper.describeContainerInstruments(basket);
        var scenario = helper.getFraudScenarioFromContainer(basket);

        logger.info(
            'MOCK_FRAUD_BEFORE_PAYMENT basket={0} last4={1} decision={2} instruments={3}',
            basket && basket.UUID,
            scenario.last4,
            scenario.preAuth,
            JSON.stringify(instruments)
        );

        helper.forEachPaymentInstrument(basket, function (paymentInstrument) {
            helper.setPreAuthDecision(paymentInstrument, scenario.preAuth);
        });

        if (scenario.preAuth === helper.PRE_AUTH.DECLINED) {
            return new Status(Status.ERROR, 'PRE_AUTH_FRAUD_DECISION_DECLINED', 'Mock fraud declined');
        }
        if (scenario.preAuth === helper.PRE_AUTH.CHALLENGE) {
            return new Status(Status.OK, 'PRE_AUTH_FRAUD_DECISION_CHALLENGE', 'Mock fraud challenge');
        }
        return new Status(Status.OK, 'PRE_AUTH_FRAUD_DECISION_APPROVED', 'Mock fraud approved');
    } catch (e) {
        logger.error('beforePayment failed: {0}', e.message);
        return new Status(Status.ERROR, 'PRE_AUTH_FRAUD_DECISION_DECLINED', e.message);
    }
};
