'use strict';

/**
 * Resolves Mock Fraud PENDING orders (last-4 0008 place, 0009 fail).
 * Run the installed job mock-fraud-resolve-pending after checkout parks the order.
 */

var Status = require('dw/system/Status');
var Logger = require('dw/system/Logger');
var Transaction = require('dw/system/Transaction');
var PaymentTransaction = require('dw/order/PaymentTransaction');
var Order = require('dw/order/Order');
var OrderMgr = require('dw/order/OrderMgr');
var helper = require('*/cartridge/scripts/helpers/mockFraudHelper');

var logger = Logger.getLogger('mock-fraud', 'resolvePending');

/**
 * @param {dw.order.Order} order
 * @returns {'pending'|'guaranteed'|'rejected'|'none'}
 */
function postAuthState(order) {
    var state = 'none';
    helper.forEachPaymentInstrument(order, function (paymentInstrument) {
        if (state === 'pending' || !paymentInstrument
            || typeof paymentInstrument.getPaymentTransaction !== 'function') {
            return;
        }
        var transaction = paymentInstrument.getPaymentTransaction();
        if (!transaction || typeof transaction.getPostAuthFraudDecision !== 'function') {
            return;
        }
        var decision = transaction.getPostAuthFraudDecision();
        if (decision === PaymentTransaction.POST_AUTH_FRAUD_DECISION_PENDING
            || decision === helper.POST_AUTH.PENDING) {
            state = 'pending';
        } else if (decision === PaymentTransaction.POST_AUTH_FRAUD_DECISION_NOT_GUARANTEED
            || decision === helper.POST_AUTH.NOT_GUARANTEED) {
            state = 'rejected';
        } else if (decision === PaymentTransaction.POST_AUTH_FRAUD_DECISION_GUARANTEED
            || decision === helper.POST_AUTH.GUARANTEED) {
            if (state === 'none') {
                state = 'guaranteed';
            }
        }
    });
    return state;
}

/**
 * attemptOrderTransition places only when post-auth is no longer PENDING, and
 * placeOrder writes the order status. Both must commit in this wrap: the job
 * step is non-transactional, so a transition outside the wrap leaves CREATED.
 *
 * @param {dw.order.Order} order
 * @param {string} last4
 * @param {string} intended
 * @returns {'placed'|'failed'|'skipped'}
 */
function transition(order, last4, intended, prepare) {
    var result;
    Transaction.wrap(function () {
        if (typeof prepare === 'function') {
            prepare();
        }
        result = OrderMgr.attemptOrderTransition(order);
    });
    var status = order.getStatus();
    var step = result && result.getStep ? result.getStep() : '';
    logger.info('Resolved order {0} last-4 {1} intended {2} status {3} step {4}',
        order.orderNo, last4, intended, status, step);
    if (status === Order.ORDER_STATUS_FAILED || status === Order.ORDER_STATUS_CANCELLED) {
        return 'failed';
    }
    if (status === Order.ORDER_STATUS_NEW || status === Order.ORDER_STATUS_OPEN
        || status === Order.ORDER_STATUS_COMPLETED) {
        return 'placed';
    }
    return 'skipped';
}

/**
 * @param {dw.order.Order} order
 */
function resolveOne(order) {
    var state = postAuthState(order);
    var scenario = helper.getFraudScenarioFromContainer(order);
    var place = scenario.pendingResolve !== helper.PENDING_RESOLVE.FAIL;
    var resolvable = state !== 'none' || scenario.pendingResolve === helper.PENDING_RESOLVE.PLACE
        || scenario.pendingResolve === helper.PENDING_RESOLVE.FAIL;
    logger.info('Considering order {0} last-4 {1} postAuth {2} status {3}',
        order.orderNo, scenario.last4, state, order.getStatus());
    if (!resolvable) {
        return 'skipped';
    }
    if (state === 'rejected') {
        place = false;
    } else if (state === 'guaranteed') {
        place = true;
    }
    var decision = place ? helper.POST_AUTH.GUARANTEED : helper.POST_AUTH.NOT_GUARANTEED;
    return transition(order, scenario.last4, place ? 'place' : 'fail', function () {
        helper.forEachPaymentInstrument(order, function (paymentInstrument) {
            helper.setPostAuthDecision(paymentInstrument, decision);
        });
    });
}

/**
 * @returns {dw.system.Status}
 */
exports.execute = function () {
    var placed = 0;
    var failed = 0;
    var skipped = 0;
    try {
        OrderMgr.processOrders(function (order) {
            try {
                var result = resolveOne(order);
                if (result === 'placed') {
                    placed += 1;
                } else if (result === 'failed') {
                    failed += 1;
                } else {
                    skipped += 1;
                }
            } catch (inner) {
                logger.error('PENDING resolve failed for {0}: {1}', order && order.orderNo, inner.message);
                skipped += 1;
            }
        }, 'status = {0}', Order.ORDER_STATUS_CREATED);
        return new Status(Status.OK, 'OK',
            'Mock fraud PENDING resolve placed=' + placed + ' failed=' + failed + ' skipped=' + skipped);
    } catch (e) {
        logger.error('PENDING resolve job failed: {0}', e.message);
        return new Status(Status.ERROR, 'MOCK_FRAUD_PENDING_RESOLVE', e.message);
    }
};
