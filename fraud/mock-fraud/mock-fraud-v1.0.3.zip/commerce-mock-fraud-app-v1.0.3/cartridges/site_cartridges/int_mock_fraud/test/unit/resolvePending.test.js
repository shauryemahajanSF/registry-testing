'use strict';

var assert = require('chai').assert;
var proxyquire = require('proxyquire').noCallThru();

function StatusStub(code, statusCode, message) {
    this.status = code;
    this.code = statusCode;
    this.message = message;
}
StatusStub.OK = 0;
StatusStub.ERROR = 1;

describe('resolvePending job', function () {
    var execute;
    var transitions;
    var helperStub;
    var decisions;

    beforeEach(function () {
        transitions = [];
        decisions = ['PENDING'];
        helperStub = {
            PENDING_RESOLVE: { PLACE: 'place', FAIL: 'fail' },
            POST_AUTH: {
                GUARANTEED: 'GUARANTEED',
                NOT_GUARANTEED: 'NOT_GUARANTEED',
                PENDING: 'PENDING'
            },
            getFraudScenarioFromContainer: function () {
                return { pendingResolve: 'place', last4: '0008' };
            },
            forEachPaymentInstrument: function (order, fn) {
                fn({
                    getPaymentTransaction: function () {
                        return {
                            getPostAuthFraudDecision: function () {
                                return decisions[0];
                            }
                        };
                    }
                });
            },
            setPostAuthDecision: function () {
                decisions[0] = 'GUARANTEED';
            }
        };
        var job = proxyquire('../../cartridge/scripts/jobs/resolvePending', {
            'dw/system/Status': StatusStub,
            'dw/system/Logger': {
                getLogger: function () {
                    return { info: function () {}, error: function () {} };
                }
            },
            'dw/system/Transaction': {
                wrap: function (fn) {
                    return fn();
                }
            },
            'dw/order/PaymentTransaction': {
                POST_AUTH_FRAUD_DECISION_PENDING: 'PENDING',
                POST_AUTH_FRAUD_DECISION_GUARANTEED: 'GUARANTEED',
                POST_AUTH_FRAUD_DECISION_NOT_GUARANTEED: 'NOT_GUARANTEED'
            },
            'dw/order/Order': {
                ORDER_STATUS_CREATED: 0,
                ORDER_STATUS_NEW: 3,
                ORDER_STATUS_OPEN: 4,
                ORDER_STATUS_COMPLETED: 5,
                ORDER_STATUS_FAILED: 8,
                ORDER_STATUS_CANCELLED: 6
            },
            'dw/order/OrderMgr': {
                processOrders: function (fn) {
                    var status = 0;
                    fn({
                        orderNo: '00001234',
                        getStatus: function () {
                            return status;
                        }
                    });
                    // attemptOrderTransition records the order number; status flips in that stub
                    void status;
                },
                attemptOrderTransition: function (order) {
                    transitions.push(order.orderNo);
                    order.getStatus = function () {
                        return 3;
                    };
                    return { getStep: function () { return null; } };
                }
            },
            '*/cartridge/scripts/helpers/mockFraudHelper': helperStub
        });
        execute = job.execute;
    });

    it('updates post-auth and calls attemptOrderTransition', function () {
        var status = execute();
        assert.strictEqual(status.status, StatusStub.OK);
        assert.deepEqual(transitions, ['00001234']);
        assert.match(status.message, /placed=1/);
    });

    it('skips orders that are not fraud-pending scenarios', function () {
        decisions[0] = null;
        helperStub.getFraudScenarioFromContainer = function () {
            return { last4: '0000' };
        };
        var status = execute();
        assert.deepEqual(transitions, []);
        assert.match(status.message, /skipped=1/);
    });
});
