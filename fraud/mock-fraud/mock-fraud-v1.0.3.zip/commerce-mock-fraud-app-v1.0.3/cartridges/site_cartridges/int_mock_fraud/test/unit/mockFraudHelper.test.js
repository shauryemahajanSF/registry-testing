'use strict';

var assert = require('chai').assert;
var proxyquire = require('proxyquire').noCallThru();

var PaymentTransactionStub = {
    PRE_AUTH_FRAUD_DECISION_APPROVED: 'APPROVED',
    PRE_AUTH_FRAUD_DECISION_CHALLENGE: 'CHALLENGE',
    PRE_AUTH_FRAUD_DECISION_DECLINED: 'DECLINED',
    POST_AUTH_FRAUD_DECISION_GUARANTEED: 'GUARANTEED',
    POST_AUTH_FRAUD_DECISION_NOT_GUARANTEED: 'NOT_GUARANTEED',
    POST_AUTH_FRAUD_DECISION_PENDING: 'PENDING'
};

function claimedContainer(method, last4) {
    return {
        getPaymentInstruments: function () {
            var items = [{
                getPaymentMethod: function () {
                    return method;
                },
                getPaymentDetails: function () {
                    return {
                        getLast4: function () {
                            return last4;
                        }
                    };
                },
                getCreditCardNumberLastDigits: function () {
                    return null;
                },
                getBankAccountNumberLastDigits: function () {
                    return null;
                }
            }];
            var index = 0;
            return {
                iterator: function () {
                    return {
                        hasNext: function () {
                            return index < items.length;
                        },
                        next: function () {
                            var item = items[index];
                            index += 1;
                            return item;
                        }
                    };
                }
            };
        }
    };
}

describe('mockFraudHelper', function () {
    var helper;

    beforeEach(function () {
        helper = proxyquire('../../cartridge/scripts/helpers/mockFraudHelper', {
            'dw/system/Logger': {
                getLogger: function () {
                    return {
                        warn: function () {},
                        error: function () {},
                        info: function () {}
                    };
                }
            },
            'dw/order/PaymentTransaction': PaymentTransactionStub
        });
    });

    describe('getFraudScenario', function () {
        it('declines 0001', function () {
            var scenario = helper.getFraudScenario('0001');
            assert.strictEqual(scenario.preAuth, helper.PRE_AUTH.DECLINED);
        });

        it('challenges 0002 and 0006', function () {
            assert.strictEqual(helper.getFraudScenario('0002').preAuth, helper.PRE_AUTH.CHALLENGE);
            assert.strictEqual(helper.getFraudScenario('0006').preAuth, helper.PRE_AUTH.CHALLENGE);
        });

        it('rejects 0003 post-auth', function () {
            var scenario = helper.getFraudScenario('0003');
            assert.strictEqual(scenario.preAuth, helper.PRE_AUTH.APPROVED);
            assert.strictEqual(scenario.postAuth, helper.POST_AUTH.NOT_GUARANTEED);
        });

        it('holds 0008 and 0009 as PENDING with place vs fail', function () {
            var place = helper.getFraudScenario('0008');
            var fail = helper.getFraudScenario('0009');
            assert.strictEqual(place.postAuth, helper.POST_AUTH.PENDING);
            assert.strictEqual(place.pendingResolve, helper.PENDING_RESOLVE.PLACE);
            assert.strictEqual(fail.postAuth, helper.POST_AUTH.PENDING);
            assert.strictEqual(fail.pendingResolve, helper.PENDING_RESOLVE.FAIL);
        });

        it('approves unknown last-4 as the happy path', function () {
            var scenario = helper.getFraudScenario('9999');
            assert.strictEqual(scenario.preAuth, helper.PRE_AUTH.APPROVED);
            assert.strictEqual(scenario.postAuth, helper.POST_AUTH.GUARANTEED);
            assert.strictEqual(scenario.last4, '9999');
        });
    });

    describe('getFraudScenarioFromContainer', function () {
        it('reads CREDIT_CARD paymentDetails.last4 from the basket', function () {
            var scenario = helper.getFraudScenarioFromContainer(claimedContainer('CREDIT_CARD', '0002'));
            assert.strictEqual(scenario.last4, '0002');
            assert.strictEqual(scenario.preAuth, helper.PRE_AUTH.CHALLENGE);
        });

        it('reads SEPA paymentDetails.last4 from the basket', function () {
            var scenario = helper.getFraudScenarioFromContainer(claimedContainer('SEPA_DIRECT_DEBIT', '0006'));
            assert.strictEqual(scenario.last4, '0006');
            assert.strictEqual(scenario.preAuth, helper.PRE_AUTH.CHALLENGE);
        });

        it('defaults to 0000 when no last-4 is present', function () {
            var scenario = helper.getFraudScenarioFromContainer({
                getPaymentInstruments: function () {
                    return {
                        iterator: function () {
                            return {
                                hasNext: function () { return false; },
                                next: function () { return null; }
                            };
                        }
                    };
                }
            });
            assert.strictEqual(scenario.last4, '0000');
            assert.strictEqual(scenario.preAuth, helper.PRE_AUTH.APPROVED);
        });
    });

    describe('setPreAuthDecision', function () {
        it('maps challenge onto the payment transaction', function () {
            var recorded = null;
            helper.setPreAuthDecision({
                getPaymentTransaction: function () {
                    return {
                        setPreAuthFraudDecision: function (value) {
                            recorded = value;
                        }
                    };
                }
            }, helper.PRE_AUTH.CHALLENGE);
            assert.strictEqual(recorded, PaymentTransactionStub.PRE_AUTH_FRAUD_DECISION_CHALLENGE);
        });
    });
});
