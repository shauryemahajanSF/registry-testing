# Mock Fraud

Backend-only sample Commerce App for Salesforce B2C Commerce 26.10 fraud orchestration. It drives pre-auth (`beforePayment`) and post-auth (`afterPayment`) decisions from the shopper email local-part so e2e and blitz can exercise Approve, Decline, Challenge, Reject, and Pending without a live fraud provider.

This app has **no Storefront Next UI**. Challenge is a signal for the **payment** app to run 3DS — not a fraud-owned screen.

## What it does

| Hook | Purpose |
|------|---------|
| `sfcc.app.fraud.beforePayment` | Sets `preAuthFraudDecision` on every payment transaction and returns `Status.OK` / `Status.ERROR` with the matching code |
| `sfcc.app.fraud.afterPayment` | Sets `postAuthFraudDecision` after all instruments are authorized/captured |
| `sfcc.app.fraud.checkConnectionHealth` | Checkout Hub connection badge |

## Email scenario matrix

Use these customer emails (local-part, case-insensitive):

| Email local-part | Pre-auth | Post-auth | Storefront result |
|------------------|----------|-----------|-------------------|
| `fraud-decline` | `DECLINED` | n/a | `createOrder` rolls back; generic place-order error; no persisted order |
| `fraud-challenge` | `CHALLENGE` | `GUARANTEED` (after 3DS auth) | Order created; payment app must **not** authorize until Authenticate |
| `fraud-reject` | `APPROVED` | `NOT_GUARANTEED` | Order created, payment authorized, then fail-order + reversal |
| `fraud-pending` | `APPROVED` | `PENDING` | Order held in `CREATED` (webhook not implemented — complete manually) |
| anything else | `APPROVED` | `GUARANTEED` | Happy path |

## Architecture

- Cartridge: `int_mock_fraud`
- Service: `mock.fraud.api` (template only; unused by the mock hooks)
- Domain: `fraud`
- No `storefrontSupport`

Enable platform orchestration with the `PaymentFraudOrchestrationEnabled` site preference (default `false`).

## Installation

1. Install the app from Commerce Apps / Checkout Hub.
2. Enable `PaymentFraudOrchestrationEnabled` on the site.
3. Install **Mock Payment** (or another payment Commerce App) so checkout can claim a tender.
4. Place orders with the emails above.

## Future provider integration

The installed `mock.fraud.api` service is unused. A real provider should replace the email matrix with Service Framework calls, persist risk scores as custom attributes, and implement a webhook that calls `OrderMgr.attemptOrderTransition` or `OrderMgr.failOrder` for `PENDING` decisions.

## Development

```bash
cd cartridges/site_cartridges/int_mock_fraud
npm install
npm test
```
