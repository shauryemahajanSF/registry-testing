'use strict';

/**
 * Shared helpers for the Mock Fraud Commerce App.
 * Decisions are driven by the shopper email local-part (no provider call).
 */

var Logger = require('dw/system/Logger');
var PaymentTransaction = require('dw/order/PaymentTransaction');

var logger = Logger.getLogger('mock-fraud', 'helper');

var PRE_AUTH = {
    APPROVED: 'APPROVED',
    DECLINED: 'DECLINED',
    CHALLENGE: 'CHALLENGE'
};

var POST_AUTH = {
    GUARANTEED: 'GUARANTEED',
    NOT_GUARANTEED: 'NOT_GUARANTEED',
    PENDING: 'PENDING'
};

/**
 * @param {string|null|undefined} email
 * @returns {string}
 */
function getEmailLocalPart(email) {
    if (!email) {
        return '';
    }
    var value = String(email).trim().toLowerCase();
    var at = value.indexOf('@');
    return at > 0 ? value.substring(0, at) : value;
}

/**
 * Resolves shopper email from a Basket or Order.
 * @param {dw.order.LineItemCtnr} container
 * @returns {string}
 */
function getShopperEmail(container) {
    if (!container) {
        return '';
    }
    try {
        if (typeof container.getCustomerEmail === 'function') {
            var customerEmail = container.getCustomerEmail();
            if (customerEmail) {
                return String(customerEmail);
            }
        }
    } catch (e) {
        logger.warn('getCustomerEmail failed: {0}', e.message);
    }
    try {
        var billing = typeof container.getBillingAddress === 'function' ? container.getBillingAddress() : null;
        if (billing && billing.email) {
            return String(billing.email);
        }
    } catch (e) {
        logger.warn('billing email lookup failed: {0}', e.message);
    }
    try {
        var customer = typeof container.getCustomer === 'function' ? container.getCustomer() : null;
        if (customer && customer.profile && customer.profile.email) {
            return String(customer.profile.email);
        }
    } catch (e) {
        logger.warn('profile email lookup failed: {0}', e.message);
    }
    return '';
}

/**
 * @param {string} email
 * @returns {{preAuth: string, postAuth: string}}
 */
function getFraudScenario(email) {
    var localPart = getEmailLocalPart(email);
    switch (localPart) {
        case 'fraud-decline':
            return { preAuth: PRE_AUTH.DECLINED, postAuth: POST_AUTH.GUARANTEED };
        case 'fraud-challenge':
            return { preAuth: PRE_AUTH.CHALLENGE, postAuth: POST_AUTH.GUARANTEED };
        case 'fraud-reject':
            return { preAuth: PRE_AUTH.APPROVED, postAuth: POST_AUTH.NOT_GUARANTEED };
        case 'fraud-pending':
            return { preAuth: PRE_AUTH.APPROVED, postAuth: POST_AUTH.PENDING };
        default:
            return { preAuth: PRE_AUTH.APPROVED, postAuth: POST_AUTH.GUARANTEED };
    }
}

/**
 * @param {dw.order.LineItemCtnr} container
 * @param {Function} fn
 */
function forEachPaymentInstrument(container, fn) {
    if (!container || typeof container.getPaymentInstruments !== 'function') {
        return;
    }
    var instruments = container.getPaymentInstruments();
    if (!instruments) {
        return;
    }
    var iter = instruments.iterator();
    while (iter.hasNext()) {
        fn(iter.next());
    }
}

/**
 * @param {dw.order.PaymentInstrument} paymentInstrument
 * @param {string} decision
 */
function setPreAuthDecision(paymentInstrument, decision) {
    if (!paymentInstrument || typeof paymentInstrument.getPaymentTransaction !== 'function') {
        return;
    }
    var transaction = paymentInstrument.getPaymentTransaction();
    if (!transaction) {
        return;
    }
    var mapped;
    if (decision === PRE_AUTH.DECLINED) {
        mapped = PaymentTransaction.PRE_AUTH_FRAUD_DECISION_DECLINED;
    } else if (decision === PRE_AUTH.CHALLENGE) {
        mapped = PaymentTransaction.PRE_AUTH_FRAUD_DECISION_CHALLENGE;
    } else {
        mapped = PaymentTransaction.PRE_AUTH_FRAUD_DECISION_APPROVED;
    }
    transaction.setPreAuthFraudDecision(mapped);
}

/**
 * @param {dw.order.PaymentInstrument} paymentInstrument
 * @param {string} decision
 */
function setPostAuthDecision(paymentInstrument, decision) {
    if (!paymentInstrument || typeof paymentInstrument.getPaymentTransaction !== 'function') {
        return;
    }
    var transaction = paymentInstrument.getPaymentTransaction();
    if (!transaction) {
        return;
    }
    var mapped;
    if (decision === POST_AUTH.NOT_GUARANTEED) {
        mapped = PaymentTransaction.POST_AUTH_FRAUD_DECISION_NOT_GUARANTEED;
    } else if (decision === POST_AUTH.PENDING) {
        mapped = PaymentTransaction.POST_AUTH_FRAUD_DECISION_PENDING;
    } else {
        mapped = PaymentTransaction.POST_AUTH_FRAUD_DECISION_GUARANTEED;
    }
    transaction.setPostAuthFraudDecision(mapped);
}

module.exports = {
    PRE_AUTH: PRE_AUTH,
    POST_AUTH: POST_AUTH,
    getEmailLocalPart: getEmailLocalPart,
    getShopperEmail: getShopperEmail,
    getFraudScenario: getFraudScenario,
    forEachPaymentInstrument: forEachPaymentInstrument,
    setPreAuthDecision: setPreAuthDecision,
    setPostAuthDecision: setPostAuthDecision
};
