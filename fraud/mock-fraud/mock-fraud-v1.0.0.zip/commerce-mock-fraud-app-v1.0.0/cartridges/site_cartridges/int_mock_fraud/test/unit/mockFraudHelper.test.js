'use strict';

var assert = require('chai').assert;
var proxyquire = require('proxyquire').noCallThru();

var PaymentTransactionStub = {
    PRE_AUTH_FRAUD_DECISION_APPROVED: 'APPROVED',
    PRE_AUTH_FRAUD_DECISION_CHALLENGE: 'CHALLENGE',
    PRE_AUTH_FRAUD_DECISION_DECLINED: 'DECLINED',
    POST_AUTH_FRAUD_DECISION_GUARANTEED: 'GUARANTEED',
    POST_AUTH_FRAUD_DECISION_NOT_GUARANTEED: 'NOT_GUARANTEED',
    POST_AUTH_FRAUD_DECISION_PENDING: 'PENDING'
};

describe('mockFraudHelper', function () {
    var helper;

    beforeEach(function () {
        helper = proxyquire('../../cartridge/scripts/helpers/mockFraudHelper', {
            'dw/system/Logger': {
                getLogger: function () {
                    return {
                        warn: function () {},
                        error: function () {},
                        info: function () {}
                    };
                }
            },
            'dw/order/PaymentTransaction': PaymentTransactionStub
        });
    });

    describe('getFraudScenario', function () {
        it('declines fraud-decline emails', function () {
            var scenario = helper.getFraudScenario('fraud-decline@example.com');
            assert.strictEqual(scenario.preAuth, helper.PRE_AUTH.DECLINED);
        });

        it('challenges fraud-challenge emails', function () {
            var scenario = helper.getFraudScenario('Fraud-Challenge@Example.COM');
            assert.strictEqual(scenario.preAuth, helper.PRE_AUTH.CHALLENGE);
            assert.strictEqual(scenario.postAuth, helper.POST_AUTH.GUARANTEED);
        });

        it('rejects fraud-reject emails post-auth', function () {
            var scenario = helper.getFraudScenario('fraud-reject@example.com');
            assert.strictEqual(scenario.preAuth, helper.PRE_AUTH.APPROVED);
            assert.strictEqual(scenario.postAuth, helper.POST_AUTH.NOT_GUARANTEED);
        });

        it('holds fraud-pending emails', function () {
            var scenario = helper.getFraudScenario('fraud-pending@example.com');
            assert.strictEqual(scenario.postAuth, helper.POST_AUTH.PENDING);
        });

        it('approves unknown emails', function () {
            var scenario = helper.getFraudScenario('shopper@example.com');
            assert.strictEqual(scenario.preAuth, helper.PRE_AUTH.APPROVED);
            assert.strictEqual(scenario.postAuth, helper.POST_AUTH.GUARANTEED);
        });
    });

    describe('getShopperEmail', function () {
        it('reads customerEmail first', function () {
            var email = helper.getShopperEmail({
                getCustomerEmail: function () {
                    return 'fraud-challenge@example.com';
                }
            });
            assert.strictEqual(email, 'fraud-challenge@example.com');
        });
    });

    describe('setPreAuthDecision', function () {
        it('maps challenge onto the payment transaction', function () {
            var recorded = null;
            helper.setPreAuthDecision({
                getPaymentTransaction: function () {
                    return {
                        setPreAuthFraudDecision: function (value) {
                            recorded = value;
                        }
                    };
                }
            }, helper.PRE_AUTH.CHALLENGE);
            assert.strictEqual(recorded, PaymentTransactionStub.PRE_AUTH_FRAUD_DECISION_CHALLENGE);
        });
    });
});
