'use strict';

/**
 * Shared helpers for the Mock Fraud Commerce App.
 * Decisions are keyed by BANK_TRANSFER last-4 (no shopper email).
 */

var Logger = require('dw/system/Logger');
var PaymentTransaction = require('dw/order/PaymentTransaction');
var PaymentInstrument = require('dw/order/PaymentInstrument');

var logger = Logger.getLogger('mock-fraud', 'helper');

var PRE_AUTH = {
    APPROVED: 'APPROVED',
    DECLINED: 'DECLINED',
    CHALLENGE: 'CHALLENGE'
};

var POST_AUTH = {
    GUARANTEED: 'GUARANTEED',
    NOT_GUARANTEED: 'NOT_GUARANTEED',
    PENDING: 'PENDING'
};

var PENDING_RESOLVE = {
    PLACE: 'place',
    FAIL: 'fail'
};

var DEFAULT_LAST4 = '0000';
var BANK_TRANSFER = PaymentInstrument.METHOD_BANK_TRANSFER || 'BANK_TRANSFER';

/**
 * Last-4 → fraud outcome. Keep in sync with Mock Payment.
 */
var LAST4_SCENARIOS = {
    '0000': { preAuth: PRE_AUTH.APPROVED, postAuth: POST_AUTH.GUARANTEED },
    '0001': { preAuth: PRE_AUTH.DECLINED, postAuth: POST_AUTH.GUARANTEED },
    '0002': { preAuth: PRE_AUTH.CHALLENGE, postAuth: POST_AUTH.GUARANTEED },
    '0003': { preAuth: PRE_AUTH.APPROVED, postAuth: POST_AUTH.NOT_GUARANTEED },
    '0004': { preAuth: PRE_AUTH.APPROVED, postAuth: POST_AUTH.GUARANTEED },
    '0005': { preAuth: PRE_AUTH.APPROVED, postAuth: POST_AUTH.GUARANTEED },
    '0006': { preAuth: PRE_AUTH.CHALLENGE, postAuth: POST_AUTH.GUARANTEED },
    '0008': {
        preAuth: PRE_AUTH.APPROVED,
        postAuth: POST_AUTH.PENDING,
        pendingResolve: PENDING_RESOLVE.PLACE
    },
    '0009': {
        preAuth: PRE_AUTH.APPROVED,
        postAuth: POST_AUTH.PENDING,
        pendingResolve: PENDING_RESOLVE.FAIL
    }
};

/**
 * @param {string|null|undefined} value
 * @returns {string}
 */
function normalizeLast4(value) {
    if (!value) {
        return DEFAULT_LAST4;
    }
    var digits = String(value).replace(/\D/g, '');
    if (!digits) {
        return DEFAULT_LAST4;
    }
    if (digits.length >= 4) {
        return digits.slice(-4);
    }
    return ('0000' + digits).slice(-4);
}

/**
 * @param {dw.order.LineItemCtnr} container
 * @param {Function} fn
 */
function forEachPaymentInstrument(container, fn) {
    if (!container || typeof container.getPaymentInstruments !== 'function') {
        return;
    }
    var instruments = container.getPaymentInstruments();
    if (!instruments) {
        return;
    }
    var iter = instruments.iterator();
    while (iter.hasNext()) {
        fn(iter.next());
    }
}

/**
 * @param {dw.order.PaymentInstrument} paymentInstrument
 * @returns {boolean}
 */
function isBankTransfer(paymentInstrument) {
    if (!paymentInstrument || typeof paymentInstrument.getPaymentMethod !== 'function') {
        return false;
    }
    return paymentInstrument.getPaymentMethod() === BANK_TRANSFER
        || paymentInstrument.getPaymentMethod() === 'BANK_TRANSFER';
}

/**
 * @param {dw.order.LineItemCtnr} container
 * @returns {string}
 */
function getBankTransferLast4(container) {
    var last4 = DEFAULT_LAST4;
    var found = false;
    forEachPaymentInstrument(container, function (paymentInstrument) {
        if (found || !isBankTransfer(paymentInstrument)) {
            return;
        }
        try {
            if (typeof paymentInstrument.getBankAccountNumberLastDigits === 'function') {
                last4 = normalizeLast4(paymentInstrument.getBankAccountNumberLastDigits());
                found = true;
            }
        } catch (e) {
            logger.warn('last-4 lookup failed: {0}', e.message);
        }
    });
    return last4;
}

/**
 * @param {string} last4
 * @returns {{preAuth: string, postAuth: string, pendingResolve: string|null, last4: string}}
 */
function getFraudScenario(last4) {
    var code = normalizeLast4(last4);
    var mapped = LAST4_SCENARIOS[code] || LAST4_SCENARIOS[DEFAULT_LAST4];
    return {
        preAuth: mapped.preAuth,
        postAuth: mapped.postAuth,
        pendingResolve: mapped.pendingResolve || null,
        last4: code
    };
}

/**
 * @param {dw.order.LineItemCtnr} container
 * @returns {{preAuth: string, postAuth: string, pendingResolve: string|null, last4: string}}
 */
function getFraudScenarioFromContainer(container) {
    return getFraudScenario(getBankTransferLast4(container));
}

/**
 * @param {dw.order.PaymentInstrument} paymentInstrument
 * @param {string} decision
 */
function setPreAuthDecision(paymentInstrument, decision) {
    if (!paymentInstrument || typeof paymentInstrument.getPaymentTransaction !== 'function') {
        return;
    }
    var transaction = paymentInstrument.getPaymentTransaction();
    if (!transaction) {
        return;
    }
    var mapped;
    if (decision === PRE_AUTH.DECLINED) {
        mapped = PaymentTransaction.PRE_AUTH_FRAUD_DECISION_DECLINED;
    } else if (decision === PRE_AUTH.CHALLENGE) {
        mapped = PaymentTransaction.PRE_AUTH_FRAUD_DECISION_CHALLENGE;
    } else {
        mapped = PaymentTransaction.PRE_AUTH_FRAUD_DECISION_APPROVED;
    }
    transaction.setPreAuthFraudDecision(mapped);
}

/**
 * @param {dw.order.PaymentInstrument} paymentInstrument
 * @param {string} decision
 */
function setPostAuthDecision(paymentInstrument, decision) {
    if (!paymentInstrument || typeof paymentInstrument.getPaymentTransaction !== 'function') {
        return;
    }
    var transaction = paymentInstrument.getPaymentTransaction();
    if (!transaction) {
        return;
    }
    var mapped;
    if (decision === POST_AUTH.NOT_GUARANTEED) {
        mapped = PaymentTransaction.POST_AUTH_FRAUD_DECISION_NOT_GUARANTEED;
    } else if (decision === POST_AUTH.PENDING) {
        mapped = PaymentTransaction.POST_AUTH_FRAUD_DECISION_PENDING;
    } else {
        mapped = PaymentTransaction.POST_AUTH_FRAUD_DECISION_GUARANTEED;
    }
    transaction.setPostAuthFraudDecision(mapped);
}

/**
 * @param {dw.order.Order} order
 * @returns {boolean}
 */
function orderHasPendingPostAuth(order) {
    var pending = false;
    forEachPaymentInstrument(order, function (paymentInstrument) {
        if (pending || typeof paymentInstrument.getPaymentTransaction !== 'function') {
            return;
        }
        var transaction = paymentInstrument.getPaymentTransaction();
        if (!transaction || typeof transaction.getPostAuthFraudDecision !== 'function') {
            return;
        }
        var decision = transaction.getPostAuthFraudDecision();
        if (decision === PaymentTransaction.POST_AUTH_FRAUD_DECISION_PENDING
            || decision === POST_AUTH.PENDING) {
            pending = true;
        }
    });
    return pending;
}

module.exports = {
    PRE_AUTH: PRE_AUTH,
    POST_AUTH: POST_AUTH,
    PENDING_RESOLVE: PENDING_RESOLVE,
    DEFAULT_LAST4: DEFAULT_LAST4,
    LAST4_SCENARIOS: LAST4_SCENARIOS,
    normalizeLast4: normalizeLast4,
    forEachPaymentInstrument: forEachPaymentInstrument,
    getBankTransferLast4: getBankTransferLast4,
    getFraudScenario: getFraudScenario,
    getFraudScenarioFromContainer: getFraudScenarioFromContainer,
    setPreAuthDecision: setPreAuthDecision,
    setPostAuthDecision: setPostAuthDecision,
    orderHasPendingPostAuth: orderHasPendingPostAuth
};
