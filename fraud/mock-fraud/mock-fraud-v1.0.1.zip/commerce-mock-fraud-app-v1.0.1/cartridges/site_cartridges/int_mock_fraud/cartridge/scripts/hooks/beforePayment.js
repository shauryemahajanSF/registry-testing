'use strict';

/**
 * sfcc.app.fraud.beforePayment
 */

var Status = require('dw/system/Status');
var Logger = require('dw/system/Logger');
var helper = require('*/cartridge/scripts/helpers/mockFraudHelper');

var logger = Logger.getLogger('mock-fraud', 'beforePayment');

/**
 * @param {dw.order.Basket} basket
 * @returns {dw.system.Status}
 */
exports.beforePayment = function (basket) {
    try {
        var scenario = helper.getFraudScenarioFromContainer(basket);
        helper.forEachPaymentInstrument(basket, function (paymentInstrument) {
            helper.setPreAuthDecision(paymentInstrument, scenario.preAuth);
        });

        if (scenario.preAuth === helper.PRE_AUTH.DECLINED) {
            logger.info('Mock fraud declined basket {0} last-4 {1}', basket && basket.UUID, scenario.last4);
            return new Status(Status.ERROR, 'PRE_AUTH_FRAUD_DECISION_DECLINED', 'Mock fraud declined');
        }
        if (scenario.preAuth === helper.PRE_AUTH.CHALLENGE) {
            logger.info('Mock fraud challenge for basket {0} last-4 {1}', basket && basket.UUID, scenario.last4);
            return new Status(Status.OK, 'PRE_AUTH_FRAUD_DECISION_CHALLENGE', 'Mock fraud challenge');
        }
        return new Status(Status.OK, 'PRE_AUTH_FRAUD_DECISION_APPROVED', 'Mock fraud approved');
    } catch (e) {
        logger.error('beforePayment failed: {0}', e.message);
        return new Status(Status.ERROR, 'PRE_AUTH_FRAUD_DECISION_DECLINED', e.message);
    }
};
