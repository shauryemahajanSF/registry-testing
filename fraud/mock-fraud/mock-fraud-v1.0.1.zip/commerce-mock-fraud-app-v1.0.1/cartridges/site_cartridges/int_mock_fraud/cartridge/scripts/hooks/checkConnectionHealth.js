'use strict';

/**
 * sfcc.app.fraud.checkConnectionHealth
 */

var Status = require('dw/system/Status');

/**
 * @returns {dw.system.Status}
 */
exports.checkConnectionHealth = function () {
    try {
        return new Status(Status.OK, 'OK', 'Mock fraud provider is ready');
    } catch (e) {
        return new Status(Status.OK);
    }
};
