'use strict';

/**
 * sfcc.app.fraud.afterPayment
 */

var Status = require('dw/system/Status');
var Logger = require('dw/system/Logger');
var helper = require('*/cartridge/scripts/helpers/mockFraudHelper');

var logger = Logger.getLogger('mock-fraud', 'afterPayment');

/**
 * @param {dw.order.Order} order
 * @returns {dw.system.Status}
 */
exports.afterPayment = function (order) {
    try {
        var scenario = helper.getFraudScenarioFromContainer(order);
        helper.forEachPaymentInstrument(order, function (paymentInstrument) {
            helper.setPostAuthDecision(paymentInstrument, scenario.postAuth);
        });

        if (scenario.postAuth === helper.POST_AUTH.NOT_GUARANTEED) {
            logger.info('Mock fraud not guaranteed for order {0} last-4 {1}', order && order.orderNo, scenario.last4);
            return new Status(Status.ERROR, 'POST_AUTH_FRAUD_DECISION_NOT_GUARANTEED', 'Mock fraud rejected');
        }
        if (scenario.postAuth === helper.POST_AUTH.PENDING) {
            logger.info('Mock fraud pending for order {0} last-4 {1}', order && order.orderNo, scenario.last4);
            return new Status(Status.OK, 'POST_AUTH_FRAUD_DECISION_PENDING', 'Mock fraud pending');
        }
        return new Status(Status.OK, 'POST_AUTH_FRAUD_DECISION_GUARANTEED', 'Mock fraud guaranteed');
    } catch (e) {
        logger.error('afterPayment failed: {0}', e.message);
        return new Status(Status.ERROR, 'POST_AUTH_FRAUD_DECISION_NOT_GUARANTEED', e.message);
    }
};
