'use strict';

/**
 * Resolves Mock Fraud PENDING orders (last-4 0008 place, 0009 fail).
 * Run the installed job mock-fraud-resolve-pending after checkout parks the order.
 */

var Status = require('dw/system/Status');
var Logger = require('dw/system/Logger');
var Order = require('dw/order/Order');
var OrderMgr = require('dw/order/OrderMgr');
var helper = require('*/cartridge/scripts/helpers/mockFraudHelper');

var logger = Logger.getLogger('mock-fraud', 'resolvePending');

/**
 * @param {dw.order.Order} order
 */
function resolveOne(order) {
    if (!helper.orderHasPendingPostAuth(order)) {
        return 'skipped';
    }
    var scenario = helper.getFraudScenarioFromContainer(order);
    var place = scenario.pendingResolve !== helper.PENDING_RESOLVE.FAIL;
    var decision = place ? helper.POST_AUTH.GUARANTEED : helper.POST_AUTH.NOT_GUARANTEED;
    helper.forEachPaymentInstrument(order, function (paymentInstrument) {
        helper.setPostAuthDecision(paymentInstrument, decision);
    });
    OrderMgr.attemptOrderTransition(order);
    logger.info('Resolved PENDING order {0} last-4 {1} as {2}',
        order.orderNo, scenario.last4, place ? 'place' : 'fail');
    return place ? 'placed' : 'failed';
}

/**
 * @returns {dw.system.Status}
 */
exports.execute = function () {
    var placed = 0;
    var failed = 0;
    var skipped = 0;
    try {
        OrderMgr.processOrders(function (order) {
            try {
                var result = resolveOne(order);
                if (result === 'placed') {
                    placed += 1;
                } else if (result === 'failed') {
                    failed += 1;
                } else {
                    skipped += 1;
                }
            } catch (inner) {
                logger.error('PENDING resolve failed for {0}: {1}', order && order.orderNo, inner.message);
                skipped += 1;
            }
        }, 'status = {0}', Order.ORDER_STATUS_CREATED);
        return new Status(Status.OK, 'OK',
            'Mock fraud PENDING resolve placed=' + placed + ' failed=' + failed + ' skipped=' + skipped);
    } catch (e) {
        logger.error('PENDING resolve job failed: {0}', e.message);
        return new Status(Status.ERROR, 'MOCK_FRAUD_PENDING_RESOLVE', e.message);
    }
};
