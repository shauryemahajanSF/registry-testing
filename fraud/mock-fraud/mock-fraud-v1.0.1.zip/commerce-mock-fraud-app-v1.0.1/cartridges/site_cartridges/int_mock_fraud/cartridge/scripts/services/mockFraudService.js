'use strict';

/**
 * Unused Service Framework wrapper. Mock hooks do not call a provider.
 * Real fraud integrations should use this pattern instead of HTTPClient.
 */

var LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');
var Logger = require('dw/system/Logger');

var logger = Logger.getLogger('mock-fraud', 'service');
var SERVICE_ID = 'mock.fraud.api';

function getService() {
    return LocalServiceRegistry.createService(SERVICE_ID, {
        createRequest: function (svc) {
            svc.setRequestMethod('GET');
            svc.addHeader('Accept', 'application/json');
            return '';
        },
        parseResponse: function (svc, client) {
            return client && client.text ? client.text : '';
        },
        filterLogMessage: function (message) {
            return message;
        }
    });
}

/**
 * @returns {dw.svc.HTTPService}
 */
function getConfiguredService() {
    try {
        return getService();
    } catch (e) {
        logger.warn('mock.fraud.api is not configured: {0}', e.message);
        return null;
    }
}

module.exports = {
    getConfiguredService: getConfiguredService
};
