'use strict';

var assert = require('chai').assert;
var proxyquire = require('proxyquire').noCallThru();

function StatusStub(code, statusCode, message) {
    this.status = code;
    this.code = statusCode;
    this.message = message;
}
StatusStub.OK = 0;
StatusStub.ERROR = 1;

describe('resolvePending job', function () {
    var execute;
    var transitions;
    var helperStub;

    beforeEach(function () {
        transitions = [];
        helperStub = {
            PENDING_RESOLVE: { PLACE: 'place', FAIL: 'fail' },
            POST_AUTH: { GUARANTEED: 'GUARANTEED', NOT_GUARANTEED: 'NOT_GUARANTEED' },
            orderHasPendingPostAuth: function () {
                return true;
            },
            getFraudScenarioFromContainer: function () {
                return { pendingResolve: 'place', last4: '0008' };
            },
            forEachPaymentInstrument: function (order, fn) {
                fn({ id: 'pi' });
            },
            setPostAuthDecision: function () {}
        };
        var job = proxyquire('../../cartridge/scripts/jobs/resolvePending', {
            'dw/system/Status': StatusStub,
            'dw/system/Logger': {
                getLogger: function () {
                    return { info: function () {}, error: function () {} };
                }
            },
            'dw/order/Order': { ORDER_STATUS_CREATED: 0 },
            'dw/order/OrderMgr': {
                processOrders: function (fn) {
                    fn({ orderNo: '00001234' });
                },
                attemptOrderTransition: function (order) {
                    transitions.push(order.orderNo);
                }
            },
            '*/cartridge/scripts/helpers/mockFraudHelper': helperStub
        });
        execute = job.execute;
    });

    it('updates post-auth and calls attemptOrderTransition', function () {
        var status = execute();
        assert.strictEqual(status.status, StatusStub.OK);
        assert.deepEqual(transitions, ['00001234']);
        assert.match(status.message, /placed=1/);
    });

    it('skips orders without PENDING post-auth', function () {
        helperStub.orderHasPendingPostAuth = function () {
            return false;
        };
        var status = execute();
        assert.deepEqual(transitions, []);
        assert.match(status.message, /skipped=1/);
    });
});
