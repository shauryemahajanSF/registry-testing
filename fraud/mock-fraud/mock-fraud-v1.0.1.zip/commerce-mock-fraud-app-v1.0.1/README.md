# Mock Fraud

Backend-only sample Commerce App for Salesforce B2C Commerce 26.10 fraud orchestration. It drives pre-auth (`beforePayment`) and post-auth (`afterPayment`) from the **BANK_TRANSFER last-4** so e2e and blitz can exercise Approve, Decline, Challenge, Reject, and Pending without a live fraud provider.

This app has **no Storefront Next UI**. Challenge is a signal for the **payment** app to run 3DS — not a fraud-owned screen. Shopper email is not a driver.

## What it does

| Hook / job | Purpose |
|------------|---------|
| `sfcc.app.fraud.beforePayment` | Sets `preAuthFraudDecision` on every payment transaction and returns `Status.OK` / `Status.ERROR` with the matching code |
| `sfcc.app.fraud.afterPayment` | Sets `postAuthFraudDecision` after all instruments are authorized/captured |
| `sfcc.app.fraud.checkConnectionHealth` | Checkout Hub connection badge |
| Job `mock-fraud-resolve-pending` | For last-4 `0008`/`0009`: set post-auth GUARANTEED or NOT_GUARANTEED, then `OrderMgr.attemptOrderTransition` |

## Last-4 scenario matrix

Keep this table in sync with Mock Payment. Enter the last-4 on the Mock Payment chip (defaults to `0000`).

| Last-4 | Pre-auth | Payment (Mock Payment) | Post-auth |
|--------|----------|------------------------|-----------|
| `0000` (default) | `APPROVED` | authorize | `GUARANTEED` |
| `0001` | `DECLINED` | — | — (`createOrder` rolls back) |
| `0002` | `CHALLENGE` | skip create/transition; `afterUpdate` authorizes | `GUARANTEED` |
| `0003` | `APPROVED` | authorize | `NOT_GUARANTEED` (fail-order) |
| `0004` | `APPROVED` | fail `afterCreate` | — |
| `0005` | `APPROVED` | leave CREATED | `afterPayment` never runs |
| `0006` | `CHALLENGE` | skip create/transition; `afterUpdate` fails | — |
| `0008` | `APPROVED` | authorize | `PENDING` → job places |
| `0009` | `APPROVED` | authorize | `PENDING` → job fails |

After an `0008` or `0009` checkout, run **Administration → Operations → Jobs → `mock-fraud-resolve-pending`**. The job does **not** call `placeOrder` / `failOrder`; it updates post-auth and uses `OrderMgr.attemptOrderTransition`. It skips `0005` (payment pending, not fraud PENDING).

## Architecture

- Cartridge: `int_mock_fraud`
- Service: `mock.fraud.api` (template only; unused by the mock hooks)
- Domain: `fraud`
- No `storefrontSupport`

Enable platform orchestration with the `PaymentFraudOrchestrationEnabled` **feature toggle** on `CommerceAppToggles` (Commerce Apps group, default `false`). This is **not** a site preference.

## Installation

1. Install the app from Commerce Apps / Checkout Hub.
2. Enable `PaymentFraudOrchestrationEnabled` (feature toggle).
3. Install **Mock Payment** so checkout can claim `BANK_TRANSFER` and persist last-4.
4. Place orders using the last-4 matrix. For `0008`/`0009`, run `mock-fraud-resolve-pending`.

## Future provider integration

The installed `mock.fraud.api` service is unused. A real provider should replace the last-4 matrix with Service Framework calls, persist risk scores as custom attributes, and implement a webhook that updates post-auth then calls `OrderMgr.attemptOrderTransition` for `PENDING` decisions.

## Development

```bash
cd cartridges/site_cartridges/int_mock_fraud
npm install
npm test
```
