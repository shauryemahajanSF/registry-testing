'use strict';

var assert = require('chai').assert;
var proxyquire = require('proxyquire').noCallThru();

function Status(code, codeName, message) {
    this.status = code;
    this.code = codeName;
    this.message = message;
}
Status.OK = 0;
Status.ERROR = 1;

var PaymentTransactionStub = {
    TYPE_AUTH: 'AUTH',
    STATUS_AUTHORIZED: 1,
    STATUS_PENDING: 8,
    PRE_AUTH_FRAUD_DECISION_CHALLENGE: 'CHALLENGE'
};

function CardDetails() {
    this.last4 = null;
    this.brand = null;
}
CardDetails.prototype.setLast4 = function (value) { this.last4 = value; };
CardDetails.prototype.setBrand = function (value) { this.brand = value; };
CardDetails.BRAND_VISA = 'visa';

function SepaDetails() {
    this.last4 = null;
    this.accountHolderName = null;
}
SepaDetails.prototype.setLast4 = function (value) { this.last4 = value; };
SepaDetails.prototype.setAccountHolderName = function (value) { this.accountHolderName = value; };

function instrumentFromDetails(last4, extras) {
    extras = extras || {};
    return {
        getPaymentMethod: function () {
            return extras.method || 'CREDIT_CARD';
        },
        getPaymentDetails: function () {
            return last4 ? { getLast4: function () { return last4; } } : null;
        },
        getCreditCardNumberLastDigits: function () {
            return extras.cardLast4 || null;
        },
        getBankAccountNumberLastDigits: function () {
            return null;
        },
        setPaymentDetails: function () {},
        getPaymentTransaction: function () {
            return extras.transaction || {
                getAmount: function () { return { getValue: function () { return 10; } }; },
                setType: function () {},
                setStatus: function () {},
                setTransactionID: function () {},
                getPreAuthFraudDecision: function () {
                    return extras.preAuth || null;
                }
            };
        }
    };
}

describe('paymentHooks.afterUpdateOrderPaymentInstrument', function () {
    var hooks;

    beforeEach(function () {
        var helper = proxyquire('../../cartridge/scripts/helpers/mockPaymentHelper', {
            'dw/system/Logger': {
                getLogger: function () {
                    return { warn: function () {}, error: function () {}, info: function () {} };
                }
            },
            'dw/order/PaymentTransaction': PaymentTransactionStub,
            'dw/extensions/payments/SalesforceCardPaymentDetails': CardDetails,
            'dw/extensions/payments/SalesforceSepaDebitPaymentDetails': SepaDetails
        });
        hooks = proxyquire('../../cartridge/scripts/hooks/paymentHooks', {
            'dw/system/Status': Status,
            'dw/system/Logger': {
                getLogger: function () {
                    return { warn: function () {}, error: function () {}, info: function () {} };
                }
            },
            'dw/order/PaymentTransaction': PaymentTransactionStub,
            '*/cartridge/scripts/helpers/mockPaymentHelper': helper
        });
    });

    it('declines 0004 on the kick PATCH even when pre-auth is not CHALLENGE', function () {
        var status = hooks.afterUpdateOrderPaymentInstrument(
            { orderNo: '00005635' },
            instrumentFromDetails('0004'),
            { getPaymentCard: function () { return null; } }
        );
        assert.strictEqual(status.status, Status.ERROR);
        assert.strictEqual(status.code, 'PAYMENT_DECLINED');
    });

    it('still declines 0006 when pre-auth is CHALLENGE', function () {
        var status = hooks.afterUpdateOrderPaymentInstrument(
            { orderNo: '00005612' },
            instrumentFromDetails('0006', { preAuth: 'CHALLENGE' }),
            { getPaymentCard: function () { return null; } }
        );
        assert.strictEqual(status.status, Status.ERROR);
        assert.strictEqual(status.code, 'PAYMENT_DECLINED');
    });

    it('leaves 0000 kick PATCH as OK so the platform can place', function () {
        var txn = recordingTransaction();
        var status = hooks.afterUpdateOrderPaymentInstrument(
            { orderNo: '00005600' },
            instrumentFromDetails('0000', { transaction: txn }),
            { getPaymentCard: function () { return null; } }
        );
        assert.strictEqual(status.status, Status.OK);
        assert.strictEqual(txn.status, null);
    });

    it('holds 0005 as STATUS_PENDING so native PATCH auth cannot place', function () {
        var txn = recordingTransaction();
        var status = hooks.afterUpdateOrderPaymentInstrument(
            { orderNo: '00005639' },
            instrumentFromDetails('0005', { transaction: txn }),
            { getPaymentCard: function () { return null; } }
        );
        assert.strictEqual(status.status, Status.OK);
        assert.strictEqual(txn.status, PaymentTransactionStub.STATUS_PENDING);
    });
});

function recordingTransaction(preAuth) {
    return {
        status: null,
        getAmount: function () { return { getValue: function () { return 10; } }; },
        setType: function () {},
        setStatus: function (value) { this.status = value; },
        setTransactionID: function () {},
        getPreAuthFraudDecision: function () {
            return preAuth || null;
        }
    };
}
