'use strict';

var assert = require('chai').assert;
var proxyquire = require('proxyquire').noCallThru();

var PaymentTransactionStub = {
    TYPE_AUTH: 'AUTH',
    STATUS_AUTHORIZED: 1,
    PRE_AUTH_FRAUD_DECISION_CHALLENGE: 'CHALLENGE'
};

function CardDetails() {
    this.last4 = null;
    this.brand = null;
}
CardDetails.prototype.setLast4 = function (value) { this.last4 = value; };
CardDetails.prototype.setBrand = function (value) { this.brand = value; };
CardDetails.BRAND_VISA = 'visa';

function SepaDetails() {
    this.last4 = null;
    this.accountHolderName = null;
}
SepaDetails.prototype.setLast4 = function (value) { this.last4 = value; };
SepaDetails.prototype.setAccountHolderName = function (value) { this.accountHolderName = value; };

function instrumentFromDetails(last4, method) {
    return {
        getPaymentMethod: function () {
            return method || 'CREDIT_CARD';
        },
        getPaymentDetails: function () {
            return last4 ? { getLast4: function () { return last4; } } : null;
        },
        getCreditCardNumberLastDigits: function () {
            return null;
        },
        getBankAccountNumberLastDigits: function () {
            return null;
        }
    };
}

describe('mockPaymentHelper', function () {
    var helper;
    var lastSetDetails;

    beforeEach(function () {
        lastSetDetails = null;
        helper = proxyquire('../../cartridge/scripts/helpers/mockPaymentHelper', {
            'dw/system/Logger': {
                getLogger: function () {
                    return {
                        warn: function () {},
                        error: function () {},
                        info: function () {}
                    };
                }
            },
            'dw/order/PaymentTransaction': PaymentTransactionStub,
            'dw/extensions/payments/SalesforceCardPaymentDetails': CardDetails,
            'dw/extensions/payments/SalesforceSepaDebitPaymentDetails': SepaDetails
        });
    });

    describe('normalizeLast4', function () {
        it('defaults missing values to 0000', function () {
            assert.strictEqual(helper.normalizeLast4(null), '0000');
            assert.strictEqual(helper.normalizeLast4(''), '0000');
            assert.strictEqual(helper.normalizeLast4('abcd'), '0000');
        });

        it('pads short digit strings and keeps the last four', function () {
            assert.strictEqual(helper.normalizeLast4('2'), '0002');
            assert.strictEqual(helper.normalizeLast4('12345'), '2345');
        });
    });

    describe('getPaymentScenario', function () {
        it('authorizes the default last-4', function () {
            var scenario = helper.getPaymentScenario(instrumentFromDetails(null));
            assert.strictEqual(scenario.pay, helper.PAY.AUTH);
            assert.strictEqual(scenario.last4, '0000');
        });

        it('reads last-4 from paymentDetails', function () {
            assert.strictEqual(helper.getInstrumentLast4(instrumentFromDetails('0004')), '0004');
            assert.strictEqual(helper.getPaymentScenario(instrumentFromDetails('0004')).pay, helper.PAY.FAIL);
            assert.strictEqual(helper.getPaymentScenario(instrumentFromDetails('0006')).pay, helper.PAY.FAIL);
        });

        it('holds 0005 as payment pending', function () {
            var scenario = helper.getPaymentScenario(instrumentFromDetails('0005'));
            assert.strictEqual(scenario.pay, helper.PAY.PENDING);
        });

        it('authorizes challenge codes so afterUpdate can succeed or fail later', function () {
            assert.strictEqual(helper.getPaymentScenario(instrumentFromDetails('0002')).pay, helper.PAY.AUTH);
        });

        it('falls back to credit-card last digits when paymentDetails is empty', function () {
            var scenario = helper.getPaymentScenario({
                getPaymentDetails: function () { return null; },
                getCreditCardNumberLastDigits: function () { return '0004'; },
                getBankAccountNumberLastDigits: function () { return '0000'; }
            });
            assert.strictEqual(scenario.last4, '0004');
            assert.strictEqual(scenario.pay, helper.PAY.FAIL);
        });
    });

    describe('persistPaymentDetails', function () {
        it('sets card paymentDetails.last4 from request paymentCard.number', function () {
            var pi = {
                getPaymentMethod: function () { return 'CREDIT_CARD'; },
                setPaymentDetails: function (details) { lastSetDetails = details; },
                getPaymentDetails: function () { return null; },
                getCreditCardNumberLastDigits: function () { return null; },
                getBankAccountNumberLastDigits: function () { return null; }
            };
            var last4 = helper.persistPaymentDetails(pi, {
                getPaymentCard: function () {
                    return {
                        getNumber: function () { return '************0002'; },
                        getNumberLastDigits: function () { return null; },
                        getHolder: function () { return 'Mock Shopper'; }
                    };
                }
            });
            assert.strictEqual(last4, '0002');
            assert.instanceOf(lastSetDetails, CardDetails);
            assert.strictEqual(lastSetDetails.last4, '0002');
            assert.strictEqual(lastSetDetails.brand, CardDetails.BRAND_VISA);
        });

        it('sets SEPA paymentDetails.last4 and holder from paymentCard', function () {
            var pi = {
                getPaymentMethod: function () { return 'SEPA_DIRECT_DEBIT'; },
                setPaymentDetails: function (details) { lastSetDetails = details; },
                getPaymentDetails: function () { return null; },
                getCreditCardNumberLastDigits: function () { return '0008'; },
                getBankAccountNumberLastDigits: function () { return null; }
            };
            helper.persistPaymentDetails(pi, {
                getPaymentCard: function () {
                    return {
                        getNumber: function () { return '************0008'; },
                        getNumberLastDigits: function () { return null; },
                        getHolder: function () { return 'Ada Lovelace'; }
                    };
                }
            });
            assert.instanceOf(lastSetDetails, SepaDetails);
            assert.strictEqual(lastSetDetails.last4, '0008');
            assert.strictEqual(lastSetDetails.accountHolderName, 'Ada Lovelace');
        });

        it('falls back to instrument last-4 when the request has no paymentCard', function () {
            var pi = {
                getPaymentMethod: function () { return 'SEPA_DIRECT_DEBIT'; },
                setPaymentDetails: function (details) { lastSetDetails = details; },
                getPaymentDetails: function () {
                    return { getLast4: function () { return '0004'; } };
                },
                getCreditCardNumberLastDigits: function () { return null; },
                getBankAccountNumberLastDigits: function () { return null; }
            };
            helper.persistPaymentDetails(pi, {
                getPaymentCard: function () { return null; }
            });
            assert.strictEqual(lastSetDetails.last4, '0004');
        });
    });

    describe('isPreAuthChallenge', function () {
        it('reads CHALLENGE from the payment transaction', function () {
            var result = helper.isPreAuthChallenge({
                getPaymentTransaction: function () {
                    return {
                        getPreAuthFraudDecision: function () {
                            return PaymentTransactionStub.PRE_AUTH_FRAUD_DECISION_CHALLENGE;
                        }
                    };
                }
            });
            assert.isTrue(result);
        });

        it('is false when decision is APPROVED', function () {
            var result = helper.isPreAuthChallenge({
                getPaymentTransaction: function () {
                    return {
                        getPreAuthFraudDecision: function () {
                            return 'APPROVED';
                        }
                    };
                }
            });
            assert.isFalse(result);
        });
    });

    describe('authorizeInstrument', function () {
        it('sets AUTHORIZED on the existing instrument amount', function () {
            var status = null;
            var type = null;
            var authorized = helper.authorizeInstrument({ orderNo: '0001' }, {
                getPaymentTransaction: function () {
                    return {
                        getAmount: function () {
                            return { getValue: function () { return 12.5; } };
                        },
                        setType: function (value) { type = value; },
                        setStatus: function (value) { status = value; },
                        setTransactionID: function () {},
                        setAmount: function () {}
                    };
                }
            });
            assert.isTrue(authorized);
            assert.strictEqual(status, PaymentTransactionStub.STATUS_AUTHORIZED);
            assert.strictEqual(type, PaymentTransactionStub.TYPE_AUTH);
        });
    });
});
