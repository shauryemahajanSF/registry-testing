'use strict';

var assert = require('chai').assert;
var proxyquire = require('proxyquire').noCallThru();

var PaymentTransactionStub = {
    TYPE_AUTH: 'AUTH',
    STATUS_AUTHORIZED: 1,
    PRE_AUTH_FRAUD_DECISION_CHALLENGE: 'CHALLENGE'
};

function CardDetails() {
    this.last4 = null;
    this.brand = null;
    this.expirationMonth = null;
    this.expirationYear = null;
    this.fundingType = null;
    this.issuingCountry = null;
    this.bin = null;
    this.token = null;
    this.tokenType = null;
}
CardDetails.prototype.setLast4 = function (value) { this.last4 = value; };
CardDetails.prototype.setBrand = function (value) { this.brand = value; };
CardDetails.prototype.setExpirationMonth = function (value) { this.expirationMonth = value; };
CardDetails.prototype.setExpirationYear = function (value) { this.expirationYear = value; };
CardDetails.prototype.setFundingType = function (value) { this.fundingType = value; };
CardDetails.prototype.setIssuingCountry = function (value) { this.issuingCountry = value; };
CardDetails.prototype.setBin = function (value) { this.bin = value; };
CardDetails.prototype.setToken = function (value) { this.token = value; };
CardDetails.prototype.setTokenType = function (value) { this.tokenType = value; };
CardDetails.BRAND_VISA = 'visa';
CardDetails.BRAND_MASTERCARD = 'mastercard';
CardDetails.FUNDING_TYPE_CREDIT = 'CREDIT';
CardDetails.TOKEN_TYPE_GATEWAY = 'GATEWAY';

function CardTransactionDetails() {
    this.cvcResult = null;
    this.avsResult = null;
    this.threeDSResult = null;
    this.threeDSVersion = null;
    this.threeDSTransactionId = null;
    this.electronicCommerceIndicator = null;
}
CardTransactionDetails.prototype.setCvcResult = function (value) { this.cvcResult = value; };
CardTransactionDetails.prototype.setAvsResult = function (value) { this.avsResult = value; };
CardTransactionDetails.prototype.setThreeDSResult = function (value) { this.threeDSResult = value; };
CardTransactionDetails.prototype.setThreeDSVersion = function (value) { this.threeDSVersion = value; };
CardTransactionDetails.prototype.setThreeDSTransactionId = function (value) { this.threeDSTransactionId = value; };
CardTransactionDetails.prototype.setElectronicCommerceIndicator = function (value) { this.electronicCommerceIndicator = value; };
CardTransactionDetails.CVC_RESULT_MATCH = 'MATCH';
CardTransactionDetails.CVC_RESULT_NO_MATCH = 'NO_MATCH';
CardTransactionDetails.CVC_RESULT_NOT_PROCESSED = 'NOT_PROCESSED';
CardTransactionDetails.AVS_RESULT_MATCH = 'Y';
CardTransactionDetails.AVS_RESULT_NO_MATCH = 'N';
CardTransactionDetails.AVS_RESULT_UNAVAILABLE = 'U';
CardTransactionDetails.THREE_DS_RESULT_AUTHENTICATED = 'AUTHENTICATED';
CardTransactionDetails.THREE_DS_RESULT_FAILED = 'FAILED';
CardTransactionDetails.THREE_DS_VERSION_V2 = 'V2';

function SepaDetails() {
    this.last4 = null;
    this.accountHolderName = null;
}
SepaDetails.prototype.setLast4 = function (value) { this.last4 = value; };
SepaDetails.prototype.setAccountHolderName = function (value) { this.accountHolderName = value; };

function instrumentFromDetails(last4, method) {
    return {
        getPaymentMethod: function () {
            return method || 'CREDIT_CARD';
        },
        getPaymentDetails: function () {
            return last4 ? { getLast4: function () { return last4; } } : null;
        },
        getCreditCardNumberLastDigits: function () {
            return null;
        },
        getBankAccountNumberLastDigits: function () {
            return null;
        }
    };
}

describe('mockPaymentHelper', function () {
    var helper;
    var lastSetDetails;

    beforeEach(function () {
        lastSetDetails = null;
        helper = proxyquire('../../cartridge/scripts/helpers/mockPaymentHelper', {
            'dw/system/Logger': {
                getLogger: function () {
                    return {
                        warn: function () {},
                        error: function () {},
                        info: function () {}
                    };
                }
            },
            'dw/order/PaymentTransaction': PaymentTransactionStub,
            'dw/extensions/payments/SalesforceCardPaymentDetails': CardDetails,
            'dw/extensions/payments/SalesforceCardTransactionDetails': CardTransactionDetails,
            'dw/extensions/payments/SalesforceSepaDebitPaymentDetails': SepaDetails
        });
    });

    describe('normalizeLast4', function () {
        it('defaults missing values to 0000', function () {
            assert.strictEqual(helper.normalizeLast4(null), '0000');
            assert.strictEqual(helper.normalizeLast4(''), '0000');
            assert.strictEqual(helper.normalizeLast4('abcd'), '0000');
        });

        it('pads short digit strings and keeps the last four', function () {
            assert.strictEqual(helper.normalizeLast4('2'), '0002');
            assert.strictEqual(helper.normalizeLast4('12345'), '2345');
        });
    });

    describe('getPaymentScenario', function () {
        it('authorizes the default last-4', function () {
            var scenario = helper.getPaymentScenario(instrumentFromDetails(null));
            assert.strictEqual(scenario.pay, helper.PAY.AUTH);
            assert.strictEqual(scenario.last4, '0000');
        });

        it('reads last-4 from paymentDetails', function () {
            assert.strictEqual(helper.getInstrumentLast4(instrumentFromDetails('0004')), '0004');
            assert.strictEqual(helper.getPaymentScenario(instrumentFromDetails('0004')).pay, helper.PAY.FAIL);
            assert.strictEqual(helper.getPaymentScenario(instrumentFromDetails('0006')).pay, helper.PAY.FAIL);
        });

        it('holds 0005 as payment pending', function () {
            var scenario = helper.getPaymentScenario(instrumentFromDetails('0005'));
            assert.strictEqual(scenario.pay, helper.PAY.PENDING);
        });

        it('authorizes challenge codes so afterUpdate can succeed or fail later', function () {
            assert.strictEqual(helper.getPaymentScenario(instrumentFromDetails('0002')).pay, helper.PAY.AUTH);
        });

        it('falls back to credit-card last digits when paymentDetails is empty', function () {
            var scenario = helper.getPaymentScenario({
                getPaymentDetails: function () { return null; },
                getCreditCardNumberLastDigits: function () { return '0004'; },
                getBankAccountNumberLastDigits: function () { return '0000'; }
            });
            assert.strictEqual(scenario.last4, '0004');
            assert.strictEqual(scenario.pay, helper.PAY.FAIL);
        });
    });

    describe('persistPaymentDetails', function () {
        it('sets card paymentDetails.last4 from request paymentCard.number', function () {
            var pi = {
                getPaymentMethod: function () { return 'CREDIT_CARD'; },
                setPaymentDetails: function (details) { lastSetDetails = details; },
                getPaymentDetails: function () { return null; },
                getCreditCardNumberLastDigits: function () { return null; },
                getBankAccountNumberLastDigits: function () { return null; }
            };
            var last4 = helper.persistPaymentDetails(pi, {
                getPaymentCard: function () {
                    return {
                        getNumber: function () { return '************0002'; },
                        getNumberLastDigits: function () { return null; },
                        getHolder: function () { return 'Mock Shopper'; }
                    };
                }
            });
            assert.strictEqual(last4, '0002');
            assert.instanceOf(lastSetDetails, CardDetails);
            assert.strictEqual(lastSetDetails.last4, '0002');
            assert.strictEqual(lastSetDetails.brand, CardDetails.BRAND_VISA);
            assert.strictEqual(lastSetDetails.expirationMonth, 12);
            assert.strictEqual(lastSetDetails.expirationYear, 2030);
            assert.strictEqual(lastSetDetails.fundingType, CardDetails.FUNDING_TYPE_CREDIT);
            assert.strictEqual(lastSetDetails.issuingCountry, 'US');
            assert.strictEqual(lastSetDetails.bin, '411111');
            assert.strictEqual(lastSetDetails.token, 'mock-tok-0002');
            assert.strictEqual(lastSetDetails.tokenType, CardDetails.TOKEN_TYPE_GATEWAY);
        });

        it('copies card type and expiration from the request payment card', function () {
            var pi = {
                getPaymentMethod: function () { return 'CREDIT_CARD'; },
                setPaymentDetails: function (details) { lastSetDetails = details; },
                getPaymentDetails: function () { return null; },
                getCreditCardNumberLastDigits: function () { return null; },
                getBankAccountNumberLastDigits: function () { return null; }
            };
            helper.persistPaymentDetails(pi, {
                getPaymentCard: function () {
                    return {
                        getNumber: function () { return '************0000'; },
                        getHolder: function () { return 'Mock Shopper'; },
                        getCardType: function () { return 'MasterCard'; },
                        getExpirationMonth: function () { return 3; },
                        getExpirationYear: function () { return 2028; }
                    };
                }
            });
            assert.strictEqual(lastSetDetails.brand, CardDetails.BRAND_MASTERCARD);
            assert.strictEqual(lastSetDetails.expirationMonth, 3);
            assert.strictEqual(lastSetDetails.expirationYear, 2028);
        });

        it('sets SEPA paymentDetails.last4 and holder from paymentCard', function () {
            var pi = {
                getPaymentMethod: function () { return 'SEPA_DIRECT_DEBIT'; },
                setPaymentDetails: function (details) { lastSetDetails = details; },
                getPaymentDetails: function () { return null; },
                getCreditCardNumberLastDigits: function () { return '0008'; },
                getBankAccountNumberLastDigits: function () { return null; }
            };
            helper.persistPaymentDetails(pi, {
                getPaymentCard: function () {
                    return {
                        getNumber: function () { return '************0008'; },
                        getNumberLastDigits: function () { return null; },
                        getHolder: function () { return 'Ada Lovelace'; }
                    };
                }
            });
            assert.instanceOf(lastSetDetails, SepaDetails);
            assert.strictEqual(lastSetDetails.last4, '0008');
            assert.strictEqual(lastSetDetails.accountHolderName, 'Ada Lovelace');
        });

        it('falls back to instrument last-4 when the request has no paymentCard', function () {
            var pi = {
                getPaymentMethod: function () { return 'SEPA_DIRECT_DEBIT'; },
                setPaymentDetails: function (details) { lastSetDetails = details; },
                getPaymentDetails: function () {
                    return { getLast4: function () { return '0004'; } };
                },
                getCreditCardNumberLastDigits: function () { return null; },
                getBankAccountNumberLastDigits: function () { return null; }
            };
            helper.persistPaymentDetails(pi, {
                getPaymentCard: function () { return null; }
            });
            assert.strictEqual(lastSetDetails.last4, '0004');
        });
    });

    describe('isPreAuthChallenge', function () {
        it('reads CHALLENGE from the payment transaction', function () {
            var result = helper.isPreAuthChallenge({
                getPaymentTransaction: function () {
                    return {
                        getPreAuthFraudDecision: function () {
                            return PaymentTransactionStub.PRE_AUTH_FRAUD_DECISION_CHALLENGE;
                        }
                    };
                }
            });
            assert.isTrue(result);
        });

        it('is false when decision is APPROVED', function () {
            var result = helper.isPreAuthChallenge({
                getPaymentTransaction: function () {
                    return {
                        getPreAuthFraudDecision: function () {
                            return 'APPROVED';
                        }
                    };
                }
            });
            assert.isFalse(result);
        });
    });

    describe('authorizeInstrument', function () {
        it('sets AUTHORIZED on the existing instrument amount', function () {
            var status = null;
            var type = null;
            var transactionDetails = null;
            var authorized = helper.authorizeInstrument({ orderNo: '0001' }, {
                getPaymentMethod: function () { return 'CREDIT_CARD'; },
                getPaymentTransaction: function () {
                    return {
                        getAmount: function () {
                            return { getValue: function () { return 12.5; } };
                        },
                        setType: function (value) { type = value; },
                        setStatus: function (value) { status = value; },
                        setTransactionID: function () {},
                        setAmount: function () {},
                        setTransactionDetails: function (details) { transactionDetails = details; },
                        getPreAuthFraudDecision: function () { return null; }
                    };
                }
            });
            assert.isTrue(authorized);
            assert.strictEqual(status, PaymentTransactionStub.STATUS_AUTHORIZED);
            assert.strictEqual(type, PaymentTransactionStub.TYPE_AUTH);
            assert.instanceOf(transactionDetails, CardTransactionDetails);
            assert.strictEqual(transactionDetails.cvcResult, CardTransactionDetails.CVC_RESULT_MATCH);
            assert.strictEqual(transactionDetails.avsResult, CardTransactionDetails.AVS_RESULT_MATCH);
            assert.strictEqual(transactionDetails.threeDSResult, null);
        });

        it('records authenticated 3DS transaction details after a challenge', function () {
            var transactionDetails = null;
            helper.authorizeInstrument({ orderNo: '00005602' }, {
                getPaymentMethod: function () { return 'CREDIT_CARD'; },
                getPaymentTransaction: function () {
                    return {
                        getAmount: function () {
                            return { getValue: function () { return 10; } };
                        },
                        setType: function () {},
                        setStatus: function () {},
                        setTransactionID: function () {},
                        setTransactionDetails: function (details) { transactionDetails = details; },
                        getPreAuthFraudDecision: function () { return 'CHALLENGE'; }
                    };
                }
            });
            assert.strictEqual(transactionDetails.threeDSResult, CardTransactionDetails.THREE_DS_RESULT_AUTHENTICATED);
            assert.strictEqual(transactionDetails.threeDSVersion, CardTransactionDetails.THREE_DS_VERSION_V2);
            assert.strictEqual(transactionDetails.electronicCommerceIndicator, '05');
            assert.strictEqual(transactionDetails.threeDSTransactionId, 'mock-3ds-00005602');
        });
    });
});
