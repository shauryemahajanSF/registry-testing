'use strict';

/**
 * Shared helpers for the Mock Payment Commerce App.
 * Claims CREDIT_CARD and SEPA_DIRECT_DEBIT. Scenarios are keyed by
 * paymentDetails.last4 (ISV pattern, not Salesforce Payments specific).
 */

var Logger = require('dw/system/Logger');
var PaymentTransaction = require('dw/order/PaymentTransaction');
var SalesforceCardPaymentDetails = require('dw/extensions/payments/SalesforceCardPaymentDetails');
var SalesforceSepaDebitPaymentDetails = require('dw/extensions/payments/SalesforceSepaDebitPaymentDetails');

var logger = Logger.getLogger('mock-payment', 'helper');

var CREDIT_CARD = 'CREDIT_CARD';
var SEPA_DIRECT_DEBIT = 'SEPA_DIRECT_DEBIT';
var CLAIMED_METHODS = [CREDIT_CARD, SEPA_DIRECT_DEBIT];
var DEFAULT_LAST4 = '0000';

var PAY = {
    AUTH: 'auth',
    FAIL: 'fail',
    PENDING: 'pending'
};

/**
 * Last-4 → payment outcome. Keep in sync with Mock Fraud.
 * 0000 happy, 0001 fraud-decline (auth unused), 0002 3DS then auth,
 * 0003 post-auth reject (auth), 0004 pay-fail, 0005 pay-pending,
 * 0006 3DS then fail, 0008 pending-then-place, 0009 pending-then-fail.
 */
var LAST4_SCENARIOS = {
    '0000': { pay: PAY.AUTH },
    '0001': { pay: PAY.AUTH },
    '0002': { pay: PAY.AUTH },
    '0003': { pay: PAY.AUTH },
    '0004': { pay: PAY.FAIL },
    '0005': { pay: PAY.PENDING },
    '0006': { pay: PAY.FAIL },
    '0008': { pay: PAY.AUTH },
    '0009': { pay: PAY.AUTH }
};

/**
 * @param {string|null|undefined} value
 * @returns {string}
 */
function normalizeLast4(value) {
    if (!value) {
        return DEFAULT_LAST4;
    }
    var digits = String(value).replace(/\D/g, '');
    if (!digits) {
        return DEFAULT_LAST4;
    }
    if (digits.length >= 4) {
        return digits.slice(-4);
    }
    return ('0000' + digits).slice(-4);
}

/**
 * @param {string|null|undefined} method
 * @returns {boolean}
 */
function isSepaMethod(method) {
    return method === SEPA_DIRECT_DEBIT || method === 'SEPA_DEBIT';
}

/**
 * @param {string|null|undefined} method
 * @returns {boolean}
 */
function isClaimedMethod(method) {
    return method === CREDIT_CARD || isSepaMethod(method);
}

/**
 * Read last-4 from a Shopper Baskets/Orders *request* WO.
 * Request documents have no paymentDetails (GET-only). Call Java getters —
 * `request.paymentDetails` / `typeof request.getPaymentCard` throw
 * Unknown property on Basket/OrderPaymentInstrumentRequestWO.
 * Last-4 is on paymentCard.number → SCAPI maskedNumber.
 * @param {Object|null|undefined} request
 * @returns {string|null}
 */
function last4FromRequest(request) {
    if (!request) {
        return null;
    }
    var card;
    try {
        card = request.getPaymentCard();
    } catch (e) {
        logger.warn('request paymentCard last-4 lookup failed: {0}', e.message);
        return null;
    }
    if (!card) {
        return null;
    }
    var raw;
    try {
        raw = card.getNumber();
    } catch (e) {
        raw = null;
    }
    if (!raw) {
        try {
            raw = card.getNumberLastDigits();
        } catch (e) {
            raw = null;
        }
    }
    return raw ? normalizeLast4(raw) : null;
}

/**
 * @param {Object|null|undefined} request
 * @returns {string|null}
 */
function holderFromRequest(request) {
    if (!request) {
        return null;
    }
    try {
        var card = request.getPaymentCard();
        if (card) {
            var holder = card.getHolder();
            if (holder) {
                return String(holder);
            }
        }
    } catch (e) {
        logger.warn('request paymentCard holder lookup failed: {0}', e.message);
    }
    return null;
}

/**
 * @param {dw.order.PaymentInstrument|null|undefined} paymentInstrument
 * @returns {string}
 */
function getInstrumentLast4(paymentInstrument) {
    if (!paymentInstrument) {
        return DEFAULT_LAST4;
    }
    try {
        var details = paymentInstrument.getPaymentDetails();
        if (details) {
            var detailsLast4 = details.getLast4();
            if (detailsLast4) {
                return normalizeLast4(detailsLast4);
            }
        }
    } catch (e) {
        logger.warn('paymentDetails last-4 lookup failed: {0}', e.message);
    }
    try {
        var cardLast4 = paymentInstrument.getCreditCardNumberLastDigits();
        if (cardLast4) {
            return normalizeLast4(cardLast4);
        }
    } catch (e) {
        logger.warn('credit-card last-4 lookup failed: {0}', e.message);
    }
    try {
        var bankLast4 = paymentInstrument.getBankAccountNumberLastDigits();
        if (bankLast4) {
            return normalizeLast4(bankLast4);
        }
    } catch (e) {
        logger.warn('bank last-4 lookup failed: {0}', e.message);
    }
    return DEFAULT_LAST4;
}

/**
 * Persist shopper-safe last-4 on paymentDetails so GET order (and any
 * document that copies getDetails()) returns paymentDetails.last4.
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument
 * @param {string} last4
 * @param {string|null|undefined} holder
 */
function applyPaymentDetails(paymentInstrument, last4, holder) {
    if (!paymentInstrument || typeof paymentInstrument.setPaymentDetails !== 'function') {
        return;
    }
    var code = normalizeLast4(last4);
    var method = null;
    try {
        method = paymentInstrument.getPaymentMethod();
    } catch (e) {
        method = null;
    }
    try {
        if (isSepaMethod(method)) {
            var sepa = new SalesforceSepaDebitPaymentDetails();
            sepa.setLast4(code);
            sepa.setAccountHolderName(holder || 'Mock Shopper');
            paymentInstrument.setPaymentDetails(sepa);
            return;
        }
        var card = new SalesforceCardPaymentDetails();
        card.setLast4(code);
        card.setBrand(SalesforceCardPaymentDetails.BRAND_VISA);
        paymentInstrument.setPaymentDetails(card);
    } catch (e) {
        logger.warn('setPaymentDetails failed: {0}', e.message);
    }
}

/**
 * @param {dw.order.PaymentInstrument} paymentInstrument
 * @param {Object|null|undefined} request
 * @returns {string}
 */
function persistPaymentDetails(paymentInstrument, request) {
    var last4 = last4FromRequest(request) || getInstrumentLast4(paymentInstrument);
    applyPaymentDetails(paymentInstrument, last4, holderFromRequest(request));
    return last4;
}

/**
 * @param {dw.order.PaymentInstrument|null|undefined} paymentInstrument
 * @returns {{pay: string, last4: string}}
 */
function getPaymentScenario(paymentInstrument) {
    var last4 = getInstrumentLast4(paymentInstrument);
    var mapped = LAST4_SCENARIOS[last4] || LAST4_SCENARIOS[DEFAULT_LAST4];
    return {
        pay: mapped.pay,
        last4: last4
    };
}

/**
 * @param {dw.order.PaymentInstrument} paymentInstrument
 * @returns {boolean}
 */
function isPreAuthChallenge(paymentInstrument) {
    if (!paymentInstrument) {
        return false;
    }
    try {
        var transaction = paymentInstrument.getPaymentTransaction();
        if (transaction) {
            var decision = transaction.getPreAuthFraudDecision();
            if (decision === PaymentTransaction.PRE_AUTH_FRAUD_DECISION_CHALLENGE
                || decision === 'CHALLENGE') {
                return true;
            }
        }
    } catch (e) {
        logger.warn('pre-auth lookup failed: {0}', e.message);
    }
    return false;
}

/**
 * Authorizes this payment instrument's amount (mixed-tender safe).
 * @param {dw.order.Order} order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument
 * @returns {boolean}
 */
function authorizeInstrument(order, paymentInstrument) {
    var transaction = paymentInstrument.getPaymentTransaction();
    if (!transaction) {
        return false;
    }
    var amount = transaction.getAmount();
    if (!amount || (typeof amount.getValue === 'function' && amount.getValue() === 0)) {
        if (order && typeof order.getTotalGrossPrice === 'function') {
            amount = order.getTotalGrossPrice();
            if (amount) {
                transaction.setAmount(amount);
            }
        }
    }
    transaction.setType(PaymentTransaction.TYPE_AUTH);
    transaction.setStatus(PaymentTransaction.STATUS_AUTHORIZED);
    if (typeof transaction.setTransactionID === 'function') {
        var seed = (order && order.orderNo ? order.orderNo : 'mock') + '-' + Date.now().toString(36);
        transaction.setTransactionID(('MOCKAUTH-' + seed).slice(0, 40));
    }
    return true;
}

/**
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument
 * @param {number} status
 */
function setTransactionStatus(paymentInstrument, status) {
    var transaction = paymentInstrument && paymentInstrument.getPaymentTransaction();
    if (!transaction) {
        return;
    }
    transaction.setStatus(status);
}

module.exports = {
    CREDIT_CARD: CREDIT_CARD,
    SEPA_DIRECT_DEBIT: SEPA_DIRECT_DEBIT,
    CLAIMED_METHODS: CLAIMED_METHODS,
    DEFAULT_LAST4: DEFAULT_LAST4,
    PAY: PAY,
    LAST4_SCENARIOS: LAST4_SCENARIOS,
    normalizeLast4: normalizeLast4,
    isSepaMethod: isSepaMethod,
    isClaimedMethod: isClaimedMethod,
    last4FromRequest: last4FromRequest,
    holderFromRequest: holderFromRequest,
    getInstrumentLast4: getInstrumentLast4,
    applyPaymentDetails: applyPaymentDetails,
    persistPaymentDetails: persistPaymentDetails,
    getPaymentScenario: getPaymentScenario,
    isPreAuthChallenge: isPreAuthChallenge,
    authorizeInstrument: authorizeInstrument,
    setTransactionStatus: setTransactionStatus
};
