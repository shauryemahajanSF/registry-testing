'use strict';

/**
 * Shared helpers for the Mock Payment Commerce App.
 * Claims CREDIT_CARD and SEPA_DIRECT_DEBIT. Scenarios are keyed by
 * paymentDetails.last4 (ISV pattern, not Salesforce Payments specific).
 */

var Logger = require('dw/system/Logger');
var PaymentTransaction = require('dw/order/PaymentTransaction');
var SalesforceCardPaymentDetails = require('dw/extensions/payments/SalesforceCardPaymentDetails');
var SalesforceCardTransactionDetails = require('dw/extensions/payments/SalesforceCardTransactionDetails');
var SalesforceSepaDebitPaymentDetails = require('dw/extensions/payments/SalesforceSepaDebitPaymentDetails');

var logger = Logger.getLogger('mock-payment', 'helper');

var CREDIT_CARD = 'CREDIT_CARD';
var SEPA_DIRECT_DEBIT = 'SEPA_DIRECT_DEBIT';
var CLAIMED_METHODS = [CREDIT_CARD, SEPA_DIRECT_DEBIT];
var DEFAULT_LAST4 = '0000';

var PAY = {
    AUTH: 'auth',
    FAIL: 'fail',
    PENDING: 'pending'
};

/**
 * Last-4 → payment outcome. Keep in sync with Mock Fraud.
 * 0000 happy, 0001 fraud-decline (auth unused), 0002 3DS then auth,
 * 0003 post-auth reject (auth), 0004 pay-fail, 0005 pay-pending,
 * 0006 3DS then fail, 0008 pending-then-place, 0009 pending-then-fail.
 */
var LAST4_SCENARIOS = {
    '0000': { pay: PAY.AUTH },
    '0001': { pay: PAY.AUTH },
    '0002': { pay: PAY.AUTH },
    '0003': { pay: PAY.AUTH },
    '0004': { pay: PAY.FAIL },
    '0005': { pay: PAY.PENDING },
    '0006': { pay: PAY.FAIL },
    '0008': { pay: PAY.AUTH },
    '0009': { pay: PAY.AUTH }
};

/**
 * @param {string|null|undefined} value
 * @returns {string}
 */
function normalizeLast4(value) {
    if (!value) {
        return DEFAULT_LAST4;
    }
    var digits = String(value).replace(/\D/g, '');
    if (!digits) {
        return DEFAULT_LAST4;
    }
    if (digits.length >= 4) {
        return digits.slice(-4);
    }
    return ('0000' + digits).slice(-4);
}

/**
 * @param {string|null|undefined} method
 * @returns {boolean}
 */
function isSepaMethod(method) {
    return method === SEPA_DIRECT_DEBIT || method === 'SEPA_DEBIT';
}

/**
 * @param {string|null|undefined} method
 * @returns {boolean}
 */
function isClaimedMethod(method) {
    return method === CREDIT_CARD || isSepaMethod(method);
}

/**
 * Read last-4 from a Shopper Baskets/Orders *request* WO.
 * Request documents have no paymentDetails (GET-only). Call Java getters —
 * `request.paymentDetails` / `typeof request.getPaymentCard` throw
 * Unknown property on Basket/OrderPaymentInstrumentRequestWO.
 * Last-4 is on paymentCard.number → SCAPI maskedNumber.
 * @param {Object|null|undefined} request
 * @returns {string|null}
 */
function last4FromRequest(request) {
    if (!request) {
        return null;
    }
    var card;
    try {
        card = request.getPaymentCard();
    } catch (e) {
        logger.warn('request paymentCard last-4 lookup failed: {0}', e.message);
        return null;
    }
    if (!card) {
        return null;
    }
    var raw;
    try {
        raw = card.getNumber();
    } catch (e) {
        raw = null;
    }
    if (!raw) {
        try {
            raw = card.getNumberLastDigits();
        } catch (e) {
            raw = null;
        }
    }
    return raw ? normalizeLast4(raw) : null;
}

/**
 * @param {Object|null|undefined} request
 * @returns {string|null}
 */
function holderFromRequest(request) {
    if (!request) {
        return null;
    }
    try {
        var card = request.getPaymentCard();
        if (card) {
            var holder = card.getHolder();
            if (holder) {
                return String(holder);
            }
        }
    } catch (e) {
        logger.warn('request paymentCard holder lookup failed: {0}', e.message);
    }
    return null;
}

/**
 * @param {dw.order.PaymentInstrument|null|undefined} paymentInstrument
 * @returns {string}
 */
function getInstrumentLast4(paymentInstrument) {
    if (!paymentInstrument) {
        return DEFAULT_LAST4;
    }
    try {
        var details = paymentInstrument.getPaymentDetails();
        if (details) {
            var detailsLast4 = details.getLast4();
            if (detailsLast4) {
                return normalizeLast4(detailsLast4);
            }
        }
    } catch (e) {
        logger.warn('paymentDetails last-4 lookup failed: {0}', e.message);
    }
    try {
        var cardLast4 = paymentInstrument.getCreditCardNumberLastDigits();
        if (cardLast4) {
            return normalizeLast4(cardLast4);
        }
    } catch (e) {
        logger.warn('credit-card last-4 lookup failed: {0}', e.message);
    }
    try {
        var bankLast4 = paymentInstrument.getBankAccountNumberLastDigits();
        if (bankLast4) {
            return normalizeLast4(bankLast4);
        }
    } catch (e) {
        logger.warn('bank last-4 lookup failed: {0}', e.message);
    }
    return DEFAULT_LAST4;
}

/**
 * @param {Object} target
 * @param {string} name
 * @param {*} value
 */
function callSetter(target, name, value) {
    if (!target || value === null || value === undefined || value === '') {
        return;
    }
    var fn = target[name];
    if (typeof fn === 'function') {
        fn.call(target, value);
    }
}

/**
 * @param {*} value
 * @returns {number|null}
 */
function toPositiveInt(value) {
    var number = Number(value);
    if (!isFinite(number) || number <= 0) {
        return null;
    }
    return number;
}

/**
 * @param {string|null|undefined} cardType
 * @returns {string}
 */
function brandForCardType(cardType) {
    var value = String(cardType || '').toLowerCase();
    if (value.indexOf('master') !== -1) {
        return SalesforceCardPaymentDetails.BRAND_MASTERCARD;
    }
    if (value.indexOf('amex') !== -1 || value.indexOf('american') !== -1) {
        return SalesforceCardPaymentDetails.BRAND_AMEX;
    }
    if (value.indexOf('discover') !== -1) {
        return SalesforceCardPaymentDetails.BRAND_DISCOVER;
    }
    if (value.indexOf('diners') !== -1) {
        return SalesforceCardPaymentDetails.BRAND_DINERS;
    }
    if (value.indexOf('jcb') !== -1) {
        return SalesforceCardPaymentDetails.BRAND_JCB;
    }
    if (value.indexOf('union') !== -1) {
        return SalesforceCardPaymentDetails.BRAND_UNIONPAY;
    }
    return SalesforceCardPaymentDetails.BRAND_VISA;
}

/**
 * Card fields for paymentDetails. Request card wins; instrument credit-card
 * fields fill gaps. Expiration defaults match the storefront mock card.
 * @param {dw.order.PaymentInstrument|null|undefined} paymentInstrument
 * @param {Object|null|undefined} request
 * @returns {{expirationMonth: number, expirationYear: number, brand: string}}
 */
function readCardInput(paymentInstrument, request) {
    var card = null;
    if (request && typeof request.getPaymentCard === 'function') {
        try {
            card = request.getPaymentCard();
        } catch (e) {
            card = null;
        }
    }
    var month = card && typeof card.getExpirationMonth === 'function' ? card.getExpirationMonth() : null;
    var year = card && typeof card.getExpirationYear === 'function' ? card.getExpirationYear() : null;
    var cardType = card && typeof card.getCardType === 'function' ? card.getCardType() : null;
    if (!month && paymentInstrument && typeof paymentInstrument.getCreditCardExpirationMonth === 'function') {
        try {
            month = paymentInstrument.getCreditCardExpirationMonth();
        } catch (e) {
            month = null;
        }
    }
    if (!year && paymentInstrument && typeof paymentInstrument.getCreditCardExpirationYear === 'function') {
        try {
            year = paymentInstrument.getCreditCardExpirationYear();
        } catch (e) {
            year = null;
        }
    }
    if (!cardType && paymentInstrument && typeof paymentInstrument.getCreditCardType === 'function') {
        try {
            cardType = paymentInstrument.getCreditCardType();
        } catch (e) {
            cardType = null;
        }
    }
    return {
        expirationMonth: toPositiveInt(month) || 12,
        expirationYear: toPositiveInt(year) || 2030,
        brand: brandForCardType(cardType)
    };
}

/**
 * @param {dw.order.Order|null|undefined} order
 * @returns {string}
 */
function threeDsTransactionId(order) {
    var orderNo = order && order.orderNo ? String(order.orderNo) : 'mock';
    return ('mock-3ds-' + orderNo).slice(0, 40);
}

/**
 * Persist shopper-safe card or SEPA paymentDetails so GET order returns them.
 * Card details include brand, expiration, BIN, funding type, issuing country,
 * and a gateway token. The token and BIN are mock values, not a PAN.
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument
 * @param {string} last4
 * @param {string|null|undefined} holder
 * @param {{expirationMonth: number, expirationYear: number, brand: string}|null|undefined} cardInput
 */
function applyPaymentDetails(paymentInstrument, last4, holder, cardInput) {
    if (!paymentInstrument || typeof paymentInstrument.setPaymentDetails !== 'function') {
        return;
    }
    var code = normalizeLast4(last4);
    var method = null;
    try {
        method = paymentInstrument.getPaymentMethod();
    } catch (e) {
        method = null;
    }
    try {
        if (isSepaMethod(method)) {
            var sepa = new SalesforceSepaDebitPaymentDetails();
            sepa.setLast4(code);
            sepa.setAccountHolderName(holder || 'Mock Shopper');
            paymentInstrument.setPaymentDetails(sepa);
            return;
        }
        var input = cardInput || readCardInput(paymentInstrument, null);
        var card = new SalesforceCardPaymentDetails();
        card.setLast4(code);
        card.setBrand(input.brand || SalesforceCardPaymentDetails.BRAND_VISA);
        callSetter(card, 'setExpirationMonth', input.expirationMonth);
        callSetter(card, 'setExpirationYear', input.expirationYear);
        callSetter(card, 'setFundingType', SalesforceCardPaymentDetails.FUNDING_TYPE_CREDIT);
        callSetter(card, 'setIssuingCountry', 'US');
        callSetter(card, 'setBin', '411111');
        callSetter(card, 'setToken', ('mock-tok-' + code).slice(0, 40));
        callSetter(card, 'setTokenType', SalesforceCardPaymentDetails.TOKEN_TYPE_GATEWAY);
        paymentInstrument.setPaymentDetails(card);
    } catch (e) {
        logger.warn('setPaymentDetails failed: {0}', e.message);
    }
}

/**
 * @param {dw.order.PaymentInstrument} paymentInstrument
 * @param {Object|null|undefined} request
 * @returns {string}
 */
function persistPaymentDetails(paymentInstrument, request) {
    var last4 = last4FromRequest(request) || getInstrumentLast4(paymentInstrument);
    applyPaymentDetails(
        paymentInstrument,
        last4,
        holderFromRequest(request),
        readCardInput(paymentInstrument, request)
    );
    return last4;
}

/**
 * Card transactionDetails for an auth attempt. Challenge last-4s also record
 * 3DS. SEPA has no card transaction details.
 * @param {dw.order.Order|null|undefined} order
 * @param {dw.order.PaymentInstrument|null|undefined} paymentInstrument
 * @param {'auth'|'fail'|'pending'} outcome
 */
function applyCardTransactionDetails(order, paymentInstrument, outcome) {
    if (!paymentInstrument) {
        return;
    }
    var method = null;
    try {
        method = paymentInstrument.getPaymentMethod();
    } catch (e) {
        method = null;
    }
    if (isSepaMethod(method)) {
        return;
    }
    var transaction = null;
    try {
        transaction = paymentInstrument.getPaymentTransaction();
    } catch (e) {
        transaction = null;
    }
    if (!transaction || typeof transaction.setTransactionDetails !== 'function') {
        return;
    }
    try {
        var details = new SalesforceCardTransactionDetails();
        var challenged = isPreAuthChallenge(paymentInstrument);
        if (outcome === 'fail' && challenged) {
            callSetter(details, 'setThreeDSResult', SalesforceCardTransactionDetails.THREE_DS_RESULT_FAILED);
            callSetter(details, 'setThreeDSVersion', SalesforceCardTransactionDetails.THREE_DS_VERSION_V2);
            callSetter(details, 'setElectronicCommerceIndicator', '07');
            callSetter(details, 'setThreeDSTransactionId', threeDsTransactionId(order));
        } else if (outcome === 'fail') {
            callSetter(details, 'setCvcResult', SalesforceCardTransactionDetails.CVC_RESULT_NO_MATCH);
            callSetter(details, 'setAvsResult', SalesforceCardTransactionDetails.AVS_RESULT_NO_MATCH);
        } else if (outcome === 'pending') {
            callSetter(details, 'setCvcResult', SalesforceCardTransactionDetails.CVC_RESULT_NOT_PROCESSED);
            callSetter(details, 'setAvsResult', SalesforceCardTransactionDetails.AVS_RESULT_UNAVAILABLE);
        } else {
            callSetter(details, 'setCvcResult', SalesforceCardTransactionDetails.CVC_RESULT_MATCH);
            callSetter(details, 'setAvsResult', SalesforceCardTransactionDetails.AVS_RESULT_MATCH);
            if (challenged) {
                callSetter(details, 'setThreeDSResult', SalesforceCardTransactionDetails.THREE_DS_RESULT_AUTHENTICATED);
                callSetter(details, 'setThreeDSVersion', SalesforceCardTransactionDetails.THREE_DS_VERSION_V2);
                callSetter(details, 'setElectronicCommerceIndicator', '05');
                callSetter(details, 'setThreeDSTransactionId', threeDsTransactionId(order));
            }
        }
        transaction.setTransactionDetails(details);
    } catch (e) {
        logger.warn('setTransactionDetails failed: {0}', e.message);
    }
}

/**
 * @param {dw.order.PaymentInstrument|null|undefined} paymentInstrument
 * @returns {{pay: string, last4: string}}
 */
function getPaymentScenario(paymentInstrument) {
    var last4 = getInstrumentLast4(paymentInstrument);
    var mapped = LAST4_SCENARIOS[last4] || LAST4_SCENARIOS[DEFAULT_LAST4];
    return {
        pay: mapped.pay,
        last4: last4
    };
}

/**
 * @param {dw.order.PaymentInstrument} paymentInstrument
 * @returns {boolean}
 */
function isPreAuthChallenge(paymentInstrument) {
    if (!paymentInstrument) {
        return false;
    }
    try {
        var transaction = paymentInstrument.getPaymentTransaction();
        if (transaction) {
            var decision = transaction.getPreAuthFraudDecision();
            if (decision === PaymentTransaction.PRE_AUTH_FRAUD_DECISION_CHALLENGE
                || decision === 'CHALLENGE') {
                return true;
            }
        }
    } catch (e) {
        logger.warn('pre-auth lookup failed: {0}', e.message);
    }
    return false;
}

/**
 * Authorizes this payment instrument's amount (mixed-tender safe).
 * @param {dw.order.Order} order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument
 * @returns {boolean}
 */
function authorizeInstrument(order, paymentInstrument) {
    var transaction = paymentInstrument.getPaymentTransaction();
    if (!transaction) {
        return false;
    }
    var amount = transaction.getAmount();
    if (!amount || (typeof amount.getValue === 'function' && amount.getValue() === 0)) {
        if (order && typeof order.getTotalGrossPrice === 'function') {
            amount = order.getTotalGrossPrice();
            if (amount) {
                transaction.setAmount(amount);
            }
        }
    }
    transaction.setType(PaymentTransaction.TYPE_AUTH);
    transaction.setStatus(PaymentTransaction.STATUS_AUTHORIZED);
    if (typeof transaction.setTransactionID === 'function') {
        var seed = (order && order.orderNo ? order.orderNo : 'mock') + '-' + Date.now().toString(36);
        transaction.setTransactionID(('MOCKAUTH-' + seed).slice(0, 40));
    }
    applyCardTransactionDetails(order, paymentInstrument, 'auth');
    return true;
}

/**
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument
 * @param {number} status
 */
function setTransactionStatus(paymentInstrument, status) {
    var transaction = paymentInstrument && paymentInstrument.getPaymentTransaction();
    if (!transaction) {
        return;
    }
    transaction.setStatus(status);
}

module.exports = {
    CREDIT_CARD: CREDIT_CARD,
    SEPA_DIRECT_DEBIT: SEPA_DIRECT_DEBIT,
    CLAIMED_METHODS: CLAIMED_METHODS,
    DEFAULT_LAST4: DEFAULT_LAST4,
    PAY: PAY,
    LAST4_SCENARIOS: LAST4_SCENARIOS,
    normalizeLast4: normalizeLast4,
    isSepaMethod: isSepaMethod,
    isClaimedMethod: isClaimedMethod,
    last4FromRequest: last4FromRequest,
    holderFromRequest: holderFromRequest,
    getInstrumentLast4: getInstrumentLast4,
    applyPaymentDetails: applyPaymentDetails,
    applyCardTransactionDetails: applyCardTransactionDetails,
    persistPaymentDetails: persistPaymentDetails,
    getPaymentScenario: getPaymentScenario,
    isPreAuthChallenge: isPreAuthChallenge,
    authorizeInstrument: authorizeInstrument,
    setTransactionStatus: setTransactionStatus
};
