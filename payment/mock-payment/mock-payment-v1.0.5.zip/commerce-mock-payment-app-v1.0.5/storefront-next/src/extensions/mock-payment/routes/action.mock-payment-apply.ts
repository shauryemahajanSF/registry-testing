/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_MOCK_PAYMENT */

import { type ActionFunctionArgs, data } from 'react-router';
import { ApiError, type ShopperBasketsV2 } from '@/scapi';
import { createApiClients } from '@/lib/api-clients.server';
import {
    addPaymentInstrumentToBasket,
    removePaymentInstrumentFromBasket,
    updatePaymentInstrumentInBasket,
} from '@/lib/api/basket.server';
import { getLogger } from '@/lib/logger.server';
import { withRevalidateTags } from '@/lib/revalidation/tags';
import { PAYMENT_BASKET_TAG } from '../lib/constants';
import {
    getMockPaymentInstruments,
    getRemainingAmount,
    isClaimedPaymentMethodId,
    mockPaymentInstrumentBody,
    normalizeLast4,
    type ClaimedPaymentMethodId,
} from '../lib/payment-utils';

type Basket = ShopperBasketsV2.schemas['Basket'];

export type ApplyPaymentActionResult = {
    success: boolean;
    basket?: Basket;
    last4?: string;
    paymentMethodId?: ClaimedPaymentMethodId;
    error?: string;
};

export async function action({ request, context }: ActionFunctionArgs) {
    if (request.method !== 'POST') {
        return data<ApplyPaymentActionResult>({ success: false, error: 'Method not allowed' }, { status: 405 });
    }

    const logger = getLogger(context);
    let basketId: string | undefined;

    try {
        const formData = await request.formData();
        basketId = formData.get('basketId')?.toString();
        if (!basketId) {
            return data<ApplyPaymentActionResult>({ success: false, error: 'basketId is required' }, { status: 400 });
        }

        const paymentMethodId = formData.get('paymentMethodId')?.toString();
        if (!isClaimedPaymentMethodId(paymentMethodId)) {
            return data<ApplyPaymentActionResult>(
                { success: false, error: 'paymentMethodId must be CREDIT_CARD or SEPA_DIRECT_DEBIT' },
                { status: 400 }
            );
        }

        const last4 = normalizeLast4(formData.get('last4')?.toString());
        logger.info('[mock-payment] apply last-4', { last4, basketId, paymentMethodId });

        const clients = createApiClients(context);
        const { data: basket } = await clients.shopperBasketsV2.getBasket({
            params: { path: { basketId } },
        });
        const existing = getMockPaymentInstruments(basket)[0];
        if (existing?.paymentInstrumentId && existing.paymentMethodId === paymentMethodId) {
            const updated = await updatePaymentInstrumentInBasket(
                context,
                basketId,
                existing.paymentInstrumentId,
                mockPaymentInstrumentBody(paymentMethodId, last4)
            );
            return withRevalidateTags(
                { success: true, basket: updated, last4, paymentMethodId } satisfies ApplyPaymentActionResult,
                [PAYMENT_BASKET_TAG]
            );
        }

        let workingBasket = basket;
        if (existing?.paymentInstrumentId) {
            workingBasket = await removePaymentInstrumentFromBasket(
                context,
                basketId,
                existing.paymentInstrumentId
            );
        }

        const remaining = getRemainingAmount(workingBasket);
        if (remaining <= 0) {
            return data<ApplyPaymentActionResult>(
                { success: false, error: 'Order total is already covered' },
                { status: 400 }
            );
        }

        const updated = await addPaymentInstrumentToBasket(
            context,
            basketId,
            mockPaymentInstrumentBody(paymentMethodId, last4, remaining)
        );

        return withRevalidateTags(
            { success: true, basket: updated, last4, paymentMethodId } satisfies ApplyPaymentActionResult,
            [PAYMENT_BASKET_TAG]
        );
    } catch (error) {
        const isApiError = error instanceof ApiError;
        logger.error('[mock-payment] apply failed', {
            basketId,
            ...(isApiError ? error.toJSON() : { message: String(error) }),
        });
        return data<ApplyPaymentActionResult>(
            {
                success: false,
                error: isApiError ? error.message : 'Unable to apply mock payment',
            },
            { status: isApiError ? (error.status ?? 500) : 500 }
        );
    }
}
