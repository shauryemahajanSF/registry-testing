/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { render, screen } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import MockPaymentMethods from '../components/payment-methods';

vi.mock('react-router', () => ({
    useFetcher: () => ({ state: 'idle', data: null, submit: vi.fn() }),
}));

vi.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (key: string) => key,
        i18n: { language: 'en-GB' },
    }),
}));

vi.mock('@/components/toast', () => ({
    useToast: () => ({ addToast: vi.fn() }),
}));

vi.mock('@/providers/basket', () => ({
    useBasket: () => mockBasket,
    useBasketUpdater: () => vi.fn(),
}));

const paymentSubmissionRef = { current: { onPlaceOrder: null as null | (() => Promise<string | null>) } };

vi.mock('@/components/checkout/payment-submission-context', () => ({
    usePaymentSubmissionRef: () => paymentSubmissionRef,
}));

let mockBasket: {
    basketId: string;
    currency: string;
    paymentInstruments: Array<{ paymentMethodId?: string; paymentInstrumentId?: string; amount?: number }>;
    orderTotal: number;
} = {
    basketId: 'basket-1',
    currency: 'USD',
    paymentInstruments: [],
    orderTotal: 10,
};

describe('MockPaymentMethods', () => {
    beforeEach(() => {
        paymentSubmissionRef.current.onPlaceOrder = null;
        mockBasket = {
            basketId: 'basket-1',
            currency: 'USD',
            paymentInstruments: [],
            orderTotal: 10,
        };
    });

    it('renders mock CC and SEPA chips and hides the native credit-card form', () => {
        render(
            <MockPaymentMethods>
                <div data-testid="native-credit-card-form">Credit Card</div>
            </MockPaymentMethods>
        );

        expect(screen.getByTestId('mock-payment-methods')).toBeInTheDocument();
        expect(screen.getByTestId('mock-payment-card')).toBeInTheDocument();
        expect(screen.getByTestId('mock-payment-sepa')).toBeInTheDocument();
        expect(screen.queryByTestId('native-credit-card-form')).not.toBeInTheDocument();
    });

    it('registers onPlaceOrder when gift cards already cover the order total', () => {
        mockBasket = {
            basketId: 'basket-1',
            currency: 'USD',
            orderTotal: 33.84,
            paymentInstruments: [
                {
                    paymentMethodId: 'COMMERCE_APP_GIFT_CARD',
                    paymentInstrumentId: 'gc-1',
                    amount: 33.84,
                },
            ],
        };

        render(<MockPaymentMethods />);

        expect(paymentSubmissionRef.current.onPlaceOrder).toBeTypeOf('function');
    });
});
