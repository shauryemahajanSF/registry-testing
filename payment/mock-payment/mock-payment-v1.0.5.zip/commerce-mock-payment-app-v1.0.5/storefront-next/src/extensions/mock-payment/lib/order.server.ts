/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_MOCK_PAYMENT */

import { createApiClients } from '@/lib/api-clients.server';
import type { RouterContextProvider } from 'react-router';
import {
    getAppliedLast4,
    getMockPaymentInstrument,
    isClaimedPaymentMethodId,
    mockOrderPaymentInstrumentPatchBody,
} from './payment-utils';

type FailOrderResponse = {
    data?: Record<string, unknown>;
    response?: { headers?: { get: (name: string) => string | null } };
};

type OrderClients = {
    shopperOrders: {
        createOrder: (args: unknown) => Promise<{ data: Record<string, unknown> }>;
        getOrder: (args: unknown) => Promise<{ data: Record<string, unknown> }>;
        failOrder?: (args: unknown) => Promise<FailOrderResponse>;
        updatePaymentInstrumentForOrder: (args: unknown) => Promise<{ data: Record<string, unknown> }>;
    };
};

function getOrdersClient(context: Readonly<RouterContextProvider>): OrderClients['shopperOrders'] {
    const clients = createApiClients(context) as unknown as OrderClients;
    return clients.shopperOrders;
}

export async function createOrderFromBasket(
    context: Readonly<RouterContextProvider>,
    basketId: string
): Promise<Record<string, unknown>> {
    const { data } = await getOrdersClient(context).createOrder({
        params: {},
        body: { basketId },
    });
    return data;
}

/**
 * PATCH a claimed CREDIT_CARD / SEPA instrument so SCAPI afterPATCH runs
 * attemptOrderTransition. Shopper Orders createOrder only fires fraud
 * beforePayment; it does not authorize claimed methods.
 *
 * Do not send skip_authorization — that query is OCAPI-only and Shopper
 * Orders v1 returns 400 for unknown parameters. CREDIT_CARD must include
 * paymentCard (cardType is already on the instrument, so amount-only
 * PATCH throws PaymentAuthorizationNoPaymentCard). Omit paymentMethodId
 * so the patch validator does not re-check BM applicability.
 */
export async function updateClaimedPaymentInstrument(
    context: Readonly<RouterContextProvider>,
    orderNo: string,
    paymentInstrumentId: string,
    amount?: number,
    paymentMethodId?: string,
    last4?: string
): Promise<Record<string, unknown>> {
    const methodId = isClaimedPaymentMethodId(paymentMethodId) ? paymentMethodId : undefined;
    const body = methodId
        ? mockOrderPaymentInstrumentPatchBody(methodId, last4 ?? '0000', amount)
        : typeof amount === 'number'
          ? { amount }
          : {};
    const { data } = await getOrdersClient(context).updatePaymentInstrumentForOrder({
        params: { path: { orderNo, paymentInstrumentId } },
        body,
    });
    return data;
}

export async function getOrderByOrderNo(
    context: Readonly<RouterContextProvider>,
    orderNo: string
): Promise<Record<string, unknown>> {
    const { data } = await getOrdersClient(context).getOrder({
        params: { path: { orderNo } },
    });
    return data;
}

export async function completeOrderChallenge(
    context: Readonly<RouterContextProvider>,
    orderNo: string,
    paymentInstrumentId: string,
    amount?: number
): Promise<Record<string, unknown>> {
    const order = await getOrderByOrderNo(context, orderNo);
    const instrument = getMockPaymentInstrument(order as Parameters<typeof getMockPaymentInstrument>[0]);
    return updateClaimedPaymentInstrument(
        context,
        orderNo,
        paymentInstrumentId,
        amount,
        instrument?.paymentMethodId,
        getAppliedLast4(instrument)
    );
}

function basketIdFromFailLocation(location: string | null | undefined): string | undefined {
    if (!location) {
        return undefined;
    }
    const match = location.match(/\/baskets\/([^/?#]+)/i);
    return match?.[1];
}

/**
 * Fail a CREATED order and reopen the basket. Shopper Orders has no PATCH
 * /orders/{orderNo}; OCAPI `{ status: failed }` 404s and leaves the shopper
 * with no cart. Use POST .../actions/fail?reopenBasket=true.
 */
export async function failCreatedOrder(
    context: Readonly<RouterContextProvider>,
    orderNo: string
): Promise<{ basketId?: string }> {
    const client = getOrdersClient(context);
    if (typeof client.failOrder !== 'function') {
        throw new Error('Shopper Orders failOrder is not available on this SCAPI client');
    }
    const { response } = await client.failOrder({
        params: {
            path: { orderNo },
            query: { reopenBasket: true },
        },
        body: {},
    });
    const location = response?.headers?.get('location') ?? response?.headers?.get('Location');
    return { basketId: basketIdFromFailLocation(location) };
}
