/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { describe, expect, it } from 'vitest';
import { CREDIT_CARD_PAYMENT_METHOD_ID, SEPA_PAYMENT_METHOD_ID } from '../lib/constants';
import {
    getAppliedLast4,
    getMockPaymentInstrument,
    getMockPaymentInstrumentId,
    getMockPaymentInstruments,
    getRemainingAmount,
    isMockPaymentInstrument,
    mockPaymentInstrumentBody,
    mockOrderPaymentInstrumentPatchBody,
    normalizeLast4,
    orderIsFailed,
    orderIsPending,
    orderNeedsChallenge,
    orderWasPlaced,
} from '../lib/payment-utils';

describe('payment-utils', () => {
    it('identifies claimed CREDIT_CARD and SEPA instruments', () => {
        expect(isMockPaymentInstrument({ paymentMethodId: CREDIT_CARD_PAYMENT_METHOD_ID })).toBe(true);
        expect(isMockPaymentInstrument({ paymentMethodId: SEPA_PAYMENT_METHOD_ID })).toBe(true);
        expect(isMockPaymentInstrument({ paymentMethodId: 'BANK_TRANSFER' })).toBe(false);
    });

    it('computes remaining amount after applied tenders', () => {
        const remaining = getRemainingAmount({
            orderTotal: 100,
            paymentInstruments: [
                { paymentMethodId: 'COMMERCE_APP_GIFT_CARD', amount: 20 },
                { paymentMethodId: CREDIT_CARD_PAYMENT_METHOD_ID, amount: 30 },
            ],
        });
        expect(remaining).toBe(50);
    });

    it('detects CHALLENGE on the created order', () => {
        expect(
            orderNeedsChallenge({
                paymentInstruments: [
                    {
                        paymentMethodId: CREDIT_CARD_PAYMENT_METHOD_ID,
                        paymentInstrumentId: 'pi-1',
                        fraudDecisions: { preAuthorization: 'CHALLENGE' },
                    },
                ],
            })
        ).toBe(true);
        expect(getMockPaymentInstrumentId({
            paymentInstruments: [{ paymentMethodId: SEPA_PAYMENT_METHOD_ID, paymentInstrumentId: 'pi-9' }],
        })).toBe('pi-9');
        expect(
            getMockPaymentInstrument({
                paymentInstruments: [
                    {
                        paymentMethodId: CREDIT_CARD_PAYMENT_METHOD_ID,
                        paymentInstrumentId: 'pi-9',
                        amount: 135.89,
                    },
                ],
            })?.amount
        ).toBe(135.89);
        expect(getMockPaymentInstruments({
            paymentInstruments: [{ paymentMethodId: SEPA_PAYMENT_METHOD_ID }],
        })).toHaveLength(1);
    });

    it('treats Shopper Orders failed status as a declined place', () => {
        expect(orderIsFailed({ status: 'failed' })).toBe(true);
        expect(orderIsFailed({ status: 'FAILED' })).toBe(true);
        expect(orderIsFailed({ status: 'created' })).toBe(false);
        expect(orderIsFailed({ status: 'new' })).toBe(false);
        expect(orderWasPlaced({ status: 'new' })).toBe(true);
        expect(orderWasPlaced({ status: 'failed' })).toBe(false);
        expect(orderWasPlaced({ status: 'created' })).toBe(false);
        expect(orderWasPlaced({})).toBe(false);
        expect(orderIsPending({ status: 'created' })).toBe(true);
    });

    it('reads last-4 from paymentDetails then paymentCard', () => {
        expect(normalizeLast4(undefined)).toBe('0000');
        expect(normalizeLast4('2')).toBe('0002');
        expect(getAppliedLast4({
            paymentMethodId: CREDIT_CARD_PAYMENT_METHOD_ID,
            paymentDetails: { last4: '0008', type: 'card' },
        } as never)).toBe('0008');
        expect(getAppliedLast4({
            paymentMethodId: CREDIT_CARD_PAYMENT_METHOD_ID,
            paymentCard: { numberLastDigits: '0004' },
        } as never)).toBe('0004');
        expect(mockPaymentInstrumentBody(SEPA_PAYMENT_METHOD_ID, '6').paymentDetails).toBeUndefined();
        expect(mockPaymentInstrumentBody(SEPA_PAYMENT_METHOD_ID, '6').paymentCard).toMatchObject({
            maskedNumber: '************0006',
        });
        expect(mockPaymentInstrumentBody(CREDIT_CARD_PAYMENT_METHOD_ID, '0002', 10)).toMatchObject({
            paymentMethodId: CREDIT_CARD_PAYMENT_METHOD_ID,
            amount: 10,
            paymentCard: {
                cardType: 'Visa',
                holder: 'Mock Shopper',
                maskedNumber: '************0002',
                expirationMonth: 12,
                expirationYear: 2030,
            },
        });
        expect(
            mockPaymentInstrumentBody(CREDIT_CARD_PAYMENT_METHOD_ID, '0002', 10)
        ).not.toHaveProperty('paymentDetails');
        expect(mockOrderPaymentInstrumentPatchBody(CREDIT_CARD_PAYMENT_METHOD_ID, '0004', 12.5)).toEqual({
            amount: 12.5,
            paymentCard: {
                cardType: 'Visa',
                holder: 'Mock Shopper',
                maskedNumber: '************0004',
                expirationMonth: 12,
                expirationYear: 2030,
            },
        });
        expect(mockOrderPaymentInstrumentPatchBody(SEPA_PAYMENT_METHOD_ID, '0006', 12.5)).toEqual({
            amount: 12.5,
        });
        expect(mockOrderPaymentInstrumentPatchBody(CREDIT_CARD_PAYMENT_METHOD_ID, '0004')).not.toHaveProperty(
            'paymentMethodId'
        );
    });
});
