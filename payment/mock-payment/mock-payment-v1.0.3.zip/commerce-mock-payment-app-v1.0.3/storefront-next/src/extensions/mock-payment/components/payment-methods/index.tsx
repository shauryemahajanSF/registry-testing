/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_MOCK_PAYMENT */

'use client';

import { useCallback, useEffect, useRef, useState, type ReactElement, type ReactNode } from 'react';
import { useFetcher } from 'react-router';
import { useTranslation } from 'react-i18next';
import { CreditCard as CardIcon, Building2 as SepaIcon, X as CloseIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/toast';
import { usePaymentSubmissionRef } from '@/components/checkout/payment-submission-context';
import { FETCHER_STATES } from '@/lib/fetcher-states';
import { formatCurrency } from '@/lib/currency';
import { useBasket, useBasketUpdater } from '@/providers/basket';
import {
    APPLY_PAYMENT_ACTION,
    COMPLETE_CHALLENGE_ACTION,
    CREDIT_CARD_PAYMENT_METHOD_ID,
    FAIL_ORDER_ACTION,
    PLACE_ORDER_ACTION,
    REMOVE_PAYMENT_ACTION,
    SEPA_PAYMENT_METHOD_ID,
} from '../../lib/constants';
import {
    getAppliedLast4,
    getMockPaymentInstruments,
    getRemainingAmount,
    type ClaimedPaymentMethodId,
} from '../../lib/payment-utils';
import type { ApplyPaymentActionResult } from '../../routes/action.mock-payment-apply';
import type { RemovePaymentActionResult } from '../../routes/action.mock-payment-remove';
import type { PlaceOrderActionResult } from '../../routes/action.mock-payment-place-order';
import type { CompleteChallengeActionResult } from '../../routes/action.mock-payment-complete';
import type { FailOrderActionResult } from '../../routes/action.mock-payment-fail';

type ChallengeState = {
    orderNo: string;
    paymentInstrumentId: string;
};

async function postAction<T>(action: string, fields: Record<string, string>): Promise<T> {
    const body = new FormData();
    Object.entries(fields).forEach(([key, value]) => {
        body.append(key, value);
    });
    const response = await fetch(action, {
        method: 'POST',
        body,
        credentials: 'same-origin',
    });
    const payload = (await response.json()) as T;
    if (!response.ok) {
        const message =
            payload && typeof payload === 'object' && 'error' in payload
                ? String((payload as { error?: string }).error || response.statusText)
                : response.statusText;
        throw new Error(message);
    }
    return payload;
}

/**
 * CREDIT_CARD and SEPA_DIRECT_DEBIT chips for `sfcc.checkout.payment.paymentMethods`.
 * Last-4 is stored on paymentDetails by the payment app hooks.
 */
export default function MockPaymentMethods({ children }: { children?: ReactNode }): ReactElement {
    const { t, i18n } = useTranslation('extMockPayment');
    const basket = useBasket();
    const updateBasket = useBasketUpdater();
    const { addToast } = useToast();
    const paymentSubmissionRef = usePaymentSubmissionRef();
    const applyFetcher = useFetcher<ApplyPaymentActionResult>();
    const removeFetcher = useFetcher<RemovePaymentActionResult>();
    const [challenge, setChallenge] = useState<ChallengeState | null>(null);
    const [last4, setLast4] = useState('0000');
    const [appliedLast4, setAppliedLast4] = useState<string | null>(null);
    const challengeResolver = useRef<((orderNo: string | null) => void) | null>(null);

    const instruments = getMockPaymentInstruments(basket);
    const applied = instruments[0];
    const remaining = getRemainingAmount(basket);
    const isApplying = applyFetcher.state === FETCHER_STATES.SUBMITTING;
    const isRemoving = removeFetcher.state === FETCHER_STATES.SUBMITTING;

    useEffect(() => {
        if (!applyFetcher.data || applyFetcher.state !== FETCHER_STATES.IDLE) {
            return;
        }
        if (applyFetcher.data.success) {
            if (applyFetcher.data.basket) {
                updateBasket(applyFetcher.data.basket);
            }
            if (applyFetcher.data.last4) {
                setAppliedLast4(applyFetcher.data.last4);
                setLast4(applyFetcher.data.last4);
            }
            addToast(t('mockPayment.success'), 'success');
            return;
        }
        addToast(applyFetcher.data.error || t('mockPayment.errorApply'), 'error');
    }, [applyFetcher.data, applyFetcher.state, addToast, t, updateBasket]);

    useEffect(() => {
        if (!removeFetcher.data || removeFetcher.state !== FETCHER_STATES.IDLE) {
            return;
        }
        if (removeFetcher.data.success) {
            if (removeFetcher.data.basket) {
                updateBasket(removeFetcher.data.basket);
            }
            setAppliedLast4(null);
            addToast(t('mockPayment.removed'), 'success');
            return;
        }
        addToast(removeFetcher.data.error || t('mockPayment.errorRemove'), 'error');
    }, [removeFetcher.data, removeFetcher.state, addToast, t, updateBasket]);

    const apply = (paymentMethodId: ClaimedPaymentMethodId) => {
        if (!basket?.basketId) {
            addToast(t('mockPayment.errorNoBasket'), 'error');
            return;
        }
        if (!applied && remaining <= 0) {
            addToast(t('mockPayment.errorCovered'), 'error');
            return;
        }
        if (isApplying) {
            return;
        }
        void applyFetcher.submit(
            { basketId: basket.basketId, last4, paymentMethodId },
            { method: 'POST', action: APPLY_PAYMENT_ACTION }
        );
    };

    const remove = () => {
        if (!basket?.basketId || !applied?.paymentInstrumentId || isRemoving) {
            return;
        }
        void removeFetcher.submit(
            { basketId: basket.basketId, paymentInstrumentId: applied.paymentInstrumentId },
            { method: 'POST', action: REMOVE_PAYMENT_ACTION }
        );
    };

    const finishChallenge = useCallback((orderNo: string | null) => {
        const resolve = challengeResolver.current;
        challengeResolver.current = null;
        setChallenge(null);
        resolve?.(orderNo);
    }, []);

    const onPlaceOrder = useCallback(async (): Promise<string | null> => {
        if (!basket?.basketId) {
            addToast(t('mockPayment.errorNoBasket'), 'error');
            return null;
        }
        try {
            const result = await postAction<PlaceOrderActionResult>(PLACE_ORDER_ACTION, {
                basketId: basket.basketId,
                last4: appliedLast4 || last4,
                paymentMethodId: applied?.paymentMethodId,
            });
            if (!result.success || !result.orderNo) {
                addToast(
                    result.declined
                        ? t('mockPayment.errorDecline')
                        : result.error || t('mockPayment.errorPlace'),
                    'error'
                );
                return null;
            }
            if (result.needsChallenge && result.paymentInstrumentId) {
                return await new Promise<string | null>((resolve) => {
                    challengeResolver.current = resolve;
                    setChallenge({
                        orderNo: result.orderNo as string,
                        paymentInstrumentId: result.paymentInstrumentId as string,
                    });
                });
            }
            if (result.pending) {
                addToast(t('mockPayment.pendingHold'), 'info');
                return null;
            }
            return result.orderNo;
        } catch (error) {
            addToast(error instanceof Error ? error.message : t('mockPayment.errorPlace'), 'error');
            return null;
        }
    }, [addToast, applied?.paymentMethodId, appliedLast4, basket?.basketId, last4, t]);

    useEffect(() => {
        if (!applied) {
            return undefined;
        }
        paymentSubmissionRef.current.onPlaceOrder = onPlaceOrder;
        return () => {
            if (paymentSubmissionRef.current.onPlaceOrder === onPlaceOrder) {
                paymentSubmissionRef.current.onPlaceOrder = null;
            }
        };
    }, [applied, onPlaceOrder, paymentSubmissionRef]);

    const approveChallenge = async () => {
        if (!challenge) {
            return;
        }
        try {
            const result = await postAction<CompleteChallengeActionResult>(COMPLETE_CHALLENGE_ACTION, {
                orderNo: challenge.orderNo,
                paymentInstrumentId: challenge.paymentInstrumentId,
            });
            if (!result.success) {
                addToast(
                    result.declined
                        ? t('mockPayment.errorDecline')
                        : result.error || t('mockPayment.errorPlace'),
                    'error'
                );
                finishChallenge(null);
                return;
            }
            finishChallenge(result.orderNo || challenge.orderNo);
        } catch (error) {
            addToast(error instanceof Error ? error.message : t('mockPayment.errorPlace'), 'error');
            finishChallenge(null);
        }
    };

    const declineChallenge = async () => {
        if (!challenge) {
            return;
        }
        try {
            const result = await postAction<FailOrderActionResult>(FAIL_ORDER_ACTION, {
                orderNo: challenge.orderNo,
            });
            if (!result.success) {
                addToast(result.error || t('mockPayment.errorDecline'), 'error');
                finishChallenge(null);
                return;
            }
            addToast(t('mockPayment.errorDecline'), 'error');
            finishChallenge(null);
        } catch (error) {
            addToast(error instanceof Error ? error.message : t('mockPayment.errorDecline'), 'error');
            finishChallenge(null);
        }
    };

    const last4Field = (id: string) => (
        <>
            <label className="sr-only" htmlFor={id}>
                {t('mockPayment.last4Label')}
            </label>
            <input
                id={id}
                type="text"
                inputMode="numeric"
                autoComplete="off"
                maxLength={4}
                pattern="[0-9]{4}"
                value={last4}
                onChange={(event) => setLast4(event.target.value.replace(/\D/g, '').slice(0, 4))}
                className="h-8 w-16 rounded-md border border-input bg-background px-2 text-center text-sm tracking-widest"
                data-testid={id}
            />
        </>
    );

    const methodRow = (
        methodId: ClaimedPaymentMethodId,
        titleKey: 'mockPayment.cardTitle' | 'mockPayment.sepaTitle',
        testId: string,
        icon: ReactNode
    ) => {
        const isApplied = applied?.paymentMethodId === methodId;
        return (
            <div className="mb-3 rounded-md border border-input p-3" data-testid={testId}>
                <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                        {icon}
                        <span className="text-sm font-medium text-card-foreground">{t(titleKey)}</span>
                    </div>
                    <div className="flex items-center gap-2">
                        {isApplied ? (
                            <span className="text-sm">
                                {formatCurrency(applied.amount ?? remaining, i18n.language, basket?.currency ?? 'USD')}
                            </span>
                        ) : null}
                        {last4Field(`${testId}-last4`)}
                        <Button
                            type="button"
                            variant="secondary"
                            className="cursor-pointer"
                            disabled={isApplying || (!isApplied && remaining <= 0)}
                            onClick={() => apply(methodId)}>
                            {isApplying ? t('mockPayment.applying') : t('mockPayment.apply')}
                        </Button>
                        {isApplied ? (
                            <Button
                                type="button"
                                variant="ghost"
                                size="icon"
                                className="size-6 cursor-pointer"
                                disabled={isRemoving}
                                aria-label={t('mockPayment.remove')}
                                onClick={remove}>
                                <CloseIcon className="size-3.5" aria-hidden="true" />
                            </Button>
                        ) : null}
                    </div>
                </div>
                {isApplied ? (
                    <p className="mt-2 text-xs text-muted-foreground">
                        {t('mockPayment.applied', {
                            last4: appliedLast4 || getAppliedLast4(applied),
                        })}
                    </p>
                ) : (
                    <p className="mt-2 text-xs text-muted-foreground">{t('mockPayment.last4Hint')}</p>
                )}
            </div>
        );
    };

    return (
        <div className="w-full" data-testid="mock-payment-methods">
            {methodRow(
                CREDIT_CARD_PAYMENT_METHOD_ID,
                'mockPayment.cardTitle',
                'mock-payment-card',
                <CardIcon className="size-4 shrink-0" aria-hidden="true" />
            )}
            {methodRow(
                SEPA_PAYMENT_METHOD_ID,
                'mockPayment.sepaTitle',
                'mock-payment-sepa',
                <SepaIcon className="size-4 shrink-0" aria-hidden="true" />
            )}

            {children}

            {challenge ? (
                <div
                    className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4"
                    role="dialog"
                    aria-modal="true"
                    aria-labelledby="mock-payment-challenge-title"
                    data-testid="mock-payment-challenge">
                    <div className="w-full max-w-md rounded-lg bg-background p-4 shadow-lg">
                        <h2 id="mock-payment-challenge-title" className="text-base font-semibold">
                            {t('mockPayment.challengeTitle')}
                        </h2>
                        <p className="mt-2 text-sm text-muted-foreground">{t('mockPayment.challengeBody')}</p>
                        <div className="mt-4 flex justify-end gap-2">
                            <Button type="button" variant="outline" className="cursor-pointer" onClick={() => void declineChallenge()}>
                                {t('mockPayment.decline')}
                            </Button>
                            <Button type="button" className="cursor-pointer" onClick={() => void approveChallenge()}>
                                {t('mockPayment.approve')}
                            </Button>
                        </div>
                    </div>
                </div>
            ) : null}
        </div>
    );
}
