/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_MOCK_PAYMENT */

import { type ActionFunctionArgs, data } from 'react-router';
import { ApiError } from '@/scapi';
import { getLogger } from '@/lib/logger.server';
import { withRevalidateTags } from '@/lib/revalidation/tags';
import { PAYMENT_BASKET_TAG } from '../lib/constants';
import { createOrderFromBasket, getOrderByOrderNo, updateClaimedPaymentInstrument } from '../lib/order.server';
import {
    getAppliedLast4,
    getMockPaymentInstrument,
    normalizeLast4,
    orderIsFailed,
    orderIsPending,
    orderNeedsChallenge,
    orderWasPlaced,
} from '../lib/payment-utils';

export type PlaceOrderActionResult = {
    success: boolean;
    orderNo?: string;
    paymentInstrumentId?: string;
    needsChallenge?: boolean;
    pending?: boolean;
    declined?: boolean;
    error?: string;
};

type CreatedOrder = {
    orderNo?: string;
    status?: string;
    paymentInstruments?: Array<{
        paymentMethodId?: string;
        paymentInstrumentId?: string;
        paymentStatus?: string;
        fraudDecisions?: { preAuthorization?: string };
    }>;
};

export async function action({ request, context }: ActionFunctionArgs) {
    if (request.method !== 'POST') {
        return data<PlaceOrderActionResult>({ success: false, error: 'Method not allowed' }, { status: 405 });
    }

    const logger = getLogger(context);
    let basketId: string | undefined;

    try {
        const formData = await request.formData();
        basketId = formData.get('basketId')?.toString();
        if (!basketId) {
            return data<PlaceOrderActionResult>({ success: false, error: 'basketId is required' }, { status: 400 });
        }

        const formLast4 = formData.get('last4')?.toString();
        const formMethodId = formData.get('paymentMethodId')?.toString();

        let order = (await createOrderFromBasket(context, basketId)) as CreatedOrder;
        if (!order?.orderNo) {
            return data<PlaceOrderActionResult>(
                { success: false, error: 'Order creation returned empty result' },
                { status: 500 }
            );
        }

        const needsChallenge = orderNeedsChallenge(order);
        const mockPayment = getMockPaymentInstrument(order);
        const paymentInstrumentId = mockPayment?.paymentInstrumentId;
        if (!needsChallenge) {
            if (!paymentInstrumentId) {
                return data<PlaceOrderActionResult>(
                    { success: false, error: 'Mock payment was not found on the order' },
                    { status: 500 }
                );
            }
            const amount = Number(mockPayment?.amount);
            // createOrder leaves claimed PIs at CREATED. PATCH triggers
            // onAttemptOrderTransition + afterPayment + place. Re-GET the order:
            // PATCH is 200 even when the platform fail+reopens (0004), and the
            // PATCH body may omit status, which made 0004 look like 0000.
            await updateClaimedPaymentInstrument(
                context,
                order.orderNo,
                paymentInstrumentId,
                Number.isFinite(amount) ? amount : undefined,
                mockPayment?.paymentMethodId || formMethodId,
                formLast4 ? normalizeLast4(formLast4) : getAppliedLast4(mockPayment)
            );
            order = (await getOrderByOrderNo(context, order.orderNo)) as CreatedOrder;
        }
        if (orderIsFailed(order) || (!orderWasPlaced(order) && !orderIsPending(order) && !needsChallenge)) {
            return withRevalidateTags(
                { success: false, declined: true } satisfies PlaceOrderActionResult,
                [PAYMENT_BASKET_TAG, 'cart']
            );
        }
        const pending = !needsChallenge && orderIsPending(order);

        return data<PlaceOrderActionResult>({
            success: true,
            orderNo: order.orderNo,
            paymentInstrumentId,
            needsChallenge,
            pending,
        });
    } catch (error) {
        const isApiError = error instanceof ApiError;
        logger.error('[mock-payment] place-order failed', {
            basketId,
            ...(isApiError ? error.toJSON() : { message: String(error) }),
        });
        return data<PlaceOrderActionResult>(
            {
                success: false,
                error: isApiError ? error.message : 'Unable to place the order',
            },
            { status: isApiError ? (error.status ?? 500) : 500 }
        );
    }
}
