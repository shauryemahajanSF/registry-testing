'use strict';

/**
 * Payment Commerce App hooks for CREDIT_CARD and SEPA_DIRECT_DEBIT.
 * last-4 lives on paymentDetails (any ISV app, not Salesforce Payments only).
 */

var Status = require('dw/system/Status');
var Logger = require('dw/system/Logger');
var PaymentTransaction = require('dw/order/PaymentTransaction');
var helper = require('*/cartridge/scripts/helpers/mockPaymentHelper');

var logger = Logger.getLogger('mock-payment', 'hooks');

function ok() {
    return new Status(Status.OK);
}

function error(code, message) {
    return new Status(Status.ERROR, code || 'PAYMENT_ERROR', message || 'Mock payment error');
}

function authorizeOrSkip(order, paymentInstrument, allowChallengeSkip) {
    var scenario = helper.getPaymentScenario(paymentInstrument);
    if (allowChallengeSkip && helper.isPreAuthChallenge(paymentInstrument)) {
        logger.info('Skipping auth because pre-auth is CHALLENGE for order {0} last-4 {1}',
            order && order.orderNo, scenario.last4);
        return ok();
    }
    if (scenario.pay === helper.PAY.FAIL) {
        logger.info('Mock payment fail for order {0} last-4 {1}', order && order.orderNo, scenario.last4);
        return error('PAYMENT_DECLINED', 'Mock payment authorization failed');
    }
    if (scenario.pay === helper.PAY.PENDING) {
        logger.info('Mock payment pending for order {0} last-4 {1}', order && order.orderNo, scenario.last4);
        return ok();
    }
    if (!helper.authorizeInstrument(order, paymentInstrument)) {
        return error('PAYMENT_ERROR', 'Missing payment transaction');
    }
    return ok();
}

exports.getClaimedPaymentMethods = function () {
    return helper.CLAIMED_METHODS.slice();
};

exports.afterCreateBasketPaymentInstrument = function (basket, paymentInstrument, request) {
    try {
        helper.persistPaymentDetails(paymentInstrument, request);
        return ok();
    } catch (e) {
        logger.error('afterCreateBasketPaymentInstrument failed: {0}', e.message);
        return error('PAYMENT_ERROR', e.message);
    }
};

exports.afterUpdateBasketPaymentInstrument = function (basket, paymentInstrument, request) {
    try {
        helper.persistPaymentDetails(paymentInstrument, request);
        return ok();
    } catch (e) {
        logger.error('afterUpdateBasketPaymentInstrument failed: {0}', e.message);
        return error('PAYMENT_ERROR', e.message);
    }
};

exports.afterCreateOrderPaymentInstrument = function (order, paymentInstrument, request) {
    try {
        helper.persistPaymentDetails(paymentInstrument, request);
        return authorizeOrSkip(order, paymentInstrument, true);
    } catch (e) {
        logger.error('afterCreateOrderPaymentInstrument failed: {0}', e.message);
        return error('PAYMENT_ERROR', e.message);
    }
};

exports.onAttemptOrderTransition = function (order, paymentInstrument) {
    try {
        return authorizeOrSkip(order, paymentInstrument, true);
    } catch (e) {
        logger.error('onAttemptOrderTransition failed: {0}', e.message);
        return error('PAYMENT_ERROR', e.message);
    }
};

exports.afterUpdateOrderPaymentInstrument = function (order, paymentInstrument, request) {
    try {
        helper.persistPaymentDetails(paymentInstrument, request);
        // 3DS complete PATCHes while pre-auth is still CHALLENGE and must auth
        // here. A kick PATCH after createOrder is not a challenge: leave CREATED
        // so onAttemptOrderTransition can authorize.
        if (helper.isPreAuthChallenge(paymentInstrument)) {
            return authorizeOrSkip(order, paymentInstrument, false);
        }
        return ok();
    } catch (e) {
        logger.error('afterUpdateOrderPaymentInstrument failed: {0}', e.message);
        return error('PAYMENT_ERROR', e.message);
    }
};

exports.reversePayment = function (order, paymentInstrument) {
    try {
        helper.setTransactionStatus(paymentInstrument, PaymentTransaction.STATUS_AUTHORIZATIONVOIDED);
        return ok();
    } catch (e) {
        logger.error('reversePayment failed: {0}', e.message);
        return error('PAYMENT_ERROR', e.message);
    }
};

exports.authorizePayment = function (order, paymentInstrument) {
    try {
        return authorizeOrSkip(order, paymentInstrument, false);
    } catch (e) {
        logger.error('authorizePayment failed: {0}', e.message);
        return error('PAYMENT_ERROR', e.message);
    }
};

exports.cancelAuthorization = function (order, paymentInstrument) {
    try {
        helper.setTransactionStatus(paymentInstrument, PaymentTransaction.STATUS_AUTHORIZATIONVOIDED);
        return ok();
    } catch (e) {
        logger.error('cancelAuthorization failed: {0}', e.message);
        return error('PAYMENT_ERROR', e.message);
    }
};

exports.capturePayment = function (order, paymentInstrument) {
    try {
        helper.setTransactionStatus(paymentInstrument, PaymentTransaction.STATUS_CAPTURED);
        return ok();
    } catch (e) {
        logger.error('capturePayment failed: {0}', e.message);
        return error('PAYMENT_ERROR', e.message);
    }
};

exports.refundCapture = function (order, paymentInstrument) {
    try {
        helper.setTransactionStatus(paymentInstrument, PaymentTransaction.STATUS_CAPTUREVOIDED);
        return ok();
    } catch (e) {
        logger.error('refundCapture failed: {0}', e.message);
        return error('PAYMENT_ERROR', e.message);
    }
};
