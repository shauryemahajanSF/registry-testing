# Mock Payment

Sample payment Commerce App for Salesforce B2C Commerce 26.10. It claims `CREDIT_CARD` and `SEPA_DIRECT_DEBIT`, persists shopper-safe last-4 on **`paymentDetails`** (the ISV field, not Salesforce Payments only), authorizes the instrument amount on `onAttemptOrderTransition` (place-order) or SCAPI-direct order PI create (or after a fake 3DS Authenticate PATCH when pre-auth fraud is `CHALLENGE`), and ships a Storefront Next payment-method chip plus `onPlaceOrder` flow.

Scenarios are keyed by **`paymentDetails.last4`**. Use with **Mock Fraud** (same last-4 map) to exercise payment/fraud orchestration.

## What it does

### Backend (Script API hooks)

| Hook | Purpose |
|------|---------|
| `sfcc.app.payment.getClaimedPaymentMethods` | Claims `CREDIT_CARD` and `SEPA_DIRECT_DEBIT` |
| `sfcc.app.payment.afterCreateBasketPaymentInstrument` | Sets card `paymentDetails` (last-4, brand, expiry, BIN, funding type, issuing country, gateway token) or SEPA last-4 and holder |
| `sfcc.app.payment.afterUpdateBasketPaymentInstrument` | Refreshes `paymentDetails.last4` on basket PI updates |
| `sfcc.app.payment.afterCreateOrderPaymentInstrument` | Sets details then authorizes when a PI is POSTed onto an existing order (SCAPI-direct); skips CHALLENGE / `0004` / `0005` |
| `sfcc.app.payment.onAttemptOrderTransition` | Authorizes during `OrderMgr.attemptOrderTransition` (place-order path); same skip rules as afterCreate |
| `sfcc.app.payment.afterUpdateOrderPaymentInstrument` | Kick PATCH after Shopper Orders `createOrder`: decline `0004`, hold `0005` as `STATUS_PENDING` (native `authorizeCreditCard` only promotes `CREATED` → `AUTHORIZED`), and authorize/fail when pre-auth is still `CHALLENGE` (`0002` / `0006`). `0000` records card `transactionDetails` (CVC `MATCH`, AVS `Y`) and leaves the transaction `CREATED` so native auth can place. `0002` also records 3DS `AUTHENTICATED`, version `V2`, ECI `05`, and a 3DS transaction id |
| `sfcc.app.payment.reversePayment` | Voids authorization on fail-order |
| `sfcc.app.payment.authorizePayment` | Shared authorize helper |
| `sfcc.app.payment.cancelAuthorization` | Voids authorization |
| `sfcc.app.payment.capturePayment` | Marks captured |
| `sfcc.app.payment.refundCapture` | Marks refunded |
| `sfcc.app.payment.checkConnectionHealth` | Checkout Hub connection badge |

Gift-card capture/refund stays with the gift-card app (Givex). Mixed tender: this app authorizes **this** claimed instrument amount only.

### Storefront Next UI

| Target | Component |
|--------|-----------|
| `sfcc.checkout.payment.paymentMethods` | Mock Credit Card and Mock SEPA chips, last-4 scenario field, apply/remove, fake 3DS Approve/Decline modal via `onPlaceOrder`. Replaces the native SFNext CREDIT_CARD form (does not render UITarget children). |

Apply POSTs Baskets V2 `{ paymentMethodId, amount, paymentCard }`. Do **not** send `paymentDetails` (Orders GET-only; Baskets extra properties must be `c_*`) or `paymentCard.numberLastDigits` (request field is `maskedNumber`). CREDIT_CARD sends `cardType` (`Visa`), `holder`, expiry, and `maskedNumber` (`************` + last-4). SEPA sends `maskedNumber` only (no `cardType`). The afterCreate hook copies last-4 from `request.getPaymentCard().getNumber()` onto `paymentInstrument.setPaymentDetails(...)`. Card details also store brand, expiration, funding type `CREDIT`, issuing country `US`, BIN `411111`, and gateway token `mock-tok-` plus the last-4, so GET order returns those fields. The order kick PATCH writes card `transactionDetails`: CVC and AVS for every authorize, plus 3DS result, version, ECI, and transaction id when pre-auth was `CHALLENGE` (`0002`). Missing last-4 defaults to `0000`.

Place-order uses **Shopper Orders**, not OCAPI Shop:

1. `POST /orders` with `{ basketId }`. Shopper Orders `createOrder` runs fraud `beforePayment` only; it does **not** call `attemptOrderTransition` for claimed methods, so the order stays `CREATED`. When the basket has no claimed mock-payment instrument but another tender already covers the total (for example a gift card), `createOrder` is the whole place: the action returns that order number and does not PATCH a payment instrument.
2. If pre-auth is not `CHALLENGE`, PATCH the claimed PI. Shopper Orders always runs native `authorizeCreditCard` / `authorize` after `afterUpdate`, then `afterPATCH` → `attemptOrderTransition`. CREDIT_CARD must include `paymentCard` (cardType is already on the instrument, so amount-only PATCH 400s). SEPA can stay `{ amount }`. Omit `paymentMethodId` so BM applicability is not re-checked. Do **not** send `skip_authorization` — that query is OCAPI-only and Shopper Orders returns 400. `0004` returns ERROR from `afterUpdate` before native auth. `0005` sets `STATUS_PENDING` first so native auth cannot promote the txn.
3. If pre-auth is `CHALLENGE`, open the Authenticate modal. Approve PATCHes the same PI body so `afterUpdate` authorizes. Decline uses `POST .../orders/{orderNo}/actions/fail?reopenBasket=true` (HTTP 201, `Location: /baskets/{id}`). There is no Shopper Orders `PATCH /orders/{orderNo}`; an OCAPI `{ status: failed }` body 404s and leaves the shopper with no cart.

`0001` (Mock Fraud pre-auth `DECLINED`) currently returns HTTP 500 from Shopper Orders `createOrder` until the platform maps `FraudAppException`. The basket is kept; do not move that decline into this payment app.

## Last-4 scenario matrix

Keep this table in sync with Mock Fraud. Shopper email is not a driver.

| Last-4 | Pre-auth (Mock Fraud) | Payment | Post-auth (Mock Fraud) |
|--------|------------------------|---------|-------------------------|
| `0000` (default) | APPROVED | authorize | GUARANTEED |
| `0001` | DECLINED | — | — (createOrder 500 until platform maps FraudAppException) |
| `0002` | CHALLENGE | skip create/transition; `afterUpdate` authorizes | GUARANTEED |
| `0003` | APPROVED | authorize | NOT_GUARANTEED (kick PATCH fails+reopens; stay on checkout) |
| `0004` | APPROVED | fail on kick PATCH `afterUpdate` | — (order FAILED; stay on checkout, basket reopened) |
| `0005` | APPROVED | `STATUS_PENDING` on kick PATCH; leave CREATED | `afterPayment` never runs (pending toast, stay on checkout) |
| `0006` | CHALLENGE | skip create/transition; `afterUpdate` fails | — |
| `0008` | APPROVED | authorize | PENDING → run Mock Fraud job to place |
| `0009` | APPROVED | authorize | PENDING → run Mock Fraud job to fail |

`CHALLENGE` **skips** authorization on `afterCreateOrderPaymentInstrument` and `onAttemptOrderTransition` even when the payment outcome is fail (`0006`). The storefront modal's Authenticate button PATCHes the order PI so `afterUpdate` runs. Decline fails the CREATED order and reopens the basket.

## Architecture

- Cartridge: `int_mock_payment`
- Service: `mock.payment.api` (template only; unused by the mock hooks)
- Domain: `payment`
- Storefront extension: `storefront-next/src/extensions/mock-payment/`

Applying a payment method updates the checkout basket even when the basket revision timestamp does not change, so the first apply stays on the page.

Enable platform orchestration with the `PaymentFraudOrchestrationEnabled` **feature toggle** when testing with Mock Fraud.

## Installation

1. Install the app from Commerce Apps / Checkout Hub.
2. Ensure `CREDIT_CARD` and `SEPA_DIRECT_DEBIT` are enabled payment methods on the site.
3. Optionally install Mock Fraud and enable `PaymentFraudOrchestrationEnabled`.
4. On Storefront Next checkout, enter a last-4 from the matrix, apply Mock Credit Card or Mock SEPA, and place the order.

## Future provider integration

The installed `mock.payment.api` service is unused. A real processor should replace mock authorize/capture/refund with Service Framework calls and a PSP 3DS SDK instead of the fake Authenticate modal. Persist shopper-safe last-4 with `setPaymentDetails` the same way this mock does.

## Development

```bash
cd cartridges/site_cartridges/int_mock_payment
npm install
npm test
```

Storefront extension unit tests live under `storefront-next/src/extensions/mock-payment/tests/`.
