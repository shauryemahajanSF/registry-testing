# Mock Payment

Sample payment Commerce App for Salesforce B2C Commerce 26.10. It claims `CREDIT_CARD` and `SEPA_DIRECT_DEBIT`, persists shopper-safe last-4 on **`paymentDetails`** (the ISV field, not Salesforce Payments only), authorizes the instrument amount on `onAttemptOrderTransition` (place-order, including a finished fake 3DS challenge) or SCAPI-direct order PI create, and ships a Storefront Next payment-method chip plus `onPlaceOrder` flow.

Scenarios are keyed by **`paymentDetails.last4`**. Use with **Mock Fraud** (same last-4 map) to exercise payment/fraud orchestration.

## What it does

### Backend (Script API hooks)

| Hook | Purpose |
|------|---------|
| `sfcc.app.payment.getClaimedPaymentMethods` | Claims `CREDIT_CARD` and `SEPA_DIRECT_DEBIT` |
| `sfcc.app.payment.afterCreateBasketPaymentInstrument` | Sets card `paymentDetails` (last-4, brand, expiry, BIN, funding type, issuing country, gateway token) or SEPA last-4 and holder |
| `sfcc.app.payment.afterUpdateBasketPaymentInstrument` | Refreshes `paymentDetails.last4` on basket PI updates |
| `sfcc.app.payment.afterCreateOrderPaymentInstrument` | Sets details then authorizes when a PI is POSTed onto an existing order (SCAPI-direct); skips CHALLENGE / `0004` / `0005` |
| `sfcc.app.payment.onAttemptOrderTransition` | Authorizes, declines, or holds during `OrderMgr.attemptOrderTransition`, including a finished 3DS challenge (`0002` / `0006`). `afterCreate` still skips `CHALLENGE` so the shopper can authenticate first |
| `sfcc.app.payment.afterUpdateOrderPaymentInstrument` | Direct order-PI PATCH fallback: decline `0004`, hold `0005` as `STATUS_PENDING` (native `authorizeCreditCard` only promotes `CREATED` → `AUTHORIZED`), and authorize/fail when pre-auth is still `CHALLENGE`. Place-order does not use this path |
| `sfcc.app.payment.reversePayment` | Voids authorization on fail-order |
| `sfcc.app.payment.authorizePayment` | Shared authorize helper |
| `sfcc.app.payment.cancelAuthorization` | Voids authorization |
| `sfcc.app.payment.capturePayment` | Marks captured |
| `sfcc.app.payment.refundCapture` | Marks refunded |
| `sfcc.app.payment.checkConnectionHealth` | Checkout Hub connection badge |

Gift-card capture/refund stays with the gift-card app (Givex). Mixed tender: this app authorizes **this** claimed instrument amount only.

### Storefront Next UI

| Target | Component |
|--------|-----------|
| `sfcc.checkout.payment.paymentMethods` | Mock Credit Card and Mock SEPA chips, last-4 scenario field, apply/remove, fake 3DS Approve/Decline modal via `onPlaceOrder`. Replaces the native SFNext CREDIT_CARD form (does not render UITarget children). |

Apply POSTs Baskets V2 `{ paymentMethodId, amount, paymentCard }`. Do **not** send `paymentDetails` (Orders GET-only; Baskets extra properties must be `c_*`) or `paymentCard.numberLastDigits` (request field is `maskedNumber`). CREDIT_CARD sends `cardType` (`Visa`), `holder`, expiry, and `maskedNumber` (`************` + last-4). SEPA sends `maskedNumber` only (no `cardType`). The afterCreate hook copies last-4 from `request.getPaymentCard().getNumber()` onto `paymentInstrument.setPaymentDetails(...)`. Card details also store brand, expiration, funding type `CREDIT`, issuing country `US`, BIN `411111`, and gateway token `mock-tok-` plus the last-4, so GET order returns those fields. Authorization writes card `transactionDetails`: CVC and AVS for every authorize, plus 3DS result, version, ECI, and transaction id when pre-auth was `CHALLENGE` (`0002`). Missing last-4 defaults to `0000`.

Place-order uses **Shopper Orders** plus the mock-payment custom API, not OCAPI Shop:

1. `POST /orders` with `{ basketId }`. Shopper Orders `createOrder` runs fraud `beforePayment` only; it does **not** call `attemptOrderTransition` for claimed methods, so the order stays `CREATED`. A successfully created order always continues to that custom API, including a gift-card-only order. `createOrder` does not place it.
2. If pre-auth is not `CHALLENGE`, `POST /custom/mock-payment/v1/organizations/{organizationId}/orders/{orderNo}/attempt-transition?siteId=...` (scope `c_mock_payment`). That calls `OrderMgr.attemptOrderTransition` while the instrument is still `PT_CREATED`, so `onAttemptOrderTransition` authorizes, declines, or holds. The storefront then re-GETs the order: a decline is HTTP 200 from the custom API while the platform fails the order and reopens the basket. `0004` returns ERROR from the hook. `0005` sets `STATUS_PENDING` so the order stays `CREATED`.
3. If pre-auth is `CHALLENGE`, open the Authenticate modal. Approve calls the same custom API, and `onAttemptOrderTransition` authorizes or declines (`0002` / `0006`) because the challenge is finished. Decline uses `POST .../orders/{orderNo}/actions/fail?reopenBasket=true` (HTTP 201, `Location: /baskets/{id}`). There is no Shopper Orders `PATCH /orders/{orderNo}`; an OCAPI `{ status: failed }` body 404s and leaves the shopper with no cart.

The extension registers client key `mockPayment` on the storefront SCAPI registry (`basePath` `/custom/mock-payment/v1`, no locale, organization prefix) if the host has not already registered it. Grant `c_mock_payment` on the shopper SLAS client.

`0001` (Mock Fraud pre-auth `DECLINED`) currently returns HTTP 500 from Shopper Orders `createOrder` until the platform maps `FraudAppException`. The basket is kept; do not move that decline into this payment app.

## Last-4 scenario matrix

Keep this table in sync with Mock Fraud. Shopper email is not a driver.

| Last-4 | Pre-auth (Mock Fraud) | Payment | Post-auth (Mock Fraud) |
|--------|------------------------|---------|-------------------------|
| `0000` (default) | APPROVED | authorize | GUARANTEED |
| `0001` | DECLINED | — | — (createOrder 500 until platform maps FraudAppException) |
| `0002` | CHALLENGE | skip create; transition after 3DS authorizes | GUARANTEED |
| `0003` | APPROVED | authorize | NOT_GUARANTEED (transition fails+reopens; stay on checkout) |
| `0004` | APPROVED | fail on `onAttemptOrderTransition` | — (order FAILED; stay on checkout, basket reopened) |
| `0005` | APPROVED | `STATUS_PENDING` on transition; leave CREATED | `afterPayment` never runs (pending toast, stay on checkout) |
| `0006` | CHALLENGE | skip create; transition after 3DS fails | — |
| `0008` | APPROVED | authorize | PENDING → run Mock Fraud job to place |
| `0009` | APPROVED | authorize | PENDING → run Mock Fraud job to fail |

`CHALLENGE` **skips** authorization on `afterCreateOrderPaymentInstrument` so the shopper can see the Authenticate modal. `onAttemptOrderTransition` does **not** skip: the storefront calls it only after the shopper approves, and that hook authorizes or declines (`0002` / `0006`). Decline fails the CREATED order and reopens the basket.

## Architecture

- Cartridge: `int_mock_payment`
- Service: `mock.payment.api` (template only; unused by the mock hooks)
- Domain: `payment`
- Storefront extension: `storefront-next/src/extensions/mock-payment/`

Applying a payment method updates the checkout basket even when the basket revision timestamp does not change, so the first apply stays on the page.

Enable platform orchestration with the `PaymentFraudOrchestrationEnabled` **feature toggle** when testing with Mock Fraud.

## Installation

1. Install the app from Commerce Apps / Checkout Hub.
2. Ensure `CREDIT_CARD` and `SEPA_DIRECT_DEBIT` are enabled payment methods on the site.
3. Optionally install Mock Fraud and enable `PaymentFraudOrchestrationEnabled`.
4. Grant the shopper SLAS client the custom scope `c_mock_payment`.
5. On Storefront Next checkout, enter a last-4 from the matrix, apply Mock Credit Card or Mock SEPA, and place the order.

## Future provider integration

The installed `mock.payment.api` service is unused. A real processor should replace mock authorize/capture/refund with Service Framework calls and a PSP 3DS SDK instead of the fake Authenticate modal. Persist shopper-safe last-4 with `setPaymentDetails` the same way this mock does.

## Development

```bash
cd cartridges/site_cartridges/int_mock_payment
npm install
npm test
```

Storefront extension unit tests live under `storefront-next/src/extensions/mock-payment/tests/`.
