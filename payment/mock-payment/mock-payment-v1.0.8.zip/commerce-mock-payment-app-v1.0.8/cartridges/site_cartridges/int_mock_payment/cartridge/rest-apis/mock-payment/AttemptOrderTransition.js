/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

'use strict';

var OrderMgr = require('dw/order/OrderMgr');
var RESTResponseMgr = require('dw/system/RESTResponseMgr');
var Logger = require('dw/system/Logger');

var logger = Logger.getLogger('mock-payment', 'attempt-order-transition');

/**
 * Shopper may transition only an order owned by the current session customer.
 * createOrder assigns that customer, including the guest profile for a guest checkout.
 * @param {dw.order.Order} order
 * @returns {boolean}
 */
function shopperOwnsOrder(order) {
    var currentCustomer = session.getCustomer();
    var orderCustomer = order.getCustomer();
    if (!currentCustomer || !orderCustomer) {
        return false;
    }
    return currentCustomer.getID() === orderCustomer.getID();
}

/**
 * POST /orders/{orderNo}/attempt-transition
 *
 * Calls OrderMgr.attemptOrderTransition after createOrder has committed.
 * The payment app's onAttemptOrderTransition hook authorizes, declines, or
 * holds the claimed instrument. The platform then places or fails the order.
 * ShopperToken scope: c_mock_payment.
 */
exports.attemptOrderTransition = function () {
    var pathParameters = request.getSCAPIPathParameters();
    var orderNo = pathParameters ? pathParameters.get('orderNo') : null;
    if (!orderNo) {
        RESTResponseMgr.createError(400, 'missing-order-no', 'Bad Request', 'orderNo is required').render();
        return;
    }

    var order = OrderMgr.getOrder(orderNo);
    if (!order) {
        RESTResponseMgr.createError(404, 'order-not-found', 'Not Found', 'Order was not found').render();
        return;
    }
    if (!shopperOwnsOrder(order)) {
        RESTResponseMgr.createError(403, 'forbidden', 'Forbidden', 'Order does not belong to the current shopper').render();
        return;
    }

    var result;
    try {
        result = OrderMgr.attemptOrderTransition(order);
    } catch (e) {
        logger.error('attemptOrderTransition failed for order {0}: {1}', orderNo, e.message);
        RESTResponseMgr.createError(
            500,
            'transition-failed',
            'Internal Server Error',
            e.message || 'Unable to attempt order transition'
        ).render();
        return;
    }

    var basket = result.getBasket();
    RESTResponseMgr.createSuccess({
        final: result.isFinal(),
        error: result.isError(),
        step: result.getStep(),
        reason: result.getReason(),
        orderNo: order.getOrderNo(),
        basketId: basket ? basket.getUUID() : null
    }).render();
};

exports.attemptOrderTransition.public = true;
