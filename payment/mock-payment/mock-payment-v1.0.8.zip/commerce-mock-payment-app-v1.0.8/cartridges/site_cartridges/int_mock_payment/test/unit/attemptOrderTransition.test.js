'use strict';

var assert = require('chai').assert;
var proxyquire = require('proxyquire').noCallThru();

describe('attemptOrderTransition custom API', function () {
    var rendered;
    var transitionArgs;
    var orders;

    function load(pathParameters) {
        rendered = null;
        transitionArgs = null;
        global.session = {
            getCustomer: function () {
                return { getID: function () { return 'shopper-1'; } };
            }
        };
        global.request = {
            getSCAPIPathParameters: function () {
                return pathParameters;
            }
        };
        return proxyquire('../../cartridge/rest-apis/mock-payment/AttemptOrderTransition', {
            'dw/order/OrderMgr': {
                getOrder: function (orderNo) {
                    return orders[orderNo] || null;
                },
                attemptOrderTransition: function (order) {
                    transitionArgs = order;
                    return {
                        isFinal: function () { return true; },
                        isError: function () { return false; },
                        getStep: function () { return null; },
                        getReason: function () { return null; },
                        getBasket: function () { return null; }
                    };
                }
            },
            'dw/system/RESTResponseMgr': {
                createError: function (status, code, title, message) {
                    return {
                        render: function () {
                            rendered = { status: status, code: code, title: title, message: message };
                        }
                    };
                },
                createSuccess: function (body) {
                    return {
                        render: function () {
                            rendered = { status: 200, body: body };
                        }
                    };
                }
            },
            'dw/system/Logger': {
                getLogger: function () {
                    return { error: function () {} };
                }
            }
        });
    }

    beforeEach(function () {
        orders = {
            '0001': {
                getOrderNo: function () { return '0001'; },
                getCustomer: function () {
                    return { getID: function () { return 'shopper-1'; } };
                }
            },
            '0002': {
                getOrderNo: function () { return '0002'; },
                getCustomer: function () {
                    return { getID: function () { return 'someone-else'; } };
                }
            }
        };
    });

    it('transitions an order owned by the current shopper', function () {
        var api = load({ get: function (name) { return name === 'orderNo' ? '0001' : null; } });
        api.attemptOrderTransition();
        assert.strictEqual(transitionArgs.getOrderNo(), '0001');
        assert.strictEqual(rendered.status, 200);
        assert.strictEqual(rendered.body.orderNo, '0001');
        assert.strictEqual(rendered.body.final, true);
        assert.strictEqual(rendered.body.error, false);
    });

    it('rejects an order owned by another shopper', function () {
        var api = load({ get: function () { return '0002'; } });
        api.attemptOrderTransition();
        assert.strictEqual(transitionArgs, null);
        assert.strictEqual(rendered.status, 403);
        assert.strictEqual(rendered.code, 'forbidden');
    });

    it('returns 404 when the order does not exist', function () {
        var api = load({ get: function () { return 'missing'; } });
        api.attemptOrderTransition();
        assert.strictEqual(rendered.status, 404);
        assert.strictEqual(rendered.code, 'order-not-found');
    });
});
