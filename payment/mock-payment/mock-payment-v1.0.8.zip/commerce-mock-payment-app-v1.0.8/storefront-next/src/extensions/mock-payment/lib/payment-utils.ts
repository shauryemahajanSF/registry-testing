/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_MOCK_PAYMENT */

import type { ShopperBasketsV2 } from '@/scapi';
import {
    CLAIMED_PAYMENT_METHOD_IDS,
    CREDIT_CARD_PAYMENT_METHOD_ID,
    SEPA_PAYMENT_METHOD_ID,
} from './constants';

export type BasketPaymentInstrument = ShopperBasketsV2.schemas['OrderPaymentInstrument'];

type PaymentDetails = {
    type?: string;
    last4?: string;
    brand?: string;
};

type FraudDecisions = {
    preAuthorization?: string;
    postAuthorization?: string;
};

type OrderPaymentInstrument = BasketPaymentInstrument & {
    paymentDetails?: PaymentDetails;
    fraudDecisions?: FraudDecisions;
};

type OrderLike = {
    orderNo?: string;
    status?: string;
    paymentInstruments?: OrderPaymentInstrument[];
};

export type ClaimedPaymentMethodId = (typeof CLAIMED_PAYMENT_METHOD_IDS)[number];

export function isClaimedPaymentMethodId(value: string | undefined): value is ClaimedPaymentMethodId {
    return value === CREDIT_CARD_PAYMENT_METHOD_ID || value === SEPA_PAYMENT_METHOD_ID;
}

export function isMockPaymentInstrument(instrument: BasketPaymentInstrument | undefined): boolean {
    return isClaimedPaymentMethodId(instrument?.paymentMethodId);
}

export function getMockPaymentInstruments(
    basket: ShopperBasketsV2.schemas['Basket'] | undefined
): BasketPaymentInstrument[] {
    return (basket?.paymentInstruments ?? []).filter(isMockPaymentInstrument);
}

function roundMoney(value: number): number {
    return Math.round(value * 100) / 100;
}

/** Remaining order total not covered by existing payment instruments. */
export function getRemainingAmount(basket: ShopperBasketsV2.schemas['Basket'] | undefined): number {
    const total = Number(basket?.orderTotal ?? 0);
    const applied = (basket?.paymentInstruments ?? []).reduce(
        (sum, instrument) => sum + Number(instrument.amount ?? 0),
        0
    );
    return Math.max(0, roundMoney(total - applied));
}

export function orderNeedsChallenge(order: OrderLike | undefined): boolean {
    return (order?.paymentInstruments ?? []).some(
        (instrument) =>
            isMockPaymentInstrument(instrument) && instrument.fraudDecisions?.preAuthorization === 'CHALLENGE'
    );
}

/** Shopper Orders kick/3DS PATCH returns 200 after platform fail+reopen. */
export function orderIsFailed(order: { status?: string } | undefined): boolean {
    const status = String(order?.status || '').toLowerCase();
    return status === 'failed' || status === 'cancelled';
}

/** Only `new`/`completed` should go to confirmation. Missing status is not a place. */
export function orderWasPlaced(order: { status?: string } | undefined): boolean {
    const status = String(order?.status || '').toLowerCase();
    return status === 'new' || status === 'completed';
}

export function orderIsPending(order: { status?: string } | undefined): boolean {
    return String(order?.status || '').toLowerCase() === 'created';
}

export function getMockPaymentInstrument(
    order: OrderLike | undefined
): OrderPaymentInstrument | undefined {
    return (order?.paymentInstruments ?? []).find(isMockPaymentInstrument);
}

export function getMockPaymentInstrumentId(order: OrderLike | undefined): string | undefined {
    return getMockPaymentInstrument(order)?.paymentInstrumentId;
}

/** Normalize a last-4; missing or non-digit input is happy-path 0000. */
export function normalizeLast4(value: string | undefined | null): string {
    const digits = String(value ?? '').replace(/\D/g, '');
    if (!digits) {
        return '0000';
    }
    return digits.slice(-4).padStart(4, '0');
}

/**
 * The shared basket context drops a write whose lastModified is not newer than
 * the basket already on the page. Payment apply often comes back with the same
 * timestamp, so the chip stays unsaved after the first click. Nudge an equal or
 * older revision by 1ms so this extension's write is accepted.
 */
export function basketVisibleToContext<T extends { basketId?: string; lastModified?: string }>(
    next: T | undefined,
    current: { basketId?: string; lastModified?: string } | null | undefined
): T | undefined {
    if (
        !next?.lastModified ||
        !current?.lastModified ||
        !next.basketId ||
        next.basketId !== current.basketId ||
        next.lastModified > current.lastModified
    ) {
        return next;
    }
    const base = Date.parse(current.lastModified);
    if (Number.isNaN(base)) {
        return next;
    }
    return { ...next, lastModified: new Date(base + 1).toISOString() };
}

type PaymentCard = {
    numberLastDigits?: string;
    maskedNumber?: string;
};

/**
 * Shopper-safe last-4: paymentDetails.last4 is the ISV field GET order copies
 * from setPaymentDetails. Shopper Baskets GET also returns
 * paymentCard.numberLastDigits for CREDIT_CARD.
 */
export function getAppliedLast4(instrument: BasketPaymentInstrument | undefined): string {
    const details = (instrument as { paymentDetails?: PaymentDetails } | undefined)?.paymentDetails;
    const card = (instrument as { paymentCard?: PaymentCard } | undefined)?.paymentCard;
    return normalizeLast4(details?.last4 || card?.numberLastDigits || card?.maskedNumber);
}

/** Shopper Baskets V2 maskedNumber: at least 6 non-digits, then last-4. */
export function maskedNumberForLast4(last4: string): string {
    return `${'*'.repeat(12)}${normalizeLast4(last4)}`;
}

export function mockCreditCardRequest(last4: string) {
    return {
        cardType: 'Visa',
        holder: 'Mock Shopper',
        maskedNumber: maskedNumberForLast4(last4),
        expirationMonth: 12,
        expirationYear: 2030,
    };
}

/**
 * Baskets V2 POST body. Do not send paymentDetails (Orders GET-only; Baskets
 * additionalProperties only allow c_*) or paymentCard.numberLastDigits (request
 * schema is OrderPaymentCardRequest, which uses maskedNumber).
 */
export function mockPaymentInstrumentBody(
    methodId: ClaimedPaymentMethodId,
    last4: string,
    amount?: number
): ShopperBasketsV2.schemas['OrderPaymentInstrument'] {
    const code = normalizeLast4(last4);
    return {
        paymentMethodId: methodId,
        paymentCard: {
            maskedNumber: maskedNumberForLast4(code),
            ...(methodId === CREDIT_CARD_PAYMENT_METHOD_ID ? mockCreditCardRequest(code) : {}),
        },
        ...(typeof amount === 'number' ? { amount } : {}),
    } as ShopperBasketsV2.schemas['OrderPaymentInstrument'];
}

/**
 * Shopper Orders PATCH body for the createOrder kick / 3DS complete.
 * CREDIT_CARD instruments already have cardType, so amount-only PATCH 400s
 * (authorizeCreditCard requires a paymentCard object). Omit paymentMethodId
 * so the patch validator does not re-check BM applicability.
 */
export function mockOrderPaymentInstrumentPatchBody(
    methodId: ClaimedPaymentMethodId,
    last4: string,
    amount?: number
): { amount?: number; paymentCard?: ReturnType<typeof mockCreditCardRequest> } {
    return {
        ...(typeof amount === 'number' ? { amount } : {}),
        ...(methodId === CREDIT_CARD_PAYMENT_METHOD_ID ? { paymentCard: mockCreditCardRequest(last4) } : {}),
    };
}
