/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_MOCK_PAYMENT */

import { createApiClients } from '@/lib/api-clients.server';
import type { RouterContextProvider } from 'react-router';
import { ensureMockPaymentClient } from './mock-payment-client.server';

type FailOrderResponse = {
    data?: Record<string, unknown>;
    response?: { headers?: { get: (name: string) => string | null } };
};

type OrderClients = {
    shopperOrders: {
        createOrder: (args: unknown) => Promise<{ data: Record<string, unknown> }>;
        getOrder: (args: unknown) => Promise<{ data: Record<string, unknown> }>;
        failOrder?: (args: unknown) => Promise<FailOrderResponse>;
    };
    mockPayment: {
        attemptOrderTransition: (args: { params: { path: { orderNo: string } } }) => Promise<unknown>;
    };
};

function getOrdersClient(context: Readonly<RouterContextProvider>): OrderClients['shopperOrders'] {
    const clients = createApiClients(context) as unknown as OrderClients;
    return clients.shopperOrders;
}

export async function createOrderFromBasket(
    context: Readonly<RouterContextProvider>,
    basketId: string
): Promise<Record<string, unknown>> {
    const { data } = await getOrdersClient(context).createOrder({
        params: {},
        body: { basketId },
    });
    return data;
}

/**
 * Run OrderMgr.attemptOrderTransition for an order createOrder already committed.
 * The mock-payment custom API dispatches onAttemptOrderTransition, which
 * authorizes, declines, or holds the claimed instrument. Call this in a
 * request after createOrder so a rolled-back create cannot leave a provider
 * authorization with no local order.
 */
export async function attemptOrderTransition(
    context: Readonly<RouterContextProvider>,
    orderNo: string
): Promise<void> {
    ensureMockPaymentClient();
    const clients = createApiClients(context) as unknown as OrderClients;
    await clients.mockPayment.attemptOrderTransition({
        params: { path: { orderNo } },
    });
}

export async function getOrderByOrderNo(
    context: Readonly<RouterContextProvider>,
    orderNo: string
): Promise<Record<string, unknown>> {
    const { data } = await getOrdersClient(context).getOrder({
        params: { path: { orderNo } },
    });
    return data;
}

function basketIdFromFailLocation(location: string | null | undefined): string | undefined {
    if (!location) {
        return undefined;
    }
    const match = location.match(/\/baskets\/([^/?#]+)/i);
    return match?.[1];
}

/**
 * Fail a CREATED order and reopen the basket. Shopper Orders has no PATCH
 * /orders/{orderNo}; OCAPI `{ status: failed }` 404s and leaves the shopper
 * with no cart. Use POST .../actions/fail?reopenBasket=true.
 */
export async function failCreatedOrder(
    context: Readonly<RouterContextProvider>,
    orderNo: string
): Promise<{ basketId?: string }> {
    const client = getOrdersClient(context);
    if (typeof client.failOrder !== 'function') {
        throw new Error('Shopper Orders failOrder is not available on this SCAPI client');
    }
    const { response } = await client.failOrder({
        params: {
            path: { orderNo },
            query: { reopenBasket: true },
        },
        body: {},
    });
    const location = response?.headers?.get('location') ?? response?.headers?.get('Location');
    return { basketId: basketIdFromFailLocation(location) };
}
