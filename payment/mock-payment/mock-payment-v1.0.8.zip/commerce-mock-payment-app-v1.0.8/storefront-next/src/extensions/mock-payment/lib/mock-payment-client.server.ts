/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_MOCK_PAYMENT */

import { customClients } from '@/scapi/custom-clients';

const BASE_PATH = '' as const;

/**
 * Operation map for POST /custom/mock-payment/v1/organizations/{organizationId}/orders/{orderNo}/attempt-transition.
 * Shape matches clients produced by `sfnext scapi add`.
 */
export const operations = {
    attemptOrderTransition: {
        m: 'POST' as const,
        b: BASE_PATH,
        s: '/orders/{orderNo}/attempt-transition',
    },
} as const;

type CustomClientEntry = {
    key: string;
    basePath: string;
    ops: typeof operations;
    locale: boolean;
    orgPrefix: boolean;
};

const mockPaymentClient: CustomClientEntry = {
    key: 'mockPayment',
    basePath: '/custom/mock-payment/v1',
    ops: operations,
    locale: false,
    orgPrefix: true,
};

/**
 * Register the mock-payment custom client on the storefront SCAPI registry.
 * createApiClients reads that registry on each call and applies shopper auth.
 * A host that already registered `mockPayment` (for example via `sfnext scapi add`) is left as-is.
 */
export function ensureMockPaymentClient(): void {
    const registry = customClients as readonly { key: string }[];
    if (registry.some((client) => client.key === 'mockPayment')) {
        return;
    }
    (customClients as unknown as CustomClientEntry[]).push(mockPaymentClient);
}
