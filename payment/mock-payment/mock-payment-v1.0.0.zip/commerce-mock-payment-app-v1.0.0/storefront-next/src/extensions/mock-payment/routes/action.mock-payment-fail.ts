/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_MOCK_PAYMENT */

import { type ActionFunctionArgs, data } from 'react-router';
import { ApiError } from '@/scapi';
import { getLogger } from '@/lib/logger.server';
import { failCreatedOrder } from '../lib/order.server';

export type FailOrderActionResult = {
    success: boolean;
    error?: string;
};

export async function action({ request, context }: ActionFunctionArgs) {
    if (request.method !== 'POST') {
        return data<FailOrderActionResult>({ success: false, error: 'Method not allowed' }, { status: 405 });
    }

    const logger = getLogger(context);
    let orderNo: string | undefined;

    try {
        const formData = await request.formData();
        orderNo = formData.get('orderNo')?.toString();
        if (!orderNo) {
            return data<FailOrderActionResult>({ success: false, error: 'orderNo is required' }, { status: 400 });
        }

        await failCreatedOrder(context, orderNo);
        return data<FailOrderActionResult>({ success: true });
    } catch (error) {
        const isApiError = error instanceof ApiError;
        logger.error('[mock-payment] fail order failed', {
            orderNo,
            ...(isApiError ? error.toJSON() : { message: String(error) }),
        });
        return data<FailOrderActionResult>(
            {
                success: false,
                error: isApiError ? error.message : 'Unable to fail the order',
            },
            { status: isApiError ? (error.status ?? 500) : 500 }
        );
    }
}
