/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_MOCK_PAYMENT */

import { createApiClients } from '@/lib/api-clients.server';
import type { RouterContextProvider } from 'react-router';
import { BANK_TRANSFER_PAYMENT_METHOD_ID } from './constants';

type OrderClients = {
    shopperOrders: {
        createOrder: (args: unknown) => Promise<{ data: Record<string, unknown> }>;
        updateOrder: (args: unknown) => Promise<{ data: Record<string, unknown> }>;
        updatePaymentInstrumentForOrder: (args: unknown) => Promise<{ data: Record<string, unknown> }>;
    };
};

function getOrdersClient(context: Readonly<RouterContextProvider>): OrderClients['shopperOrders'] {
    const clients = createApiClients(context) as unknown as OrderClients;
    return clients.shopperOrders;
}

export async function createOrderFromBasket(
    context: Readonly<RouterContextProvider>,
    basketId: string
): Promise<Record<string, unknown>> {
    const { data } = await getOrdersClient(context).createOrder({
        params: {},
        body: { basketId },
    });
    return data;
}

export async function completeOrderChallenge(
    context: Readonly<RouterContextProvider>,
    orderNo: string,
    paymentInstrumentId: string,
    amount?: number
): Promise<Record<string, unknown>> {
    const { data } = await getOrdersClient(context).updatePaymentInstrumentForOrder({
        params: { path: { orderNo, paymentInstrumentId } },
        body: {
            paymentMethodId: BANK_TRANSFER_PAYMENT_METHOD_ID,
            ...(typeof amount === 'number' ? { amount } : {}),
        },
    });
    return data;
}

export async function failCreatedOrder(
    context: Readonly<RouterContextProvider>,
    orderNo: string
): Promise<Record<string, unknown>> {
    const { data } = await getOrdersClient(context).updateOrder({
        params: { path: { orderNo } },
        body: { status: 'failed' },
    });
    return data;
}
