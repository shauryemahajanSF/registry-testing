/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_MOCK_PAYMENT */

import { type ActionFunctionArgs, data } from 'react-router';
import { ApiError } from '@/scapi';
import { getLogger } from '@/lib/logger.server';
import { createOrderFromBasket } from '../lib/order.server';
import { getBankTransferInstrumentId, orderNeedsChallenge } from '../lib/payment-utils';

export type PlaceOrderActionResult = {
    success: boolean;
    orderNo?: string;
    paymentInstrumentId?: string;
    needsChallenge?: boolean;
    pending?: boolean;
    error?: string;
};

type CreatedOrder = {
    orderNo?: string;
    status?: string;
    paymentInstruments?: Array<{
        paymentMethodId?: string;
        paymentInstrumentId?: string;
        paymentStatus?: string;
        fraudDecisions?: { preAuthorization?: string };
    }>;
};

export async function action({ request, context }: ActionFunctionArgs) {
    if (request.method !== 'POST') {
        return data<PlaceOrderActionResult>({ success: false, error: 'Method not allowed' }, { status: 405 });
    }

    const logger = getLogger(context);
    let basketId: string | undefined;

    try {
        const formData = await request.formData();
        basketId = formData.get('basketId')?.toString();
        if (!basketId) {
            return data<PlaceOrderActionResult>({ success: false, error: 'basketId is required' }, { status: 400 });
        }

        const order = (await createOrderFromBasket(context, basketId)) as CreatedOrder;
        if (!order?.orderNo) {
            return data<PlaceOrderActionResult>(
                { success: false, error: 'Order creation returned empty result' },
                { status: 500 }
            );
        }

        const needsChallenge = orderNeedsChallenge(order);
        const paymentInstrumentId = getBankTransferInstrumentId(order);
        const pending = !needsChallenge && String(order.status || '').toLowerCase() === 'created';

        return data<PlaceOrderActionResult>({
            success: true,
            orderNo: order.orderNo,
            paymentInstrumentId,
            needsChallenge,
            pending,
        });
    } catch (error) {
        const isApiError = error instanceof ApiError;
        logger.error('[mock-payment] place-order failed', {
            basketId,
            ...(isApiError ? error.toJSON() : { message: String(error) }),
        });
        return data<PlaceOrderActionResult>(
            {
                success: false,
                error: isApiError ? error.message : 'Unable to place the order',
            },
            { status: isApiError ? (error.status ?? 500) : 500 }
        );
    }
}
