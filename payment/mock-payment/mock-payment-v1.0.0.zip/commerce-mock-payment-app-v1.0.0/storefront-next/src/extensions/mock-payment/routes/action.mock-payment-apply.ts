/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_MOCK_PAYMENT */

import { type ActionFunctionArgs, data } from 'react-router';
import { ApiError, type ShopperBasketsV2 } from '@/scapi';
import { createApiClients } from '@/lib/api-clients.server';
import { addPaymentInstrumentToBasket } from '@/lib/api/basket.server';
import { getLogger } from '@/lib/logger.server';
import { withRevalidateTags } from '@/lib/revalidation/tags';
import { BANK_TRANSFER_PAYMENT_METHOD_ID, PAYMENT_BASKET_TAG } from '../lib/constants';
import { getBankTransferInstruments, getRemainingAmount } from '../lib/payment-utils';

type Basket = ShopperBasketsV2.schemas['Basket'];

export type ApplyBankTransferActionResult = {
    success: boolean;
    basket?: Basket;
    error?: string;
};

export async function action({ request, context }: ActionFunctionArgs) {
    if (request.method !== 'POST') {
        return data<ApplyBankTransferActionResult>(
            { success: false, error: 'Method not allowed' },
            { status: 405 }
        );
    }

    const logger = getLogger(context);
    let basketId: string | undefined;

    try {
        const formData = await request.formData();
        basketId = formData.get('basketId')?.toString();
        if (!basketId) {
            return data<ApplyBankTransferActionResult>(
                { success: false, error: 'basketId is required' },
                { status: 400 }
            );
        }

        const clients = createApiClients(context);
        const { data: basket } = await clients.shopperBasketsV2.getBasket({
            params: { path: { basketId } },
        });
        if (getBankTransferInstruments(basket).length > 0) {
            return withRevalidateTags(
                { success: true, basket } satisfies ApplyBankTransferActionResult,
                [PAYMENT_BASKET_TAG]
            );
        }

        const remaining = getRemainingAmount(basket);
        if (remaining <= 0) {
            return data<ApplyBankTransferActionResult>(
                { success: false, error: 'Order total is already covered' },
                { status: 400 }
            );
        }

        const updated = await addPaymentInstrumentToBasket(context, basketId, {
            paymentMethodId: BANK_TRANSFER_PAYMENT_METHOD_ID,
            amount: remaining,
        } as ShopperBasketsV2.schemas['OrderPaymentInstrument']);

        return withRevalidateTags(
            { success: true, basket: updated } satisfies ApplyBankTransferActionResult,
            [PAYMENT_BASKET_TAG]
        );
    } catch (error) {
        const isApiError = error instanceof ApiError;
        logger.error('[mock-payment] apply failed', {
            basketId,
            ...(isApiError ? error.toJSON() : { message: String(error) }),
        });
        return data<ApplyBankTransferActionResult>(
            {
                success: false,
                error: isApiError ? error.message : 'Unable to apply mock bank transfer',
            },
            { status: isApiError ? (error.status ?? 500) : 500 }
        );
    }
}
