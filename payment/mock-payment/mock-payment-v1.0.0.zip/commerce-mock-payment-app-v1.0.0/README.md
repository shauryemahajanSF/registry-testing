# Mock Payment

Sample payment Commerce App for Salesforce B2C Commerce 26.10. It claims `BANK_TRANSFER`, authorizes the instrument amount on order PI create (or after a fake 3DS Authenticate PATCH when pre-auth fraud is `CHALLENGE`), and ships a Storefront Next payment-method chip plus `onPlaceOrder` flow.

Use with **Mock Fraud** to exercise the full payment/fraud orchestration path.

## What it does

### Backend (Script API hooks)

| Hook | Purpose |
|------|---------|
| `sfcc.app.payment.getClaimedPaymentMethods` | Claims `BANK_TRANSFER` |
| `sfcc.app.payment.afterAddBasketPaymentInstrument` | Accepts the basket PI |
| `sfcc.app.payment.afterUpdateBasketPaymentInstrument` | Accepts basket PI updates |
| `sfcc.app.payment.afterCreateOrderPaymentInstrument` | Authorizes this PI's amount unless pre-auth is `CHALLENGE`, `pay-fail`, or `pay-pending` |
| `sfcc.app.payment.afterUpdateOrderPaymentInstrument` | Authorizes after shopper Authenticate (3DS complete) |
| `sfcc.app.payment.reversePayment` | Voids authorization on fail-order |
| `sfcc.app.payment.authorizePayment` | Shared authorize helper |
| `sfcc.app.payment.cancelAuthorization` | Voids authorization |
| `sfcc.app.payment.capturePayment` | Marks captured |
| `sfcc.app.payment.refundCapture` | Marks refunded |
| `sfcc.app.payment.checkConnectionHealth` | Checkout Hub connection badge |

Gift-card capture/refund stays with the gift-card app (Givex). Mixed tender: this app authorizes **this** BANK_TRANSFER instrument amount only.

### Storefront Next UI

| Target | Component |
|--------|-----------|
| `sfcc.checkout.payment.paymentMethods.before` | BANK_TRANSFER chip, apply/remove, fake 3DS Approve/Decline modal via `onPlaceOrder` |

## Email scenario matrix

Shopper email local-part (case-insensitive), in addition to Mock Fraud emails:

| Email local-part | Payment behavior |
|------------------|------------------|
| `pay-fail` | `afterCreate` / `afterUpdate` returns `Status.ERROR` (authorization fails) |
| `pay-pending` | Leaves the transaction in `CREATED` (order stays `CREATED`) |
| anything else | Authorizes on create, unless pre-auth fraud is `CHALLENGE` |

`CHALLENGE` (from Mock Fraud `fraud-challenge@`) **skips** `afterCreate` authorization. The storefront modal's Authenticate button PATCHes the order PI so `afterUpdate` authorizes. Decline PATCHes the order `{status: failed}`.

## Architecture

- Cartridge: `int_mock_payment`
- Service: `mock.payment.api` (template only; unused by the mock hooks)
- Domain: `payment`
- Storefront extension: `storefront-next/src/extensions/mock-payment/`

Enable platform orchestration with `PaymentFraudOrchestrationEnabled` when testing with Mock Fraud.

## Installation

1. Install the app from Commerce Apps / Checkout Hub.
2. Ensure `BANK_TRANSFER` is an enabled payment method on the site.
3. Optionally install Mock Fraud and enable `PaymentFraudOrchestrationEnabled`.
4. On Storefront Next checkout, select Mock Bank Transfer and place the order.

## Future provider integration

The installed `mock.payment.api` service is unused. A real processor should replace mock authorize/capture/refund with Service Framework calls and a PSP 3DS SDK instead of the fake Authenticate modal.

## Development

```bash
cd cartridges/site_cartridges/int_mock_payment
npm install
npm test
```

Storefront extension unit tests live under `storefront-next/src/extensions/mock-payment/tests/`.
