'use strict';

/**
 * Shared helpers for the Mock Payment Commerce App.
 * Authorization is mock; CHALLENGE skips afterCreate and waits for afterUpdate.
 */

var Logger = require('dw/system/Logger');
var PaymentTransaction = require('dw/order/PaymentTransaction');

var logger = Logger.getLogger('mock-payment', 'helper');

var CLAIMED_METHOD = 'BANK_TRANSFER';

/**
 * @param {string|null|undefined} email
 * @returns {string}
 */
function getEmailLocalPart(email) {
    if (!email) {
        return '';
    }
    var value = String(email).trim().toLowerCase();
    var at = value.indexOf('@');
    return at > 0 ? value.substring(0, at) : value;
}

/**
 * @param {dw.order.LineItemCtnr} container
 * @returns {string}
 */
function getShopperEmail(container) {
    if (!container) {
        return '';
    }
    try {
        if (typeof container.getCustomerEmail === 'function') {
            var customerEmail = container.getCustomerEmail();
            if (customerEmail) {
                return String(customerEmail);
            }
        }
    } catch (e) {
        logger.warn('getCustomerEmail failed: {0}', e.message);
    }
    try {
        var billing = typeof container.getBillingAddress === 'function' ? container.getBillingAddress() : null;
        if (billing && billing.email) {
            return String(billing.email);
        }
    } catch (e) {
        logger.warn('billing email lookup failed: {0}', e.message);
    }
    return '';
}

/**
 * @param {string} email
 * @returns {{fail: boolean, pending: boolean}}
 */
function getPaymentScenario(email) {
    var localPart = getEmailLocalPart(email);
    return {
        fail: localPart === 'pay-fail',
        pending: localPart === 'pay-pending'
    };
}

/**
 * @param {dw.order.PaymentInstrument} paymentInstrument
 * @returns {boolean}
 */
function isPreAuthChallenge(paymentInstrument) {
    if (!paymentInstrument) {
        return false;
    }
    try {
        var transaction = paymentInstrument.getPaymentTransaction();
        if (transaction && typeof transaction.getPreAuthFraudDecision === 'function') {
            var decision = transaction.getPreAuthFraudDecision();
            if (decision === PaymentTransaction.PRE_AUTH_FRAUD_DECISION_CHALLENGE
                || decision === 'CHALLENGE') {
                return true;
            }
        }
    } catch (e) {
        logger.warn('pre-auth lookup failed: {0}', e.message);
    }
    try {
        if (typeof paymentInstrument.getPaymentDetails === 'function') {
            var details = paymentInstrument.getPaymentDetails();
            if (details && typeof details.getPreAuthorizationFraudResult === 'function') {
                var result = details.getPreAuthorizationFraudResult();
                if (result === 'CHALLENGE') {
                    return true;
                }
            }
        }
    } catch (e) {
        logger.warn('payment details lookup failed: {0}', e.message);
    }
    return false;
}

/**
 * Authorizes this payment instrument's amount (mixed-tender safe).
 * @param {dw.order.Order} order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument
 * @returns {boolean}
 */
function authorizeInstrument(order, paymentInstrument) {
    var transaction = paymentInstrument.getPaymentTransaction();
    if (!transaction) {
        return false;
    }
    var amount = transaction.getAmount();
    if (!amount || (typeof amount.getValue === 'function' && amount.getValue() === 0)) {
        if (order && typeof order.getTotalGrossPrice === 'function') {
            amount = order.getTotalGrossPrice();
            if (amount) {
                transaction.setAmount(amount);
            }
        }
    }
    transaction.setType(PaymentTransaction.TYPE_AUTH);
    transaction.setStatus(PaymentTransaction.STATUS_AUTHORIZED);
    if (typeof transaction.setTransactionID === 'function') {
        var seed = (order && order.orderNo ? order.orderNo : 'mock') + '-' + Date.now().toString(36);
        transaction.setTransactionID(('MOCKAUTH-' + seed).slice(0, 40));
    }
    return true;
}

/**
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument
 * @param {number} status
 */
function setTransactionStatus(paymentInstrument, status) {
    var transaction = paymentInstrument && paymentInstrument.getPaymentTransaction();
    if (!transaction) {
        return;
    }
    transaction.setStatus(status);
}

module.exports = {
    CLAIMED_METHOD: CLAIMED_METHOD,
    getEmailLocalPart: getEmailLocalPart,
    getShopperEmail: getShopperEmail,
    getPaymentScenario: getPaymentScenario,
    isPreAuthChallenge: isPreAuthChallenge,
    authorizeInstrument: authorizeInstrument,
    setTransactionStatus: setTransactionStatus
};
