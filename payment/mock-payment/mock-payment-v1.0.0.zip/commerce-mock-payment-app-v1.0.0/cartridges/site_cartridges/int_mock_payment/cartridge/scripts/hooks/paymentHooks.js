'use strict';

/**
 * Payment Commerce App hooks for BANK_TRANSFER.
 */

var Status = require('dw/system/Status');
var Logger = require('dw/system/Logger');
var PaymentTransaction = require('dw/order/PaymentTransaction');
var helper = require('*/cartridge/scripts/helpers/mockPaymentHelper');

var logger = Logger.getLogger('mock-payment', 'hooks');

function ok() {
    return new Status(Status.OK);
}

function error(code, message) {
    return new Status(Status.ERROR, code || 'PAYMENT_ERROR', message || 'Mock payment error');
}

function authorizeOrSkip(order, paymentInstrument, allowChallengeSkip) {
    var scenario = helper.getPaymentScenario(helper.getShopperEmail(order));
    if (scenario.fail) {
        logger.info('Mock payment fail for order {0}', order && order.orderNo);
        return error('PAYMENT_DECLINED', 'Mock payment authorization failed');
    }
    if (scenario.pending) {
        logger.info('Mock payment pending for order {0}', order && order.orderNo);
        return ok();
    }
    if (allowChallengeSkip && helper.isPreAuthChallenge(paymentInstrument)) {
        logger.info('Skipping afterCreate auth because pre-auth is CHALLENGE for order {0}', order && order.orderNo);
        return ok();
    }
    if (!helper.authorizeInstrument(order, paymentInstrument)) {
        return error('PAYMENT_ERROR', 'Missing payment transaction');
    }
    return ok();
}

exports.getClaimedPaymentMethods = function () {
    return [helper.CLAIMED_METHOD];
};

exports.afterAddBasketPaymentInstrument = function (basket, paymentInstrument, request) {
    try {
        return ok();
    } catch (e) {
        logger.error('afterAddBasketPaymentInstrument failed: {0}', e.message);
        return error('PAYMENT_ERROR', e.message);
    }
};

exports.afterUpdateBasketPaymentInstrument = function (basket, paymentInstrument, request) {
    try {
        return ok();
    } catch (e) {
        logger.error('afterUpdateBasketPaymentInstrument failed: {0}', e.message);
        return error('PAYMENT_ERROR', e.message);
    }
};

exports.afterCreateOrderPaymentInstrument = function (order, paymentInstrument) {
    try {
        return authorizeOrSkip(order, paymentInstrument, true);
    } catch (e) {
        logger.error('afterCreateOrderPaymentInstrument failed: {0}', e.message);
        return error('PAYMENT_ERROR', e.message);
    }
};

exports.afterUpdateOrderPaymentInstrument = function (order, paymentInstrument, request) {
    try {
        return authorizeOrSkip(order, paymentInstrument, false);
    } catch (e) {
        logger.error('afterUpdateOrderPaymentInstrument failed: {0}', e.message);
        return error('PAYMENT_ERROR', e.message);
    }
};

exports.reversePayment = function (order, paymentInstrument) {
    try {
        helper.setTransactionStatus(paymentInstrument, PaymentTransaction.STATUS_AUTHORIZATIONVOIDED);
        return ok();
    } catch (e) {
        logger.error('reversePayment failed: {0}', e.message);
        return error('PAYMENT_ERROR', e.message);
    }
};

exports.authorizePayment = function (order, paymentInstrument) {
    try {
        return authorizeOrSkip(order, paymentInstrument, false);
    } catch (e) {
        logger.error('authorizePayment failed: {0}', e.message);
        return error('PAYMENT_ERROR', e.message);
    }
};

exports.cancelAuthorization = function (order, paymentInstrument) {
    try {
        helper.setTransactionStatus(paymentInstrument, PaymentTransaction.STATUS_AUTHORIZATIONVOIDED);
        return ok();
    } catch (e) {
        logger.error('cancelAuthorization failed: {0}', e.message);
        return error('PAYMENT_ERROR', e.message);
    }
};

exports.capturePayment = function (order, paymentInstrument) {
    try {
        helper.setTransactionStatus(paymentInstrument, PaymentTransaction.STATUS_CAPTURED);
        return ok();
    } catch (e) {
        logger.error('capturePayment failed: {0}', e.message);
        return error('PAYMENT_ERROR', e.message);
    }
};

exports.refundCapture = function (order, paymentInstrument) {
    try {
        helper.setTransactionStatus(paymentInstrument, PaymentTransaction.STATUS_CAPTUREVOIDED);
        return ok();
    } catch (e) {
        logger.error('refundCapture failed: {0}', e.message);
        return error('PAYMENT_ERROR', e.message);
    }
};
