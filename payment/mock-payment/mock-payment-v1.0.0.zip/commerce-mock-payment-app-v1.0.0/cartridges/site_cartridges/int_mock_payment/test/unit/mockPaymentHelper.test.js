'use strict';

var assert = require('chai').assert;
var proxyquire = require('proxyquire').noCallThru();

var PaymentTransactionStub = {
    TYPE_AUTH: 'AUTH',
    STATUS_AUTHORIZED: 1,
    PRE_AUTH_FRAUD_DECISION_CHALLENGE: 'CHALLENGE'
};

describe('mockPaymentHelper', function () {
    var helper;

    beforeEach(function () {
        helper = proxyquire('../../cartridge/scripts/helpers/mockPaymentHelper', {
            'dw/system/Logger': {
                getLogger: function () {
                    return {
                        warn: function () {},
                        error: function () {},
                        info: function () {}
                    };
                }
            },
            'dw/order/PaymentTransaction': PaymentTransactionStub
        });
    });

    describe('getPaymentScenario', function () {
        it('fails pay-fail emails', function () {
            var scenario = helper.getPaymentScenario('pay-fail@example.com');
            assert.isTrue(scenario.fail);
            assert.isFalse(scenario.pending);
        });

        it('holds pay-pending emails', function () {
            var scenario = helper.getPaymentScenario('PAY-PENDING@example.com');
            assert.isTrue(scenario.pending);
        });

        it('authorizes other emails', function () {
            var scenario = helper.getPaymentScenario('shopper@example.com');
            assert.isFalse(scenario.fail);
            assert.isFalse(scenario.pending);
        });
    });

    describe('isPreAuthChallenge', function () {
        it('reads CHALLENGE from the payment transaction', function () {
            var result = helper.isPreAuthChallenge({
                getPaymentTransaction: function () {
                    return {
                        getPreAuthFraudDecision: function () {
                            return PaymentTransactionStub.PRE_AUTH_FRAUD_DECISION_CHALLENGE;
                        }
                    };
                }
            });
            assert.isTrue(result);
        });

        it('is false when decision is APPROVED', function () {
            var result = helper.isPreAuthChallenge({
                getPaymentTransaction: function () {
                    return {
                        getPreAuthFraudDecision: function () {
                            return 'APPROVED';
                        }
                    };
                }
            });
            assert.isFalse(result);
        });
    });

    describe('authorizeInstrument', function () {
        it('sets AUTHORIZED on the existing instrument amount', function () {
            var status = null;
            var type = null;
            var authorized = helper.authorizeInstrument({ orderNo: '0001' }, {
                getPaymentTransaction: function () {
                    return {
                        getAmount: function () {
                            return { getValue: function () { return 12.5; } };
                        },
                        setType: function (value) { type = value; },
                        setStatus: function (value) { status = value; },
                        setTransactionID: function () {},
                        setAmount: function () {}
                    };
                }
            });
            assert.isTrue(authorized);
            assert.strictEqual(status, PaymentTransactionStub.STATUS_AUTHORIZED);
            assert.strictEqual(type, PaymentTransactionStub.TYPE_AUTH);
        });
    });
});
