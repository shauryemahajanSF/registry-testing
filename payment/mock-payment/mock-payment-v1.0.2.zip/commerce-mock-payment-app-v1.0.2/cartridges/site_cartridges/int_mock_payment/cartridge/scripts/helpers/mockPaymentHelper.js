'use strict';

/**
 * Shared helpers for the Mock Payment Commerce App.
 * Scenarios are keyed by BANK_TRANSFER last-4. CHALLENGE skips afterCreate.
 */

var Logger = require('dw/system/Logger');
var PaymentTransaction = require('dw/order/PaymentTransaction');

var logger = Logger.getLogger('mock-payment', 'helper');

var CLAIMED_METHOD = 'BANK_TRANSFER';
var DEFAULT_LAST4 = '0000';

var PAY = {
    AUTH: 'auth',
    FAIL: 'fail',
    PENDING: 'pending'
};

/**
 * Last-4 → payment outcome. Keep in sync with Mock Fraud.
 * 0000 happy, 0001 fraud-decline (auth unused), 0002 3DS then auth,
 * 0003 post-auth reject (auth), 0004 pay-fail, 0005 pay-pending,
 * 0006 3DS then fail, 0008 pending-then-place, 0009 pending-then-fail.
 */
var LAST4_SCENARIOS = {
    '0000': { pay: PAY.AUTH },
    '0001': { pay: PAY.AUTH },
    '0002': { pay: PAY.AUTH },
    '0003': { pay: PAY.AUTH },
    '0004': { pay: PAY.FAIL },
    '0005': { pay: PAY.PENDING },
    '0006': { pay: PAY.FAIL },
    '0008': { pay: PAY.AUTH },
    '0009': { pay: PAY.AUTH }
};

/**
 * @param {string|null|undefined} value
 * @returns {string}
 */
function normalizeLast4(value) {
    if (!value) {
        return DEFAULT_LAST4;
    }
    var digits = String(value).replace(/\D/g, '');
    if (!digits) {
        return DEFAULT_LAST4;
    }
    if (digits.length >= 4) {
        return digits.slice(-4);
    }
    return ('0000' + digits).slice(-4);
}

/**
 * @param {dw.order.PaymentInstrument|null|undefined} paymentInstrument
 * @returns {string}
 */
function getInstrumentLast4(paymentInstrument) {
    if (!paymentInstrument) {
        return DEFAULT_LAST4;
    }
    try {
        if (typeof paymentInstrument.getBankAccountNumberLastDigits === 'function') {
            return normalizeLast4(paymentInstrument.getBankAccountNumberLastDigits());
        }
    } catch (e) {
        logger.warn('last-4 lookup failed: {0}', e.message);
    }
    return DEFAULT_LAST4;
}

/**
 * @param {dw.order.PaymentInstrument|null|undefined} paymentInstrument
 * @returns {{pay: string, last4: string}}
 */
function getPaymentScenario(paymentInstrument) {
    var last4 = getInstrumentLast4(paymentInstrument);
    var mapped = LAST4_SCENARIOS[last4] || LAST4_SCENARIOS[DEFAULT_LAST4];
    return {
        pay: mapped.pay,
        last4: last4
    };
}

/**
 * @param {dw.order.PaymentInstrument} paymentInstrument
 * @returns {boolean}
 */
function isPreAuthChallenge(paymentInstrument) {
    if (!paymentInstrument) {
        return false;
    }
    try {
        var transaction = paymentInstrument.getPaymentTransaction();
        if (transaction && typeof transaction.getPreAuthFraudDecision === 'function') {
            var decision = transaction.getPreAuthFraudDecision();
            if (decision === PaymentTransaction.PRE_AUTH_FRAUD_DECISION_CHALLENGE
                || decision === 'CHALLENGE') {
                return true;
            }
        }
    } catch (e) {
        logger.warn('pre-auth lookup failed: {0}', e.message);
    }
    try {
        if (typeof paymentInstrument.getPaymentDetails === 'function') {
            var details = paymentInstrument.getPaymentDetails();
            if (details && typeof details.getPreAuthorizationFraudResult === 'function') {
                var result = details.getPreAuthorizationFraudResult();
                if (result === 'CHALLENGE') {
                    return true;
                }
            }
        }
    } catch (e) {
        logger.warn('payment details lookup failed: {0}', e.message);
    }
    return false;
}

/**
 * Authorizes this payment instrument's amount (mixed-tender safe).
 * @param {dw.order.Order} order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument
 * @returns {boolean}
 */
function authorizeInstrument(order, paymentInstrument) {
    var transaction = paymentInstrument.getPaymentTransaction();
    if (!transaction) {
        return false;
    }
    var amount = transaction.getAmount();
    if (!amount || (typeof amount.getValue === 'function' && amount.getValue() === 0)) {
        if (order && typeof order.getTotalGrossPrice === 'function') {
            amount = order.getTotalGrossPrice();
            if (amount) {
                transaction.setAmount(amount);
            }
        }
    }
    transaction.setType(PaymentTransaction.TYPE_AUTH);
    transaction.setStatus(PaymentTransaction.STATUS_AUTHORIZED);
    if (typeof transaction.setTransactionID === 'function') {
        var seed = (order && order.orderNo ? order.orderNo : 'mock') + '-' + Date.now().toString(36);
        transaction.setTransactionID(('MOCKAUTH-' + seed).slice(0, 40));
    }
    return true;
}

/**
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument
 * @param {number} status
 */
function setTransactionStatus(paymentInstrument, status) {
    var transaction = paymentInstrument && paymentInstrument.getPaymentTransaction();
    if (!transaction) {
        return;
    }
    transaction.setStatus(status);
}

module.exports = {
    CLAIMED_METHOD: CLAIMED_METHOD,
    DEFAULT_LAST4: DEFAULT_LAST4,
    PAY: PAY,
    LAST4_SCENARIOS: LAST4_SCENARIOS,
    normalizeLast4: normalizeLast4,
    getInstrumentLast4: getInstrumentLast4,
    getPaymentScenario: getPaymentScenario,
    isPreAuthChallenge: isPreAuthChallenge,
    authorizeInstrument: authorizeInstrument,
    setTransactionStatus: setTransactionStatus
};
