'use strict';

/**
 * Unused Service Framework wrapper. Mock hooks do not call a processor.
 */

var LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');
var Logger = require('dw/system/Logger');

var logger = Logger.getLogger('mock-payment', 'service');
var SERVICE_ID = 'mock.payment.api';

function getService() {
    return LocalServiceRegistry.createService(SERVICE_ID, {
        createRequest: function (svc) {
            svc.setRequestMethod('POST');
            svc.addHeader('Content-Type', 'application/json');
            svc.addHeader('Accept', 'application/json');
            return '';
        },
        parseResponse: function (svc, client) {
            return client && client.text ? client.text : '';
        },
        filterLogMessage: function (message) {
            return message;
        }
    });
}

/**
 * @returns {dw.svc.HTTPService}
 */
function getConfiguredService() {
    try {
        return getService();
    } catch (e) {
        logger.warn('mock.payment.api is not configured: {0}', e.message);
        return null;
    }
}

module.exports = {
    getConfiguredService: getConfiguredService
};
