'use strict';

var assert = require('chai').assert;
var proxyquire = require('proxyquire').noCallThru();

var PaymentTransactionStub = {
    TYPE_AUTH: 'AUTH',
    STATUS_AUTHORIZED: 1,
    PRE_AUTH_FRAUD_DECISION_CHALLENGE: 'CHALLENGE'
};

function instrument(last4) {
    return {
        getBankAccountNumberLastDigits: function () {
            return last4;
        }
    };
}

describe('mockPaymentHelper', function () {
    var helper;

    beforeEach(function () {
        helper = proxyquire('../../cartridge/scripts/helpers/mockPaymentHelper', {
            'dw/system/Logger': {
                getLogger: function () {
                    return {
                        warn: function () {},
                        error: function () {},
                        info: function () {}
                    };
                }
            },
            'dw/order/PaymentTransaction': PaymentTransactionStub
        });
    });

    describe('normalizeLast4', function () {
        it('defaults missing values to 0000', function () {
            assert.strictEqual(helper.normalizeLast4(null), '0000');
            assert.strictEqual(helper.normalizeLast4(''), '0000');
            assert.strictEqual(helper.normalizeLast4('abcd'), '0000');
        });

        it('pads short digit strings and keeps the last four', function () {
            assert.strictEqual(helper.normalizeLast4('2'), '0002');
            assert.strictEqual(helper.normalizeLast4('12345'), '2345');
        });
    });

    describe('getPaymentScenario', function () {
        it('authorizes the default last-4', function () {
            var scenario = helper.getPaymentScenario(instrument(null));
            assert.strictEqual(scenario.pay, helper.PAY.AUTH);
            assert.strictEqual(scenario.last4, '0000');
        });

        it('fails 0004 and 0006', function () {
            assert.strictEqual(helper.getPaymentScenario(instrument('0004')).pay, helper.PAY.FAIL);
            assert.strictEqual(helper.getPaymentScenario(instrument('0006')).pay, helper.PAY.FAIL);
        });

        it('holds 0005 as payment pending', function () {
            var scenario = helper.getPaymentScenario(instrument('0005'));
            assert.strictEqual(scenario.pay, helper.PAY.PENDING);
        });

        it('authorizes challenge codes so afterUpdate can succeed or fail later', function () {
            assert.strictEqual(helper.getPaymentScenario(instrument('0002')).pay, helper.PAY.AUTH);
        });
    });

    describe('isPreAuthChallenge', function () {
        it('reads CHALLENGE from the payment transaction', function () {
            var result = helper.isPreAuthChallenge({
                getPaymentTransaction: function () {
                    return {
                        getPreAuthFraudDecision: function () {
                            return PaymentTransactionStub.PRE_AUTH_FRAUD_DECISION_CHALLENGE;
                        }
                    };
                }
            });
            assert.isTrue(result);
        });

        it('is false when decision is APPROVED', function () {
            var result = helper.isPreAuthChallenge({
                getPaymentTransaction: function () {
                    return {
                        getPreAuthFraudDecision: function () {
                            return 'APPROVED';
                        }
                    };
                }
            });
            assert.isFalse(result);
        });
    });

    describe('authorizeInstrument', function () {
        it('sets AUTHORIZED on the existing instrument amount', function () {
            var status = null;
            var type = null;
            var authorized = helper.authorizeInstrument({ orderNo: '0001' }, {
                getPaymentTransaction: function () {
                    return {
                        getAmount: function () {
                            return { getValue: function () { return 12.5; } };
                        },
                        setType: function (value) { type = value; },
                        setStatus: function (value) { status = value; },
                        setTransactionID: function () {},
                        setAmount: function () {}
                    };
                }
            });
            assert.isTrue(authorized);
            assert.strictEqual(status, PaymentTransactionStub.STATUS_AUTHORIZED);
            assert.strictEqual(type, PaymentTransactionStub.TYPE_AUTH);
        });
    });
});
