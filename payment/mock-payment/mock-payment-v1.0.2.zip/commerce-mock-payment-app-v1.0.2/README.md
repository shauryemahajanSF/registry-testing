# Mock Payment

Sample payment Commerce App for Salesforce B2C Commerce 26.10. It claims `BANK_TRANSFER`, authorizes the instrument amount on `onAttemptOrderTransition` (place-order) or SCAPI-direct order PI create (or after a fake 3DS Authenticate PATCH when pre-auth fraud is `CHALLENGE`), and ships a Storefront Next payment-method chip plus `onPlaceOrder` flow.

Scenarios are keyed by the **BANK_TRANSFER last-4** persisted as `paymentBankAccount.number`. Use with **Mock Fraud** (same last-4 map) to exercise payment/fraud orchestration.

## What it does

### Backend (Script API hooks)

| Hook | Purpose |
|------|---------|
| `sfcc.app.payment.getClaimedPaymentMethods` | Claims `BANK_TRANSFER` |
| `sfcc.app.payment.afterCreateBasketPaymentInstrument` | Accepts the basket PI |
| `sfcc.app.payment.afterUpdateBasketPaymentInstrument` | Accepts basket PI updates |
| `sfcc.app.payment.afterCreateOrderPaymentInstrument` | Authorizes when a PI is POSTed onto an existing order (SCAPI-direct); skips CHALLENGE / `0004` / `0005` |
| `sfcc.app.payment.onAttemptOrderTransition` | Authorizes during `OrderMgr.attemptOrderTransition` (place-order path); same skip rules as afterCreate |
| `sfcc.app.payment.afterUpdateOrderPaymentInstrument` | Authorizes only when pre-auth is still `CHALLENGE` (3DS Authenticate). A kick PATCH after `createOrder` is a no-op so `onAttemptOrderTransition` can authorize. `0006` fails here |
| `sfcc.app.payment.reversePayment` | Voids authorization on fail-order |
| `sfcc.app.payment.authorizePayment` | Shared authorize helper |
| `sfcc.app.payment.cancelAuthorization` | Voids authorization |
| `sfcc.app.payment.capturePayment` | Marks captured |
| `sfcc.app.payment.refundCapture` | Marks refunded |
| `sfcc.app.payment.checkConnectionHealth` | Checkout Hub connection badge |

Gift-card capture/refund stays with the gift-card app (Givex). Mixed tender: this app authorizes **this** BANK_TRANSFER instrument amount only.

### Storefront Next UI

| Target | Component |
|--------|-----------|
| `sfcc.checkout.payment.paymentMethods.before` | BANK_TRANSFER chip, last-4 scenario field, apply/remove, fake 3DS Approve/Decline modal via `onPlaceOrder` |

Apply POSTs `{ paymentMethodId, amount, paymentBankAccount: { number: last4 } }`. Missing last-4 defaults to `0000`.

Place-order uses **Shopper Orders**, not OCAPI Shop:

1. `POST /orders` with `{ basketId }`. Shopper Orders `createOrder` runs fraud `beforePayment` only; it does **not** call `attemptOrderTransition` for claimed methods, so the order stays `CREATED`.
2. If pre-auth is not `CHALLENGE`, PATCH the claimed PI `{ amount }` so SCAPI `afterPATCH` runs `onAttemptOrderTransition` + `afterPayment` + place. Do **not** send `skip_authorization` — that query is OCAPI-only and Shopper Orders returns 400.
3. If pre-auth is `CHALLENGE`, open the Authenticate modal. Approve PATCHes the same PI `{ amount }` so `afterUpdate` authorizes. Decline uses `POST .../orders/{orderNo}/actions/fail?reopenBasket=true` (HTTP 201, `Location: /baskets/{id}`). There is no Shopper Orders `PATCH /orders/{orderNo}`; an OCAPI `{ status: failed }` body 404s and leaves the shopper with no cart.

`0001` (Mock Fraud pre-auth `DECLINED`) currently returns HTTP 500 from Shopper Orders `createOrder` until the platform maps `FraudAppException`. The basket is kept; do not move that decline into this payment app.

## Last-4 scenario matrix

Keep this table in sync with Mock Fraud. Shopper email is not a driver.

| Last-4 | Pre-auth (Mock Fraud) | Payment | Post-auth (Mock Fraud) |
|--------|------------------------|---------|-------------------------|
| `0000` (default) | APPROVED | authorize | GUARANTEED |
| `0001` | DECLINED | — | — (createOrder 500 until platform maps FraudAppException) |
| `0002` | CHALLENGE | skip create/transition; `afterUpdate` authorizes | GUARANTEED |
| `0003` | APPROVED | authorize | NOT_GUARANTEED (kick PATCH fails+reopens; stay on checkout) |
| `0004` | APPROVED | fail `onAttempt` | — (kick PATCH 200 with FAILED; stay on checkout, basket reopened) |
| `0005` | APPROVED | leave CREATED | `afterPayment` never runs |
| `0006` | CHALLENGE | skip create/transition; `afterUpdate` fails | — |
| `0008` | APPROVED | authorize | PENDING → run Mock Fraud job to place |
| `0009` | APPROVED | authorize | PENDING → run Mock Fraud job to fail |

`CHALLENGE` **skips** authorization on `afterCreateOrderPaymentInstrument` and `onAttemptOrderTransition` even when the payment outcome is fail (`0006`). The storefront modal's Authenticate button PATCHes the order PI so `afterUpdate` runs. Decline fails the CREATED order and reopens the basket.

## Architecture

- Cartridge: `int_mock_payment`
- Service: `mock.payment.api` (template only; unused by the mock hooks)
- Domain: `payment`
- Storefront extension: `storefront-next/src/extensions/mock-payment/`

Enable platform orchestration with the `PaymentFraudOrchestrationEnabled` **feature toggle** when testing with Mock Fraud.

## Installation

1. Install the app from Commerce Apps / Checkout Hub.
2. Ensure `BANK_TRANSFER` is an enabled payment method on the site.
3. Optionally install Mock Fraud and enable `PaymentFraudOrchestrationEnabled`.
4. On Storefront Next checkout, enter a last-4 from the matrix, apply Mock Bank Transfer, and place the order.

## Future provider integration

The installed `mock.payment.api` service is unused. A real processor should replace mock authorize/capture/refund with Service Framework calls and a PSP 3DS SDK instead of the fake Authenticate modal.

## Development

```bash
cd cartridges/site_cartridges/int_mock_payment
npm install
npm test
```

Storefront extension unit tests live under `storefront-next/src/extensions/mock-payment/tests/`.
