/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_MOCK_PAYMENT */

export const BANK_TRANSFER_PAYMENT_METHOD_ID = 'BANK_TRANSFER';

export const APPLY_BANK_TRANSFER_ACTION = '/action/mock-payment-apply';

export const REMOVE_BANK_TRANSFER_ACTION = '/action/mock-payment-remove';

export const PLACE_ORDER_ACTION = '/action/mock-payment-place-order';

export const COMPLETE_CHALLENGE_ACTION = '/action/mock-payment-complete';

export const FAIL_ORDER_ACTION = '/action/mock-payment-fail';

export const PAYMENT_BASKET_TAG = 'cart.paymentInstruments';
