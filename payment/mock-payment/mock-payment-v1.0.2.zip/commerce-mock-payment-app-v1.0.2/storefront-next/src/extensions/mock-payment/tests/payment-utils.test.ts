/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { describe, expect, it } from 'vitest';
import { BANK_TRANSFER_PAYMENT_METHOD_ID } from '../lib/constants';
import {
    getAppliedLast4,
    getBankTransferInstrument,
    getBankTransferInstrumentId,
    getBankTransferInstruments,
    getRemainingAmount,
    isBankTransferInstrument,
    normalizeLast4,
    orderNeedsChallenge,
} from '../lib/payment-utils';

describe('payment-utils', () => {
    it('identifies BANK_TRANSFER instruments', () => {
        expect(isBankTransferInstrument({ paymentMethodId: BANK_TRANSFER_PAYMENT_METHOD_ID })).toBe(true);
        expect(isBankTransferInstrument({ paymentMethodId: 'CREDIT_CARD' })).toBe(false);
    });

    it('computes remaining amount after applied tenders', () => {
        const remaining = getRemainingAmount({
            orderTotal: 100,
            paymentInstruments: [
                { paymentMethodId: 'COMMERCE_APP_GIFT_CARD', amount: 20 },
                { paymentMethodId: BANK_TRANSFER_PAYMENT_METHOD_ID, amount: 30 },
            ],
        });
        expect(remaining).toBe(50);
    });

    it('detects CHALLENGE on the created order', () => {
        expect(
            orderNeedsChallenge({
                paymentInstruments: [
                    {
                        paymentMethodId: BANK_TRANSFER_PAYMENT_METHOD_ID,
                        paymentInstrumentId: 'pi-1',
                        fraudDecisions: { preAuthorization: 'CHALLENGE' },
                    },
                ],
            })
        ).toBe(true);
        expect(getBankTransferInstrumentId({
            paymentInstruments: [{ paymentMethodId: BANK_TRANSFER_PAYMENT_METHOD_ID, paymentInstrumentId: 'pi-9' }],
        })).toBe('pi-9');
        expect(
            getBankTransferInstrument({
                paymentInstruments: [
                    {
                        paymentMethodId: BANK_TRANSFER_PAYMENT_METHOD_ID,
                        paymentInstrumentId: 'pi-9',
                        amount: 135.89,
                    },
                ],
            })?.amount
        ).toBe(135.89);
        expect(getBankTransferInstruments({
            paymentInstruments: [{ paymentMethodId: BANK_TRANSFER_PAYMENT_METHOD_ID }],
        })).toHaveLength(1);
    });

    it('normalizes last-4 and reads it from the applied instrument', () => {
        expect(normalizeLast4(undefined)).toBe('0000');
        expect(normalizeLast4('2')).toBe('0002');
        expect(getAppliedLast4({
            paymentMethodId: BANK_TRANSFER_PAYMENT_METHOD_ID,
            paymentBankAccount: { number: '0008' },
        } as never)).toBe('0008');
    });
});
