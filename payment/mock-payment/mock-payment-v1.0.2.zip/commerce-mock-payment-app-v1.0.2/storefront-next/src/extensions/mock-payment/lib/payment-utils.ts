/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_MOCK_PAYMENT */

import type { ShopperBasketsV2 } from '@/scapi';
import { BANK_TRANSFER_PAYMENT_METHOD_ID } from './constants';

export type BasketPaymentInstrument = ShopperBasketsV2.schemas['OrderPaymentInstrument'];

type FraudDecisions = {
    preAuthorization?: string;
    postAuthorization?: string;
};

type OrderPaymentInstrument = BasketPaymentInstrument & {
    fraudDecisions?: FraudDecisions;
};

type OrderLike = {
    orderNo?: string;
    status?: string;
    paymentInstruments?: OrderPaymentInstrument[];
};

export function isBankTransferInstrument(instrument: BasketPaymentInstrument | undefined): boolean {
    return instrument?.paymentMethodId === BANK_TRANSFER_PAYMENT_METHOD_ID;
}

export function getBankTransferInstruments(
    basket: ShopperBasketsV2.schemas['Basket'] | undefined
): BasketPaymentInstrument[] {
    return (basket?.paymentInstruments ?? []).filter(isBankTransferInstrument);
}

function roundMoney(value: number): number {
    return Math.round(value * 100) / 100;
}

/** Remaining order total not covered by existing payment instruments. */
export function getRemainingAmount(basket: ShopperBasketsV2.schemas['Basket'] | undefined): number {
    const total = Number(basket?.orderTotal ?? 0);
    const applied = (basket?.paymentInstruments ?? []).reduce(
        (sum, instrument) => sum + Number(instrument.amount ?? 0),
        0
    );
    return Math.max(0, roundMoney(total - applied));
}

export function orderNeedsChallenge(order: OrderLike | undefined): boolean {
    return (order?.paymentInstruments ?? []).some(
        (instrument) =>
            isBankTransferInstrument(instrument) && instrument.fraudDecisions?.preAuthorization === 'CHALLENGE'
    );
}

export function getBankTransferInstrument(
    order: OrderLike | undefined
): OrderPaymentInstrument | undefined {
    return (order?.paymentInstruments ?? []).find(isBankTransferInstrument);
}

export function getBankTransferInstrumentId(order: OrderLike | undefined): string | undefined {
    return getBankTransferInstrument(order)?.paymentInstrumentId;
}

type PaymentBankAccount = {
    number?: string;
    numberLastDigits?: string;
};

/** Normalize a bank-account last-4; missing or non-digit input is happy-path 0000. */
export function normalizeLast4(value: string | undefined | null): string {
    const digits = String(value ?? '').replace(/\D/g, '');
    if (!digits) {
        return '0000';
    }
    return digits.slice(-4).padStart(4, '0');
}

export function getAppliedLast4(instrument: BasketPaymentInstrument | undefined): string {
    const bank = (instrument as { paymentBankAccount?: PaymentBankAccount } | undefined)?.paymentBankAccount;
    return normalizeLast4(bank?.numberLastDigits || bank?.number);
}
