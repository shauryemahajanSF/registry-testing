/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_MOCK_PAYMENT */

'use client';

import { useCallback, useEffect, useRef, useState, type ReactElement } from 'react';
import { useFetcher } from 'react-router';
import { useTranslation } from 'react-i18next';
import { Building2 as BankIcon, X as CloseIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/toast';
import { usePaymentSubmissionRef } from '@/components/checkout/payment-submission-context';
import { FETCHER_STATES } from '@/lib/fetcher-states';
import { formatCurrency } from '@/lib/currency';
import { useBasket, useBasketUpdater } from '@/providers/basket';
import {
    APPLY_BANK_TRANSFER_ACTION,
    COMPLETE_CHALLENGE_ACTION,
    FAIL_ORDER_ACTION,
    PLACE_ORDER_ACTION,
    REMOVE_BANK_TRANSFER_ACTION,
} from '../../lib/constants';
import { getBankTransferInstruments, getRemainingAmount } from '../../lib/payment-utils';
import type { ApplyBankTransferActionResult } from '../../routes/action.mock-payment-apply';
import type { RemoveBankTransferActionResult } from '../../routes/action.mock-payment-remove';
import type { PlaceOrderActionResult } from '../../routes/action.mock-payment-place-order';
import type { CompleteChallengeActionResult } from '../../routes/action.mock-payment-complete';
import type { FailOrderActionResult } from '../../routes/action.mock-payment-fail';

type ChallengeState = {
    orderNo: string;
    paymentInstrumentId: string;
};

async function postAction<T>(action: string, fields: Record<string, string>): Promise<T> {
    const body = new FormData();
    Object.entries(fields).forEach(([key, value]) => {
        body.append(key, value);
    });
    const response = await fetch(action, {
        method: 'POST',
        body,
        credentials: 'same-origin',
    });
    const payload = (await response.json()) as T;
    if (!response.ok) {
        const message =
            payload && typeof payload === 'object' && 'error' in payload
                ? String((payload as { error?: string }).error || response.statusText)
                : response.statusText;
        throw new Error(message);
    }
    return payload;
}

/**
 * BANK_TRANSFER chip for `sfcc.checkout.payment.paymentMethods.before`.
 * Registers `onPlaceOrder` so createOrder + fake 3DS run on Place Order.
 */
export default function BankTransferMethod(): ReactElement {
    const { t, i18n } = useTranslation('extMockPayment');
    const basket = useBasket();
    const updateBasket = useBasketUpdater();
    const { addToast } = useToast();
    const paymentSubmissionRef = usePaymentSubmissionRef();
    const applyFetcher = useFetcher<ApplyBankTransferActionResult>();
    const removeFetcher = useFetcher<RemoveBankTransferActionResult>();
    const [challenge, setChallenge] = useState<ChallengeState | null>(null);
    const challengeResolver = useRef<((orderNo: string | null) => void) | null>(null);

    const instruments = getBankTransferInstruments(basket);
    const applied = instruments[0];
    const remaining = getRemainingAmount(basket);
    const isApplying = applyFetcher.state === FETCHER_STATES.SUBMITTING;
    const isRemoving = removeFetcher.state === FETCHER_STATES.SUBMITTING;

    useEffect(() => {
        if (!applyFetcher.data || applyFetcher.state !== FETCHER_STATES.IDLE) {
            return;
        }
        if (applyFetcher.data.success) {
            if (applyFetcher.data.basket) {
                updateBasket(applyFetcher.data.basket);
            }
            addToast(t('mockPayment.success'), 'success');
            return;
        }
        addToast(applyFetcher.data.error || t('mockPayment.errorApply'), 'error');
    }, [applyFetcher.data, applyFetcher.state, addToast, t, updateBasket]);

    useEffect(() => {
        if (!removeFetcher.data || removeFetcher.state !== FETCHER_STATES.IDLE) {
            return;
        }
        if (removeFetcher.data.success) {
            if (removeFetcher.data.basket) {
                updateBasket(removeFetcher.data.basket);
            }
            addToast(t('mockPayment.removed'), 'success');
            return;
        }
        addToast(removeFetcher.data.error || t('mockPayment.errorRemove'), 'error');
    }, [removeFetcher.data, removeFetcher.state, addToast, t, updateBasket]);

    const apply = () => {
        if (!basket?.basketId) {
            addToast(t('mockPayment.errorNoBasket'), 'error');
            return;
        }
        if (remaining <= 0) {
            addToast(t('mockPayment.errorCovered'), 'error');
            return;
        }
        if (isApplying) {
            return;
        }
        void applyFetcher.submit({ basketId: basket.basketId }, { method: 'POST', action: APPLY_BANK_TRANSFER_ACTION });
    };

    const remove = () => {
        if (!basket?.basketId || !applied?.paymentInstrumentId || isRemoving) {
            return;
        }
        void removeFetcher.submit(
            { basketId: basket.basketId, paymentInstrumentId: applied.paymentInstrumentId },
            { method: 'POST', action: REMOVE_BANK_TRANSFER_ACTION }
        );
    };

    const finishChallenge = useCallback((orderNo: string | null) => {
        const resolve = challengeResolver.current;
        challengeResolver.current = null;
        setChallenge(null);
        resolve?.(orderNo);
    }, []);

    const onPlaceOrder = useCallback(async (): Promise<string | null> => {
        if (!basket?.basketId) {
            addToast(t('mockPayment.errorNoBasket'), 'error');
            return null;
        }
        try {
            const result = await postAction<PlaceOrderActionResult>(PLACE_ORDER_ACTION, {
                basketId: basket.basketId,
            });
            if (!result.success || !result.orderNo) {
                addToast(result.error || t('mockPayment.errorPlace'), 'error');
                return null;
            }
            if (result.needsChallenge && result.paymentInstrumentId) {
                return await new Promise<string | null>((resolve) => {
                    challengeResolver.current = resolve;
                    setChallenge({
                        orderNo: result.orderNo as string,
                        paymentInstrumentId: result.paymentInstrumentId as string,
                    });
                });
            }
            if (result.pending) {
                addToast(t('mockPayment.pendingHold'), 'info');
                return null;
            }
            return result.orderNo;
        } catch (error) {
            addToast(error instanceof Error ? error.message : t('mockPayment.errorPlace'), 'error');
            return null;
        }
    }, [addToast, basket?.basketId, t]);

    useEffect(() => {
        if (!applied) {
            return undefined;
        }
        paymentSubmissionRef.current.onPlaceOrder = onPlaceOrder;
        return () => {
            if (paymentSubmissionRef.current.onPlaceOrder === onPlaceOrder) {
                paymentSubmissionRef.current.onPlaceOrder = null;
            }
        };
    }, [applied, onPlaceOrder, paymentSubmissionRef]);

    const approveChallenge = async () => {
        if (!challenge) {
            return;
        }
        try {
            const result = await postAction<CompleteChallengeActionResult>(COMPLETE_CHALLENGE_ACTION, {
                orderNo: challenge.orderNo,
                paymentInstrumentId: challenge.paymentInstrumentId,
            });
            if (!result.success) {
                addToast(result.error || t('mockPayment.errorPlace'), 'error');
                finishChallenge(null);
                return;
            }
            finishChallenge(result.orderNo || challenge.orderNo);
        } catch (error) {
            addToast(error instanceof Error ? error.message : t('mockPayment.errorPlace'), 'error');
            finishChallenge(null);
        }
    };

    const declineChallenge = async () => {
        if (!challenge) {
            return;
        }
        try {
            await postAction<FailOrderActionResult>(FAIL_ORDER_ACTION, { orderNo: challenge.orderNo });
        } catch (error) {
            addToast(error instanceof Error ? error.message : t('mockPayment.errorDecline'), 'error');
        }
        addToast(t('mockPayment.errorDecline'), 'error');
        finishChallenge(null);
    };

    return (
        <div className="w-full" data-testid="mock-payment-bank-transfer">
            <div className="mb-3 rounded-md border border-input p-3">
                <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                        <BankIcon className="size-4 shrink-0" aria-hidden="true" />
                        <span className="text-sm font-medium text-card-foreground">{t('mockPayment.title')}</span>
                    </div>
                    {applied ? (
                        <div className="flex items-center gap-2">
                            <span className="text-sm">
                                {formatCurrency(applied.amount ?? remaining, i18n.language, basket?.currency ?? 'USD')}
                            </span>
                            <Button
                                type="button"
                                variant="ghost"
                                size="icon"
                                className="size-6 cursor-pointer"
                                disabled={isRemoving}
                                aria-label={t('mockPayment.remove')}
                                onClick={remove}>
                                <CloseIcon className="size-3.5" aria-hidden="true" />
                            </Button>
                        </div>
                    ) : (
                        <Button
                            type="button"
                            variant="secondary"
                            className="cursor-pointer"
                            disabled={isApplying || remaining <= 0}
                            onClick={apply}>
                            {isApplying ? t('mockPayment.applying') : t('mockPayment.apply')}
                        </Button>
                    )}
                </div>
                {applied ? (
                    <p className="mt-2 text-xs text-muted-foreground">{t('mockPayment.applied')}</p>
                ) : null}
            </div>

            {challenge ? (
                <div
                    className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4"
                    role="dialog"
                    aria-modal="true"
                    aria-labelledby="mock-payment-challenge-title"
                    data-testid="mock-payment-challenge">
                    <div className="w-full max-w-md rounded-lg bg-background p-4 shadow-lg">
                        <h2 id="mock-payment-challenge-title" className="text-base font-semibold">
                            {t('mockPayment.challengeTitle')}
                        </h2>
                        <p className="mt-2 text-sm text-muted-foreground">{t('mockPayment.challengeBody')}</p>
                        <div className="mt-4 flex justify-end gap-2">
                            <Button type="button" variant="outline" className="cursor-pointer" onClick={() => void declineChallenge()}>
                                {t('mockPayment.decline')}
                            </Button>
                            <Button type="button" className="cursor-pointer" onClick={() => void approveChallenge()}>
                                {t('mockPayment.approve')}
                            </Button>
                        </div>
                    </div>
                </div>
            ) : null}
        </div>
    );
}
