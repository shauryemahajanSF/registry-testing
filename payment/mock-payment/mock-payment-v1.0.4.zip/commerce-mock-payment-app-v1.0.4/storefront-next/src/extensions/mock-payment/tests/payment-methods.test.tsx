/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import MockPaymentMethods from '../components/payment-methods';

vi.mock('react-router', () => ({
    useFetcher: () => ({ state: 'idle', data: null, submit: vi.fn() }),
}));

vi.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (key: string) => key,
        i18n: { language: 'en-GB' },
    }),
}));

vi.mock('@/components/toast', () => ({
    useToast: () => ({ addToast: vi.fn() }),
}));

vi.mock('@/components/checkout/payment-submission-context', () => ({
    usePaymentSubmissionRef: () => ({ current: { onPlaceOrder: null } }),
}));

vi.mock('@/providers/basket', () => ({
    useBasket: () => ({
        basketId: 'basket-1',
        currency: 'USD',
        paymentInstruments: [],
        orderTotal: 10,
    }),
    useBasketUpdater: () => vi.fn(),
}));

describe('MockPaymentMethods', () => {
    it('renders mock CC and SEPA chips and hides the native credit-card form', () => {
        render(
            <MockPaymentMethods>
                <div data-testid="native-credit-card-form">Credit Card</div>
            </MockPaymentMethods>
        );

        expect(screen.getByTestId('mock-payment-methods')).toBeInTheDocument();
        expect(screen.getByTestId('mock-payment-card')).toBeInTheDocument();
        expect(screen.getByTestId('mock-payment-sepa')).toBeInTheDocument();
        expect(screen.queryByTestId('native-credit-card-form')).not.toBeInTheDocument();
    });
});
