/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

'use client';

import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { useFetcher } from 'react-router';
import { useTranslation } from 'react-i18next';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Loader2, Plus } from 'lucide-react';
import { useSite } from '@salesforce/storefront-next-runtime/site-context';
import { Form } from '@/components/ui/form';
import { AddressFormFields } from '@/components/address-form-fields';
import { useAddPaymentMethodDialog } from '@/components/payment-methods/account-payment-dialog-context';
import { useCorrelationId } from '@/providers/correlation';
import type { ShopperCustomers } from '@/scapi';
import { useSFPaymentsContext } from '../../providers/sf-payments-provider';
import { useSFPaymentsConfig, type PaymentMethodSetAccount } from '../../hooks/use-sf-payments-config';
import { getLocaleDerivedCountryCode } from '../../lib/sf-payments-country';
import { buildTheme } from '../../lib/sf-payments-theme';
import {
    getGatewayFromPaymentMethod,
    PAYMENT_GATEWAYS,
    PAYMENT_METHOD_TYPES,
    SDK_RESPONSE_CODE,
    type PaymentGateway,
} from '../../lib/sf-payments-utils';
import { reportClientDiagnostic } from '../../lib/report-client-diagnostic';
import { requiresBillingDetailsForType } from '../../lib/requires-billing-details';
import {
    ACCOUNT_SAVED_METHODS_FETCHER_KEY,
    ACCOUNT_SAVED_METHODS_RESOURCE,
} from '../../lib/account-saved-methods-fetchers';
import type {
    AccountSetupVendor,
    SetupAccountSavedMethodResult,
} from '../../routes/action.sf-payments-account-setup-saved-method';
import type { CompleteAccountSavedMethodResult } from '../../routes/action.sf-payments-account-complete-saved-method';

type CustomerAddress = ShopperCustomers.schemas['CustomerAddress'];

/** Same field names as checkout / host AddressFormFields (`fieldPrefix="billing"`). */
const billingAddressSchema = z.object({
    billingFirstName: z.string().trim().min(1),
    billingLastName: z.string().trim().min(1),
    billingAddress1: z.string().trim().min(1),
    billingAddress2: z.string().optional(),
    billingCity: z.string().trim().min(1),
    billingStateCode: z.string().trim().min(1),
    billingPostalCode: z.string().trim().min(1),
    billingCountryCode: z.string().trim().min(1),
});

type BillingAddressFormValues = z.infer<typeof billingAddressSchema>;

function emptyBillingFormValues(countryCode: string): BillingAddressFormValues {
    return {
        billingFirstName: '',
        billingLastName: '',
        billingAddress1: '',
        billingAddress2: '',
        billingCity: '',
        billingStateCode: '',
        billingPostalCode: '',
        billingCountryCode: countryCode || 'US',
    };
}

/** SDK SetupResponse — confirm may resolve success/fail or reject with the same shape. */
type SetupConfirmResult = {
    responseCode: number;
    data?: { error?: unknown; status?: string };
};

type SetupHandle = {
    confirm: (billingDetails?: unknown) => Promise<SetupConfirmResult>;
    destroy: () => void;
};

/** Drop-in / Payment Element payload passed into createSetupIntent (Adyen encrypts card first). */
type CreateSetupIntentArg = {
    paymentMethod?: Record<string, unknown>;
    [key: string]: unknown;
};

function extractAdyenPaymentMethod(paymentData?: CreateSetupIntentArg): Record<string, unknown> | undefined {
    if (!paymentData || typeof paymentData !== 'object') return undefined;
    const nested = paymentData.paymentMethod;
    if (nested && typeof nested === 'object' && !Array.isArray(nested)) {
        return nested as Record<string, unknown>;
    }
    // Some SDK paths may pass the encrypted fields at the top level.
    if (typeof paymentData.encryptedCardNumber === 'string' || typeof paymentData.type === 'string') {
        return paymentData as Record<string, unknown>;
    }
    return undefined;
}

/** Provider text for diagnostics only — never shown to the shopper. */
function extractVendorMessage(payload: unknown): string | undefined {
    const error = (payload as { error?: unknown } | null)?.error;
    if (typeof error === 'string' && error.trim()) return error;
    const msg = (error as { message?: unknown } | null)?.message;
    if (typeof msg === 'string' && msg.trim()) return msg;
    if (payload instanceof Error && payload.message.trim()) return payload.message;
    return undefined;
}

const SETUP_ACTION = '/action/sf-payments-account-setup-saved-method';
const COMPLETE_ACTION = '/action/sf-payments-account-complete-saved-method';

/** My Account Add types. Stripe: card + SEPA. Adyen: card only (commerce rejects SEPA setup). */
type AccountSetupPaymentMethodType = 'card' | 'sepa_debit';

function accountSetupTypesForVendor(vendor: AccountSetupVendor): ReadonlySet<AccountSetupPaymentMethodType> {
    return vendor === 'adyen' ? new Set(['card']) : new Set(['card', 'sepa_debit']);
}

function isAccountSetupPaymentMethodType(value: string): value is AccountSetupPaymentMethodType {
    return value === 'card' || value === 'sepa_debit';
}

function addressLabel(address: CustomerAddress): string {
    const name = [address.firstName, address.lastName].filter(Boolean).join(' ');
    const line = [address.address1, address.city].filter(Boolean).join(', ');
    return [name, line].filter(Boolean).join(' — ') || address.addressId || '';
}

function toBillingDetails(
    address: Pick<
        CustomerAddress,
        | 'firstName'
        | 'lastName'
        | 'phone'
        | 'address1'
        | 'address2'
        | 'city'
        | 'stateCode'
        | 'postalCode'
        | 'countryCode'
    >,
    email?: string
) {
    return {
        name: [address.firstName, address.lastName].filter(Boolean).join(' ') || undefined,
        // Stripe Payment Element uses fields.billing_details = 'never', so email must be supplied here.
        email: email || undefined,
        phone: address.phone || undefined,
        address: {
            line1: address.address1 || '',
            line2: address.address2 || '',
            city: address.city || '',
            state: address.stateCode || '',
            postalCode: address.postalCode || '',
            country: address.countryCode || '',
        },
    };
}

function billingFormToCustomerAddress(values: BillingAddressFormValues): CustomerAddress {
    return {
        firstName: values.billingFirstName,
        lastName: values.billingLastName,
        address1: values.billingAddress1,
        address2: values.billingAddress2 || '',
        city: values.billingCity,
        stateCode: values.billingStateCode,
        postalCode: values.billingPostalCode,
        countryCode: values.billingCountryCode,
    };
}

function toAccountSetupVendor(gateway: PaymentGateway | null): AccountSetupVendor | null {
    if (gateway === PAYMENT_GATEWAYS.STRIPE) return 'stripe';
    if (gateway === PAYMENT_GATEWAYS.ADYEN) return 'adyen';
    return null;
}

async function createSetupIntent(
    zoneId: string,
    vendor: AccountSetupVendor,
    paymentMethodType: AccountSetupPaymentMethodType,
    paymentMethod?: Record<string, unknown>
): Promise<Extract<SetupAccountSavedMethodResult, { success: true }>> {
    const form = new FormData();
    form.set('zoneId', zoneId);
    form.set('paymentMethodType', paymentMethodType);
    form.set('vendor', vendor);
    if (vendor === 'adyen') {
        if (!paymentMethod) {
            throw new Error('Adyen setup requires paymentMethod from Drop-in');
        }
        form.set('paymentMethod', JSON.stringify(paymentMethod));
    }

    const response = await fetch(SETUP_ACTION, { method: 'POST', body: form });
    const payload = (await response.json()) as SetupAccountSavedMethodResult;

    if (!response.ok || !payload || payload.success !== true) {
        const message =
            payload && 'error' in payload && typeof payload.error === 'string'
                ? payload.error
                : 'Unable to set up payment method';
        throw new Error(message);
    }

    return payload;
}

/** Marks the confirmed Stripe SetupIntent shopper-reusable (digital#35526). Not used for Adyen. */
async function completeSetupIntent(zoneId: string, paymentMethodReferenceSetupId: string): Promise<void> {
    const form = new FormData();
    form.set('zoneId', zoneId);
    form.set('paymentMethodReferenceSetupId', paymentMethodReferenceSetupId);

    const response = await fetch(COMPLETE_ACTION, { method: 'POST', body: form });
    const payload = (await response.json()) as CompleteAccountSavedMethodResult;

    if (!response.ok || !payload || payload.success !== true) {
        const message =
            payload && 'error' in payload && typeof payload.error === 'string'
                ? payload.error
                : 'Unable to complete payment method setup';
        throw new Error(message);
    }
}

/**
 * CAP body for My Account Add (`sfcc.myAccount.payments.addMethod`).
 *
 * Host owns the dialog shell / openAdd. When SFP is enabled this replaces the
 * native card form with `sfp.setup()` (Stripe card + SEPA; Adyen card). Never
 * calls native `/action/payment-method-add`.
 *
 * Stripe: setup → confirm → complete (card and sepa_debit).
 * Adyen: Drop-in encrypts card → setup with paymentMethod → Authorised (no complete).
 * Adyen SEPA is out of scope — commerce rejects sepa_debit on My Account setup.
 * Layout matches Figma: payment surface first, billing address below (when required).
 */
export default function AccountAddSavedPaymentMethod({ children }: { children?: ReactNode }) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { t } = useTranslation('extSfPayments' as any);
    const { enabled, metadataLoading, sfp, metadata } = useSFPaymentsContext();
    const dialog = useAddPaymentMethodDialog();
    const correlationId = useCorrelationId();
    const { locale, currency: siteCurrency } = useSite();
    const countryCode = useMemo(() => getLocaleDerivedCountryCode(locale.id), [locale.id]);
    const currency = siteCurrency || '';

    const {
        config: paymentConfig,
        loading: paymentConfigLoading,
        error: paymentConfigError,
    } = useSFPaymentsConfig({ currency, countryCode });

    const listFetcher = useFetcher({ key: ACCOUNT_SAVED_METHODS_FETCHER_KEY });
    const listFetcherLoad = listFetcher.load;

    const mountRef = useRef<HTMLDivElement>(null);
    const setupRef = useRef<SetupHandle | null>(null);
    /** Setup id from createSetupIntent — required by Stripe complete after confirm. */
    const pendingSetupIdRef = useRef<string | null>(null);
    /** True once createSetupIntent runs inside confirm — Adyen field validation fails before this. */
    const setupIntentAttemptedRef = useRef(false);
    /** Selected SDK method — createSetupIntent must send this type to SCAPI. */
    const selectedPaymentMethodTypeRef = useRef<AccountSetupPaymentMethodType>('card');
    const [selectedPaymentMethodType, setSelectedPaymentMethodType] = useState<AccountSetupPaymentMethodType>('card');
    const [selectedAddressId, setSelectedAddressId] = useState('');
    const [isAddingNewAddress, setIsAddingNewAddress] = useState(false);
    const [saving, setSaving] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [setupReady, setSetupReady] = useState(false);

    // Host owns X / overlay / Escape — keep the shell open for the whole confirm→complete trip.
    // Optional until host provides setBusy; without it dismiss can still interrupt complete.
    const setBusy = dialog.setBusy;
    useEffect(() => {
        setBusy?.(saving);
        return () => setBusy?.(false);
    }, [setBusy, saving]);

    const zoneId = paymentConfig?.zoneId ?? null;
    const addresses = dialog.addresses;

    const billingForm = useForm<BillingAddressFormValues>({
        resolver: zodResolver(billingAddressSchema),
        mode: 'onSubmit',
        // After the first Save, clear/update field errors as the shopper edits (Stripe Element does this).
        reValidateMode: 'onChange',
        defaultValues: emptyBillingFormValues(countryCode),
    });
    /** `trigger()` alone does not always enable reValidateMode; gate onChange re-checks after first Save. */
    const billingValidatedOnceRef = useRef(false);

    const cardGateway = useMemo(
        () =>
            getGatewayFromPaymentMethod('card', paymentConfig?.paymentMethods, paymentConfig?.paymentMethodSetAccounts),
        [paymentConfig]
    );
    const sepaGateway = useMemo(
        () =>
            getGatewayFromPaymentMethod(
                PAYMENT_METHOD_TYPES.SEPA_DEBIT,
                paymentConfig?.paymentMethods,
                paymentConfig?.paymentMethodSetAccounts
            ),
        [paymentConfig]
    );
    // Prefer card's gateway when both exist; SEPA-only zones still resolve via sepa.
    const setupVendor = toAccountSetupVendor(cardGateway) ?? toAccountSetupVendor(sepaGateway);

    const setupMethods = useMemo(() => {
        if (!setupVendor || !paymentConfig?.paymentMethods) return [];
        const allowed = accountSetupTypesForVendor(setupVendor);
        return paymentConfig.paymentMethods.filter(
            (method) =>
                isAccountSetupPaymentMethodType(method.paymentMethodType) && allowed.has(method.paymentMethodType)
        );
    }, [paymentConfig, setupVendor]);

    const billingRequired = requiresBillingDetailsForType(metadata, selectedPaymentMethodType);
    const showInlineAddress = billingRequired && (addresses.length === 0 || isAddingNewAddress);

    useEffect(() => {
        if (!selectedAddressId && addresses[0]?.addressId) {
            setSelectedAddressId(addresses[0].addressId);
        }
    }, [addresses, selectedAddressId]);

    useEffect(() => {
        // Zero saved addresses → inline form is the only path when billing is required.
        if (billingRequired && addresses.length === 0) {
            setIsAddingNewAddress(true);
        }
    }, [billingRequired, addresses.length]);

    useEffect(() => {
        const current = billingForm.getValues('billingCountryCode');
        if (!current) {
            billingForm.setValue('billingCountryCode', countryCode || 'US');
        }
    }, [billingForm, countryCode]);

    useEffect(() => {
        const subscription = billingForm.watch((_values, info) => {
            if (!billingValidatedOnceRef.current || info.type !== 'change' || !info.name) return;
            void billingForm.trigger(info.name);
        });
        return () => subscription.unsubscribe();
    }, [billingForm]);

    useEffect(() => {
        if (!enabled) return;
        if (!sfp || !metadata || !paymentConfig || !zoneId || !mountRef.current) return;
        if (!setupVendor) {
            setError(t('accountAddSavedPaymentMethod.methodUnavailable'));
            setSetupReady(false);
            return;
        }

        if (setupMethods.length === 0) {
            setError(t('accountAddSavedPaymentMethod.methodUnavailable'));
            setSetupReady(false);
            return;
        }

        const firstMethod = setupMethods[0];
        const initialType =
            firstMethod && isAccountSetupPaymentMethodType(firstMethod.paymentMethodType)
                ? firstMethod.paymentMethodType
                : 'card';
        selectedPaymentMethodTypeRef.current = initialType;
        setSelectedPaymentMethodType(initialType);

        // Remount / first mount — keep the Save CTA disabled and show the spinner
        // until sfp.setup() returns a handle.
        setSetupReady(false);
        setError(null);

        const paymentMethodSetAccounts = (paymentConfig.paymentMethodSetAccounts ?? []).map(
            (account: PaymentMethodSetAccount) => ({ ...account, gatewayId: account.accountId })
        );
        const paymentMethodSet = {
            paymentMethods: setupMethods,
            paymentMethodSetAccounts,
        };

        const setupElement = document.createElement('div');
        mountRef.current.replaceChildren(setupElement);

        const onMethodSelected = (event: Event) => {
            const detail = (event as CustomEvent<{ selectedPaymentMethod?: string }>).detail;
            const methodType = detail?.selectedPaymentMethod;
            if (methodType && isAccountSetupPaymentMethodType(methodType)) {
                selectedPaymentMethodTypeRef.current = methodType;
                setSelectedPaymentMethodType(methodType);
            }
        };
        setupElement.addEventListener('sfp:paymentmethodselected', onMethodSelected);

        try {
            setupRef.current = sfp.setup(
                metadata,
                paymentMethodSet,
                {
                    theme: buildTheme(),
                    actions: {
                        createSetupIntent: async (paymentData?: CreateSetupIntentArg) => {
                            setupIntentAttemptedRef.current = true;
                            const paymentMethodType = selectedPaymentMethodTypeRef.current;
                            const adyenPaymentMethod =
                                setupVendor === 'adyen' ? extractAdyenPaymentMethod(paymentData) : undefined;
                            const result = await createSetupIntent(
                                zoneId,
                                setupVendor,
                                paymentMethodType,
                                adyenPaymentMethod
                            );
                            pendingSetupIdRef.current = result.paymentMethodReferenceSetupId;
                            if (result.vendor === 'stripe') {
                                return { client_secret: result.clientSecret };
                            }
                            // Adyen SDK checks resultCode === 'Authorised'.
                            return { resultCode: result.resultCode };
                        },
                    },
                    options: {
                        showSaveAsDefaultCheckbox: false,
                    },
                },
                {
                    currency,
                    locale: locale.id,
                    country: countryCode,
                },
                setupElement
            ) as SetupHandle;
            setSetupReady(true);
        } catch (mountError) {
            setSetupReady(false);
            // Shopper sees a stable category only — raw SDK text stays in diagnostics.
            setError(t('accountAddSavedPaymentMethod.mountFailed'));
            reportClientDiagnostic({
                signal: 'account setup mount failed',
                correlationId,
                metadata: {
                    vendorMessage: extractVendorMessage(mountError),
                    errorName: mountError instanceof Error ? mountError.name : undefined,
                    vendor: setupVendor,
                },
            });
        }

        return () => {
            setupElement.removeEventListener('sfp:paymentmethodselected', onMethodSelected);
            try {
                setupRef.current?.destroy();
            } catch {
                // SDK may throw if already destroyed.
            }
            setupRef.current = null;
            pendingSetupIdRef.current = null;
            setSetupReady(false);
        };
        // Omit `t` — i18n returns a new function each render and would remount the SDK.
        // eslint-disable-next-line react-hooks/exhaustive-deps -- t is stable enough for mount-time copy
    }, [
        enabled,
        sfp,
        metadata,
        paymentConfig,
        zoneId,
        setupVendor,
        setupMethods,
        currency,
        locale.id,
        countryCode,
        correlationId,
    ]);

    const handleSave = useCallback(async () => {
        if (saving || !setupRef.current || !setupVendor) return;
        setError(null);

        if (!dialog.email) {
            setError(t('accountAddSavedPaymentMethod.emailUnavailable'));
            return;
        }

        let billingDetails: ReturnType<typeof toBillingDetails> | { email: string } = {
            email: dialog.email,
        };

        if (billingRequired) {
            if (showInlineAddress) {
                billingValidatedOnceRef.current = true;
                const billingValid = await billingForm.trigger();
                if (!billingValid) {
                    // Do not confirm until billing is valid — Stripe would orphan a SetupIntent
                    // (confirm can succeed, complete is skipped); Adyen would silent-save on setup.
                    return;
                }
                billingDetails = toBillingDetails(billingFormToCustomerAddress(billingForm.getValues()), dialog.email);
            } else {
                const address = addresses.find((entry) => entry.addressId === selectedAddressId);
                if (!address) {
                    setError(t('accountAddSavedPaymentMethod.selectAddress'));
                    return;
                }
                billingDetails = toBillingDetails(address, dialog.email);
            }
        }

        setSaving(true);
        setupIntentAttemptedRef.current = false;
        try {
            let confirmResult: SetupConfirmResult;
            try {
                confirmResult = await setupRef.current.confirm(billingDetails);
            } catch (confirmError) {
                // Stripe Element / Adyen Drop-in field errors stay on the card — no CAP banner.
                // Adyen setup/API failures (createSetupIntent ran) have no field UI — use the banner.
                reportClientDiagnostic({
                    signal: 'account setup confirm threw',
                    correlationId,
                    metadata: {
                        vendor: setupVendor,
                        vendorMessage: extractVendorMessage(
                            confirmError instanceof Error
                                ? confirmError
                                : ((confirmError as SetupConfirmResult | null)?.data ?? confirmError)
                        ),
                        errorName: confirmError instanceof Error ? confirmError.name : undefined,
                        responseCode:
                            confirmError &&
                            typeof confirmError === 'object' &&
                            'responseCode' in confirmError &&
                            typeof (confirmError as SetupConfirmResult).responseCode === 'number'
                                ? (confirmError as SetupConfirmResult).responseCode
                                : undefined,
                    },
                });
                if (setupVendor === 'adyen' && setupIntentAttemptedRef.current) {
                    setError(t('accountAddSavedPaymentMethod.setupFailed'));
                    dialog.onError();
                }
                return;
            }

            // Same gate as checkout confirm — do not complete on resolved non-success.
            if (!confirmResult || confirmResult.responseCode !== SDK_RESPONSE_CODE.SUCCESS) {
                reportClientDiagnostic({
                    signal: 'account setup confirm non-success',
                    correlationId,
                    metadata: {
                        responseCode: confirmResult?.responseCode ?? null,
                        vendorMessage: extractVendorMessage(confirmResult?.data),
                        vendor: setupVendor,
                        status:
                            confirmResult?.data && 'status' in confirmResult.data
                                ? confirmResult.data.status
                                : undefined,
                    },
                });
                if (setupVendor === 'adyen' && setupIntentAttemptedRef.current) {
                    setError(t('accountAddSavedPaymentMethod.setupFailed'));
                    dialog.onError();
                }
                return;
            }

            if (setupVendor === 'stripe') {
                const setupId = pendingSetupIdRef.current;
                if (!setupId || !zoneId) {
                    setError(t('accountAddSavedPaymentMethod.setupFailed'));
                    dialog.onError();
                    return;
                }
                try {
                    // digital#35526 — marks the confirmed method shopper-reusable so it appears in the list.
                    await completeSetupIntent(zoneId, setupId);
                } catch (completeError) {
                    setError(t('accountAddSavedPaymentMethod.setupFailed'));
                    reportClientDiagnostic({
                        signal: 'account setup complete threw',
                        correlationId,
                        metadata: {
                            vendor: setupVendor,
                            vendorMessage: extractVendorMessage(completeError),
                            errorName: completeError instanceof Error ? completeError.name : undefined,
                        },
                    });
                    dialog.onError();
                    return;
                }
            }
            // Adyen: Authorised setup alone stores + marks shopper-reuse. Complete is unsupported.
            pendingSetupIdRef.current = null;

            // Host onComplete: close + toast only. CAP owns the single SFP list refresh
            // (host revalidate would also re-run this keyed fetcher → double load).
            dialog.onComplete();
            void listFetcherLoad(ACCOUNT_SAVED_METHODS_RESOURCE);
        } finally {
            setSaving(false);
        }
    }, [
        saving,
        setupVendor,
        addresses,
        selectedAddressId,
        dialog,
        listFetcherLoad,
        zoneId,
        t,
        correlationId,
        billingRequired,
        showInlineAddress,
        billingForm,
    ]);

    if (metadataLoading) {
        return (
            <p className="text-sm text-muted-foreground" data-testid="account-add-saved-payment-method-loading">
                {t('accountAddSavedPaymentMethod.loading')}
            </p>
        );
    }

    if (!enabled) {
        return <>{children}</>;
    }

    if (paymentConfigLoading) {
        return (
            <p className="text-sm text-muted-foreground" data-testid="account-add-saved-payment-method-loading">
                {t('accountAddSavedPaymentMethod.loading')}
            </p>
        );
    }

    if (paymentConfigError || !zoneId) {
        return (
            <div
                className="rounded-ui border border-destructive/40 bg-destructive/10 px-4 py-3"
                role="alert"
                data-testid="account-add-saved-payment-method-config-error">
                <p className="text-sm text-foreground">
                    {paymentConfigError || t('accountAddSavedPaymentMethod.zoneUnavailable')}
                </p>
            </div>
        );
    }

    if (!setupVendor || setupMethods.length === 0) {
        return (
            <div
                className="rounded-ui border border-destructive/40 bg-destructive/10 px-4 py-3"
                role="alert"
                data-testid="account-add-saved-payment-method-config-error">
                <p className="text-sm text-foreground">{t('accountAddSavedPaymentMethod.methodUnavailable')}</p>
            </div>
        );
    }

    const busy = saving || dialog.isLoading;

    return (
        <div className="space-y-5" data-testid="account-add-saved-payment-method" data-vendor={setupVendor}>
            {error ? (
                <div
                    className="rounded-ui border border-destructive/40 bg-destructive/10 px-4 py-3"
                    role="alert"
                    data-testid="account-add-saved-payment-method-error">
                    <p className="text-sm text-foreground">{error}</p>
                </div>
            ) : null}

            <div>
                <p className="text-sm font-medium text-foreground mb-2">
                    {t('accountAddSavedPaymentMethod.paymentMethodLabel')}
                </p>
                <div
                    className="relative rounded-ui border border-border bg-background p-3 min-h-32"
                    data-testid="account-add-saved-payment-method-sdk">
                    {!setupReady && !error ? (
                        <div
                            className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-2 bg-background/80"
                            role="status"
                            aria-live="polite"
                            aria-busy="true"
                            data-testid="account-add-saved-payment-method-sdk-loading">
                            <Loader2 className="h-8 w-8 animate-spin text-primary" aria-hidden="true" />
                            <span className="sr-only">{t('accountAddSavedPaymentMethod.loading')}</span>
                        </div>
                    ) : null}
                    <div ref={mountRef} className="min-h-24" aria-busy={!setupReady} />
                </div>
            </div>

            {billingRequired ? (
                <div data-testid="account-add-saved-payment-method-billing">
                    <p className="text-sm font-medium text-foreground mb-2">
                        {t('accountAddSavedPaymentMethod.billingAddress')}
                    </p>
                    {addresses.length > 0 ? (
                        <>
                            <label htmlFor="account-add-billing-address" className="sr-only">
                                {t('accountAddSavedPaymentMethod.billingAddress')}
                            </label>
                            <select
                                id="account-add-billing-address"
                                className="w-full rounded-ui border border-input bg-background px-3 py-2 text-sm"
                                value={showInlineAddress ? '' : selectedAddressId}
                                onChange={(event) => {
                                    setSelectedAddressId(event.target.value);
                                    // Selecting a saved address closes the inline form and takes precedence.
                                    if (event.target.value) setIsAddingNewAddress(false);
                                }}
                                disabled={busy}
                                required={!showInlineAddress}
                                aria-required={!showInlineAddress}
                                data-testid="account-add-saved-payment-method-address-select">
                                <option value="">{t('accountAddSavedPaymentMethod.selectAddressPlaceholder')}</option>
                                {addresses.map((address) => (
                                    <option key={address.addressId} value={address.addressId || ''}>
                                        {addressLabel(address)}
                                    </option>
                                ))}
                            </select>
                            <button
                                type="button"
                                className="mt-2 flex cursor-pointer items-center gap-1 text-sm font-medium text-primary transition-colors hover:text-primary/80"
                                onClick={() => {
                                    setSelectedAddressId('');
                                    billingValidatedOnceRef.current = false;
                                    billingForm.reset(emptyBillingFormValues(countryCode));
                                    setIsAddingNewAddress(true);
                                }}
                                disabled={busy}
                                data-testid="account-add-saved-payment-method-toggle-new-address">
                                <Plus className="size-4" aria-hidden="true" />
                                {t('accountAddSavedPaymentMethod.addNewAddress')}
                            </button>
                        </>
                    ) : null}

                    {showInlineAddress ? (
                        <div className="mt-3" data-testid="account-add-saved-payment-method-inline-address">
                            <Form {...billingForm}>
                                <AddressFormFields
                                    form={billingForm}
                                    fieldPrefix="billing"
                                    showPhone={false}
                                    showCountry
                                    countryCode={countryCode || 'US'}
                                />
                            </Form>
                        </div>
                    ) : null}
                </div>
            ) : null}

            <div className="flex items-center justify-end gap-3 pt-4">
                <button
                    type="button"
                    className="rounded-ui border border-border bg-background px-4 py-2 text-sm font-medium text-foreground hover:bg-muted cursor-pointer disabled:opacity-50"
                    onClick={() => dialog.onClose()}
                    disabled={busy}>
                    {t('accountAddSavedPaymentMethod.cancel')}
                </button>
                <button
                    type="button"
                    className="rounded-ui bg-primary px-4 py-2 text-sm font-medium text-primary-foreground cursor-pointer disabled:opacity-50"
                    onClick={() => void handleSave()}
                    disabled={busy || !setupReady}
                    data-testid="account-add-saved-payment-method-save">
                    {busy ? t('accountAddSavedPaymentMethod.saving') : t('accountAddSavedPaymentMethod.save')}
                </button>
            </div>
        </div>
    );
}
