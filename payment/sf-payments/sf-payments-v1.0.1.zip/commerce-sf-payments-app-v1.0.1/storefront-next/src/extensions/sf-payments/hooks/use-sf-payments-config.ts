/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

'use client';

import { useEffect, useState } from 'react';

/**
 * Shape of a payment method set account from SCAPI.
 */
export interface PaymentMethodSetAccount {
    accountId: string;
    config?: {
        key?: string;
        accountId?: string;
        bnCode?: string;
        [key: string]: unknown;
    };
    gatewayId: string;
    gatewayResponse?: {
        paymentMethods?: { brands?: string[]; type?: string }[];
        [key: string]: unknown;
    } | null;
    isLive: boolean;
    vendor: string;
}

/**
 * Shape of a configured payment method from SCAPI.
 */
export interface PaymentMethod {
    accountId: string;
    paymentMethodType: string;
    paymentModes: string[];
}

/**
 * Full payment configuration from Shopper Payments SCAPI.
 */
export interface PaymentConfiguration {
    zoneId?: string | null;
    paymentMethodSetAccounts: PaymentMethodSetAccount[];
    paymentMethods: PaymentMethod[];
}

/**
 * Module-level per-key memo cache.
 *
 * Keyed by `${currency}:${countryCode}`. Lifetime is the JS module — cleared on
 * hard/soft page refresh. Entries persist for the page lifetime; there is no
 * TTL or background revalidation. Failed fetches delete their entry so the
 * next caller retries (no negative caching).
 *
 * This serves two roles with one structure:
 *   - Dedupe: concurrent callers for the same key share the in-flight promise.
 *   - Cache: later callers for the same key reuse the resolved promise.
 *
 * Payment gateway configuration is administratively configured and changes
 * rarely, so page-lifetime caching is a safe tradeoff; merchants flipping a
 * gateway will see the change after hard nav.
 */
const configCache = new Map<string, Promise<PaymentConfiguration>>();

function cacheKey(currency: string, countryCode?: string): string {
    return `${currency}:${countryCode ?? ''}`;
}

/**
 * Fetches payment configuration from the Shopper Payments SCAPI.
 *
 * Imperative form — used by the `useSFPaymentsConfig` hook and available for
 * any future non-React consumer (route actions, imperative checkout flows).
 * Concurrent callers for the same `${currency}:${countryCode}` key share a
 * single in-flight request, and resolved entries are cached for the module
 * lifetime. On failure the entry is cleared so the next caller retries.
 */
export function fetchPaymentConfig(currency: string, countryCode?: string): Promise<PaymentConfiguration> {
    const key = cacheKey(currency, countryCode);
    const existing = configCache.get(key);
    if (existing) return existing;

    const params = new URLSearchParams({ currency });
    if (countryCode) {
        params.set('countryCode', countryCode);
    }

    const promise = fetch(`/resource/sf-payments-config?${params}`)
        .then(async (res) => {
            if (!res.ok) {
                const body = await res.json().catch(() => ({}));
                throw new Error(body.error ?? `HTTP ${res.status}`);
            }
            return res.json();
        })
        .catch((err) => {
            configCache.delete(key);
            throw err;
        });

    configCache.set(key, promise);
    return promise;
}

export interface UseSFPaymentsConfigArgs {
    currency: string;
    countryCode: string;
}

export interface UseSFPaymentsConfigResult {
    config: PaymentConfiguration | null;
    accounts: PaymentMethodSetAccount[];
    loading: boolean;
    error: string | null;
}

/**
 * Per-consumer hook for fetching payment configuration by `(currency, countryCode)`.
 *
 * Each call site sources its own transaction values (basket currency on
 * checkout, product/variant currency on PDP, billing-address country on
 * payment sheet) and passes them as args. The module-level cache dedupes
 * concurrent fetches for the same key and returns cached data on subsequent
 * calls — a cart preview and a checkout express button using the same
 * `(currency, countryCode)` share a single network request.
 *
 * Lazy by design: consumers gated off by merchant config (e.g. a hidden
 * express-buttons placement) never mount the hook and pay no network cost.
 */
export function useSFPaymentsConfig({ currency, countryCode }: UseSFPaymentsConfigArgs): UseSFPaymentsConfigResult {
    const [config, setConfig] = useState<PaymentConfiguration | null>(null);
    const [loading, setLoading] = useState<boolean>(Boolean(currency));
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        if (!currency) {
            setConfig(null);
            setLoading(false);
            setError(null);
            return;
        }

        let cancelled = false;
        setLoading(true);
        setError(null);

        fetchPaymentConfig(currency, countryCode)
            .then((next) => {
                if (cancelled) return;
                setConfig(next);
                setLoading(false);
            })
            .catch((err: unknown) => {
                if (cancelled) return;
                setConfig(null);
                setError(err instanceof Error ? err.message : 'Unknown error');
                setLoading(false);
            });

        return () => {
            cancelled = true;
        };
    }, [currency, countryCode]);

    return {
        config,
        accounts: config?.paymentMethodSetAccounts ?? [],
        loading,
        error,
    };
}
