/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { beforeEach, describe, expect, test, vi } from 'vitest';
import type { RouterContextProvider } from 'react-router';
import { loader } from './resource.sf-payments-saved-methods';

vi.mock('@/middlewares/auth.server', () => ({ getAuth: vi.fn() }));
vi.mock('@/lib/api-clients.server', () => ({ createApiClients: vi.fn() }));

import { getAuth } from '@/middlewares/auth.server';
import { createApiClients } from '@/lib/api-clients.server';

const mockContext = { get: vi.fn(), set: vi.fn() } as unknown as RouterContextProvider;
const mockArgs = {
    context: mockContext,
    params: {},
    request: new Request('https://shop.example/resource/sf-payments-saved-methods'),
} as any;

beforeEach(() => {
    vi.clearAllMocks();
});

describe('resource.sf-payments-saved-methods loader', () => {
    test('returns empty array for guest shopper', async () => {
        vi.mocked(getAuth).mockReturnValue({ userType: 'guest', customerId: null } as any);

        const response = await loader(mockArgs);
        const data = await response.json();

        expect(data).toEqual([]);
    });

    test('returns empty array when customerId is missing', async () => {
        vi.mocked(getAuth).mockReturnValue({ userType: 'registered', customerId: null } as any);

        const response = await loader(mockArgs);
        const data = await response.json();

        expect(data).toEqual([]);
    });

    test('returns raw paymentMethodReferences for registered shopper', async () => {
        const refs = [{ id: 'pm_123', type: 'card', last4: '4242', accountId: 'acct_stripe' }];
        vi.mocked(getAuth).mockReturnValue({ userType: 'registered', customerId: 'c1' } as any);
        vi.mocked(createApiClients).mockReturnValue({
            shopperCustomers: {
                getCustomer: vi.fn().mockResolvedValue({ data: { paymentMethodReferences: refs } }),
            },
        } as any);

        const response = await loader(mockArgs);
        const data = await response.json();

        expect(data).toEqual(refs);
    });

    test('returns empty array when customer has no paymentMethodReferences', async () => {
        vi.mocked(getAuth).mockReturnValue({ userType: 'registered', customerId: 'c1' } as any);
        vi.mocked(createApiClients).mockReturnValue({
            shopperCustomers: {
                getCustomer: vi.fn().mockResolvedValue({ data: {} }),
            },
        } as any);

        const response = await loader(mockArgs);
        const data = await response.json();

        expect(data).toEqual([]);
    });

    test('returns empty array on SCAPI error', async () => {
        vi.mocked(getAuth).mockReturnValue({ userType: 'registered', customerId: 'c1' } as any);
        vi.mocked(createApiClients).mockReturnValue({
            shopperCustomers: {
                getCustomer: vi.fn().mockRejectedValue(new Error('SCAPI unavailable')),
            },
        } as any);

        const response = await loader(mockArgs);
        const data = await response.json();

        expect(data).toEqual([]);
    });
});
