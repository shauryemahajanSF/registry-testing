/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';

const mockShopperConfig = {
    SalesforcePaymentsAllowed: true,
    cardCaptureAutomatic: true,
    futureUsageOffSession: false,
};

describe('fetchShopperConfig', () => {
    let fetchShopperConfig: typeof import('./use-sf-payments-shopper-config').fetchShopperConfig;

    beforeEach(async () => {
        vi.resetModules();
        vi.spyOn(globalThis, 'fetch').mockImplementation(() =>
            Promise.resolve(new Response(JSON.stringify(mockShopperConfig)))
        );
        const mod = await import('./use-sf-payments-shopper-config');
        fetchShopperConfig = mod.fetchShopperConfig;
    });

    afterEach(() => {
        vi.restoreAllMocks();
    });

    it('fetches shopper config from resource route', async () => {
        const result = await fetchShopperConfig();
        expect(result).toEqual(mockShopperConfig);
        expect(globalThis.fetch).toHaveBeenCalledWith('/resource/sf-payments-shopper-config');
    });

    it('returns the resolved config on subsequent calls without refetching', async () => {
        const result1 = await fetchShopperConfig();
        const result2 = await fetchShopperConfig();
        expect(result1).toBe(result2);
        expect(globalThis.fetch).toHaveBeenCalledTimes(1);
    });

    it('deduplicates in-flight requests', async () => {
        const promise1 = fetchShopperConfig();
        const promise2 = fetchShopperConfig();
        const [result1, result2] = await Promise.all([promise1, promise2]);
        expect(result1).toEqual(result2);
        expect(globalThis.fetch).toHaveBeenCalledTimes(1);
    });

    it('clears the pending request on error so next call retries', async () => {
        vi.mocked(globalThis.fetch).mockRejectedValueOnce(new Error('Network error'));

        await expect(fetchShopperConfig()).rejects.toThrow('Network error');

        vi.mocked(globalThis.fetch).mockImplementation(() =>
            Promise.resolve(new Response(JSON.stringify(mockShopperConfig)))
        );
        const result = await fetchShopperConfig();
        expect(result).toEqual(mockShopperConfig);
    });

    it('throws with error message from response body', async () => {
        vi.mocked(globalThis.fetch).mockImplementation(() =>
            Promise.resolve(new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401 }))
        );
        await expect(fetchShopperConfig()).rejects.toThrow('Unauthorized');
    });

    it('falls back to HTTP status when response body has no error field', async () => {
        vi.mocked(globalThis.fetch).mockImplementation(() => Promise.resolve(new Response('', { status: 500 })));
        await expect(fetchShopperConfig()).rejects.toThrow('HTTP 500');
    });

    it('normalizes boolean-like shopper config string values', async () => {
        vi.mocked(globalThis.fetch).mockImplementation(() =>
            Promise.resolve(
                new Response(
                    JSON.stringify({
                        SalesforcePaymentsAllowed: 'true',
                        cardCaptureAutomatic: 'false',
                        futureUsageOffSession: 'true',
                    })
                )
            )
        );

        const result = await fetchShopperConfig();
        expect(result).toEqual({
            SalesforcePaymentsAllowed: true,
            cardCaptureAutomatic: false,
            futureUsageOffSession: true,
        });
    });
});
