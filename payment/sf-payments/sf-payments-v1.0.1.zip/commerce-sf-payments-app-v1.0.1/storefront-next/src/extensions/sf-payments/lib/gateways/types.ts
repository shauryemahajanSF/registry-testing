/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

/**
 * GatewayStrategy — one implementation per payment vendor (Stripe, Adyen,
 * PayPal) that encapsulates per-gateway differences in SDK callback behavior.
 *
 * Key invariants:
 *
 * - Strategies are gateway-aware, flow-agnostic. No `if (flow === 'express')`
 *   branches; components own flow-specific shaping of return values.
 * - Strategies call `lib/api/*` mutations and return rich per-gateway results.
 *   They do not know whether a basket is temp or main, and do not import React.
 */

import type { ShopperBasketsV2, ShopperOrders } from '@/scapi';
import type { PaymentMethodType } from '../sf-payments-utils';
import type { PaymentConfig } from '../api/types';

type Basket = ShopperBasketsV2.schemas['Basket'];
type Order = ShopperOrders.schemas['Order'];

/**
 * Arguments passed to {@link GatewayStrategy.createIntent}.
 *
 * `paymentData` is only populated for Adyen, which receives the shopper's
 * addresses here rather than in a separate `onPayerApprove` callback.
 */
export interface CreateIntentArgs {
    basket: Basket;
    paymentMethodType: PaymentMethodType;
    paymentConfig: PaymentConfig;
    /** Base URL (origin + site prefix, e.g. "https://shop.example/us/en-US") used to build the redirect return URL. */
    baseUrl: string;
    /**
     * Gateway-specific payload from the SDK.
     * Adyen: `{ paymentMethod, billingDetails, shippingDetails, returnUrl, origin, browserInfo }`.
     * Stripe: not populated.
     */
    paymentData?: Record<string, unknown>;
    /** Whether the shopper opted in to saving this payment method for future use. */
    storePaymentMethod?: boolean;
    /** Whether the payment method should be authorized for off-session future use (e.g. recurring charges). */
    futureUsageOffSession?: boolean;
    /**
     * PayPal-only hint that's forwarded onto the PayPal-side order. Valid
     * values follow PayPal's `shippingPreference` enum (e.g.
     * `'SET_PROVIDED_ADDRESS'`, `'GET_FROM_FILE'`, `'NO_SHIPPING'`).
     */
    shippingPreference?: string;
    /**
     * Fired by the strategy when it starts the post-authorization work the
     * shopper is waiting on (push addresses, ensure PI, create order). Lets
     * the component paint processing UI without knowing per-gateway timing.
     */
    onProcessingStarted?: () => void;
    /** When true, the strategy submits create-order via plain `fetch` instead of
     *  `useFetcher`, bypassing React Router's automatic post-action loader
     *  revalidation. Set on surfaces (e.g. cart) whose loader would return an
     *  empty basket after order creation and tear down this subtree mid-flow. */
    skipPostOrderRevalidation?: boolean;
}

/**
 * Arguments passed to {@link GatewayStrategy.onPayerApprove}.
 *
 * `shippingAddress` / `billingAddress` come from the wallet approval (Apple Pay
 * / Google Pay / PayPal). Strategies push them onto the basket before PI work.
 */
export interface PayerApproveArgs {
    basket: Basket;
    paymentMethodType: PaymentMethodType;
    paymentConfig: PaymentConfig;
    shippingAddress?: Record<string, unknown>;
    billingAddress?: Record<string, unknown>;
    paymentData?: Record<string, unknown>;
    /**
     * Fired by the strategy when it starts the post-authorization work the
     * shopper is waiting on (push addresses, ensure PI). Lets the component
     * paint processing UI without knowing per-gateway timing.
     */
    onProcessingStarted?: () => void;
}

/**
 * Arguments passed to {@link GatewayStrategy.onApprove} (PayPal only).
 *
 * Invoked after the PayPal popup is approved. By this point the basket has a
 * fresh SF Payments PI and verified addresses; the strategy's job is to create
 * the commerce order and patch the PI.
 */
export interface ApproveArgs {
    basket: Basket;
    paymentMethodType: PaymentMethodType;
    paymentConfig: PaymentConfig;
    baseUrl: string;
    /** See {@link CreateIntentArgs.skipPostOrderRevalidation}. PayPal creates the
     *  commerce order in `onApprove` rather than `createIntent`, so the flag
     *  must reach here too. */
    skipPostOrderRevalidation?: boolean;
}

/**
 * Opaque, SDK-shaped payload produced by a strategy's `createIntent`.
 *
 * The shape is intentionally `unknown` — there's no useful common type
 * because each gateway's SDK expects different fields, and even the one
 * conceptually shared value (the SF Payments paymentReferenceId) lives
 * under different keys per gateway:
 *
 *   - Stripe: `{ client_secret, id }`           — `id` is the paymentReferenceId
 *   - Adyen:  `{ pspReference, guid, resultCode, action }` — `guid` is the paymentReferenceId
 *   - PayPal: `{ id }`                          — `id` is the paymentReferenceId
 *
 * Each strategy is the single source of truth for its own shape and
 * consumers just forward this payload to the SDK. The named alias exists
 * so reading code shows "this is the SDK payload" instead of bare `unknown`.
 */
export type SdkIntentPayload = unknown;

/**
 * Return shape of every gateway's `createIntent`. The strategy is the single
 * source of truth for `sdkResult`'s shape; consumers destructure `order`
 * (when present) for navigation and forward `sdkResult` to the SDK.
 *
 * `order` is present when `createIntent` creates the commerce order (Stripe,
 * Adyen). PayPal defers order creation to `onApprove`, so its `order` is
 * undefined.
 */
export interface CreateIntentResult {
    sdkResult: SdkIntentPayload;
    order?: Order;
}

/**
 * Per-gateway orchestration contract for express flows.
 *
 * Each gateway's method set reflects which SDK callbacks the SF Payments SDK
 * actually invokes for that vendor:
 *
 * - Stripe: onClick (prep) → onPayerApprove (addresses + PI) → createIntent (order)
 * - Adyen:  onClick (prep) → createIntent (addresses from paymentData + order)
 * - PayPal: onClick (skip prep) → createIntent (lazy prep + PI) → onPayerApprove (addresses) → onApprove (order)
 */
export interface GatewayStrategy {
    /**
     * Whether the component should synchronously kick off `prepareBasket` in
     * the SDK's `onClick` callback.
     *
     * - `true` for Stripe and Adyen — basket prep can start immediately.
     * - `false` for PayPal — on the PayPal path the SDK creates its PayPal-side
     *   order on button click *before* `createIntent` fires, and prepping earlier
     *   would race it. PayPal's strategy preps lazily inside `createIntent`.
     */
    prepareBasketOnClick: boolean;

    /**
     * Wallet-approval callback. Returns the updated basket so the component
     * can refresh its ref.
     *
     * - Stripe: push shipping + billing addresses, add PI to basket. No order.
     * - PayPal: push shipping + billing addresses from PayPal's returned details.
     *   PI was already added in `createIntent`; no order.
     * - Adyen: omitted — addresses arrive on `createIntent.paymentData`, so the
     *   component must skip calling this for Adyen.
     */
    onPayerApprove?(args: PayerApproveArgs): Promise<Basket>;

    /**
     * Create-intent callback — the SDK's primary "prepare payment" hook.
     * Each gateway packs its own SDK-shaped `sdkResult`:
     *
     * - Stripe: create commerce order + patch PI; `sdkResult` = `{ client_secret, id }`.
     * - Adyen:  apply addresses from `paymentData`, ensure PI, create commerce
     *           order; `sdkResult` = `{ pspReference, guid, resultCode, action }`.
     * - PayPal: lazy prepareBasket, remove stale PI, add fresh PI. **No order**
     *           (created later in `onApprove`); `sdkResult` = `{ id }`.
     */
    createIntent(args: CreateIntentArgs): Promise<CreateIntentResult>;

    /**
     * Post-wallet-approval callback (PayPal only).
     *
     * - PayPal: create commerce order + patch PI (after SDK confirms PayPal-side
     *   approval and `onPayerApprove` has pushed addresses).
     * - Stripe / Adyen: omitted — their order is created in `createIntent`.
     */
    onApprove?(args: ApproveArgs): Promise<Record<string, unknown>>;
}
