/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';
import { renderHook } from '@testing-library/react';
import { usePaymentMethodsCallbacks } from './use-payment-methods-callbacks';

function renderWithRouter<T>(hook: () => T) {
    return renderHook(hook);
}

vi.mock('react-i18next', () => ({
    useTranslation: vi.fn(() => ({
        t: (key: string) => key,
    })),
}));

const mockStrategyCreateIntent = vi.fn();

const mockFailAndRecover = vi.fn(() => Promise.resolve({ basketRecovered: true, orderNo: '' }));
const mockResetFailOrder = vi.fn();

vi.mock('../../hooks/use-sf-payments-failure-recovery', () => ({
    useSFPaymentsFailureRecovery: vi.fn(() => ({
        failAndRecover: mockFailAndRecover,
        resetFailOrder: mockResetFailOrder,
    })),
}));

vi.mock('../../hooks/gateways/use-select-gateway-strategy', () => ({
    useSelectGatewayStrategy: vi.fn(() =>
        vi.fn(() => ({
            prepareBasketOnClick: true,
            createIntent: mockStrategyCreateIntent,
        }))
    ),
}));

describe('usePaymentMethodsCallbacks', () => {
    const mockBasket = {
        basketId: 'test-basket-123',
        currency: 'USD',
        orderTotal: 99.99,
        productTotal: 89.99,
        customerInfo: {
            email: 'test@example.com',
        },
        billingAddress: {
            firstName: 'John',
            lastName: 'Doe',
            fullName: 'John Doe',
            address1: '123 Main St',
            city: 'San Francisco',
            stateCode: 'CA',
            postalCode: '94105',
            countryCode: 'US',
            phone: '555-1234',
        },
        shipments: [
            {
                shippingAddress: {
                    firstName: 'John',
                    lastName: 'Doe',
                    fullName: 'John Doe',
                    address1: '123 Main St',
                    city: 'San Francisco',
                    stateCode: 'CA',
                    postalCode: '94105',
                    countryCode: 'US',
                },
            },
        ],
    } as any;

    const mockPaymentConfig = {
        paymentMethods: [{ type: 'card', name: 'Credit Card' }],
        paymentMethodSetAccounts: [],
        zoneId: 'test-zone',
    } as any;

    const mockCheckoutComponent = {
        confirm: vi.fn(),
        destroy: vi.fn(),
        updateAmount: vi.fn(),
    };

    beforeEach(() => {
        vi.clearAllMocks();
    });

    describe('confirmPayment', () => {
        it('should return error if SDK not ready', async () => {
            const checkoutComponentRef = { current: null };
            const paymentMethodTypeRef = { current: 'card' as const };

            const { result } = renderWithRouter(() =>
                usePaymentMethodsCallbacks({
                    basket: mockBasket,
                    paymentConfig: mockPaymentConfig,
                    checkoutComponentRef,
                    paymentMethodTypeRef,
                    storePaymentMethodRef: { current: false },
                    futureUsageOffSession: false,
                    sitePrefix: '',
                    updateReturnUrl: vi.fn(),
                })
            );

            const confirmResult = await result.current.confirmPayment();

            expect(confirmResult.success).toBe(false);
            expect(confirmResult.error).toBe('paymentMethods.errorInitializing');
        });

        it('should return error if basket not available', async () => {
            const checkoutComponentRef = { current: mockCheckoutComponent };
            const paymentMethodTypeRef = { current: 'card' as const };

            const { result } = renderWithRouter(() =>
                usePaymentMethodsCallbacks({
                    basket: null,
                    paymentConfig: mockPaymentConfig,
                    checkoutComponentRef,
                    paymentMethodTypeRef,
                    storePaymentMethodRef: { current: false },
                    futureUsageOffSession: false,
                    sitePrefix: '',
                    updateReturnUrl: vi.fn(),
                })
            );

            const confirmResult = await result.current.confirmPayment();

            expect(confirmResult.success).toBe(false);
            expect(confirmResult.error).toBe('paymentMethods.errorBasketUnavailable');
        });

        it('should call SDK confirm with billing and shipping details', async () => {
            const checkoutComponentRef = { current: mockCheckoutComponent };
            const paymentMethodTypeRef = { current: 'card' as const };

            mockCheckoutComponent.confirm.mockResolvedValue({
                responseCode: 0,
            });

            const { result } = renderWithRouter(() =>
                usePaymentMethodsCallbacks({
                    basket: mockBasket,
                    paymentConfig: mockPaymentConfig,
                    checkoutComponentRef,
                    paymentMethodTypeRef,
                    storePaymentMethodRef: { current: false },
                    futureUsageOffSession: false,
                    sitePrefix: '',
                    updateReturnUrl: vi.fn(),
                })
            );

            await result.current.confirmPayment();

            expect(mockCheckoutComponent.confirm).toHaveBeenCalledWith(
                null,
                expect.objectContaining({
                    email: 'test@example.com',
                    name: 'John Doe',
                }),
                expect.objectContaining({
                    name: 'John Doe',
                })
            );
        });

        it('should return success with orderNo when payment succeeds', async () => {
            const checkoutComponentRef = { current: mockCheckoutComponent };
            const paymentMethodTypeRef = { current: 'card' as const };

            mockStrategyCreateIntent.mockResolvedValue({
                sdkResult: { client_secret: 'cs_test_secret', id: 'pi_ref_123' },
                order: { orderNo: 'ORDER-789' },
            });
            mockCheckoutComponent.confirm.mockResolvedValue({
                responseCode: 0,
            });

            const { result } = renderWithRouter(() =>
                usePaymentMethodsCallbacks({
                    basket: mockBasket,
                    paymentConfig: mockPaymentConfig,
                    checkoutComponentRef,
                    paymentMethodTypeRef,
                    storePaymentMethodRef: { current: false },
                    futureUsageOffSession: false,
                    sitePrefix: '',
                    updateReturnUrl: vi.fn(),
                })
            );

            await result.current.createIntent();
            const confirmResult = await result.current.confirmPayment();

            expect(confirmResult.success).toBe(true);
            expect(confirmResult.orderNo).toBe('ORDER-789');
        });

        it('should return error when SDK returns non-success code', async () => {
            const checkoutComponentRef = { current: mockCheckoutComponent };
            const paymentMethodTypeRef = { current: 'card' as const };

            mockCheckoutComponent.confirm.mockResolvedValue({
                responseCode: 1,
                data: { error: 'Card declined' },
            });

            const { result } = renderWithRouter(() =>
                usePaymentMethodsCallbacks({
                    basket: mockBasket,
                    paymentConfig: mockPaymentConfig,
                    checkoutComponentRef,
                    paymentMethodTypeRef,
                    storePaymentMethodRef: { current: false },
                    futureUsageOffSession: false,
                    sitePrefix: '',
                    updateReturnUrl: vi.fn(),
                })
            );

            const confirmResult = await result.current.confirmPayment();

            expect(confirmResult.success).toBe(false);
            expect(confirmResult.error).toContain('Card declined');
        });

        it('should handle SDK confirm throwing error', async () => {
            const checkoutComponentRef = { current: mockCheckoutComponent };
            const paymentMethodTypeRef = { current: 'card' as const };

            mockCheckoutComponent.confirm.mockRejectedValue(new Error('Network error'));

            const { result } = renderWithRouter(() =>
                usePaymentMethodsCallbacks({
                    basket: mockBasket,
                    paymentConfig: mockPaymentConfig,
                    checkoutComponentRef,
                    paymentMethodTypeRef,
                    storePaymentMethodRef: { current: false },
                    futureUsageOffSession: false,
                    sitePrefix: '',
                    updateReturnUrl: vi.fn(),
                })
            );

            const confirmResult = await result.current.confirmPayment();

            expect(confirmResult.success).toBe(false);
            // Non-vendor errors (JS TypeError, network failure, etc.) surface the
            // generic i18n message to shoppers — raw error.message stays in the log.
            expect(confirmResult.error).toBe('paymentMethods.errorConfirmationFailed');
        });

        it('should return basketRecovered false when recovery fails', async () => {
            const checkoutComponentRef = { current: mockCheckoutComponent };
            const paymentMethodTypeRef = { current: 'card' as const };

            mockCheckoutComponent.confirm.mockResolvedValue({
                responseCode: 1,
                data: { error: 'Card declined' },
            });
            mockFailAndRecover.mockResolvedValue({ basketRecovered: false, orderNo: 'ORDER-FAIL' });

            const { result } = renderWithRouter(() =>
                usePaymentMethodsCallbacks({
                    basket: mockBasket,
                    paymentConfig: mockPaymentConfig,
                    checkoutComponentRef,
                    paymentMethodTypeRef,
                    storePaymentMethodRef: { current: false },
                    futureUsageOffSession: false,
                    sitePrefix: '',
                    updateReturnUrl: vi.fn(),
                })
            );

            const confirmResult = await result.current.confirmPayment();

            expect(confirmResult.success).toBe(false);
            expect(confirmResult.basketRecovered).toBe(false);
            expect(confirmResult.error).toBe('Card declined');
            expect(mockFailAndRecover).toHaveBeenCalled();
        });

        it('should return basketRecovered false when confirm throws and recovery fails', async () => {
            const checkoutComponentRef = { current: mockCheckoutComponent };
            const paymentMethodTypeRef = { current: 'card' as const };

            mockCheckoutComponent.confirm.mockRejectedValue(new Error('Network error'));
            mockFailAndRecover.mockResolvedValue({ basketRecovered: false, orderNo: 'ORDER-FAIL' });

            const { result } = renderWithRouter(() =>
                usePaymentMethodsCallbacks({
                    basket: mockBasket,
                    paymentConfig: mockPaymentConfig,
                    checkoutComponentRef,
                    paymentMethodTypeRef,
                    storePaymentMethodRef: { current: false },
                    futureUsageOffSession: false,
                    sitePrefix: '',
                    updateReturnUrl: vi.fn(),
                })
            );

            const confirmResult = await result.current.confirmPayment();

            expect(confirmResult.success).toBe(false);
            expect(confirmResult.basketRecovered).toBe(false);
            // Non-vendor errors surface the generic i18n message to shoppers.
            expect(confirmResult.error).toBe('paymentMethods.errorConfirmationFailed');
            expect(mockFailAndRecover).toHaveBeenCalled();
        });
    });

    describe('createIntent', () => {
        it('should throw error if basket not available', async () => {
            const checkoutComponentRef = { current: mockCheckoutComponent };
            const paymentMethodTypeRef = { current: 'card' as const };

            const { result } = renderWithRouter(() =>
                usePaymentMethodsCallbacks({
                    basket: null,
                    paymentConfig: mockPaymentConfig,
                    checkoutComponentRef,
                    paymentMethodTypeRef,
                    storePaymentMethodRef: { current: false },
                    futureUsageOffSession: false,
                    sitePrefix: '',
                    updateReturnUrl: vi.fn(),
                })
            );

            await expect(result.current.createIntent()).rejects.toThrow('Basket is not available');
        });

        it('should throw error if payment config not resolved', async () => {
            const checkoutComponentRef = { current: mockCheckoutComponent };
            const paymentMethodTypeRef = { current: 'card' as const };

            const { result } = renderWithRouter(() =>
                usePaymentMethodsCallbacks({
                    basket: mockBasket,
                    paymentConfig: null,
                    checkoutComponentRef,
                    paymentMethodTypeRef,
                    storePaymentMethodRef: { current: false },
                    futureUsageOffSession: false,
                    sitePrefix: '',
                    updateReturnUrl: vi.fn(),
                })
            );

            await expect(result.current.createIntent()).rejects.toThrow('Payment configuration is not resolved');
        });

        it('should delegate to gateway strategy createIntent', async () => {
            const mockOrder = { orderNo: 'ORDER-456' };
            const mockSdkResult = { client_secret: 'cs_test_secret', id: 'pi_ref_123' };
            mockStrategyCreateIntent.mockResolvedValue({
                sdkResult: mockSdkResult,
                order: mockOrder,
            });

            const checkoutComponentRef = { current: mockCheckoutComponent };
            const paymentMethodTypeRef = { current: 'card' as const };

            const { result } = renderWithRouter(() =>
                usePaymentMethodsCallbacks({
                    basket: mockBasket,
                    paymentConfig: mockPaymentConfig,
                    checkoutComponentRef,
                    paymentMethodTypeRef,
                    storePaymentMethodRef: { current: false },
                    futureUsageOffSession: false,
                    sitePrefix: '',
                    updateReturnUrl: vi.fn(),
                })
            );

            const intentResult = await result.current.createIntent();

            expect(mockStrategyCreateIntent).toHaveBeenCalledWith({
                basket: mockBasket,
                paymentMethodType: 'card',
                paymentConfig: mockPaymentConfig,
                baseUrl: expect.any(String),
                paymentData: undefined,
                storePaymentMethod: false,
                futureUsageOffSession: false,
                shippingPreference: 'SET_PROVIDED_ADDRESS',
            });
            expect(intentResult).toBe(mockSdkResult);
        });

        it('should forward storePaymentMethod=true and futureUsageOffSession=true to gateway strategy', async () => {
            mockStrategyCreateIntent.mockResolvedValue({
                sdkResult: { client_secret: 'cs_test_secret', id: 'pi_ref_999' },
                order: { orderNo: 'ORDER-999' },
            });

            const checkoutComponentRef = { current: mockCheckoutComponent };
            const paymentMethodTypeRef = { current: 'card' as const };

            const { result } = renderWithRouter(() =>
                usePaymentMethodsCallbacks({
                    basket: mockBasket,
                    paymentConfig: mockPaymentConfig,
                    checkoutComponentRef,
                    paymentMethodTypeRef,
                    storePaymentMethodRef: { current: true },
                    futureUsageOffSession: true,
                    sitePrefix: '',
                    updateReturnUrl: vi.fn(),
                })
            );

            await result.current.createIntent();

            expect(mockStrategyCreateIntent).toHaveBeenCalledWith({
                basket: mockBasket,
                paymentMethodType: 'card',
                paymentConfig: mockPaymentConfig,
                baseUrl: expect.any(String),
                paymentData: undefined,
                storePaymentMethod: true,
                futureUsageOffSession: true,
                shippingPreference: 'SET_PROVIDED_ADDRESS',
            });
        });

        it('forwards Adyen strategy sdkResult opaquely to the SDK', async () => {
            const mockSdkResult = {
                pspReference: 'psp-123',
                guid: 'pref-adyen-1',
                resultCode: 'Authorised',
            };
            mockStrategyCreateIntent.mockResolvedValue({
                sdkResult: mockSdkResult,
                order: { orderNo: 'ORDER-ADYEN-1' },
            });

            const checkoutComponentRef = { current: mockCheckoutComponent };
            const paymentMethodTypeRef = { current: 'card' as const };

            const { result } = renderWithRouter(() =>
                usePaymentMethodsCallbacks({
                    basket: mockBasket,
                    paymentConfig: mockPaymentConfig,
                    checkoutComponentRef,
                    paymentMethodTypeRef,
                    storePaymentMethodRef: { current: false },
                    futureUsageOffSession: false,
                    sitePrefix: '',
                    updateReturnUrl: vi.fn(),
                })
            );

            const intentResult = await result.current.createIntent();

            expect(intentResult).toBe(mockSdkResult);
        });
    });

    describe('Adyen end-to-end through confirmPayment', () => {
        it('should return success with orderNo when Adyen payment confirms', async () => {
            const checkoutComponentRef = { current: mockCheckoutComponent };
            const paymentMethodTypeRef = { current: 'card' as const };

            mockStrategyCreateIntent.mockResolvedValue({
                sdkResult: {
                    pspReference: 'psp-456',
                    guid: 'pref-adyen-1',
                    resultCode: 'Authorised',
                },
                order: { orderNo: 'ORDER-ADYEN-2' },
            });
            mockCheckoutComponent.confirm.mockResolvedValue({
                responseCode: 0,
            });

            const { result } = renderWithRouter(() =>
                usePaymentMethodsCallbacks({
                    basket: mockBasket,
                    paymentConfig: mockPaymentConfig,
                    checkoutComponentRef,
                    paymentMethodTypeRef,
                    storePaymentMethodRef: { current: false },
                    futureUsageOffSession: false,
                    sitePrefix: '',
                    updateReturnUrl: vi.fn(),
                })
            );

            await result.current.createIntent();
            const confirmResult = await result.current.confirmPayment();

            expect(confirmResult.success).toBe(true);
            expect(confirmResult.orderNo).toBe('ORDER-ADYEN-2');
        });

        it('should return error when Adyen confirm fails (e.g. 3DS required)', async () => {
            const checkoutComponentRef = { current: mockCheckoutComponent };
            const paymentMethodTypeRef = { current: 'card' as const };

            mockStrategyCreateIntent.mockResolvedValue({
                sdkResult: {
                    pspReference: 'psp-789',
                    guid: 'pref-adyen-1',
                    resultCode: 'IdentifyShopper',
                    action: { type: 'redirect', url: 'https://adyen.test/3ds' },
                },
                order: { orderNo: 'ORDER-ADYEN-3' },
            });
            mockCheckoutComponent.confirm.mockResolvedValue({
                responseCode: 1,
                data: { error: 'Additional authentication required' },
            });

            const { result } = renderWithRouter(() =>
                usePaymentMethodsCallbacks({
                    basket: mockBasket,
                    paymentConfig: mockPaymentConfig,
                    checkoutComponentRef,
                    paymentMethodTypeRef,
                    storePaymentMethodRef: { current: false },
                    futureUsageOffSession: false,
                    sitePrefix: '',
                    updateReturnUrl: vi.fn(),
                })
            );

            await result.current.createIntent();
            const confirmResult = await result.current.confirmPayment();

            expect(confirmResult.success).toBe(false);
            expect(confirmResult.error).toBe('Additional authentication required');
        });
    });

    describe('getBillingAddress (host-persisted billing override)', () => {
        // Shopper-entered "use different billing" address returned by the
        // host's PaymentSubmissionRef.billingAddressGetter.
        const shopperBilling = {
            firstName: 'Alice',
            lastName: 'Smith',
            address1: '999 Bill St',
            address2: 'Apt 2',
            city: 'Oakland',
            stateCode: 'CA',
            postalCode: '94607',
            phone: '555-0000',
            countryCode: 'US',
        };

        it('shapes SDK billingDetails from the getter when it returns non-null', async () => {
            const checkoutComponentRef = { current: mockCheckoutComponent };
            const paymentMethodTypeRef = { current: 'card' as const };
            mockCheckoutComponent.confirm.mockResolvedValue({ responseCode: 0 });
            mockStrategyCreateIntent.mockResolvedValue({
                sdkResult: { client_secret: 'cs' },
                order: { orderNo: 'ORDER-BA-1' },
            });

            const { result } = renderWithRouter(() =>
                usePaymentMethodsCallbacks({
                    basket: mockBasket,
                    paymentConfig: mockPaymentConfig,
                    checkoutComponentRef,
                    paymentMethodTypeRef,
                    storePaymentMethodRef: { current: false },
                    futureUsageOffSession: false,
                    sitePrefix: '',
                    updateReturnUrl: vi.fn(),
                    getBillingAddress: () => shopperBilling,
                })
            );

            await result.current.createIntent();
            await result.current.confirmPayment();

            expect(mockCheckoutComponent.confirm).toHaveBeenCalledWith(
                null,
                expect.objectContaining({
                    email: 'test@example.com',
                    name: 'Alice Smith',
                    address: expect.objectContaining({
                        line1: '999 Bill St',
                        city: 'Oakland',
                        postalCode: '94607',
                    }),
                }),
                expect.any(Object)
            );
        });

        it('falls back to basket.billingAddress when the getter returns null', async () => {
            const checkoutComponentRef = { current: mockCheckoutComponent };
            const paymentMethodTypeRef = { current: 'card' as const };
            mockCheckoutComponent.confirm.mockResolvedValue({ responseCode: 0 });
            mockStrategyCreateIntent.mockResolvedValue({
                sdkResult: { client_secret: 'cs' },
                order: { orderNo: 'ORDER-BA-2' },
            });

            const { result } = renderWithRouter(() =>
                usePaymentMethodsCallbacks({
                    basket: mockBasket,
                    paymentConfig: mockPaymentConfig,
                    checkoutComponentRef,
                    paymentMethodTypeRef,
                    storePaymentMethodRef: { current: false },
                    futureUsageOffSession: false,
                    sitePrefix: '',
                    updateReturnUrl: vi.fn(),
                    getBillingAddress: () => null,
                })
            );

            await result.current.createIntent();
            await result.current.confirmPayment();

            expect(mockCheckoutComponent.confirm).toHaveBeenCalledWith(
                null,
                expect.objectContaining({ name: 'John Doe' }),
                expect.any(Object)
            );
        });
    });
});
