/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { describe, test, expect, vi, beforeEach } from 'vitest';
import { render, act } from '@testing-library/react';
import { createMemoryRouter, RouterProvider } from 'react-router';
import PaymentProcessingPage from './_checkout.payment-processing';

// --- Mocks ---

const mockNavigate = vi.fn();
vi.mock('@/hooks/use-navigate', () => ({ useNavigate: () => mockNavigate }));

const mockAddToast = vi.fn();
vi.mock('@/components/toast', () => ({ useToast: () => ({ addToast: mockAddToast }) }));

vi.mock('react-i18next', () => ({
    useTranslation: () => ({ t: (key: string) => key }),
}));

const mockSfpHandleRedirect = vi.fn();
vi.mock('../providers/sf-payments-provider', () => ({
    useSFPaymentsContext: () => ({ sfp: { handleRedirect: mockSfpHandleRedirect } }),
}));

const mockFailAndRecover = vi.fn().mockResolvedValue({ basketRecovered: true, orderNo: 'o1' });
vi.mock('../hooks/use-sf-payments-failure-recovery', () => ({
    useSFPaymentsFailureRecovery: () => ({ failAndRecover: mockFailAndRecover }),
}));

// useLoaderData returns whatever loaderData is set to for that route
function renderWithLoaderData(loaderData: unknown) {
    const router = createMemoryRouter([{ path: '/', element: <PaymentProcessingPage />, loader: () => loaderData }], {
        initialEntries: ['/'],
    });
    return render(<RouterProvider router={router} />);
}

beforeEach(() => {
    vi.clearAllMocks();
});

// ---

describe('PaymentProcessingPage — error state', () => {
    test('shows error toast before navigating to /checkout', async () => {
        renderWithLoaderData({ state: 'error' });
        await act(() => Promise.resolve());

        expect(mockAddToast).toHaveBeenCalledWith('sfPayments.paymentProcessing.errorDescription', 'error', {
            duration: 8000,
        });
        expect(mockNavigate).toHaveBeenCalledWith('/checkout');
    });

    test('toast fires before navigate (call order)', async () => {
        const callOrder: string[] = [];
        mockAddToast.mockImplementation(() => callOrder.push('toast'));
        mockNavigate.mockImplementation(() => callOrder.push('navigate'));

        renderWithLoaderData({ state: 'error' });
        await act(() => Promise.resolve());

        expect(callOrder).toEqual(['toast', 'navigate']);
    });

    test('does not navigate to confirmation', async () => {
        renderWithLoaderData({ state: 'error' });
        await act(() => Promise.resolve());

        expect(mockNavigate).not.toHaveBeenCalledWith(expect.stringContaining('order-confirmation'));
    });
});

describe('PaymentProcessingPage — success state', () => {
    test('navigates to /order-confirmation/:orderNo without toast', async () => {
        renderWithLoaderData({ state: 'success', orderNo: 'o1' });
        await act(() => Promise.resolve());

        expect(mockNavigate).toHaveBeenCalledWith('/order-confirmation/o1');
        expect(mockAddToast).not.toHaveBeenCalled();
    });
});

describe('PaymentProcessingPage — gateway-redirect state (Stripe client-side)', () => {
    test('navigates to confirmation when handleRedirect succeeds', async () => {
        mockSfpHandleRedirect.mockResolvedValue({ responseCode: 0 });

        renderWithLoaderData({ state: 'gateway-redirect', orderNo: 'o1', vendor: 'Stripe' });
        await act(() => Promise.resolve());

        expect(mockNavigate).toHaveBeenCalledWith('/order-confirmation/o1');
        expect(mockAddToast).not.toHaveBeenCalled();
    });

    test('shows error toast and navigates to /checkout when handleRedirect returns non-success', async () => {
        const callOrder: string[] = [];
        mockSfpHandleRedirect.mockResolvedValue({ responseCode: 1 });
        mockAddToast.mockImplementation(() => callOrder.push('toast'));
        mockNavigate.mockImplementation(() => callOrder.push('navigate'));

        renderWithLoaderData({ state: 'gateway-redirect', orderNo: 'o1', vendor: 'Stripe' });
        await act(() => Promise.resolve());

        expect(callOrder).toEqual(['toast', 'navigate']);
        expect(mockAddToast).toHaveBeenCalledWith('sfPayments.paymentProcessing.errorDescription', 'error', {
            duration: 8000,
        });
        expect(mockNavigate).toHaveBeenCalledWith('/checkout');
    });

    test('shows error toast and navigates to /checkout when handleRedirect throws', async () => {
        const callOrder: string[] = [];
        mockSfpHandleRedirect.mockRejectedValue(new Error('SDK error'));
        mockAddToast.mockImplementation(() => callOrder.push('toast'));
        mockNavigate.mockImplementation(() => callOrder.push('navigate'));

        renderWithLoaderData({ state: 'gateway-redirect', orderNo: 'o1', vendor: 'Stripe' });
        await act(() => Promise.resolve());

        expect(callOrder).toEqual(['toast', 'navigate']);
        expect(mockAddToast).toHaveBeenCalledWith('sfPayments.paymentProcessing.errorDescription', 'error', {
            duration: 8000,
        });
        expect(mockNavigate).toHaveBeenCalledWith('/checkout');
    });
});
