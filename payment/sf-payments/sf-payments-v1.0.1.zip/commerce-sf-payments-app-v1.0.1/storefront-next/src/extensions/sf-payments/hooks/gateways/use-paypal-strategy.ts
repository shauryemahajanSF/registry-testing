/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

'use client';

/**
 * PayPal gateway strategy hook.
 *
 * Flow:
 *   1. onClick skips prep — on the PayPal path the SDK creates the PayPal-side
 *      order on click before createIntent fires; prepping earlier would race it.
 *   2. createIntent: ensure the SF Payments PI is attached. No commerce
 *      order yet — PayPal needs the PI to exist so its paymentReference
 *      populates with the PayPal order ID. Returns `{ id }` for the SDK.
 *   3. onPayerApprove: wallet authorized; expand=paymentReference fetches
 *      the PayPal-side addresses and pushes them onto the basket.
 *   4. onApprove: create the commerce order + patch the final PI.
 */

import { useCallback } from 'react';
import { useFetcher } from 'react-router';
import type { ShopperBasketsV2, ShopperOrders } from '@/scapi';
import { useFetcherPromise } from '../use-fetcher-promise';
import { getSFPaymentsInstrument } from '../../lib/sf-payments-utils';
import type {
    ApproveArgs,
    CreateIntentArgs,
    CreateIntentResult,
    GatewayStrategy,
    PayerApproveArgs,
} from '../../lib/gateways/types';
import { submitCreateOrder } from './submit-create-order';

type Basket = ShopperBasketsV2.schemas['Basket'];
type Order = ShopperOrders.schemas['Order'];
type ActionResponse<T> = ({ success: true } & T) | { success: false; error?: string };

type EnsurePiResponse = ActionResponse<{ basket: Basket }>;
type ResolveAddressesResponse = ActionResponse<{ basket: Basket }>;
type CreateOrderResponse = ActionResponse<{ order: Order; orderNo?: string }>;

/**
 * PayPal-path createIntent payload. Local to this strategy — the
 * GatewayStrategy contract returns this as opaque `SdkIntentPayload`, so
 * consumers can't read fields off it. On the PayPal path the SDK reads
 * `id` as the paymentReferenceId.
 */
interface PaypalSdkIntentPayload {
    id: string;
}

/** Narrow a settled action-route response to its success branch. */
function assertSuccess<T extends { success: boolean; error?: string }>(
    result: T | undefined,
    fallbackMessage: string
): Extract<T, { success: true }> {
    if (!result) {
        throw new Error(fallbackMessage);
    }
    if (result.success !== true) {
        throw new Error(result.error || fallbackMessage);
    }
    return result as Extract<T, { success: true }>;
}

export function usePaypalStrategy(): GatewayStrategy {
    const ensurePiFetcher = useFetcher<EnsurePiResponse>();
    const resolveAddressesFetcher = useFetcher<ResolveAddressesResponse>();
    const createOrderFetcher = useFetcher<CreateOrderResponse>();

    const awaitEnsurePi = useFetcherPromise(ensurePiFetcher, 'ensure-pi failed');
    const awaitResolveAddresses = useFetcherPromise(resolveAddressesFetcher, 'resolve-paypal-addresses failed');
    const awaitCreateOrder = useFetcherPromise(createOrderFetcher, 'create-order failed');

    const createIntent = useCallback(
        async (args: CreateIntentArgs): Promise<CreateIntentResult> => {
            const { basket, paymentMethodType, paymentConfig, shippingPreference } = args;
            if (!basket.basketId) {
                throw new Error('PayPal createIntent: basket is missing a basketId');
            }

            const ensureForm = new FormData();
            ensureForm.set('basket', JSON.stringify(basket));
            ensureForm.set('paymentMethodType', paymentMethodType);
            ensureForm.set('paymentConfig', JSON.stringify(paymentConfig));
            if (shippingPreference) ensureForm.set('shippingPreference', shippingPreference);
            // PayPal needs a fresh `paymentReference.paymentReferenceId`. SCAPI
            // only returns it in the immediate addPaymentInstrument response, so
            // ensure-pi removes any stale PI and adds a new one.
            ensureForm.set('refreshPaymentReference', 'true');
            void ensurePiFetcher.submit(ensureForm, {
                method: 'POST',
                action: '/action/sf-payments-ensure-pi',
            });
            const ensured = assertSuccess(await awaitEnsurePi(), 'ensure-pi failed');

            const pi = getSFPaymentsInstrument(ensured.basket);
            const paymentReferenceId = (pi as { paymentReference?: { paymentReferenceId?: string } } | undefined)
                ?.paymentReference?.paymentReferenceId;
            if (!paymentReferenceId) {
                throw new Error('PayPal createIntent: basket is missing a paymentReferenceId');
            }

            const sdkResult: PaypalSdkIntentPayload = { id: paymentReferenceId };
            return { sdkResult };
        },
        [ensurePiFetcher, awaitEnsurePi]
    );

    const onPayerApprove = useCallback(
        async (args: PayerApproveArgs): Promise<Basket> => {
            const { basket, onProcessingStarted } = args;
            if (!basket.basketId) {
                throw new Error('PayPal onPayerApprove: basket is missing a basketId');
            }
            // Wallet authorized; addresses about to flow in. Signal
            // "processing started" before any network work begins.
            onProcessingStarted?.();

            const form = new FormData();
            form.set('basketId', basket.basketId);
            void resolveAddressesFetcher.submit(form, {
                method: 'POST',
                action: '/action/sf-payments-resolve-paypal-addresses',
            });
            const resolved = assertSuccess(await awaitResolveAddresses(), 'resolve-paypal-addresses failed');
            return resolved.basket;
        },
        [resolveAddressesFetcher, awaitResolveAddresses]
    );

    const onApprove = useCallback(
        async (args: ApproveArgs): Promise<Record<string, unknown>> => {
            const { basket, paymentMethodType, paymentConfig, baseUrl, skipPostOrderRevalidation } = args;
            if (!basket.basketId) {
                throw new Error('PayPal onApprove: basket is missing a basketId');
            }

            const orderForm = new FormData();
            orderForm.set('basketId', basket.basketId);
            orderForm.set('paymentMethodType', paymentMethodType);
            orderForm.set('paymentConfig', JSON.stringify(paymentConfig));
            orderForm.set('origin', baseUrl);

            const ordered = await submitCreateOrder({
                orderForm,
                fetcher: createOrderFetcher,
                awaitCreateOrder,
                skipPostOrderRevalidation,
            });

            const pi = getSFPaymentsInstrument(ordered.order);
            const paymentReferenceId = (pi as { paymentReference?: { paymentReferenceId?: string } } | undefined)
                ?.paymentReference?.paymentReferenceId;
            if (!paymentReferenceId) {
                throw new Error('PayPal onApprove: order is missing a paymentReferenceId');
            }
            return { order: ordered.order, orderNo: ordered.orderNo, paymentReferenceId };
        },
        [createOrderFetcher, awaitCreateOrder]
    );

    return {
        prepareBasketOnClick: false,
        createIntent,
        onPayerApprove,
        onApprove,
    };
}
