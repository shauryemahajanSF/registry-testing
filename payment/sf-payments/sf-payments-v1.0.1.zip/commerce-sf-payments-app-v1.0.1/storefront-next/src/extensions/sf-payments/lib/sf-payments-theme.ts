/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

export interface BuildThemeOptions {
    expressButtonLayout?: 'horizontal' | 'vertical';
}

/**
 * Reads a CSS custom property value from the document root.
 * Returns empty string on the server (SSR) — the SDK only runs client-side.
 */
function readCssVar(name: string): string {
    if (typeof window === 'undefined') return '';
    return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
}

/**
 * Returns a theme configuration object for the SF Payments SDK.
 *
 * Maps sfnext CSS custom properties to the SDK's designTokens shape so the
 * payment surfaces (checkout sheet and express buttons) match the active
 * storefront theme (light, dark, or any custom variant).
 *
 * Called at SDK mount time inside useEffect — reads the resolved CSS var
 * values for the theme that is active when the payment surface mounts.
 *
 * expressButtons defaults (shape, colors, labels) follow pwa-kit:
 * packages/template-retail-react-app/app/utils/sf-payments-utils.js
 */
export function buildTheme(options?: BuildThemeOptions) {
    return {
        designTokens: {
            'color-text-default': readCssVar('--foreground'),
            'color-text-error': readCssVar('--destructive'),
            'color-text-placeholder': readCssVar('--muted-foreground'),
            'color-text-weak': readCssVar('--muted-foreground'),
            'color-background': readCssVar('--background'),
            'color-brand': readCssVar('--primary'),
            'color-text-brand-primary': readCssVar('--primary-foreground'),
            'color-text-inverse': readCssVar('--primary-foreground'),
            'color-border-input': readCssVar('--input'),
            'font-family': readCssVar('--font-sans'),
        },
        expressButtons: {
            buttonLayout: options?.expressButtonLayout ?? 'vertical',
            buttonHeight: 44,
        },
    };
}
