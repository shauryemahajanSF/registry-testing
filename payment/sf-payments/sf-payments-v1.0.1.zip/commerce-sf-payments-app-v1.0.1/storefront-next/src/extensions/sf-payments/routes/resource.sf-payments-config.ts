/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

import type { LoaderFunctionArgs } from 'react-router';
import { siteContext } from '@salesforce/storefront-next-runtime/site-context';
import { createApiClients } from '@/lib/api-clients.server';
import { getLogger } from '@/lib/logger.server';
import { getLocaleDerivedCountryCode } from '../lib/sf-payments-country';

/**
 * Server-side resource route that fetches payment configuration
 * from the Shopper Payments SCAPI.
 *
 * Returns:
 * - zoneId: resolved payment zone
 * - paymentMethodSetAccounts: gateway accounts with publishable keys
 * - paymentMethods: available payment methods with supported modes
 *
 * Query Parameters (all optional — each falls back to the active site context):
 * - currency:    ISO 4217 currency code (e.g. "USD"). Falls back to the
 *                active site context currency resolved by
 *                createSiteContextMiddleware.
 * - countryCode: ISO 3166-1 alpha-2 (e.g. "US"). Falls back to the country
 *                subtag of the active locale (via getLocaleDerivedCountryCode).
 * - zoneId:      Specific zone override. No fallback — omitted if absent.
 *
 * Callers pass explicit overrides for basket/address-driven flows (checkout,
 * cart). Non-transactional surfaces (PDP, express buttons) can omit them and
 * rely on the active site context defaults.
 *
 * GET /resource/sf-payments-config?currency=USD&countryCode=US
 */
export async function loader({ request, context }: LoaderFunctionArgs) {
    try {
        const url = new URL(request.url);
        const activeSiteContext = context.get(siteContext);

        const currency = url.searchParams.get('currency') ?? activeSiteContext?.currency;
        const countryCode =
            url.searchParams.get('countryCode') ??
            (activeSiteContext?.locale ? getLocaleDerivedCountryCode(activeSiteContext.locale.id) : undefined);
        const zoneId = url.searchParams.get('zoneId') ?? undefined;

        if (!currency) {
            return Response.json(
                { error: 'currency is required (query param or active site context)' },
                { status: 400 }
            );
        }

        const clients = createApiClients(context);

        const { data } = await clients.shopperPayments.getPaymentConfiguration({
            params: {
                query: {
                    currency,
                    ...(countryCode && { countryCode }),
                    ...(zoneId && { zoneId }),
                },
            },
        });

        return Response.json(data);
    } catch (error) {
        getLogger(context).error('[sf-payments] fetch payment configuration failed', {
            message: error instanceof Error ? error.message : String(error),
        });

        return Response.json(
            {
                error: 'Failed to fetch payment configuration',
                details: error instanceof Error ? error.message : 'Unknown error',
            },
            { status: 500 }
        );
    }
}
