/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

import { type ActionFunctionArgs, data } from 'react-router';
import { ApiError, type ShopperBasketsV2 } from '@/scapi';
import { getLogger } from '@/lib/logger.server';
import {
    getShippingMethodsForShipment,
    patchPaymentInstrumentOnBasket,
    updateShippingAddressForShipment,
    validateAndUpdateShippingMethod,
} from '../lib/api/basket-mutations.server';
import {
    buildExpressCallbackData,
    buildPaypalPatchSync,
    createPaymentInstrumentBody,
    getSFPaymentsInstrument,
    type ExpressCallbackLabels,
    type PaymentMethodType,
} from '../lib/sf-payments-utils';
import type { PaymentConfig } from '../lib/api/types';

type OrderAddress = ShopperBasketsV2.schemas['OrderAddress'];

const DEFAULT_SHIPMENT_ID = 'me';

/**
 * Update the shipping address on an express basket, refresh the applicable
 * shipping methods, validate/switch the selected method if needed, then
 * compute the express callback payload (total, methods, line items) the SDK
 * expects as the response to `onShippingAddressChange`.
 *
 * POST body (FormData):
 *   basketId: string (required)
 *   shippingAddress: JSON-stringified OrderAddress (required)
 *   labels: JSON-stringified ExpressCallbackLabels (required) — translated line-item labels
 *   shipmentId: string (optional, defaults to 'me')
 */
export async function action({ request, context }: ActionFunctionArgs) {
    if (request.method !== 'POST') {
        return data({ success: false, error: 'Method not allowed' }, { status: 405 });
    }

    const logger = getLogger(context);
    let basketId: string | undefined;
    try {
        const formData = await request.formData();
        basketId = formData.get('basketId')?.toString();
        const shippingAddressRaw = formData.get('shippingAddress')?.toString();
        const labelsRaw = formData.get('labels')?.toString();
        const shipmentId = formData.get('shipmentId')?.toString() || DEFAULT_SHIPMENT_ID;
        const paymentMethodType = formData.get('paymentMethodType')?.toString() as PaymentMethodType | undefined;
        const paymentConfigRaw = formData.get('paymentConfig')?.toString();

        if (!basketId || !shippingAddressRaw || !labelsRaw) {
            return data(
                { success: false, error: 'basketId, shippingAddress, and labels are required' },
                { status: 400 }
            );
        }

        const shippingAddress = JSON.parse(shippingAddressRaw) as OrderAddress;
        const labels = JSON.parse(labelsRaw) as ExpressCallbackLabels;

        const afterAddress = await updateShippingAddressForShipment(context, basketId, shipmentId, shippingAddress);
        const methodsResult = await getShippingMethodsForShipment(context, basketId, shipmentId);
        let basket = await validateAndUpdateShippingMethod(
            context,
            afterAddress,
            {
                applicableShippingMethods: (methodsResult.applicableShippingMethods ?? []) as Array<{ id: string }>,
                defaultShippingMethodId: methodsResult.defaultShippingMethodId,
            },
            shipmentId
        );

        // PATCH the SF Payments PI so the server pushes the recomputed
        // basket (tax + shipping options + total) out to the gateway.
        // The PI was POSTed earlier by ensurePaymentInstrumentInBasket
        // when the wallet's createIntent fired. Only runs when a PI is
        // already on the basket — Stripe and Adyen express attach the PI
        // after createIntent, so they skip this branch.
        const pi = getSFPaymentsInstrument(basket);
        if (pi?.paymentInstrumentId && paymentMethodType && paymentConfigRaw) {
            const paymentConfig = JSON.parse(paymentConfigRaw) as PaymentConfig;
            const amount = basket.orderTotal ?? basket.productSubTotal ?? pi.amount;
            const paypalPatchSync = buildPaypalPatchSync(
                basket,
                methodsResult.applicableShippingMethods as Array<{ id?: string; name?: string; price?: number }>
            );
            // Bail with a sync error rather than send a malformed PATCH — the wallet treats it as transient.
            if (typeof amount !== 'number' || !paymentConfig.zoneId || !paypalPatchSync) {
                return data({ success: false, error: 'gateway_sync_failed' }, { status: 500 });
            }
            const body = createPaymentInstrumentBody({
                amount,
                paymentMethodType,
                zoneId: paymentConfig.zoneId,
                paymentMethods: paymentConfig.paymentMethods,
                paymentMethodSetAccounts: paymentConfig.paymentMethodSetAccounts,
                paypalPatchSync,
            });
            try {
                basket = await patchPaymentInstrumentOnBasket(
                    context,
                    basketId,
                    pi.paymentInstrumentId,
                    body as unknown as ShopperBasketsV2.schemas['OrderPaymentInstrument']
                );
            } catch (error) {
                const isApiError = error instanceof ApiError;
                logger.error('[sf-payments] gateway sync (PATCH PI) failed on shipping-address update', {
                    basketId,
                    ...(isApiError ? error.toJSON() : { message: String(error) }),
                });
                return data({ success: false, error: 'gateway_sync_failed' }, { status: 500 });
            }
        }

        const callbackData = buildExpressCallbackData(
            basket,
            {
                applicableShippingMethods: (methodsResult.applicableShippingMethods ?? []) as Array<{
                    id: string;
                    name: string;
                    description?: string;
                    price: number;
                }>,
            },
            labels
        );
        return { success: true, basket, callbackData };
    } catch (error) {
        const isApiError = error instanceof ApiError;
        logger.error('[sf-payments] update-shipping-address failed', {
            basketId,
            ...(isApiError ? error.toJSON() : { message: String(error) }),
        });
        return data(
            { success: false, error: isApiError ? error.body?.detail || error.message : String(error) },
            { status: isApiError ? error.status : 500 }
        );
    }
}
