/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { beforeEach, describe, expect, test, vi } from 'vitest';
import type { RouterContextProvider } from 'react-router';
import { action } from './action.sf-payments-push-addresses';
import {
    updateBillingAddressForBasket,
    updateCustomerForBasket,
    updateShippingAddressForShipment,
} from '../lib/api/basket-mutations.server';

vi.mock('../lib/api/basket-mutations.server', () => ({
    updateBillingAddressForBasket: vi.fn(),
    updateCustomerForBasket: vi.fn(),
    updateShippingAddressForShipment: vi.fn(),
}));

vi.mock('@/lib/logger.server', () => ({
    getLogger: vi.fn(() => ({ error: vi.fn(), info: vi.fn(), warn: vi.fn() })),
}));

const mockContext = { get: vi.fn(), set: vi.fn() } as unknown as RouterContextProvider;

function statusOf(result: unknown): number | undefined {
    return (result as { init?: { status?: number } })?.init?.status;
}

function dataOf(result: unknown): { success: boolean; error?: string; basket?: unknown } {
    const d = (result as { data?: unknown })?.data;
    return (d ?? result) as { success: boolean; error?: string; basket?: unknown };
}

const SHIPPING = {
    firstName: 'Jane',
    lastName: 'Doe',
    address1: '1 Ship Ln',
    city: 'SF',
    stateCode: 'CA',
    postalCode: '94105',
    countryCode: 'US',
};

const BILLING = {
    firstName: 'Jane',
    lastName: 'Doe',
    address1: '999 Bill St',
    city: 'Oakland',
    stateCode: 'CA',
    postalCode: '94607',
    countryCode: 'US',
};

function makeRequest(fields: Record<string, string>, method = 'POST') {
    const form = new FormData();
    for (const [k, v] of Object.entries(fields)) form.set(k, v);
    const canHaveBody = method !== 'GET' && method !== 'HEAD';
    return new Request('https://shop.example/action/sf-payments-push-addresses', {
        method,
        ...(canHaveBody && { body: form }),
    });
}

beforeEach(() => {
    vi.clearAllMocks();
});

describe('action.sf-payments-push-addresses', () => {
    test('returns 405 for non-POST', async () => {
        const result = await action({
            request: makeRequest({}, 'GET'),
            context: mockContext,
            params: {},
        } as any);
        expect(statusOf(result)).toBe(405);
        expect(dataOf(result).success).toBe(false);
    });

    test('returns 400 when neither shipping nor billing is provided', async () => {
        const result = await action({
            request: makeRequest({ basketId: 'b1' }),
            context: mockContext,
            params: {},
        } as any);
        expect(statusOf(result)).toBe(400);
        const body = dataOf(result);
        expect(body.success).toBe(false);
        expect(body.error).toMatch(/at least one of shippingAddress or billingAddress/i);
    });

    test('returns 400 when basketId is missing', async () => {
        const result = await action({
            request: makeRequest({ shippingAddress: JSON.stringify(SHIPPING) }),
            context: mockContext,
            params: {},
        } as any);
        expect(statusOf(result)).toBe(400);
        expect(dataOf(result).success).toBe(false);
    });

    test('shipping-only path pushes shipping and skips billing (express first-half contract)', async () => {
        const shippedBasket = { basketId: 'b1', shipments: [{ shippingAddress: SHIPPING }] };
        vi.mocked(updateShippingAddressForShipment).mockResolvedValue(shippedBasket as never);

        const result = await action({
            request: makeRequest({
                basketId: 'b1',
                shippingAddress: JSON.stringify(SHIPPING),
            }),
            context: mockContext,
            params: {},
        } as any);

        expect(updateShippingAddressForShipment).toHaveBeenCalledWith(mockContext, 'b1', 'me', SHIPPING);
        expect(updateBillingAddressForBasket).not.toHaveBeenCalled();
        expect(updateCustomerForBasket).not.toHaveBeenCalled();
        const body = dataOf(result);
        expect(body.success).toBe(true);
        expect(body.basket).toEqual(shippedBasket);
    });

    test('billing-only path pushes billing and skips shipping (sheet contract)', async () => {
        const billedBasket = { basketId: 'b1', billingAddress: BILLING };
        vi.mocked(updateBillingAddressForBasket).mockResolvedValue(billedBasket as never);

        const result = await action({
            request: makeRequest({
                basketId: 'b1',
                billingAddress: JSON.stringify(BILLING),
            }),
            context: mockContext,
            params: {},
        } as any);

        expect(updateBillingAddressForBasket).toHaveBeenCalledWith(mockContext, 'b1', BILLING);
        expect(updateShippingAddressForShipment).not.toHaveBeenCalled();
        expect(updateCustomerForBasket).not.toHaveBeenCalled();
        const body = dataOf(result);
        expect(body.success).toBe(true);
        expect(body.basket).toEqual(billedBasket);
    });

    test('both-addresses path pushes shipping then billing (express full contract)', async () => {
        const afterShipping = { basketId: 'b1', shipments: [{ shippingAddress: SHIPPING }] };
        const afterBilling = { basketId: 'b1', billingAddress: BILLING };
        vi.mocked(updateShippingAddressForShipment).mockResolvedValue(afterShipping as never);
        vi.mocked(updateBillingAddressForBasket).mockResolvedValue(afterBilling as never);

        const result = await action({
            request: makeRequest({
                basketId: 'b1',
                shippingAddress: JSON.stringify(SHIPPING),
                billingAddress: JSON.stringify(BILLING),
            }),
            context: mockContext,
            params: {},
        } as any);

        expect(updateShippingAddressForShipment).toHaveBeenCalledWith(mockContext, 'b1', 'me', SHIPPING);
        expect(updateBillingAddressForBasket).toHaveBeenCalledWith(mockContext, 'b1', BILLING);
        // last write wins — returned basket is the post-billing one
        expect(dataOf(result).basket).toEqual(afterBilling);
    });

    test('email is applied after addresses when provided', async () => {
        const afterShipping = { basketId: 'b1' };
        const afterEmail = { basketId: 'b1', customerInfo: { email: 'shopper@example.com' } };
        vi.mocked(updateShippingAddressForShipment).mockResolvedValue(afterShipping as never);
        vi.mocked(updateCustomerForBasket).mockResolvedValue(afterEmail as never);

        const result = await action({
            request: makeRequest({
                basketId: 'b1',
                shippingAddress: JSON.stringify(SHIPPING),
                email: 'shopper@example.com',
            }),
            context: mockContext,
            params: {},
        } as any);

        expect(updateCustomerForBasket).toHaveBeenCalledWith(mockContext, 'b1', 'shopper@example.com');
        expect(dataOf(result).basket).toEqual(afterEmail);
    });

    test('shipmentId override is honored', async () => {
        vi.mocked(updateShippingAddressForShipment).mockResolvedValue({ basketId: 'b1' } as never);

        await action({
            request: makeRequest({
                basketId: 'b1',
                shippingAddress: JSON.stringify(SHIPPING),
                shipmentId: 'pickup',
            }),
            context: mockContext,
            params: {},
        } as any);

        expect(updateShippingAddressForShipment).toHaveBeenCalledWith(mockContext, 'b1', 'pickup', SHIPPING);
    });
});
