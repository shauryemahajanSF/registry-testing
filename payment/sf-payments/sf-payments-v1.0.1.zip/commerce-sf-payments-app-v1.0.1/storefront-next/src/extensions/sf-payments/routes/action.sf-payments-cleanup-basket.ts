/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

import { type ActionFunctionArgs, data } from 'react-router';
import { ApiError, type ShopperBasketsV2 } from '@/scapi';
import { getLogger } from '@/lib/logger.server';
import { cleanupExpressBasket } from '../lib/api/basket-mutations.server';

type Basket = ShopperBasketsV2.schemas['Basket'];

/**
 * Cleanup an express basket after cancellation or error. Removes the SF
 * Payments instrument (if present) and deletes the temp basket — no-op if the
 * commerce order was already created (the basket is consumed at that point).
 *
 * @remarks Express-only — do not call for the main basket. The caller
 *   (use-express-callbacks) knows which basket to clean from its own refs.
 *
 * POST body (FormData):
 *   basket: JSON-stringified Basket (required) — snapshot with paymentInstruments
 *   orderWasCreated: 'true' | 'false' (required)
 */
export async function action({ request, context }: ActionFunctionArgs) {
    if (request.method !== 'POST') {
        return data({ success: false, error: 'Method not allowed' }, { status: 405 });
    }

    const logger = getLogger(context);
    let basket: Basket | undefined;
    try {
        const formData = await request.formData();
        const basketRaw = formData.get('basket')?.toString();
        const orderWasCreatedRaw = formData.get('orderWasCreated')?.toString();

        if (!basketRaw || orderWasCreatedRaw === undefined) {
            return data({ success: false, error: 'basket and orderWasCreated are required' }, { status: 400 });
        }

        basket = JSON.parse(basketRaw) as Basket;
        const orderWasCreated = orderWasCreatedRaw === 'true';

        await cleanupExpressBasket(context, basket, orderWasCreated);
        return { success: true };
    } catch (error) {
        const isApiError = error instanceof ApiError;
        logger.error('[sf-payments] cleanup-basket failed', {
            basketId: basket?.basketId,
            ...(isApiError ? error.toJSON() : { message: String(error) }),
        });
        return data(
            { success: false, error: isApiError ? error.body?.detail || error.message : String(error) },
            { status: isApiError ? error.status : 500 }
        );
    }
}
