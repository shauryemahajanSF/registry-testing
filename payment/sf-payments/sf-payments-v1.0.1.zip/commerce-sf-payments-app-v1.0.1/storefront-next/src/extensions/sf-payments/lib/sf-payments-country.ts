/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

/**
 * Derives an ISO 3166-1 alpha-2 country code from a BCP 47 locale tag.
 * e.g. "en-US" → "US", "fr-FR" → "FR", "ja-JP" → "JP".
 *
 * The input is required to be a populated locale string — `useSite()` and the
 * site-context middleware both guarantee this upstream, so callers should
 * always have a real value.
 *
 * Throws when the locale has no region subtag (e.g. "en", "fr"). This matches
 * how the site-context middleware handles locale misconfiguration in
 * `middlewares/site-context.server.ts` — throw loudly at the source rather
 * than silently defaulting, so a merchant configuring a language-only locale
 * sees a clear error at runtime instead of a shopper being quietly routed
 * through the wrong regional payment gateways.
 *
 * Currency is NOT derived here — callers source currency from the basket,
 * product, or site context, which is the authoritative per-transaction value.
 *
 * Typical caller preference order:
 *   1. Basket / order shipping address country (when available)
 *   2. config.site.locale → this helper
 */
export function getLocaleDerivedCountryCode(locale: string): string {
    const parts = locale.split('-');
    if (parts.length >= 2 && parts[1]) {
        return parts[1].toUpperCase();
    }
    throw new Error(
        `Cannot derive country code from locale "${locale}". ` +
            `Expected a BCP 47 tag with a region subtag (e.g. "en-US"). ` +
            `Check your site's supportedLocales configuration.`
    );
}
