/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

'use client';

import { useEffect, useRef, useState, type ReactNode } from 'react';
import { useFetcher } from 'react-router';
import { useTranslation } from 'react-i18next';
import { useAccountPaymentMethodsListActions } from '@/components/payment-methods/account-payment-methods-list-context';
import { RemovePaymentMethodDialog } from '@/components/payment-methods/remove-payment-method-dialog';
import { useSFPaymentsContext } from '../../providers/sf-payments-provider';
import type { AccountSavedPaymentMethod } from '../../lib/account-saved-payment-methods';
import {
    ACCOUNT_SAVED_METHODS_FETCHER_KEY,
    ACCOUNT_SAVED_METHODS_RESOURCE,
} from '../../lib/account-saved-methods-fetchers';
import { AccountPaymentMethodCard } from './account-payment-method-card';
import { toHostPaymentMethod } from './to-host-payment-method';

interface AccountSavedMethodsSuccess {
    methods: AccountSavedPaymentMethod[];
}

interface AccountSavedMethodsError {
    error: string;
}

type AccountSavedMethodsResponse = AccountSavedMethodsSuccess | AccountSavedMethodsError;

type RemoveAccountSavedMethodResult = { success: true } | { success: false; error: string };

function isErrorResponse(data: AccountSavedMethodsResponse | undefined): data is AccountSavedMethodsError {
    return Boolean(data && 'error' in data);
}

function ListSkeleton({ label }: { label: string }) {
    return (
        <div
            className="space-y-6 py-2"
            data-testid="account-saved-payment-methods-loading"
            role="status"
            aria-live="polite"
            aria-busy="true"
            aria-label={label}>
            {[1, 2].map((i) => (
                <div key={i} className="rounded-ui border border-border bg-card p-6 animate-pulse">
                    <div className="h-5 w-48 mb-2 rounded-ui bg-muted" />
                    <div className="h-4 w-64 mb-4 rounded-ui bg-muted" />
                    <div className="h-4 w-16 rounded-ui bg-muted" />
                </div>
            ))}
        </div>
    );
}

/**
 * CAP My Account saved payment methods list (US-1 + US-2 remove).
 *
 * Registered at `sfcc.accountPaymentOptions.payments.savedPaymentMethods`.
 * When SFP is disabled, renders host children (native instruments + native remove).
 * When enabled, replaces children with the all-zone SFP reference list and deletes
 * via `deleteCustomerPaymentMethodReference` (never native payment-method-remove).
 */
export default function AccountSavedPaymentMethods({ children }: { children?: ReactNode }) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { t } = useTranslation('extSfPayments' as any);
    const { enabled, metadataLoading } = useSFPaymentsContext();
    const listActions = useAccountPaymentMethodsListActions();
    // Shared list key so Add (and Remove) can reload without call-order fetcher mocks.
    const listFetcher = useFetcher<AccountSavedMethodsResponse>({ key: ACCOUNT_SAVED_METHODS_FETCHER_KEY });
    const removeFetcher = useFetcher<RemoveAccountSavedMethodResult>({
        key: 'sf-payments-account-remove-saved-method',
    });
    const [pendingRemove, setPendingRemove] = useState<AccountSavedPaymentMethod | null>(null);
    const [removeError, setRemoveError] = useState<string | null>(null);
    const handledRemoveResultRef = useRef<RemoveAccountSavedMethodResult | null>(null);

    const listFetcherLoad = listFetcher.load;
    useEffect(() => {
        if (enabled) {
            void listFetcherLoad(ACCOUNT_SAVED_METHODS_RESOURCE);
        }
    }, [enabled, listFetcherLoad]);

    // Handle remove action result once per response (fetcher.data persists across renders).
    useEffect(() => {
        if (removeFetcher.state !== 'idle' || !removeFetcher.data) return;
        if (handledRemoveResultRef.current === removeFetcher.data) return;
        handledRemoveResultRef.current = removeFetcher.data;

        if (removeFetcher.data.success) {
            setPendingRemove(null);
            setRemoveError(null);
            void listFetcherLoad(ACCOUNT_SAVED_METHODS_RESOURCE);
            return;
        }

        setPendingRemove(null);
        setRemoveError(t('accountSavedPaymentMethods.removeFailed'));
    }, [removeFetcher.state, removeFetcher.data, listFetcherLoad, t]);

    if (metadataLoading) {
        return <ListSkeleton label={t('accountSavedPaymentMethods.loading')} />;
    }

    if (!enabled) {
        return <>{children}</>;
    }

    // Initial load only — keep the list visible while refreshing after delete.
    const isInitialLoading = listFetcher.data === undefined;
    if (isInitialLoading) {
        return <ListSkeleton label={t('accountSavedPaymentMethods.loading')} />;
    }

    if (isErrorResponse(listFetcher.data)) {
        return (
            <div
                className="rounded-ui border border-destructive/40 bg-destructive/10 px-4 py-3 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"
                data-testid="account-saved-payment-methods-unavailable"
                role="alert"
                aria-live="assertive">
                <p className="text-sm text-foreground">{t('accountSavedPaymentMethods.unavailable')}</p>
                <button
                    type="button"
                    className="inline-flex shrink-0 items-center justify-center rounded-ui border border-border bg-background px-4 py-2 text-sm font-medium text-foreground hover:bg-muted cursor-pointer"
                    onClick={() => void listFetcher.load(ACCOUNT_SAVED_METHODS_RESOURCE)}>
                    {t('accountSavedPaymentMethods.retry')}
                </button>
            </div>
        );
    }

    const methods = listFetcher.data?.methods ?? [];
    const isRemoving = removeFetcher.state !== 'idle';

    const confirmRemove = () => {
        if (!pendingRemove || isRemoving) return;
        handledRemoveResultRef.current = null;
        setRemoveError(null);
        void removeFetcher.submit(
            {
                paymentMethodReferenceId: pendingRemove.id,
                accountId: pendingRemove.accountId,
            },
            { method: 'POST', action: '/action/sf-payments-account-remove-saved-method' }
        );
    };

    if (methods.length === 0) {
        return (
            <div className="py-8 text-center" data-testid="account-saved-payment-methods-empty" role="status">
                <div className="flex flex-col items-center gap-4">
                    <div className="text-muted-foreground">
                        <p className="text-sm font-medium">{t('accountSavedPaymentMethods.empty')}</p>
                        <p className="text-sm mt-1">{t('accountSavedPaymentMethods.emptyHint')}</p>
                    </div>
                    <button
                        type="button"
                        className="inline-flex items-center justify-center rounded-ui border border-border bg-background px-4 py-2 text-sm font-medium text-foreground hover:bg-muted cursor-pointer"
                        onClick={() => listActions?.openAdd()}
                        data-testid="account-saved-payment-methods-add-cta">
                        {t('accountSavedPaymentMethods.addCta')}
                    </button>
                </div>
            </div>
        );
    }

    return (
        <>
            {removeError ? (
                <div
                    className="mb-4 rounded-ui border border-destructive/40 bg-destructive/10 px-4 py-3"
                    data-testid="account-saved-payment-methods-remove-error"
                    role="alert"
                    aria-live="assertive">
                    <p className="text-sm text-foreground">{removeError}</p>
                </div>
            ) : null}

            <div className="space-y-6" data-testid="account-saved-payment-methods-list">
                {methods.map((method) => (
                    <AccountPaymentMethodCard
                        key={method.id}
                        method={method}
                        onRemove={() => {
                            setRemoveError(null);
                            setPendingRemove(method);
                        }}
                    />
                ))}
            </div>

            {/* Same shell/CTA styling as native My Account remove — host owns account-destructive tokens. */}
            <RemovePaymentMethodDialog
                open={pendingRemove !== null}
                onOpenChange={(open) => {
                    if (!open && !isRemoving) setPendingRemove(null);
                }}
                paymentMethod={pendingRemove ? toHostPaymentMethod(pendingRemove) : null}
                onConfirm={() => confirmRemove()}
                isLoading={isRemoving}
            />
        </>
    );
}
