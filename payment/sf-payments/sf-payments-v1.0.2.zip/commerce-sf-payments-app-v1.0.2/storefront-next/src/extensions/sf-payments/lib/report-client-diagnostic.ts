/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

'use client';

import type { ClientDiagnosticSignal } from './client-diagnostic-signals';

export interface ReportClientDiagnosticArgs {
    signal: ClientDiagnosticSignal;
    /** Host request correlation ID — sent as `x-correlation-id` so middleware binds MRT logs. */
    correlationId?: string;
    metadata?: Record<string, unknown>;
}

/**
 * Fire-and-forget POST of a browser diagnostic to MRT via
 * `/action/sf-payments-report-diagnostic`. Never throws — payment failure
 * recovery must not depend on telemetry succeeding.
 */
export function reportClientDiagnostic({ signal, correlationId, metadata }: ReportClientDiagnosticArgs): void {
    try {
        const form = new FormData();
        form.set('signal', signal);
        if (metadata) {
            form.set('metadata', JSON.stringify(metadata));
        }
        // Header (not FormData): correlation middleware binds before the action runs.
        const headers = correlationId ? { 'x-correlation-id': correlationId } : undefined;
        void fetch('/action/sf-payments-report-diagnostic', {
            method: 'POST',
            body: form,
            headers,
            keepalive: true,
        }).catch(() => {
            // Telemetry must not surface to the shopper path.
        });
    } catch {
        // Same: never disrupt Place Order / approve failure handling.
    }
}
