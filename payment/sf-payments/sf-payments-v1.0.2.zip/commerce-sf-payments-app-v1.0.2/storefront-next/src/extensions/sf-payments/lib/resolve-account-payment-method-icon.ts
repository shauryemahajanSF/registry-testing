/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

type MetadataImage = { src?: string; mode?: string; variant?: string };
type PaymentMethodTypeEntry = { images?: MetadataImage[] };
type PaymentInstrumentTypeEntry = { apiValue?: string };
type CardMapping = {
    paymentMethodType?: string;
    variantPaymentMethodTypes?: Record<string, string>;
};
type GatewayEntry = {
    paymentMethodMappings?: Record<string, CardMapping>;
};

/** Minimal fields needed to resolve an icon — intentionally wider than today's list model. */
export type AccountPaymentMethodIconSource = {
    /** Wire / API type, e.g. `card`, `sepa_debit`, `affirm`, `klarna`. */
    type: string;
    /** Card network when `type` is `card` (visa, mc, cup, …). */
    brand?: string | null;
};

/**
 * Picks the default (non-dark) image src for a paymentMethodTypes entry.
 * Metadata from `/resource/sf-payments-metadata` already rewrites `/icons/…`
 * to absolute Commerce Cloud static URLs.
 */
function pickDefaultImageSrc(entry: PaymentMethodTypeEntry | undefined): string | undefined {
    const images = entry?.images ?? [];
    const light = images.find((image) => !image.mode && !image.variant) ?? images.find((image) => !image.mode);
    return light?.src || images[0]?.src;
}

/**
 * Same as sfp MetadataReader.getPaymentInstrumentTypeName: map API type
 * (`sepa_debit`, `affirm`, …) → metadata key (`SepaDebit`, `Affirm`, …).
 */
function getPaymentInstrumentTypeName(
    paymentInstrumentTypes: Record<string, PaymentInstrumentTypeEntry> | undefined,
    apiType: string
): string | undefined {
    if (!paymentInstrumentTypes || !apiType) return undefined;
    for (const [name, entry] of Object.entries(paymentInstrumentTypes)) {
        if (entry.apiValue === apiType) return name;
    }
    return undefined;
}

/**
 * Card-network icon via gateway variant maps (Stripe + Adyen aliases like mc/cup/maestro).
 */
function resolveCardBrandIconUrl(
    paymentMethodTypes: Record<string, PaymentMethodTypeEntry>,
    gateways: Record<string, GatewayEntry> | undefined,
    brand: string
): string | undefined {
    const normalized = brand.trim().toLowerCase();
    if (!normalized) {
        return pickDefaultImageSrc(paymentMethodTypes.Card);
    }

    for (const gateway of Object.values(gateways ?? {})) {
        for (const mapping of Object.values(gateway.paymentMethodMappings ?? {})) {
            if (mapping.paymentMethodType !== 'Card') continue;
            const typeName = mapping.variantPaymentMethodTypes?.[normalized];
            if (!typeName) continue;
            return pickDefaultImageSrc(paymentMethodTypes[typeName]) ?? pickDefaultImageSrc(paymentMethodTypes.Card);
        }
    }

    return pickDefaultImageSrc(paymentMethodTypes.Card);
}

/**
 * Resolves a payment-method icon URL from SFP metadata (same maps sfp.js uses).
 *
 * - Non-card types (`sepa_debit`, `affirm`, `klarna`, …): `paymentInstrumentTypes.apiValue`
 *   → `paymentMethodTypes[name].images` (SDK `getPaymentMethodIconUrl`).
 * - `card`: gateway `variantPaymentMethodTypes` brand lookup (SDK `getVariantPaymentMethodIconUrl`).
 */
export function resolveAccountPaymentMethodIconUrl(
    metadata: Record<string, unknown> | null | undefined,
    method: AccountPaymentMethodIconSource
): string | undefined {
    if (!metadata) return undefined;

    const paymentMethodTypes = metadata.paymentMethodTypes as Record<string, PaymentMethodTypeEntry> | undefined;
    if (!paymentMethodTypes) return undefined;

    const apiType = method.type.trim().toLowerCase();
    const instrumentTypeName = getPaymentInstrumentTypeName(
        metadata.paymentInstrumentTypes as Record<string, PaymentInstrumentTypeEntry> | undefined,
        apiType
    );

    // Card (or unknown type that still carries a brand): network variant lookup.
    if (apiType === 'card' || instrumentTypeName === 'Card') {
        return resolveCardBrandIconUrl(
            paymentMethodTypes,
            metadata.gateways as Record<string, GatewayEntry> | undefined,
            method.brand ?? ''
        );
    }

    // sepa_debit, affirm, klarna, … — type → paymentMethodTypes images.
    if (instrumentTypeName) {
        return pickDefaultImageSrc(paymentMethodTypes[instrumentTypeName]);
    }

    return undefined;
}
