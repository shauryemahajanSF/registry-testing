/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

import { type ActionFunctionArgs, data } from 'react-router';
import { ApiError } from '@/scapi';
import { createApiClients } from '@/lib/api-clients.server';
import { getAuth } from '@/middlewares/auth.server';
import { getLogger } from '@/lib/logger.server';

export type AccountSetupVendor = 'stripe' | 'adyen';

export type SetupAccountSavedMethodSuccess =
    | {
          success: true;
          vendor: 'stripe';
          paymentMethodReferenceSetupId: string;
          /** Stripe SetupIntent client secret for `sfp.setup()` confirmation. */
          clientSecret: string;
      }
    | {
          success: true;
          vendor: 'adyen';
          paymentMethodReferenceSetupId: string;
          /**
           * Adyen zero-auth result. SDK treats `Authorised` as success.
           * Complete is unsupported for Adyen — setup alone stores the method.
           */
          resultCode: string;
      };

export type SetupAccountSavedMethodFailure = {
    success: false;
    error: string;
};

export type SetupAccountSavedMethodResult = SetupAccountSavedMethodSuccess | SetupAccountSavedMethodFailure;

/** Duck-type SCAPI status — runtime ApiError may differ from the CAP stub in tests. */
function scapiErrorMeta(error: unknown): Record<string, unknown> {
    if (error instanceof ApiError) {
        return {
            scapiStatus: error.status,
            scapiTitle: error.body?.title,
            scapiDetail: error.body?.detail,
            scapiType: error.body?.type,
            // Truncate — enough to diagnose scope/zone/entitlement without dumping secrets.
            scapiRawBody: error.rawBody?.slice(0, 500) || undefined,
        };
    }
    if (error && typeof error === 'object' && 'status' in error) {
        const e = error as {
            status?: number;
            body?: { title?: string; detail?: string; type?: string };
            rawBody?: string;
            message?: string;
        };
        return {
            scapiStatus: e.status,
            scapiTitle: e.body?.title,
            scapiDetail: e.body?.detail,
            scapiType: e.body?.type,
            scapiRawBody: e.rawBody?.slice(0, 500) || undefined,
            message: e.message,
        };
    }
    return { message: error instanceof Error ? error.message : String(error) };
}

const SETUP_REQUIRED_SCOPE = 'sfcc.shopper-myaccount.paymentinstruments.rw';

/** Adyen Web scheme fields commerce accepts on setup (AdyenSavedPaymentMethodService). */
const ADYEN_CARD_PAYMENT_METHOD_FIELDS = new Set([
    'type',
    'encryptedCardNumber',
    'encryptedExpiryMonth',
    'encryptedExpiryYear',
    'encryptedSecurityCode',
    'holderName',
    'brand',
    'checkoutAttemptId',
]);

const ADYEN_REQUIRED_CARD_FIELDS = ['encryptedCardNumber', 'encryptedExpiryMonth', 'encryptedExpiryYear'] as const;

/**
 * Decode JWT `scp` without verifying the signature — diagnostic only.
 * Never log the raw token.
 */
function paymentScopeDiagnostics(accessToken: string | undefined): Record<string, unknown> {
    if (!accessToken || typeof accessToken !== 'string') {
        return { tokenScopesAvailable: false };
    }
    try {
        const payloadPart = accessToken.split('.')[1];
        if (!payloadPart) return { tokenScopesAvailable: false };
        const base64 = payloadPart.replace(/-/g, '+').replace(/_/g, '/');
        const json = typeof Buffer !== 'undefined' ? Buffer.from(base64, 'base64').toString('utf-8') : atob(base64);
        const payload = JSON.parse(json) as { scp?: string | string[]; scope?: string | string[] };
        const raw = payload.scp ?? payload.scope;
        const scopes = Array.isArray(raw) ? raw : typeof raw === 'string' ? raw.split(/[\s,]+/).filter(Boolean) : [];
        const paymentScopes = scopes.filter((scope) => scope.includes('payment') || scope.includes('myaccount'));
        return {
            tokenScopesAvailable: true,
            hasPaymentInstrumentsRw: scopes.includes(SETUP_REQUIRED_SCOPE),
            hasPaymentInstrumentsRead: scopes.includes('sfcc.shopper-myaccount.paymentinstruments'),
            paymentRelatedScopes: paymentScopes.sort(),
        };
    } catch {
        return { tokenScopesAvailable: false, tokenDecodeFailed: true };
    }
}

function parseVendor(raw: string | undefined): AccountSetupVendor | null {
    if (!raw) return 'stripe';
    const normalized = raw.trim().toLowerCase();
    if (normalized === 'stripe' || normalized === 'adyen') return normalized;
    return null;
}

/**
 * Parse + sanitize Adyen Drop-in `paymentMethod` from FormData.
 * Never log encrypted field values.
 *
 * Commerce (`AdyenSavedPaymentMethodService`) requires:
 * - `type` exactly `"scheme"` (Drop-in may send `"card"` — normalize here)
 * - only allowlisted keys
 * - every present value a non-blank string (blank optional fields → 400)
 */
function parseAdyenPaymentMethod(
    raw: string | undefined
): { ok: true; paymentMethod: Record<string, string>; fieldKeys: string[] } | { ok: false; error: string } {
    if (!raw?.trim()) {
        return { ok: false, error: 'adyen paymentMethod is required' };
    }
    let parsed: unknown;
    try {
        parsed = JSON.parse(raw);
    } catch {
        return { ok: false, error: 'adyen paymentMethod must be valid JSON' };
    }
    // SDK may pass the paymentMethod object, or accidentally double-encode / wrap it.
    if (typeof parsed === 'string') {
        try {
            parsed = JSON.parse(parsed);
        } catch {
            return { ok: false, error: 'adyen paymentMethod must be an object' };
        }
    }
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
        return { ok: false, error: 'adyen paymentMethod must be an object' };
    }
    const source = parsed as Record<string, unknown>;
    const paymentMethod: Record<string, string> = {};
    for (const [key, value] of Object.entries(source)) {
        if (!ADYEN_CARD_PAYMENT_METHOD_FIELDS.has(key) || key === 'type') continue;
        if (typeof value !== 'string') continue;
        const trimmed = value.trim();
        if (!trimmed) continue;
        paymentMethod[key] = trimmed;
    }
    // Card setup always uses Adyen scheme — do not forward Drop-in's "card" type.
    paymentMethod.type = 'scheme';

    for (const field of ADYEN_REQUIRED_CARD_FIELDS) {
        if (!paymentMethod[field]) {
            return { ok: false, error: `adyen paymentMethod.${field} is required` };
        }
    }
    return { ok: true, paymentMethod, fieldKeys: Object.keys(paymentMethod).sort() };
}

/**
 * Starts SCAPI setup for a new SFP payment-method reference (My Account Add).
 *
 * Stripe: returns SetupIntent `clientSecret` — CAP confirms then calls complete.
 * Adyen: requires Drop-in encrypted `paymentMethod`; returns `resultCode`.
 * Complete is unsupported for Adyen — Authorised setup alone stores the method.
 *
 * POST /action/sf-payments-account-setup-saved-method
 * FormData:
 *   zoneId: string (required)
 *   paymentMethodType: `card` | `sepa_debit` (optional, default `card`)
 *   vendor: `stripe` | `adyen` (optional, default `stripe`)
 *   paymentMethod: string (Adyen card only) — JSON of Drop-in encrypted card fields
 *
 * Stripe SEPA uses the same setup → confirm → complete path as card.
 * Adyen My Account setup is card-only (commerce rejects `sepa_debit`).
 */
export async function action({ request, context }: ActionFunctionArgs) {
    if (request.method !== 'POST') {
        return data({ success: false, error: 'Method not allowed' } satisfies SetupAccountSavedMethodResult, {
            status: 405,
        });
    }

    const auth = getAuth(context);
    const { customerId, userType } = auth;
    if (userType !== 'registered' || !customerId) {
        return data({ success: false, error: 'Not authenticated' } satisfies SetupAccountSavedMethodResult, {
            status: 401,
        });
    }
    const accessToken =
        auth && typeof auth === 'object' && 'accessToken' in auth && typeof auth.accessToken === 'string'
            ? auth.accessToken
            : undefined;

    const formData = await request.formData();
    const zoneId = formData.get('zoneId')?.toString()?.trim();
    const paymentMethodType = formData.get('paymentMethodType')?.toString()?.trim() || 'card';
    const vendor = parseVendor(formData.get('vendor')?.toString());
    const paymentMethodRaw = formData.get('paymentMethod')?.toString();

    if (!zoneId) {
        return data({ success: false, error: 'zoneId is required' } satisfies SetupAccountSavedMethodResult, {
            status: 400,
        });
    }

    if (vendor == null) {
        return data({ success: false, error: 'Unsupported vendor' } satisfies SetupAccountSavedMethodResult, {
            status: 400,
        });
    }

    // Stripe My Account Add: card + sepa_debit. Adyen: card only (commerce rejects sepa_debit).
    if (paymentMethodType !== 'card' && paymentMethodType !== 'sepa_debit') {
        return data(
            {
                success: false,
                error: 'Unsupported paymentMethodType',
            } satisfies SetupAccountSavedMethodResult,
            { status: 400 }
        );
    }

    if (vendor === 'adyen' && paymentMethodType !== 'card') {
        return data(
            {
                success: false,
                error: 'Adyen account setup supports card only',
            } satisfies SetupAccountSavedMethodResult,
            { status: 400 }
        );
    }

    let adyenPaymentMethod: Record<string, string> | undefined;
    let adyenPaymentMethodKeys: string[] | undefined;
    if (vendor === 'adyen') {
        const parsed = parseAdyenPaymentMethod(paymentMethodRaw);
        if (!parsed.ok) {
            return data({ success: false, error: parsed.error } satisfies SetupAccountSavedMethodResult, {
                status: 400,
            });
        }
        adyenPaymentMethod = parsed.paymentMethod;
        adyenPaymentMethodKeys = parsed.fieldKeys;
    }

    const logger = getLogger(context);

    try {
        const clients = createApiClients(context);
        const body =
            vendor === 'adyen'
                ? {
                      paymentMethodType: 'card' as const,
                      gatewayProperties: {
                          adyen: {
                              paymentMethod: adyenPaymentMethod,
                          },
                      },
                  }
                : {
                      paymentMethodType: paymentMethodType as 'card' | 'sepa_debit',
                      gatewayProperties: {
                          stripe: {
                              usage: 'on_session',
                          },
                      },
                  };

        const { data: setup } = await clients.shopperCustomers.setupCustomerPaymentMethodReference({
            params: {
                path: { customerId },
                query: { zoneId },
            },
            body,
        });

        const paymentMethodReferenceSetupId =
            typeof (setup as { paymentMethodReferenceSetupId?: unknown })?.paymentMethodReferenceSetupId === 'string'
                ? (setup as { paymentMethodReferenceSetupId: string }).paymentMethodReferenceSetupId
                : undefined;

        if (vendor === 'stripe') {
            const clientSecret =
                typeof (setup as { gatewayProperties?: { stripe?: { clientSecret?: unknown } } })?.gatewayProperties
                    ?.stripe?.clientSecret === 'string'
                    ? (setup as { gatewayProperties: { stripe: { clientSecret: string } } }).gatewayProperties.stripe
                          .clientSecret
                    : undefined;

            if (!clientSecret || !paymentMethodReferenceSetupId) {
                logger.error('[sf-payments] account setup saved method missing client secret', {
                    zoneId,
                    paymentMethodType,
                    vendor,
                    hasSetupId: Boolean(paymentMethodReferenceSetupId),
                    hasClientSecret: Boolean(clientSecret),
                });
                return data(
                    {
                        success: false,
                        error: 'Unable to set up payment method',
                    } satisfies SetupAccountSavedMethodResult,
                    { status: 502 }
                );
            }

            logger.info('[sf-payments] account saved payment method setup started', {
                zoneId,
                paymentMethodType,
                vendor,
            });

            return {
                success: true,
                vendor: 'stripe',
                paymentMethodReferenceSetupId,
                clientSecret,
            } satisfies SetupAccountSavedMethodResult;
        }

        const resultCode =
            typeof (setup as { gatewayProperties?: { adyen?: { resultCode?: unknown } } })?.gatewayProperties?.adyen
                ?.resultCode === 'string'
                ? (setup as { gatewayProperties: { adyen: { resultCode: string } } }).gatewayProperties.adyen.resultCode
                : undefined;

        if (!paymentMethodReferenceSetupId || !resultCode) {
            logger.error('[sf-payments] account setup saved method missing Adyen result', {
                zoneId,
                paymentMethodType,
                vendor,
                hasSetupId: Boolean(paymentMethodReferenceSetupId),
                hasResultCode: Boolean(resultCode),
            });
            return data(
                {
                    success: false,
                    error: 'Unable to set up payment method',
                } satisfies SetupAccountSavedMethodResult,
                { status: 502 }
            );
        }

        // Fail closed — only Authorised means stored + shopper-reuse. Do not hand
        // RedirectShopper / Pending / etc. to the SDK as a successful setup.
        if (resultCode !== 'Authorised') {
            logger.error('[sf-payments] account setup saved method non-Authorised Adyen result', {
                zoneId,
                paymentMethodType,
                vendor,
                resultCode,
            });
            return data(
                {
                    success: false,
                    error: 'Unable to set up payment method',
                } satisfies SetupAccountSavedMethodResult,
                { status: 502 }
            );
        }

        logger.info('[sf-payments] account saved payment method setup started', {
            zoneId,
            paymentMethodType,
            vendor,
            resultCode,
        });

        return {
            success: true,
            vendor: 'adyen',
            paymentMethodReferenceSetupId,
            resultCode,
        } satisfies SetupAccountSavedMethodResult;
    } catch (error) {
        const scapiMeta = scapiErrorMeta(error);
        const scapiDetail = typeof scapiMeta.scapiDetail === 'string' ? scapiMeta.scapiDetail : undefined;
        // Commerce maps Adyen ResultCode.REFUSED → 400 parameter gatewayProperties.adyen.resultCode.
        // RedirectShopper / other non-Authorised codes are Operation Not Supported (not this path).
        const adyenRefused = vendor === 'adyen' && scapiDetail === 'gatewayProperties.adyen.resultCode';
        // Adyen: drop scapiRawBody — commerce may echo encrypted* fields in the error body.
        const { scapiRawBody: _adyenRawBody, ...adyenSafeScapiMeta } = scapiMeta;
        logger.error('[sf-payments] account saved payment method setup failed', {
            zoneId,
            paymentMethodType,
            vendor,
            requiredScope: SETUP_REQUIRED_SCOPE,
            // Keys only — never encrypted card payloads.
            ...(adyenPaymentMethodKeys ? { adyenPaymentMethodKeys } : {}),
            ...(adyenRefused ? { adyenResultCode: 'Refused' } : {}),
            ...(vendor === 'adyen' ? adyenSafeScapiMeta : scapiMeta),
            // On 403, surface whether the shopper JWT carries paymentinstruments.rw.
            ...(scapiMeta.scapiStatus === 403 ? paymentScopeDiagnostics(accessToken) : {}),
        });
        return data(
            {
                success: false,
                error: adyenRefused ? 'Payment was refused. Try a different card.' : 'Unable to set up payment method',
            } satisfies SetupAccountSavedMethodResult,
            { status: 502 }
        );
    }
}
