/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

import { type ActionFunctionArgs, data } from 'react-router';
import { createApiClients } from '@/lib/api-clients.server';
import { getAuth } from '@/middlewares/auth.server';
import { getLogger } from '@/lib/logger.server';
import { ApiError } from '@/scapi';

export type RemoveAccountSavedMethodResult = { success: true } | { success: false; error: string };

/**
 * Deletes an SFP payment method reference for the registered shopper.
 *
 * Does not touch native SFCC payment instruments — when SFP is disabled the
 * host still owns remove via `/action/payment-method-remove`.
 *
 * POST /action/sf-payments-account-remove-saved-method
 * FormData:
 *   paymentMethodReferenceId: string (required)
 *   accountId: string (required) — SCAPI scopes the delete by payment account
 */
export async function action({ request, context }: ActionFunctionArgs) {
    if (request.method !== 'POST') {
        return data({ success: false, error: 'Method not allowed' } satisfies RemoveAccountSavedMethodResult, {
            status: 405,
        });
    }

    const { customerId, userType } = getAuth(context);
    if (userType !== 'registered' || !customerId) {
        return data({ success: false, error: 'Not authenticated' } satisfies RemoveAccountSavedMethodResult, {
            status: 401,
        });
    }

    const formData = await request.formData();
    const paymentMethodReferenceId = formData.get('paymentMethodReferenceId')?.toString()?.trim();
    const accountId = formData.get('accountId')?.toString()?.trim();

    if (!paymentMethodReferenceId || !accountId) {
        return data(
            {
                success: false,
                error: 'paymentMethodReferenceId and accountId are required',
            } satisfies RemoveAccountSavedMethodResult,
            { status: 400 }
        );
    }

    const logger = getLogger(context);

    try {
        const clients = createApiClients(context);
        await clients.shopperCustomers.deleteCustomerPaymentMethodReference({
            params: {
                path: {
                    customerId,
                    paymentMethodReferenceId,
                },
                query: {
                    accountId,
                },
            },
        });

        logger.info('[sf-payments] account saved payment method removed', {
            customerId,
            paymentMethodReferenceId,
            accountId,
        });

        return { success: true } satisfies RemoveAccountSavedMethodResult;
    } catch (error) {
        // Already gone — treat as success so a retry after a partial success
        // (deleted on gateway, client never got the OK) does not look like a hard error.
        if (error instanceof ApiError && error.status === 404) {
            logger.info('[sf-payments] account saved payment method already removed', {
                customerId,
                paymentMethodReferenceId,
                accountId,
            });
            return { success: true } satisfies RemoveAccountSavedMethodResult;
        }

        logger.error('[sf-payments] account saved payment method remove failed', {
            customerId,
            paymentMethodReferenceId,
            accountId,
            message: error instanceof Error ? error.message : String(error),
        });
        return data(
            { success: false, error: 'Unable to remove payment method' } satisfies RemoveAccountSavedMethodResult,
            { status: 502 }
        );
    }
}
