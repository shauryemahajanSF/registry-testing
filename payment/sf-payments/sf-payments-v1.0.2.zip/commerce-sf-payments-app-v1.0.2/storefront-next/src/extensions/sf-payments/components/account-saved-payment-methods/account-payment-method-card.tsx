/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

'use client';

import { PaymentMethodCard } from '@/components/payment-methods/payment-method-card';
import type { AccountSavedPaymentMethod } from '../../lib/account-saved-payment-methods';
import { toHostPaymentMethod } from './to-host-payment-method';

export interface AccountPaymentMethodCardProps {
    method: AccountSavedPaymentMethod;
    onRemove: () => void;
}

/**
 * SFP SPM row via host PaymentMethodCard.
 * Passes onRemove only — omitting onSetDefault hides Set Default; mapper sets isDefault: false.
 */
export function AccountPaymentMethodCard({ method, onRemove }: AccountPaymentMethodCardProps) {
    return (
        <div data-testid="account-payment-method-card" data-method-id={method.id} data-method-type={method.type}>
            <PaymentMethodCard paymentMethod={toHostPaymentMethod(method)} onRemove={onRemove} />
        </div>
    );
}
