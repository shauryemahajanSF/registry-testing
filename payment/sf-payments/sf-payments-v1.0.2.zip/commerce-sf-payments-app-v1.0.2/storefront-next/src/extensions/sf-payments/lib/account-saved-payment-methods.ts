/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

/**
 * Wire shape for Shopper Customers paymentMethodReferences after digital#35525.
 * Generated OAS clients may lag — keep this local until storefront-next regenerates.
 * Month/year may arrive as number or numeric string depending on gateway serialization.
 */
export interface PaymentMethodReferenceWire {
    id?: string;
    type?: string;
    accountId?: string;
    brand?: string;
    last4?: string | number;
    expiryMonth?: number | string;
    expiryYear?: number | string;
    /** Native PI naming sometimes appears on older payloads. */
    expirationMonth?: number | string;
    expirationYear?: number | string;
    accountHolderName?: string;
    /** Alternate holder fields some gateways / payloads use. */
    cardholderName?: string;
    holderName?: string;
    name?: string;
}

export type AccountSavedPaymentMethodType = 'card' | 'sepa_debit';

export interface AccountSavedPaymentMethodCapabilities {
    canRemove: boolean;
    canSetDefault: boolean;
}

/** Account-page view model for an SFP payment method reference. */
export interface AccountSavedPaymentMethod {
    id: string;
    type: AccountSavedPaymentMethodType;
    brand: string | null;
    last4: string | null;
    expiryMonth: number | null;
    expiryYear: number | null;
    accountHolderName: string | null;
    source: 'sfp';
    capabilities: AccountSavedPaymentMethodCapabilities;
    /** Opaque routing value for Delete — not shown in UI. */
    accountId: string;
}

/** Coerce SCAPI number | numeric string into a finite integer; otherwise null. */
export function parseOptionalInt(value: unknown): number | null {
    if (typeof value === 'number' && Number.isFinite(value)) {
        return Math.trunc(value);
    }
    if (typeof value === 'string' && value.trim().length > 0) {
        const parsed = Number.parseInt(value.trim(), 10);
        return Number.isFinite(parsed) ? parsed : null;
    }
    return null;
}

function parseOptionalLast4(value: unknown): string | null {
    if (typeof value === 'string' && value.length > 0) return value;
    if (typeof value === 'number' && Number.isFinite(value)) return String(Math.trunc(value));
    return null;
}

function parseOptionalName(ref: PaymentMethodReferenceWire): string | null {
    for (const value of [ref.accountHolderName, ref.cardholderName, ref.holderName, ref.name]) {
        if (typeof value === 'string' && value.trim().length > 0) return value.trim();
    }
    return null;
}

/**
 * Maps SCAPI paymentMethodReferences to the My Account list model.
 * Preserves SCAPI order (backend newest-first, all zones). No zone / gateway
 * client filter — checkout sheet filtering is separate.
 * Omits only rows missing id/accountId or with unsupported type (not zone filter).
 */
export function mapPaymentMethodReferencesToAccountView(
    refs: PaymentMethodReferenceWire[] | null | undefined
): AccountSavedPaymentMethod[] {
    if (!refs?.length) return [];

    const result: AccountSavedPaymentMethod[] = [];
    for (const ref of refs) {
        if (!ref.id || !ref.accountId) continue;
        if (ref.type !== 'card' && ref.type !== 'sepa_debit') continue;

        result.push({
            id: ref.id,
            type: ref.type,
            brand: typeof ref.brand === 'string' && ref.brand.length > 0 ? ref.brand : null,
            last4: parseOptionalLast4(ref.last4),
            expiryMonth: parseOptionalInt(ref.expiryMonth ?? ref.expirationMonth),
            expiryYear: parseOptionalInt(ref.expiryYear ?? ref.expirationYear),
            accountHolderName: parseOptionalName(ref),
            source: 'sfp',
            capabilities: { canRemove: true, canSetDefault: false },
            accountId: ref.accountId,
        });
    }
    return result;
}
