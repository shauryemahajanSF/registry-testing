/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

import type { PaymentMethod } from '@/components/payment-methods/payment-method-card';
import type { AccountSavedPaymentMethod } from '../../lib/account-saved-payment-methods';

/** Maps an SFP account SPM onto the host PaymentMethodCard model. */
export function toHostPaymentMethod(method: AccountSavedPaymentMethod): PaymentMethod {
    if (method.type === 'sepa_debit') {
        return {
            id: method.id,
            type: 'sepa_debit',
            last4: method.last4 ?? '',
            expiryMonth: '',
            expiryYear: '',
            cardholderName: method.accountHolderName ?? '',
            isDefault: false,
        };
    }

    return {
        id: method.id,
        type: method.brand ?? 'card',
        last4: method.last4 ?? '',
        // Pad month so PaymentMethodCard shows "Expires 06/2029" like native cards.
        expiryMonth: method.expiryMonth != null ? String(method.expiryMonth).padStart(2, '0') : '',
        expiryYear: method.expiryYear != null ? String(method.expiryYear) : '',
        cardholderName: method.accountHolderName ?? '',
        isDefault: false,
    };
}
