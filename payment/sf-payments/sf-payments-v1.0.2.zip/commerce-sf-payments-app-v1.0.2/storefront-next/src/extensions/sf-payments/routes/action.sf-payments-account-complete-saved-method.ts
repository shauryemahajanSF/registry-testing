/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

import { type ActionFunctionArgs, data } from 'react-router';
import { ApiError } from '@/scapi';
import { createApiClients } from '@/lib/api-clients.server';
import { getAuth } from '@/middlewares/auth.server';
import { getLogger } from '@/lib/logger.server';

/** Duck-type SCAPI status — runtime ApiError is a different class than the CAP stub. */
function scapiStatusOf(error: unknown): number | undefined {
    if (
        error &&
        typeof error === 'object' &&
        'status' in error &&
        typeof (error as { status: unknown }).status === 'number'
    ) {
        return (error as { status: number }).status;
    }
    if (error instanceof Error) {
        const match = /^API Error (\d+):/.exec(error.message);
        if (match) return Number(match[1]);
    }
    return undefined;
}

function scapiErrorMeta(error: unknown): Record<string, unknown> {
    if (error instanceof ApiError) {
        return {
            scapiStatus: error.status,
            scapiTitle: error.body?.title,
            scapiDetail: error.body?.detail,
            scapiType: error.body?.type,
            scapiRawBody: error.rawBody?.slice(0, 500) || undefined,
        };
    }
    if (error && typeof error === 'object' && 'status' in error) {
        const e = error as {
            status?: number;
            body?: { title?: string; detail?: string; type?: string };
            rawBody?: string;
            message?: string;
        };
        return {
            scapiStatus: e.status,
            scapiTitle: e.body?.title,
            scapiDetail: e.body?.detail,
            scapiType: e.body?.type,
            scapiRawBody: e.rawBody?.slice(0, 500) || undefined,
            message: e.message,
        };
    }
    return { message: error instanceof Error ? error.message : String(error) };
}

export type CompleteAccountSavedMethodSuccess = {
    success: true;
};

export type CompleteAccountSavedMethodFailure = {
    success: false;
    error: string;
};

export type CompleteAccountSavedMethodResult = CompleteAccountSavedMethodSuccess | CompleteAccountSavedMethodFailure;

/**
 * Completes SCAPI setup after the shopper confirms the provider SetupIntent.
 *
 * Setup alone creates the Stripe SetupIntent. Complete verifies success with
 * secret-key access and marks the PaymentMethod shopper-reusable so it appears
 * in the account list (digital#35526). Skip this and Add looks successful with
 * an empty list.
 *
 * POST /action/sf-payments-account-complete-saved-method
 * FormData:
 *   zoneId: string (required)
 *   paymentMethodReferenceSetupId: string (required) — id returned by setup
 */
export async function action({ request, context }: ActionFunctionArgs) {
    if (request.method !== 'POST') {
        return data({ success: false, error: 'Method not allowed' } satisfies CompleteAccountSavedMethodResult, {
            status: 405,
        });
    }

    const { customerId, userType } = getAuth(context);
    if (userType !== 'registered' || !customerId) {
        return data({ success: false, error: 'Not authenticated' } satisfies CompleteAccountSavedMethodResult, {
            status: 401,
        });
    }

    const formData = await request.formData();
    const zoneId = formData.get('zoneId')?.toString()?.trim();
    const paymentMethodReferenceSetupId = formData.get('paymentMethodReferenceSetupId')?.toString()?.trim();

    if (!zoneId) {
        return data({ success: false, error: 'zoneId is required' } satisfies CompleteAccountSavedMethodResult, {
            status: 400,
        });
    }

    if (!paymentMethodReferenceSetupId) {
        return data(
            {
                success: false,
                error: 'paymentMethodReferenceSetupId is required',
            } satisfies CompleteAccountSavedMethodResult,
            { status: 400 }
        );
    }

    const logger = getLogger(context);

    try {
        const clients = createApiClients(context);
        const completeFn = (
            clients.shopperCustomers as {
                completeCustomerPaymentMethodReferenceSetup?: (args: unknown) => Promise<unknown>;
            }
        ).completeCustomerPaymentMethodReferenceSetup;

        if (typeof completeFn !== 'function') {
            logger.error('[sf-payments] account complete missing SCAPI client method', {
                zoneId,
                // Wrong/missing ops-map name surfaces as "is not a function" with no ApiClients fetch line.
                availableOps: Object.keys(clients.shopperCustomers)
                    .filter((key) => key.toLowerCase().includes('payment'))
                    .sort(),
            });
            return data(
                {
                    success: false,
                    error: 'Complete endpoint unavailable on this commerce instance',
                } satisfies CompleteAccountSavedMethodResult,
                { status: 502 }
            );
        }

        await completeFn({
            params: {
                path: { customerId },
                query: { zoneId },
            },
            body: {
                paymentMethodReferenceSetupId,
            },
        });

        // zoneId is the agreed client-visible routing key; customer/setup ids stay off telemetry.
        logger.info('[sf-payments] account saved payment method setup completed', {
            zoneId,
        });

        return { success: true } satisfies CompleteAccountSavedMethodResult;
    } catch (error) {
        const scapiStatus = scapiStatusOf(error);
        // 404 = route missing on this commerce build (digital#35526 not deployed), not a bad setup id.
        logger.error('[sf-payments] account saved payment method setup complete failed', {
            zoneId,
            scapiStatus,
            ...scapiErrorMeta(error),
        });
        return data(
            {
                success: false,
                error:
                    scapiStatus === 404
                        ? 'Complete endpoint unavailable on this commerce instance'
                        : 'Unable to complete payment method setup',
            } satisfies CompleteAccountSavedMethodResult,
            { status: 502 }
        );
    }
}
