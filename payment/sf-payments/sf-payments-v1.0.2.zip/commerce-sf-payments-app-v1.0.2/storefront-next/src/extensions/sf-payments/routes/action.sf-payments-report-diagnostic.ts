/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

import { type ActionFunctionArgs, data } from 'react-router';
import { getLogger } from '@/lib/logger.server';
import { isClientDiagnosticSignal } from '../lib/client-diagnostic-signals';

/**
 * Mirror a browser-only payment diagnostic into MRT server logs.
 *
 * No SCAPI side effects — observability only. Callers fire-and-forget from
 * the sheet callbacks when SDK confirm / approve fails client-side.
 *
 * POST body (FormData):
 *   signal: one of the allowlisted ClientDiagnosticSignal values (required)
 *   metadata: JSON-stringified object (optional) — basketId, orderNo, vendorMessage, …
 *
 * Request header:
 *   x-correlation-id: string (optional) — bound by correlation middleware before
 *     this action runs so getLogger(context) joins the browser console line
 */
export async function action({ request, context }: ActionFunctionArgs) {
    if (request.method !== 'POST') {
        return data({ success: false, error: 'Method not allowed' }, { status: 405 });
    }

    const logger = getLogger(context);
    const formData = await request.formData();
    const signal = formData.get('signal')?.toString();

    if (!signal || !isClientDiagnosticSignal(signal)) {
        return data({ success: false, error: 'Invalid signal' }, { status: 400 });
    }

    let metadata: Record<string, unknown> = {};
    const metadataRaw = formData.get('metadata')?.toString();
    if (metadataRaw) {
        try {
            const parsed: unknown = JSON.parse(metadataRaw);
            if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
                metadata = parsed as Record<string, unknown>;
            }
        } catch {
            // Bad JSON — still emit the signal; metadata is best-effort.
        }
    }

    // Server logger already binds correlationId; drop a client-echoed copy.
    const safeMetadata = { ...metadata };
    delete safeMetadata.correlationId;

    logger.error(`[sf-payments] ${signal}`, safeMetadata);
    return { success: true };
}
