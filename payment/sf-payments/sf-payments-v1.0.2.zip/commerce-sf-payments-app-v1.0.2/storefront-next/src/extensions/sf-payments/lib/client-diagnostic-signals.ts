/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

/**
 * Browser-only payment-failure signals that must also land in MRT logs.
 * Message suffixes match the existing client `logger.error('[sf-payments] …')`
 * lines so on-call greps stay stable across browser and server.
 */
export const CLIENT_DIAGNOSTIC_SIGNALS = [
    'SDK confirm() returned non-success',
    'confirmPayment threw',
    'onPaymentApprove strategy failed',
    'account setup mount failed',
    'account setup confirm non-success',
    'account setup confirm threw',
    'account setup complete threw',
] as const;

export type ClientDiagnosticSignal = (typeof CLIENT_DIAGNOSTIC_SIGNALS)[number];

export const CLIENT_DIAGNOSTIC_SIGNAL_SET: ReadonlySet<string> = new Set(CLIENT_DIAGNOSTIC_SIGNALS);

export function isClientDiagnosticSignal(value: string): value is ClientDiagnosticSignal {
    return CLIENT_DIAGNOSTIC_SIGNAL_SET.has(value);
}
