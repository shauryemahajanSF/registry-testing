/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

import type { RouterContextProvider } from 'react-router';
import { PerformanceTimer, performanceTimerContext } from '@/middlewares/performance-metrics';

/**
 * SFP mark names for the host PerformanceTimer / Server-Timing pipeline.
 *
 * Host `PERFORMANCE_MARKS` has no SFP entries yet — these string names are
 * accepted by `PerformanceTimer.mark()` without a storefront-next change.
 * Optional host follow-up: add them to `PERFORMANCE_MARKS` + category icons.
 */
export const SFP_PERFORMANCE_MARKS = {
    /** Browser `<script>` load of sfp.js (client metrics logs). */
    sdkLoad: 'sfPayments.sdkLoad',
    /** Shopper configurations SCAPI via `/resource/sf-payments-shopper-config`. */
    shopperConfigFetch: 'sfPayments.shopperConfigFetch',
    /** Static metadata JSON via `/resource/sf-payments-metadata`. */
    metadataFetch: 'sfPayments.metadataFetch',
    /** Payment configuration SCAPI via `/resource/sf-payments-config`. */
    paymentConfigFetch: 'sfPayments.paymentConfigFetch',
    /** Order create + PI patch via `/action/sf-payments-create-order`. */
    createOrder: 'sfPayments.createOrder',
} as const;

export type SfpPerformanceMark = (typeof SFP_PERFORMANCE_MARKS)[keyof typeof SFP_PERFORMANCE_MARKS];

type MarkerType = 'start' | 'end';

type PerformanceTimerLike = {
    mark: (name: string, type: MarkerType, options?: { startTime?: number; detail?: string }) => void;
    log?: () => void;
};

/**
 * Read the host request-scoped PerformanceTimer (no-op when metrics disabled
 * or middleware did not install a timer).
 */
export function getPerformanceTimer(context: Readonly<RouterContextProvider>): PerformanceTimerLike | undefined {
    return context.get(performanceTimerContext) as PerformanceTimerLike | undefined;
}

export function markPerformance(
    context: Readonly<RouterContextProvider>,
    name: SfpPerformanceMark | string,
    type: MarkerType
): void {
    getPerformanceTimer(context)?.mark(name, type);
}

/**
 * Time an async server operation with start/end marks. Always ends the mark
 * (success or throw) so Server-Timing still records failed attempts.
 */
export async function withPerformanceMark<T>(
    context: Readonly<RouterContextProvider>,
    name: SfpPerformanceMark | string,
    fn: () => Promise<T>
): Promise<T> {
    markPerformance(context, name, 'start');
    try {
        return await fn();
    } finally {
        markPerformance(context, name, 'end');
    }
}

/**
 * Client-side PerformanceTimer for browser-only work (SDK script load, fan-out
 * fetches). Uses the same host class so logs match the middleware format when
 * `clientPerformanceMetricsEnabled` is on. Does not participate in Server-Timing
 * (that header is response-scoped on the server).
 */
export function createClientPerformanceTimer(
    enabled: boolean,
    options: { requestId?: string; requestUrl?: string } = {}
): PerformanceTimer {
    return new PerformanceTimer({
        enabled,
        requestId: options.requestId ?? `sf-payments-client-${Date.now()}`,
        requestUrl: options.requestUrl ?? (typeof window !== 'undefined' ? window.location.href : 'sf-payments-client'),
    });
}

/**
 * Time a client promise with start/end on an existing PerformanceTimer.
 * Safe when the timer was constructed with `enabled: false` (marks no-op).
 */
export function measureClientPromise<T>(
    timer: PerformanceTimerLike,
    name: SfpPerformanceMark | string,
    promise: Promise<T>
): Promise<T> {
    timer.mark(name, 'start');
    return promise.finally(() => {
        timer.mark(name, 'end');
    });
}
