/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

/** Shared React Router fetcher key for the My Account SFP list (list / remove / add). */
export const ACCOUNT_SAVED_METHODS_FETCHER_KEY = 'sf-payments-account-saved-methods';

/** GET path for the fail-closed My Account saved-methods resource. */
export const ACCOUNT_SAVED_METHODS_RESOURCE = '/resource/sf-payments-account-saved-methods';
