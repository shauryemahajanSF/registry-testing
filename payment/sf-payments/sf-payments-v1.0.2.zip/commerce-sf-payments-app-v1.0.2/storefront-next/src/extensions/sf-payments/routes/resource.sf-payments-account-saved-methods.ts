/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

import type { LoaderFunctionArgs } from 'react-router';
import { createApiClients } from '@/lib/api-clients.server';
import { getAuth } from '@/middlewares/auth.server';
import { getLogger } from '@/lib/logger.server';
import {
    mapPaymentMethodReferencesToAccountView,
    type PaymentMethodReferenceWire,
} from '../lib/account-saved-payment-methods';

/**
 * Strict My Account list of SFP payment method references (all zones).
 *
 * Unlike `/resource/sf-payments-saved-methods` (checkout, fail-open → `[]`),
 * this route surfaces retrieval failures so the UI can show unavailable + Retry
 * instead of a false-empty wallet.
 *
 * GET /resource/sf-payments-account-saved-methods
 */
export async function loader({ context }: LoaderFunctionArgs) {
    const { customerId, userType } = getAuth(context);

    if (userType !== 'registered' || !customerId) {
        return Response.json({ error: 'Not authenticated' }, { status: 401 });
    }

    const logger = getLogger(context);

    try {
        const clients = createApiClients(context);
        const { data: customer } = await clients.shopperCustomers.getCustomer({
            params: { path: { customerId }, query: { expand: ['paymentmethodreferences'] } },
        });

        // Backend already newest-first; mapper preserves order and does not invent fields.
        // Cast through unknown — OAS CustomerPaymentMethodReference still omits brand/expiry/holder.
        const refs = (customer.paymentMethodReferences ?? []) as unknown as PaymentMethodReferenceWire[];
        const methods = mapPaymentMethodReferencesToAccountView(refs);

        // Empty UI with HTTP 200 almost always means the mapper dropped every ref
        // (missing accountId, or type other than card/sepa_debit) — log enough to spot which.
        if (refs.length > 0 && methods.length === 0) {
            logger.warn('[sf-payments] account SPM refs returned but mapper produced 0 methods', {
                customerId,
                rawCount: refs.length,
                sample: refs.slice(0, 3).map((ref) => ({
                    id: ref.id,
                    type: ref.type,
                    hasAccountId: Boolean(ref.accountId),
                    keys: Object.keys(ref as object).sort(),
                })),
            });
        }

        const cardsMissingExpiry = methods.filter(
            (method) => method.type === 'card' && (method.expiryMonth == null || method.expiryYear == null)
        );
        if (cardsMissingExpiry.length > 0) {
            // digital#35525 should supply expiryMonth/expiryYear; absence means the commerce
            // instance build (or gateway payload) is not returning display fields yet.
            logger.warn('[sf-payments] card SPMs missing expiry from SCAPI', {
                customerId,
                count: cardsMissingExpiry.length,
                ids: cardsMissingExpiry.map((method) => method.id),
                sampleKeys: refs[0] ? Object.keys(refs[0] as object).sort() : [],
            });
        }

        return Response.json({ methods });
    } catch (error) {
        logger.error('[sf-payments] account saved payment methods fetch failed', {
            customerId,
            message: error instanceof Error ? error.message : String(error),
        });
        return Response.json({ error: 'Unable to load saved payment methods' }, { status: 502 });
    }
}
