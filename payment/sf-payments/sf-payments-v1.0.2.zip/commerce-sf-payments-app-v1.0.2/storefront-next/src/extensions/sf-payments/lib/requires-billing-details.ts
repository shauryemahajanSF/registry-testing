/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

type PaymentInstrumentTypeMeta = {
    apiValue?: string;
    requiresBillingDetails?: boolean;
};

/**
 * Reads `requiresBillingDetails` from SFP static metadata for a payment method
 * apiValue (e.g. "card"). Defaults to true when metadata is missing/unknown —
 * Stripe Payment Element uses fields.billingDetails = 'never', so callers must
 * supply billing when the flag is unset.
 */
export function requiresBillingDetailsForType(
    metadata: Record<string, unknown> | null | undefined,
    paymentMethodType: string
): boolean {
    const types = metadata?.paymentInstrumentTypes;
    if (!types || typeof types !== 'object') return true;

    for (const entry of Object.values(types as Record<string, PaymentInstrumentTypeMeta>)) {
        if (entry?.apiValue === paymentMethodType) {
            return entry.requiresBillingDetails !== false;
        }
    }
    return true;
}
