/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

'use client';

/**
 * Adyen gateway strategy hook. Adyen has no `onPayerApprove` step — the SDK
 * sends shopper addresses on `paymentData` to `createIntent` instead, so
 * `createIntent` handles push-addresses, ensure-PI, and create-order in
 * sequence and returns Adyen-namespace fields read off the order's PI.
 */

import { useCallback } from 'react';
import { useFetcher } from 'react-router';
import type { ShopperBasketsV2, ShopperOrders } from '@salesforce/storefront-next-runtime/scapi';
import { useFetcherPromise } from '../use-fetcher-promise';
import { getSFPaymentsInstrument, transformAddressDetails } from '../../lib/sf-payments-utils';
import type { CreateIntentArgs, CreateIntentResult, GatewayStrategy } from '../../lib/gateways/types';

type Basket = ShopperBasketsV2.schemas['Basket'];
type Order = ShopperOrders.schemas['Order'];
type ActionResponse<T> = ({ success: true } & T) | { success: false; error?: string };

type EnsurePiResponse = ActionResponse<{ basket: Basket }>;
type PushAddressesResponse = ActionResponse<{ basket: Basket }>;
type CreateOrderResponse = ActionResponse<{ order: Order; orderNo?: string }>;

/** Shape of the Adyen payment-intent fields on a SF Payments instrument. */
interface AdyenPaymentIntent {
    id?: string;
    resultCode?: string;
    adyenPaymentIntentAction?: Record<string, unknown>;
}

/** Adyen-namespace shape on a SF Payments PI's `paymentReference`. */
interface AdyenPaymentReference {
    paymentReferenceId?: string;
    gatewayProperties?: { adyen?: { adyenPaymentIntent?: AdyenPaymentIntent } };
}

/**
 * Adyen SDK's createIntent payload. Local to this strategy — the
 * GatewayStrategy contract returns this as opaque `SdkIntentPayload`, so
 * consumers can't read fields off it.
 */
interface AdyenSdkIntentPayload {
    /** Adyen PSP reference for this payment intent. */
    pspReference?: string;
    /** SF Payments paymentReferenceId; the Adyen SDK reads it as `guid`. */
    guid: string;
    resultCode?: string;
    action?: Record<string, unknown>;
}

/** Narrow a settled action-route response to its success branch. */
function assertSuccess<T extends { success: boolean; error?: string }>(
    result: T | undefined,
    fallbackMessage: string
): Extract<T, { success: true }> {
    if (!result) {
        throw new Error(fallbackMessage);
    }
    if (result.success !== true) {
        throw new Error(result.error || fallbackMessage);
    }
    return result as Extract<T, { success: true }>;
}

export function useAdyenStrategy(): GatewayStrategy {
    const pushAddressesFetcher = useFetcher<PushAddressesResponse>();
    const ensurePiFetcher = useFetcher<EnsurePiResponse>();
    const createOrderFetcher = useFetcher<CreateOrderResponse>();

    const awaitPushAddresses = useFetcherPromise(pushAddressesFetcher, 'push-addresses failed');
    const awaitEnsurePi = useFetcherPromise(ensurePiFetcher, 'ensure-pi failed');
    const awaitCreateOrder = useFetcherPromise(createOrderFetcher, 'create-order failed');

    const createIntent = useCallback(
        async (args: CreateIntentArgs): Promise<CreateIntentResult> => {
            const { basket, paymentMethodType, paymentConfig, origin, paymentData } = args;
            if (!basket.basketId) {
                throw new Error('Adyen createIntent: basket is missing a basketId');
            }

            // Push addresses if Adyen supplied them in paymentData. Adyen's SDK
            // sends shippingDetails for express; billingDetails may be absent
            // for some payment methods, in which case transformAddressDetails
            // falls back to shipping for billing.
            const shippingDetails = (paymentData as { shippingDetails?: unknown } | undefined)?.shippingDetails;
            if (shippingDetails) {
                const billingDetails = (paymentData as { billingDetails?: unknown } | undefined)?.billingDetails;
                const { billingAddress, shippingAddress } = transformAddressDetails(
                    billingDetails as Parameters<typeof transformAddressDetails>[0],
                    shippingDetails as Parameters<typeof transformAddressDetails>[1]
                );

                const pushForm = new FormData();
                pushForm.set('basketId', basket.basketId);
                pushForm.set('shippingAddress', JSON.stringify(shippingAddress));
                pushForm.set('billingAddress', JSON.stringify(billingAddress));
                void pushAddressesFetcher.submit(pushForm, {
                    method: 'POST',
                    action: '/action/sf-payments-push-addresses',
                });
                assertSuccess(await awaitPushAddresses(), 'push-addresses failed');
            }

            // Ensure the SF Payments PI is attached. Adyen has no
            // onPayerApprove to do this earlier, so it happens here.
            const ensureForm = new FormData();
            ensureForm.set('basket', JSON.stringify(basket));
            ensureForm.set('paymentMethodType', paymentMethodType);
            ensureForm.set('paymentConfig', JSON.stringify(paymentConfig));
            void ensurePiFetcher.submit(ensureForm, {
                method: 'POST',
                action: '/action/sf-payments-ensure-pi',
            });
            assertSuccess(await awaitEnsurePi(), 'ensure-pi failed');

            // Create order + patch PI. paymentData is forwarded so the
            // server-side createPaymentInstrumentBody picks up Adyen's
            // paymentMethod/returnUrl/origin/lineItems/billingDetails.
            const orderForm = new FormData();
            orderForm.set('basketId', basket.basketId);
            orderForm.set('paymentMethodType', paymentMethodType);
            orderForm.set('paymentConfig', JSON.stringify(paymentConfig));
            orderForm.set('origin', origin);
            if (paymentData) {
                orderForm.set('paymentData', JSON.stringify(paymentData));
            }
            void createOrderFetcher.submit(orderForm, {
                method: 'POST',
                action: '/action/sf-payments-create-order',
            });
            const ordered = assertSuccess(await awaitCreateOrder(), 'create-order failed');

            const pi = getSFPaymentsInstrument(ordered.order);
            const paymentReference = (pi as { paymentReference?: AdyenPaymentReference } | undefined)?.paymentReference;
            const paymentReferenceId = paymentReference?.paymentReferenceId;
            if (!paymentReferenceId) {
                throw new Error('Adyen createIntent: order is missing a paymentReferenceId');
            }
            const adyenIntent = paymentReference?.gatewayProperties?.adyen?.adyenPaymentIntent;

            const sdkResult: AdyenSdkIntentPayload = {
                pspReference: adyenIntent?.id,
                guid: paymentReferenceId,
                resultCode: adyenIntent?.resultCode,
                action: adyenIntent?.adyenPaymentIntentAction,
            };
            return { sdkResult, order: ordered.order };
        },
        [pushAddressesFetcher, ensurePiFetcher, createOrderFetcher, awaitPushAddresses, awaitEnsurePi, awaitCreateOrder]
    );

    return {
        prepareBasketOnClick: true,
        createIntent,
    };
}
