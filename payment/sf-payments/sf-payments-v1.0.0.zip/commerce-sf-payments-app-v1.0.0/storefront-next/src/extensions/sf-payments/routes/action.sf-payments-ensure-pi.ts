/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

import { type ActionFunctionArgs, data } from 'react-router';
import { ApiError } from '@salesforce/storefront-next-runtime/scapi';
import { getLogger } from '@/lib/logger.server';
import { ensurePaymentInstrumentInBasket } from '../lib/api/basket-mutations.server';
import type { PaymentConfig } from '../lib/api/types';
import type { PaymentMethodType } from '../lib/sf-payments-utils';

/**
 * Ensure the given basket has a Salesforce Payments instrument. Idempotent —
 * if the instrument already exists, returns the basket unchanged.
 *
 * POST body (FormData — matches storefront-next's useFetcher convention;
 * complex values are JSON-stringified into individual fields):
 *   basket: JSON-stringified Basket (required) — current basket snapshot from the client
 *   paymentMethodType: string (required)
 *   paymentConfig: JSON-stringified PaymentConfig (required)
 */
export async function action({ request, context }: ActionFunctionArgs) {
    if (request.method !== 'POST') {
        return data({ success: false, error: 'Method not allowed' }, { status: 405 });
    }

    const logger = getLogger(context);
    try {
        const formData = await request.formData();
        const basketRaw = formData.get('basket')?.toString();
        const paymentMethodType = formData.get('paymentMethodType')?.toString() as PaymentMethodType | undefined;
        const paymentConfigRaw = formData.get('paymentConfig')?.toString();
        const paymentDataRaw = formData.get('paymentData')?.toString();

        if (!basketRaw || !paymentMethodType || !paymentConfigRaw) {
            return data(
                { success: false, error: 'basket, paymentMethodType, and paymentConfig are required' },
                { status: 400 }
            );
        }

        const basket = JSON.parse(basketRaw) as Parameters<typeof ensurePaymentInstrumentInBasket>[1];
        const paymentConfig = JSON.parse(paymentConfigRaw) as PaymentConfig;
        const paymentData = paymentDataRaw ? (JSON.parse(paymentDataRaw) as Record<string, unknown>) : undefined;
        const updated = await ensurePaymentInstrumentInBasket(
            context,
            basket,
            paymentMethodType,
            paymentConfig,
            paymentData
        );
        // _skipRevalidation: suppress loader revalidation during the payment flow.
        // This action runs mid-confirm; revalidation would re-fetch the basket and disrupt the flow.
        return { success: true, basket: updated, _skipRevalidation: true };
    } catch (error) {
        const isApiError = error instanceof ApiError;
        logger.error('[sf-payments] ensure-pi failed', {
            ...(isApiError ? error.toJSON() : { message: String(error) }),
        });
        return data(
            { success: false, error: isApiError ? error.body?.detail || error.message : String(error) },
            { status: isApiError ? error.status : 500 }
        );
    }
}
