/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import type { Meta, StoryObj } from '@storybook/react-vite';
import PaymentMethods from '../index';
import { useSite } from '@salesforce/storefront-next-runtime/site-context';
import { useBasket } from '@/providers/basket';
import { useSFPaymentsContext } from '../../../providers/sf-payments-provider';
import { useSFPaymentsConfig } from '../../../hooks/use-sf-payments-config';

const meta = {
    title: 'SF Payments/Payment Methods',
    component: PaymentMethods,
    parameters: {
        layout: 'centered',
    },
    tags: ['autodocs'],
} satisfies Meta<typeof PaymentMethods>;

export default meta;
type Story = StoryObj<typeof meta>;

/**
 * Loading state - shown while SDK and payment config are initializing.
 */
export const Loading: Story = {
    decorators: [
        (Story) => {
            (useSite as any) = () => ({
                locale: { id: 'en-US' },
            });
            (useBasket as any) = () => ({
                basketId: 'test-basket-123',
                currency: 'USD',
                orderTotal: 99.99,
            });
            (useSFPaymentsContext as any) = () => ({
                enabled: true,
                sfp: null,
                metadata: null,
                metadataLoading: true,
            });
            (useSFPaymentsConfig as any) = () => ({
                config: null,
                loading: true,
                error: null,
            });

            return (
                <div className="w-full max-w-2xl bg-card p-6 rounded-lg border">
                    <Story />
                </div>
            );
        },
    ],
};

/**
 * Error state - shown when payment configuration fails to load.
 */
export const Error: Story = {
    decorators: [
        (Story) => {
            (useSite as any) = () => ({
                locale: { id: 'en-US' },
            });
            (useBasket as any) = () => ({
                basketId: 'test-basket-123',
                currency: 'USD',
                orderTotal: 99.99,
            });
            (useSFPaymentsContext as any) = () => ({
                enabled: true,
                sfp: null,
                metadata: null,
                metadataLoading: false,
            });
            (useSFPaymentsConfig as any) = () => ({
                config: null,
                loading: false,
                error: 'Failed to load payment configuration. Please try again.',
            });

            return (
                <div className="w-full max-w-2xl bg-card p-6 rounded-lg border">
                    <Story />
                </div>
            );
        },
    ],
};

/**
 * Ready state - SDK loaded and ready to accept payment.
 * In a real environment, this would show the SF Payments SDK checkout UI.
 * In Storybook, we show a placeholder since the SDK requires a real backend.
 */
export const Ready: Story = {
    decorators: [
        (Story) => {
            (useSite as any) = () => ({
                locale: { id: 'en-US' },
            });
            (useBasket as any) = () => ({
                basketId: 'test-basket-123',
                currency: 'USD',
                orderTotal: 99.99,
                billingAddress: {
                    firstName: 'John',
                    lastName: 'Doe',
                    address1: '123 Main St',
                    city: 'San Francisco',
                    stateCode: 'CA',
                    postalCode: '94105',
                    countryCode: 'US',
                },
            });
            (useSFPaymentsContext as any) = () => ({
                enabled: true,
                sfp: {
                    checkout: () => ({
                        updateAmount: () => {},
                        destroy: () => {},
                    }),
                },
                metadata: { clientId: 'test-client' },
                metadataLoading: false,
            });
            (useSFPaymentsConfig as any) = () => ({
                config: {
                    paymentMethods: [
                        { type: 'card', name: 'Credit Card' },
                        { type: 'googlepay', name: 'Google Pay' },
                        { type: 'applepay', name: 'Apple Pay' },
                    ],
                    paymentMethodSetAccounts: [
                        { accountId: 'stripe-account', gatewayId: 'stripe-gw' },
                    ],
                    zoneId: 'default-zone',
                },
                loading: false,
                error: null,
            });

            return (
                <div className="w-full max-w-2xl bg-card p-6 rounded-lg border">
                    <div className="mb-4 text-sm text-muted-foreground">
                        Note: In a real environment, the SF Payments SDK would render payment method UI here.
                        This story shows the component structure without the actual SDK integration.
                    </div>
                    <Story />
                </div>
            );
        },
    ],
};

/**
 * No basket - component returns null when basket has no currency.
 */
export const NoBasket: Story = {
    decorators: [
        (Story) => {
            (useSite as any) = () => ({
                locale: { id: 'en-US' },
            });
            (useBasket as any) = () => ({
                basketId: 'test-basket-123',
                currency: null,
                orderTotal: 99.99,
            });
            (useSFPaymentsContext as any) = () => ({
                enabled: true,
                sfp: null,
                metadata: null,
                metadataLoading: false,
            });
            (useSFPaymentsConfig as any) = () => ({
                config: null,
                loading: false,
                error: null,
            });

            return (
                <div className="w-full max-w-2xl bg-card p-6 rounded-lg border">
                    <div className="mb-4 text-sm text-muted-foreground">
                        When basket has no currency, component returns null (nothing rendered).
                    </div>
                    <Story />
                </div>
            );
        },
    ],
};
