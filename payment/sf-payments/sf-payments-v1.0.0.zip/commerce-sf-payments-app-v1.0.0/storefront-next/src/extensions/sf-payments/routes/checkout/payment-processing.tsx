/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

/**
 * Payment Processing Route — /checkout/payment-processing
 *
 * Landing page for redirect-based express payment methods. The gateway appends
 * `redirect_status` and gateway-specific params to the return URL; our
 * `buildExpressPaymentReturnUrl` adds `orderNo`, `type`, and `zoneId`.
 *
 * Loader logic (server-side):
 *   - `redirect_status=succeeded`            → success state; component navigates to confirmation
 *   - `redirect_status=failed|canceled|<?>` → attemptFailOrder + error state; component goes to checkout
 *   - `redirect_status` absent (abandoned)   → same as failure path
 *   - `redirect_status=processing`           → loading state; shopper can manually return to checkout
 *   - `orderNo` absent                       → immediate redirect to checkout
 */

import React, { useEffect, useRef } from 'react';
import { type LoaderFunctionArgs, redirect, useLoaderData } from 'react-router';
import { useTranslation } from 'react-i18next';
import { getLogger } from '@/lib/logger.server';
import { useNavigate } from '@/hooks/use-navigate';
import { useSFPaymentsContext } from '../../providers/sf-payments-provider';
import { attemptFailOrder } from '../../lib/api/order-mutations.server';

/** Matches `STATUS_SUCCESS = 0` exported from the SF Payments SDK . */
const SDK_RESPONSE_SUCCESS = 0;
const STRIPE_VENDOR = 'Stripe';
const REDIRECT_STATUS_SUCCEEDED = 'succeeded';
const REDIRECT_STATUS_PROCESSING = 'processing';

type LoaderData =
    | { state: 'success'; orderNo: string }
    | { state: 'gateway-redirect'; orderNo: string; vendor: 'Stripe' }
    | { state: 'error' }
    | { state: 'loading'; orderNo: string };

export async function loader({ request, context }: LoaderFunctionArgs): Promise<LoaderData | Response> {
    const url = new URL(request.url);
    const orderNo = url.searchParams.get('orderNo');
    const redirectStatus = url.searchParams.get('redirect_status');
    const vendor = url.searchParams.get('vendor');
    const logger = getLogger(context);

    if (!orderNo) {
        return redirect('/checkout');
    }

    // Gateway redirect — delegate to sfp.handleRedirect() on the client to get
    // ground-truth payment status. Only fail immediately on explicit failure/cancel;
    // success and processing both go to the client.
    if (vendor === STRIPE_VENDOR) {
        if (redirectStatus === REDIRECT_STATUS_SUCCEEDED || redirectStatus === REDIRECT_STATUS_PROCESSING) {
            return { state: 'gateway-redirect', orderNo, vendor: 'Stripe' };
        }
        logger.warn('[sf-payments] payment-processing: gateway redirect failed', {
            orderNo,
            redirectStatus: redirectStatus ?? 'abandoned',
        });
        await attemptFailOrder(context, orderNo);
        return { state: 'error' };
    }

    if (redirectStatus === REDIRECT_STATUS_SUCCEEDED) {
        return { state: 'success', orderNo };
    }

    if (redirectStatus === REDIRECT_STATUS_PROCESSING) {
        return { state: 'loading', orderNo };
    }

    // failed, canceled, unknown status, or no redirect_status (abandoned)
    const reason = redirectStatus ?? 'abandoned';
    logger.warn('[sf-payments] payment-processing: non-success return', { orderNo, redirectStatus: reason });
    await attemptFailOrder(context, orderNo);
    return { state: 'error' };
}

// TODO: add translations for non en-US locales
function PaymentProcessingView({ state }: { state: 'loading' | 'success' | 'error' }) {
    const { t } = useTranslation();
    return (
        <div className="flex min-h-screen items-center justify-center bg-background">
            <div className="w-full max-w-md space-y-6 p-6">
                <div className="text-center" role="status" aria-live="polite">
                    {state === 'loading' && (
                        <>
                            <div className="mb-4 flex justify-center">
                                <div className="h-12 w-12 animate-spin rounded-full border-4 border-primary border-t-transparent" />
                            </div>
                            <h1 className="text-2xl font-semibold">
                                {t('sfPayments.paymentProcessing.loadingTitle')}
                            </h1>
                            <p className="mt-2 text-sm text-muted-foreground">
                                {t('sfPayments.paymentProcessing.loadingDescription')}
                            </p>
                        </>
                    )}

                    {state === 'success' && (
                        <>
                            <div className="mb-4 flex justify-center">
                                <svg
                                    className="h-12 w-12 text-success"
                                    fill="none"
                                    stroke="currentColor"
                                    viewBox="0 0 24 24"
                                    aria-hidden="true"
                                >
                                    <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth={2}
                                        d="M5 13l4 4L19 7"
                                    />
                                </svg>
                            </div>
                            <h1 className="text-2xl font-semibold">
                                {t('sfPayments.paymentProcessing.successTitle')}
                            </h1>
                            <p className="mt-2 text-sm text-muted-foreground">
                                {t('sfPayments.paymentProcessing.successDescription')}
                            </p>
                        </>
                    )}

                    {state === 'error' && (
                        <>
                            <div className="mb-4 flex justify-center">
                                <svg
                                    className="h-12 w-12 text-destructive"
                                    fill="none"
                                    stroke="currentColor"
                                    viewBox="0 0 24 24"
                                    aria-hidden="true"
                                >
                                    <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth={2}
                                        d="M6 18L18 6M6 6l12 12"
                                    />
                                </svg>
                            </div>
                            <h1 className="text-2xl font-semibold">
                                {t('sfPayments.paymentProcessing.errorTitle')}
                            </h1>
                            <p className="mt-2 text-sm text-destructive">
                                {t('sfPayments.paymentProcessing.errorDescription')}
                            </p>
                            <p className="mt-2 text-sm text-muted-foreground">
                                {t('sfPayments.paymentProcessing.errorRedirect')}
                            </p>
                        </>
                    )}
                </div>
            </div>
        </div>
    );
}

async function handleVendorRedirect(
    vendor: 'Stripe',
    sfp: { handleRedirect: () => Promise<{ responseCode: number }> },
    orderNo: string
): Promise<boolean> {
    switch (vendor) {
        case 'Stripe': {
            const result = await sfp.handleRedirect();
            return result?.responseCode === SDK_RESPONSE_SUCCESS;
        }
        // case 'Adyen': add when the slice lands — likely calls an action route
    }
}

export default function PaymentProcessingPage() {
    const data = useLoaderData<typeof loader>() as LoaderData;
    const navigate = useNavigate();
    const { sfp } = useSFPaymentsContext();
    const isHandled = useRef(false);

    useEffect(() => {
        if (isHandled.current) return;

        switch (data.state) {
            case 'success':
                isHandled.current = true;
                void navigate(`/order-confirmation/${data.orderNo}`);
                return;

            case 'error':
                isHandled.current = true;
                void navigate('/checkout');
                return;

            // TODO: `processing` state redirects immediately to checkout without calling attemptFailOrder,
            // so the order stays in `created` and the basket is not reopened. Recovery will be addressed
            // in a follow-up slice.
            case 'loading':
                isHandled.current = true;
                void navigate('/checkout');
                return;

            case 'gateway-redirect':
                if (!sfp) return;
                isHandled.current = true;
                void (async () => {
                    try {
                        const success = await handleVendorRedirect(
                            data.vendor,
                            sfp as { handleRedirect: () => Promise<{ responseCode: number }> },
                            data.orderNo
                        );
                        void navigate(success ? `/order-confirmation/${data.orderNo}` : '/checkout');
                    } catch {
                        void navigate('/checkout');
                    }
                })();
                return;
        }
    }, [data, sfp, navigate]);

    return <PaymentProcessingView state={data.state === 'gateway-redirect' ? 'loading' : data.state} />;
}
