/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

import { type ActionFunctionArgs, data } from 'react-router';
import { ApiError, type ShopperBasketsV2 } from '@/scapi';
import { getLogger } from '@/lib/logger.server';
import { withRevalidateTags } from '@/lib/revalidation/tags';
import { CHECKOUT_PAYMENT_COMPLETE_TAG } from '../lib/constants';
import { updateBillingAddressForBasket, updateShippingAddressForShipment } from '../lib/api/basket-mutations.server';

type OrderAddress = ShopperBasketsV2.schemas['OrderAddress'];
const DEFAULT_SHIPMENT_ID = 'me';

/**
 * Push shipping (required) + billing (optional) addresses onto a basket.
 * Called after the shopper approves payment in the wallet sheet, when the
 * full (un-redacted) address details are first available. Shipping is
 * updated first, then billing if provided.
 *
 * POST body (FormData — matches storefront-next's useFetcher convention;
 * complex values are JSON-stringified into individual fields):
 *   basketId: string (required)
 *   shippingAddress: JSON-stringified OrderAddress (required)
 *   billingAddress: JSON-stringified OrderAddress (optional)
 *   shipmentId: string (optional, defaults to 'me')
 */
export async function action({ request, context }: ActionFunctionArgs) {
    if (request.method !== 'POST') {
        return data({ success: false, error: 'Method not allowed' }, { status: 405 });
    }

    const logger = getLogger(context);
    try {
        const formData = await request.formData();
        const basketId = formData.get('basketId')?.toString();
        const shippingAddressRaw = formData.get('shippingAddress')?.toString();
        const billingAddressRaw = formData.get('billingAddress')?.toString();
        const shipmentId = formData.get('shipmentId')?.toString() || DEFAULT_SHIPMENT_ID;

        if (!basketId || !shippingAddressRaw) {
            return data({ success: false, error: 'basketId and shippingAddress are required' }, { status: 400 });
        }

        const shippingAddress = JSON.parse(shippingAddressRaw) as OrderAddress;
        const billingAddress = billingAddressRaw ? (JSON.parse(billingAddressRaw) as OrderAddress) : undefined;

        let basket = await updateShippingAddressForShipment(context, basketId, shipmentId, shippingAddress);
        if (billingAddress) {
            basket = await updateBillingAddressForBasket(context, basketId, billingAddress);
        }
        return withRevalidateTags({ success: true, basket }, [CHECKOUT_PAYMENT_COMPLETE_TAG]);
    } catch (error) {
        const isApiError = error instanceof ApiError;
        logger.error('[sf-payments] push-addresses failed', {
            ...(isApiError ? error.toJSON() : { message: String(error) }),
        });
        return data(
            { success: false, error: isApiError ? error.body?.detail || error.message : String(error) },
            { status: isApiError ? error.status : 500 }
        );
    }
}
