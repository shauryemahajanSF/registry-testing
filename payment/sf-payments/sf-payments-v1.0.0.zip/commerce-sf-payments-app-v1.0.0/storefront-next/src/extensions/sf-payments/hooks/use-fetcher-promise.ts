/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

'use client';

import { useEffect, useMemo, useRef } from 'react';
import type { FetcherWithComponents } from 'react-router';

/**
 * Adapter that turns a React Router `useFetcher()` into an awaitable Promise.
 *
 * Storefront-next's convention for action-route calls is `useFetcher()` +
 * `submit()`. Gateway-strategy hooks need to sequence several fetcher
 * submissions and await each one — this helper bridges the gap by watching
 * `fetcher.state` and resolving the returned promise when the fetcher returns
 * to `'idle'`.
 *
 * Usage:
 * ```ts
 * const fetcher = useFetcher<{ success: boolean; basket?: Basket }>();
 * const awaitResult = useFetcherPromise(fetcher, 'ensure-pi failed');
 * fetcher.submit(formData, { method: 'POST', action: '/action/sf-payments-ensure-pi' });
 * const result = await awaitResult(); // resolves with fetcher.data
 * ```
 *
 * Port of `packages/template-retail-rsc-app/src/hooks/use-fetcher-promise.ts`
 * from storefront-next's `feature/salesforce-payments` branch.
 */
export function useFetcherPromise<TData>(
    fetcher: FetcherWithComponents<TData>,
    defaultErrorMessage: string
): () => Promise<TData | undefined> {
    const promiseRef = useRef<{
        resolve: (value: TData | undefined) => void;
        reject: (error: Error) => void;
    } | null>(null);
    const previousStateRef = useRef<string | undefined>(undefined);

    useEffect(() => {
        const stateChanged = previousStateRef.current !== fetcher.state;
        previousStateRef.current = fetcher.state;

        if (stateChanged && fetcher.state === 'idle' && promiseRef.current) {
            const { resolve, reject } = promiseRef.current;
            promiseRef.current = null;

            if (fetcher.data !== undefined) {
                resolve(fetcher.data);
            } else {
                reject(new Error(defaultErrorMessage));
            }
        }
    }, [fetcher.state, fetcher.data, defaultErrorMessage]);

    return useMemo(() => {
        return () => {
            return new Promise<TData | undefined>((resolve, reject) => {
                promiseRef.current = { resolve, reject };
            });
        };
    }, []);
}
