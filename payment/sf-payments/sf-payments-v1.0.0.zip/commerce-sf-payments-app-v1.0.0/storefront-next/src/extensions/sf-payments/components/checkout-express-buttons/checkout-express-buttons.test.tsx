/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import React from 'react';
import { render, screen } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import CheckoutExpressButtons from './index';
import { useBasket } from '@/providers/basket';
import ExpressButtons from '../express-buttons';

vi.mock('@salesforce/storefront-next-runtime/site-context', () => ({
    useSite: vi.fn(() => ({
        currency: 'USD',
        locale: { id: 'en-US' },
    })),
}));

vi.mock('@/providers/basket', () => ({
    useBasket: vi.fn(),
}));

vi.mock('../express-buttons', () => ({
    default: vi.fn(({ onPaymentMethodsRendered }) => {
        if (onPaymentMethodsRendered) {
            setTimeout(() => onPaymentMethodsRendered(), 0);
        }
        return <div data-testid="express-buttons-mock">Express Buttons</div>;
    }),
}));

vi.mock('../../lib/sf-payments-country', () => ({
    getLocaleDerivedCountryCode: vi.fn(() => 'US'),
}));

vi.mock('../../lib/sf-payments-utils', () => ({
    EXPRESS_PAY_NOW: 0,
}));

vi.mock('react-i18next', () => ({
    useTranslation: vi.fn(() => ({
        t: (key: string, opts?: { defaultValue?: string }) => opts?.defaultValue ?? key,
    })),
}));

vi.mock('@/components/ui/card', () => ({
    Card: ({ children, ...props }: any) => <div data-testid="card-mock" {...props}>{children}</div>,
}));

const defaultBasket = {
    basketId: 'test-basket-123',
    currency: 'USD',
    orderTotal: 99.99,
    billingAddress: {
        countryCode: 'US',
    },
};

describe('CheckoutExpressButtons', () => {
    beforeEach(() => {
        vi.clearAllMocks();
        vi.mocked(useBasket).mockReturnValue(defaultBasket as any);
    });

    it('renders express buttons when basket exists', () => {
        render(<CheckoutExpressButtons />);
        expect(screen.getByTestId('express-buttons-mock')).toBeInTheDocument();
    });

    it('renders null when no basket', () => {
        vi.mocked(useBasket).mockReturnValueOnce(null as any);

        const { container } = render(<CheckoutExpressButtons />);
        expect(container.firstChild).toBeNull();
    });

    it('passes correct props to ExpressButtons', () => {
        render(<CheckoutExpressButtons />);

        expect(vi.mocked(ExpressButtons)).toHaveBeenCalledWith(
            expect.objectContaining({
                initialAmount: 99.99,
                currency: 'USD',
                countryCode: 'US',
                usage: 0,
                expressButtonLayout: 'horizontal',
                maximumButtonCount: 5,
            }),
            undefined
        );
    });

    it('uses billing address country code when available', () => {
        render(<CheckoutExpressButtons />);

        expect(vi.mocked(ExpressButtons)).toHaveBeenCalledWith(
            expect.objectContaining({
                countryCode: 'US',
            }),
            undefined
        );
    });

    it('falls back to locale-derived country when no billing address', () => {
        vi.mocked(useBasket).mockReturnValueOnce({
            basketId: 'test-basket-123',
            currency: 'USD',
            orderTotal: 99.99,
            billingAddress: null,
        } as any);

        render(<CheckoutExpressButtons />);

        expect(vi.mocked(ExpressButtons)).toHaveBeenCalledWith(
            expect.objectContaining({
                countryCode: 'US',
            }),
            undefined
        );
    });

    it('uses productTotal as fallback when orderTotal is not available', () => {
        vi.mocked(useBasket).mockReturnValueOnce({
            basketId: 'test-basket-456',
            currency: 'USD',
            orderTotal: undefined,
            productTotal: 79.99,
            billingAddress: { countryCode: 'US' },
        } as any);

        render(<CheckoutExpressButtons />);

        expect(vi.mocked(ExpressButtons)).toHaveBeenCalledWith(
            expect.objectContaining({
                initialAmount: 79.99,
            }),
            undefined
        );
    });
});
