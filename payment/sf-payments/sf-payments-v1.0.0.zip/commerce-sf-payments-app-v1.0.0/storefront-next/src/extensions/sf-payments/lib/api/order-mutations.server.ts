/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

/**
 * Shared order SCAPI operations for SF Payments.
 *
 * Each function is a plain async function taking the React Router context as
 * its first argument. No hooks, no placement awareness — these are callable
 * from express and sheet flows alike.
 */

import type { RouterContextProvider } from 'react-router';
import type { ShopperOrders } from '@salesforce/storefront-next-runtime/scapi';
import { createApiClients } from '@/lib/api-clients.server';
import { createPaymentInstrumentBody, getSFPaymentsInstrument, type PaymentMethodType } from '../sf-payments-utils';
import type { PaymentConfig } from './types';

type Order = ShopperOrders.schemas['Order'];

/**
 * Extends `Error` with the order number created before the failure so the
 * caller can drive recovery (`attemptFailOrder`). Thrown by
 * `createOrderAndUpdatePayment` when payment-instrument patch fails.
 */
export interface OrderCreationError extends Error {
    orderNo?: string;
}

/**
 * Create an order from a basket.
 *
 * Direct wrapper around `shopperOrders.createOrder`. Unlike
 * `/action/place-order`, this performs no customer-profile side effects and
 * no basket middleware cleanup — callers own those concerns.
 */
export async function createOrderFromBasket(
    context: Readonly<RouterContextProvider>,
    basketId: string
): Promise<Order> {
    const clients = createApiClients(context);
    const { data: order } = await clients.shopperOrders.createOrder({
        params: {},
        body: { basketId },
    });
    return order;
}

/**
 * Update a payment instrument on an order. This is the SCAPI call that
 * actually triggers the gateway authorization/charge.
 */
export async function updatePaymentInstrumentForOrder(
    context: Readonly<RouterContextProvider>,
    orderNo: string,
    paymentInstrumentId: string,
    body: ShopperOrders.schemas['OrderPaymentInstrumentRequest']
): Promise<Order> {
    const clients = createApiClients(context);
    const { data: order } = await clients.shopperOrders.updatePaymentInstrumentForOrder({
        params: { path: { orderNo, paymentInstrumentId } },
        body,
    });
    return order;
}

/**
 * Attempt to fail an order and reopen its basket so the shopper can retry.
 *
 * Only the `created` order status supports the `failOrder` transition — any
 * other status resolves to `false` without error. Errors are swallowed and
 * reported as `false`; failOrder is best-effort recovery, not a guarantee.
 *
 * @returns `true` if the order was failed and the basket reopened, else `false`.
 */
export async function attemptFailOrder(context: Readonly<RouterContextProvider>, orderNo: string): Promise<boolean> {
    if (!orderNo) return false;
    const clients = createApiClients(context);
    try {
        const { data: order } = await clients.shopperOrders.getOrder({
            params: { path: { orderNo } },
        });
        if (order.status !== 'created') {
            return false;
        }
        await clients.shopperOrders.failOrder({
            params: { path: { orderNo }, query: { reopenBasket: true } },
            body: { reasonCode: 'payment_confirm_failure' },
        });
        return true;
    } catch {
        return false;
    }
}

/**
 * Build the 3DS/redirect return URL for a payment instrument body.
 *
 * Consumed by gateway strategies (Stripe, Adyen) that require a redirect URL
 * when the gateway escalates to an authentication challenge.
 *
 * `zoneId` is omitted from the URL when undefined rather than substituted
 * with a placeholder — the `/checkout/payment-processing` handler treats a
 * missing `zoneId` as fail-loud, which is the desired behavior now that the
 * backend is moving away from a 'default' zone value.
 */
export function buildPaymentReturnUrl(
    origin: string,
    orderNo: string,
    zoneId: string | undefined,
    paymentMethodType: string
): string {
    const params = new URLSearchParams({ orderNo, type: paymentMethodType });
    if (zoneId !== undefined) {
        params.set('zoneId', zoneId);
    }
    return `${origin}/checkout/payment-processing?${params.toString()}`;
}

/**
 * Create an order and patch its SF Payments instrument in one step.
 *
 * Workflow:
 * 1. `createOrder({ body: { basketId } })` — basket is consumed; `order.orderNo` exists.
 * 2. Find the SF Payments instrument on the order via `getSFPaymentsInstrument`.
 * 3. Build a `returnUrl` for 3DS/redirect flows.
 * 4. `updatePaymentInstrumentForOrder(...)` — triggers gateway authorization.
 *
 * On a failure in step 4 the returned error carries `orderNo` so the caller
 * can invoke {@link attemptFailOrder} for basket recovery.
 */
export async function createOrderAndUpdatePayment(
    context: Readonly<RouterContextProvider>,
    args: {
        basketId: string;
        paymentMethodType: PaymentMethodType;
        paymentConfig: PaymentConfig;
        paymentData?: Record<string, unknown>;
        /** Origin (protocol + host) used to build the 3DS return URL. */
        origin: string;
    }
): Promise<Order> {
    const { basketId, paymentMethodType, paymentConfig, paymentData, origin } = args;
    if (!paymentConfig.zoneId) {
        throw new Error('Payment config is missing a zoneId');
    }
    const { zoneId } = paymentConfig;
    const order = await createOrderFromBasket(context, basketId);
    if (!order.orderNo) {
        throw new Error('Order creation returned no orderNo');
    }
    const orderPI = getSFPaymentsInstrument(order);
    if (!orderPI?.paymentInstrumentId) {
        throw new Error('Order is missing a Salesforce Payments instrument');
    }
    if (typeof order.orderTotal !== 'number' || !Number.isFinite(order.orderTotal) || order.orderTotal <= 0) {
        throw new Error(`Order has an invalid orderTotal: ${String(order.orderTotal)}`);
    }

    const returnUrl = buildPaymentReturnUrl(origin, order.orderNo, zoneId, paymentMethodType);
    const body = createPaymentInstrumentBody({
        amount: order.orderTotal,
        paymentMethodType,
        zoneId,
        paymentData: { ...(paymentData ?? {}), returnUrl },
        paymentMethods: paymentConfig.paymentMethods,
        paymentMethodSetAccounts: paymentConfig.paymentMethodSetAccounts,
    });

    try {
        return await updatePaymentInstrumentForOrder(
            context,
            order.orderNo,
            orderPI.paymentInstrumentId,
            body as ShopperOrders.schemas['OrderPaymentInstrumentRequest']
        );
    } catch (error) {
        const err = (error instanceof Error ? error : new Error(String(error))) as OrderCreationError;
        err.orderNo = order.orderNo;
        throw err;
    }
}
