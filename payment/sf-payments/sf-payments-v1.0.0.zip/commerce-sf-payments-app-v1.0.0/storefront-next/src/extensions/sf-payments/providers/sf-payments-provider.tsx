/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

'use client'

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react'
import { useConfig } from '@salesforce/storefront-next-runtime/config'
import { fetchShopperConfig } from '../hooks/use-sf-payments-shopper-config'
import { loadScript } from '../lib/sf-payments-sdk-loader'
import { fetchMetadata } from '../hooks/use-sf-payments-metadata'

/**
 * SDK-lifecycle state shared across the app.
 *
 * Intentionally narrow: transaction values (currency, countryCode) and
 * per-(currency, countryCode) payment configuration are NOT stored here —
 * they vary per consumer (PDP vs. cart vs. checkout vs. payment sheet) and
 * are fetched by `useSFPaymentsConfig({ currency, countryCode })` at the
 * consumer level.
 *
 * What lives here is genuinely singleton-per-app:
 *   - SF Payments enabled flag (site-level shopper config)
 *   - Metadata (tenant/account-level SDK config: payment methods, icons, gateways)
 *   - The loaded `sfp.js` script state and the single `new SFPayments()` instance
 *
 * Duplicating any of these across consumers would waste bandwidth (script),
 * double-register SDK listeners (sfp instance), or race on metadata.
 */
export interface SFPaymentsContextValue {
    enabled: boolean
    metadata: Record<string, unknown> | null
    metadataLoading: boolean
    sfp: any | null
}

const defaultState: SFPaymentsContextValue = {
    enabled: false,
    metadata: null,
    metadataLoading: false,
    sfp: null
}

const SFPaymentsContext = createContext<SFPaymentsContextValue>(defaultState)

type SFPaymentsUpdater = {
    setPayments: (next: Partial<SFPaymentsContextValue>) => void
}

const SFPaymentsUpdaterContext = createContext<SFPaymentsUpdater | undefined>(undefined)

export interface SFPaymentsProviderProps {
    children: ReactNode
}

/**
 * SF Payments provider — thin shell for SDK-lifecycle state.
 *
 * Holds context state and an updater. Fires zero network requests on mount.
 * The init cascade (shopper config + metadata + SDK script, all in parallel)
 * is triggered lazily by the first component that calls `useSFPaymentsContext()`.
 */
export default function SFPaymentsProvider({ children }: SFPaymentsProviderProps) {
    const [state, setState] = useState<SFPaymentsContextValue>(defaultState)

    const setPayments = useCallback((next: Partial<SFPaymentsContextValue>) => {
        setState((current) => ({ ...current, ...next }))
    }, [])

    const updaterValue = useMemo(() => ({ setPayments }), [setPayments])

    return (
        <SFPaymentsUpdaterContext.Provider value={updaterValue}>
            <SFPaymentsContext.Provider value={state}>
                {children}
            </SFPaymentsContext.Provider>
        </SFPaymentsUpdaterContext.Provider>
    )
}

/**
 * Returns the current SF Payments SDK-lifecycle context. On first call,
 * triggers the init cascade (shopper config, metadata, and SDK script fan out
 * in parallel; the `sfp` instance is constructed once the script resolves).
 * Subsequent calls — and remounts under the same provider — reuse the hydrated
 * state.
 *
 * Pages without SF Payments consumers pay zero cost.
 *
 * Two independent gates control downloads:
 *
 *   1. Local config (`config.sfPayments.enabled` + `sdkUrl`) — evaluated
 *      synchronously via `useConfig()`. This is the merchant's operational
 *      kill switch and A/B-test dial. When off, we fire no requests and load
 *      no script. First paint is unaffected.
 *
 *   2. Shopper config (`SalesforcePaymentsAllowed`) — evaluated asynchronously
 *      from SCAPI. This is the server-side feature toggle managed in Business
 *      Manager. We still start the SDK script and metadata fetches in parallel
 *      with this check to minimize time-to-interactive; the flag gates
 *      instantiation of `new SFPayments()` and exposure of the context
 *      `enabled` field that downstream components use to decide whether to
 *      render the Pay / Express buttons.
 */
export function useSFPaymentsContext(): SFPaymentsContextValue {
    const config = useConfig()
    const state = useContext(SFPaymentsContext)
    const updater = useContext(SFPaymentsUpdaterContext)
    const initRef = useRef(false)
    // Snapshot state so the init effect can see the latest provider state
    // on remount without making `state` itself a dep (which would re-run the
    // cascade on every setPayments call).
    const stateRef = useRef(state)
    stateRef.current = state

    const sfPaymentsConfig = (config as any)?.sfPayments
    const localEnabled = sfPaymentsConfig?.enabled === true
    const sdkUrl: string | undefined = sfPaymentsConfig?.sdkUrl

    useEffect(() => {
        if (initRef.current || !updater) return

        // Sync gate — if the merchant disabled SF Payments locally or hasn't
        // configured an sdkUrl, skip the cascade entirely. No fetches, no
        // script download. Bandwidth and first-paint cost on pages that
        // happen to render a payments consumer but have the feature off.
        if (!localEnabled || !sdkUrl) return

        initRef.current = true

        // Remount guard: SFPaymentsProvider lives at the app root and survives
        // route navigations, so on PDP → PLP → PDP the consumer remounts but the
        // context is still hydrated from the first visit. Skip the cascade —
        // the module-level single-flight memos would dedupe the network calls
        // anyway, but re-running setPayments causes a brief loading flicker and
        // discards the working SDK instance.
        const prev = stateRef.current
        if (prev.metadata && prev.sfp) return

        updater.setPayments({ metadataLoading: true })

        // Fan out all three async operations in parallel. They have no data
        // dependencies on each other — shopper config gates SDK _usage_ but
        // not download; metadata and sdk script are independent.
        ;(async () => {
            const [shopperResult, metadataResult, scriptResult] = await Promise.allSettled([
                fetchShopperConfig(),
                fetchMetadata(),
                loadScript(sdkUrl, 'sf-payments-sdk'),
            ])

            const enabled =
                shopperResult.status === 'fulfilled' &&
                shopperResult.value?.SalesforcePaymentsAllowed === true

            const metadata =
                metadataResult.status === 'fulfilled' ? metadataResult.value.metadata : null

            // Only instantiate SFPayments if the shopper flag is on AND the
            // script loaded AND the global is present.
            const canInstantiate =
                enabled &&
                scriptResult.status === 'fulfilled' &&
                typeof window !== 'undefined' &&
                typeof (window as any).SFPayments === 'function'

            updater.setPayments({
                enabled,
                metadata,
                metadataLoading: false,
                sfp: canInstantiate ? new (window as any).SFPayments() : null,
            })
        })()
    }, [updater, localEnabled, sdkUrl])

    return state
}
