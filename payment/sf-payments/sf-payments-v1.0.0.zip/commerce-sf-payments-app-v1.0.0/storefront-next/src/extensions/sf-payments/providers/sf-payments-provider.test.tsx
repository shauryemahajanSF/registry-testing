/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 */
import { describe, expect, it, beforeEach, afterEach, vi } from 'vitest'
import { render, renderHook, screen, waitFor } from '@testing-library/react'
import type { PropsWithChildren } from 'react'
import SFPaymentsProvider, { useSFPaymentsContext } from './sf-payments-provider'

// --- Mocks ---

const mockShopperConfig = { SalesforcePaymentsAllowed: true }
const mockMetadata = { metadata: { version: '1.0' } }
const defaultSfPaymentsConfig = {
    enabled: true,
    sdkUrl: 'https://example.com/sfp.js',
    metadataUrl: 'https://example.com/metadata.json',
}

vi.mock('@salesforce/storefront-next-runtime/config', () => ({
    useConfig: vi.fn(() => ({ sfPayments: defaultSfPaymentsConfig })),
}))

vi.mock('../hooks/use-sf-payments-shopper-config', () => ({
    fetchShopperConfig: vi.fn(() => Promise.resolve(mockShopperConfig))
}))

vi.mock('../lib/sf-payments-sdk-loader', () => ({
    loadScript: vi.fn(() => Promise.resolve())
}))

vi.mock('../hooks/use-sf-payments-metadata', () => ({
    fetchMetadata: vi.fn(() => Promise.resolve({ metadata: { version: '1.0' } }))
}))

const mockSfpInstance = { express: vi.fn() }

// Import mocked modules for per-test control
import { useConfig } from '@salesforce/storefront-next-runtime/config'
import { fetchShopperConfig } from '../hooks/use-sf-payments-shopper-config'
import { loadScript } from '../lib/sf-payments-sdk-loader'
import { fetchMetadata } from '../hooks/use-sf-payments-metadata'

describe('SFPaymentsProvider + useSFPaymentsContext', () => {
    beforeEach(() => {
        vi.clearAllMocks()
        vi.mocked(useConfig).mockReturnValue({ sfPayments: defaultSfPaymentsConfig } as any)
        vi.mocked(fetchShopperConfig).mockResolvedValue(mockShopperConfig)
        // loadScript mock sets window.SFPayments when it resolves,
        // matching real behavior where the script tag sets the global.
        // Use a regular `function` (not arrow) so the provider can call it
        // with `new` — arrows are not constructors.
        vi.mocked(loadScript).mockImplementation(() => {
            ;(window as any).SFPayments = function () {
                return mockSfpInstance
            }
            return Promise.resolve()
        })
        vi.mocked(fetchMetadata).mockResolvedValue({
            metadata: mockMetadata.metadata,
        })
    })

    afterEach(() => {
        vi.restoreAllMocks()
        delete (window as any).SFPayments
    })

    const wrapper = ({ children }: PropsWithChildren) => (
        <SFPaymentsProvider>{children}</SFPaymentsProvider>
    )

    it('returns default state before any consumer mounts', () => {
        // Render provider without calling useSFPaymentsContext
        const { result } = renderHook(
            () => {
                // Access raw context to verify default state without triggering init
                return null
            },
            { wrapper }
        )

        expect(result.current).toBeNull()
        expect(fetchShopperConfig).not.toHaveBeenCalled()
        expect(loadScript).not.toHaveBeenCalled()
        expect(fetchMetadata).not.toHaveBeenCalled()
    })

    it('fans out shopper config, metadata, and SDK script in parallel on first consumer', async () => {
        renderHook(() => useSFPaymentsContext(), { wrapper })

        await waitFor(() => {
            expect(fetchShopperConfig).toHaveBeenCalledTimes(1)
            expect(fetchMetadata).toHaveBeenCalledTimes(1)
            expect(loadScript).toHaveBeenCalledWith('https://example.com/sfp.js', 'sf-payments-sdk')
        })
    })

    it('hydrates SDK-lifecycle state after cascade completes', async () => {
        const { result } = renderHook(() => useSFPaymentsContext(), { wrapper })

        await waitFor(() => {
            expect(result.current.enabled).toBe(true)
            expect(result.current.metadata).toEqual({ version: '1.0' })
            expect(result.current.metadataLoading).toBe(false)
            expect(result.current.sfp).toBe(mockSfpInstance)
        })
    })

    it('does not re-trigger cascade on rerender', async () => {
        const { result, rerender } = renderHook(() => useSFPaymentsContext(), { wrapper })

        await waitFor(() => {
            expect(result.current.enabled).toBe(true)
        })

        rerender()
        rerender()

        expect(fetchShopperConfig).toHaveBeenCalledTimes(1)
        expect(fetchMetadata).toHaveBeenCalledTimes(1)
    })

    it('does not re-trigger cascade when consumer unmounts and remounts under the same provider', async () => {
        // Simulates PDP → PLP → PDP: the provider lives at the app root and
        // survives route navigation, but the consuming component
        // (e.g. PDPExpressButtons) unmounts on leave and remounts on return.
        // The remount guard inside useSFPaymentsContext should keep the already-
        // hydrated context intact without re-running the cascade.

        function Consumer() {
            const ctx = useSFPaymentsContext()
            return (
                <div data-testid="consumer">
                    {ctx.sfp ? 'hydrated' : ctx.metadataLoading ? 'loading' : 'idle'}
                </div>
            )
        }

        const { rerender } = render(
            <SFPaymentsProvider>
                <Consumer />
            </SFPaymentsProvider>
        )

        await waitFor(() => {
            expect(screen.getByTestId('consumer').textContent).toBe('hydrated')
        })

        expect(fetchShopperConfig).toHaveBeenCalledTimes(1)
        expect(fetchMetadata).toHaveBeenCalledTimes(1)
        expect(loadScript).toHaveBeenCalledTimes(1)

        // Unmount the consumer (simulate navigation away from PDP).
        rerender(<SFPaymentsProvider>{null}</SFPaymentsProvider>)

        // Remount the consumer (simulate navigation back to PDP).
        rerender(
            <SFPaymentsProvider>
                <Consumer />
            </SFPaymentsProvider>
        )

        // The guard should short-circuit before any setPayments({ ...Loading: true })
        // call, so the context reads as fully hydrated on first render.
        expect(screen.getByTestId('consumer').textContent).toBe('hydrated')

        // And no fetcher / script / SDK instantiation should run a second time.
        expect(fetchShopperConfig).toHaveBeenCalledTimes(1)
        expect(fetchMetadata).toHaveBeenCalledTimes(1)
        expect(loadScript).toHaveBeenCalledTimes(1)
    })

    it('sets enabled to false when shopper config fetch fails and does not instantiate sfp', async () => {
        vi.mocked(fetchShopperConfig).mockRejectedValue(new Error('Network error'))

        const { result } = renderHook(() => useSFPaymentsContext(), { wrapper })

        await waitFor(() => {
            expect(result.current.metadataLoading).toBe(false)
        })

        expect(result.current.enabled).toBe(false)
        expect(result.current.sfp).toBeNull()
    })

    it('does not instantiate sfp when shopper config disables SF Payments, even though script and metadata loaded', async () => {
        vi.mocked(fetchShopperConfig).mockResolvedValue({ SalesforcePaymentsAllowed: false })

        const { result } = renderHook(() => useSFPaymentsContext(), { wrapper })

        await waitFor(() => {
            expect(result.current.metadataLoading).toBe(false)
        })

        expect(result.current.enabled).toBe(false)
        expect(result.current.metadata).toEqual({ version: '1.0' })
        // Script still loads in parallel (shopper flag doesn't gate download),
        // but we never construct `new SFPayments()` if the flag is off.
        expect(loadScript).toHaveBeenCalledTimes(1)
        expect(result.current.sfp).toBeNull()
    })

    it('skips the entire cascade when local config disables SF Payments', async () => {
        vi.mocked(useConfig).mockReturnValue({
            sfPayments: { ...defaultSfPaymentsConfig, enabled: false },
        } as any)

        const { result } = renderHook(() => useSFPaymentsContext(), { wrapper })

        // No async work should run — this is a synchronous kill switch.
        expect(fetchShopperConfig).not.toHaveBeenCalled()
        expect(fetchMetadata).not.toHaveBeenCalled()
        expect(loadScript).not.toHaveBeenCalled()
        expect(result.current.enabled).toBe(false)
        expect(result.current.metadata).toBeNull()
        expect(result.current.sfp).toBeNull()
    })

    it('skips the entire cascade when sdkUrl is not configured', async () => {
        vi.mocked(useConfig).mockReturnValue({
            sfPayments: { ...defaultSfPaymentsConfig, sdkUrl: '' },
        } as any)

        const { result } = renderHook(() => useSFPaymentsContext(), { wrapper })

        expect(fetchShopperConfig).not.toHaveBeenCalled()
        expect(fetchMetadata).not.toHaveBeenCalled()
        expect(loadScript).not.toHaveBeenCalled()
        expect(result.current.sfp).toBeNull()
    })

    it('skips the entire cascade when sfPayments config is absent', async () => {
        vi.mocked(useConfig).mockReturnValue({} as any)

        const { result } = renderHook(() => useSFPaymentsContext(), { wrapper })

        expect(fetchShopperConfig).not.toHaveBeenCalled()
        expect(fetchMetadata).not.toHaveBeenCalled()
        expect(loadScript).not.toHaveBeenCalled()
        expect(result.current.sfp).toBeNull()
    })

    it('handles metadata fetch failure gracefully', async () => {
        vi.mocked(fetchMetadata).mockRejectedValue(new Error('HTTP 500'))

        const { result } = renderHook(() => useSFPaymentsContext(), { wrapper })

        await waitFor(() => {
            expect(result.current.metadataLoading).toBe(false)
        })

        expect(result.current.metadata).toBeNull()
        // Shopper config + script can still succeed → sfp gets instantiated
        // even though metadata fetch failed. Metadata is required for the
        // UI blueprint but not for SFPayments construction.
        expect(result.current.enabled).toBe(true)
    })

    it('handles SDK script load failure gracefully', async () => {
        vi.mocked(loadScript).mockRejectedValue(new Error('Script load failed'))

        const { result } = renderHook(() => useSFPaymentsContext(), { wrapper })

        await waitFor(() => {
            expect(result.current.metadataLoading).toBe(false)
        })

        expect(result.current.sfp).toBeNull()
        expect(result.current.enabled).toBe(true)
        expect(result.current.metadata).toEqual({ version: '1.0' })
    })
})
