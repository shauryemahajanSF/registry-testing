/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

import { type ActionFunctionArgs, data } from 'react-router';
import { getLogger } from '@/lib/logger.server';
import { attemptFailOrder } from '../lib/api/order-mutations.server';

/**
 * Fail an order and reopen its basket after payment confirmation fails.
 *
 * POST body (FormData):
 *   orderNo: string (required)
 *   flow: 'express' | 'sheet' (optional) — for log attribution only
 */
export async function action({ request, context }: ActionFunctionArgs) {
    if (request.method !== 'POST') {
        return data({ success: false, error: 'Method not allowed' }, { status: 405 });
    }

    const logger = getLogger(context);
    const formData = await request.formData();
    const orderNo = formData.get('orderNo')?.toString();
    const flowRaw = formData.get('flow')?.toString();
    const flow = flowRaw === 'express' || flowRaw === 'sheet' ? flowRaw : 'unknown';

    if (!orderNo) {
        return data({ success: false, error: 'orderNo is required' }, { status: 400 });
    }

    // attemptFailOrder swallows SCAPI errors internally and returns false — this catch
    // is defense-in-depth for unexpected programming errors (logger crash, context misuse).
    try {
        const basketRecovered = await attemptFailOrder(context, orderNo);
        logger.info('[sf-payments] fail-order', { orderNo, flow, basketRecovered });
        return { success: true, basketRecovered };
    } catch (error) {
        logger.error('[sf-payments] fail-order threw unexpectedly', { orderNo, message: String(error) });
        return data({ success: false, error: String(error) }, { status: 500 });
    }
}
