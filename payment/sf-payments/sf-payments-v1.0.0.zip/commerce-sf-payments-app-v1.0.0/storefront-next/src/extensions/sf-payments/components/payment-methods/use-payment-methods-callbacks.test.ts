/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';
import { renderHook } from '@testing-library/react';
import { usePaymentMethodsCallbacks } from './use-payment-methods-callbacks';

vi.mock('react-i18next', () => ({
    useTranslation: vi.fn(() => ({
        t: (key: string) => key,
    })),
}));

const mockStrategyCreateIntent = vi.fn();

vi.mock('../../hooks/gateways/use-select-gateway-strategy', () => ({
    useSelectGatewayStrategy: vi.fn(() =>
        vi.fn(() => ({
            prepareBasketOnClick: true,
            createIntent: mockStrategyCreateIntent,
        }))
    ),
}));

describe('usePaymentMethodsCallbacks', () => {
    const mockBasket = {
        basketId: 'test-basket-123',
        currency: 'USD',
        orderTotal: 99.99,
        productTotal: 89.99,
        customerInfo: {
            email: 'test@example.com',
        },
        billingAddress: {
            firstName: 'John',
            lastName: 'Doe',
            fullName: 'John Doe',
            address1: '123 Main St',
            city: 'San Francisco',
            stateCode: 'CA',
            postalCode: '94105',
            countryCode: 'US',
            phone: '555-1234',
        },
        shipments: [
            {
                shippingAddress: {
                    firstName: 'John',
                    lastName: 'Doe',
                    fullName: 'John Doe',
                    address1: '123 Main St',
                    city: 'San Francisco',
                    stateCode: 'CA',
                    postalCode: '94105',
                    countryCode: 'US',
                },
            },
        ],
    } as any;

    const mockPaymentConfig = {
        paymentMethods: [{ type: 'card', name: 'Credit Card' }],
        paymentMethodSetAccounts: [],
        zoneId: 'test-zone',
    } as any;

    const mockCheckoutComponent = {
        confirm: vi.fn(),
        destroy: vi.fn(),
        updateAmount: vi.fn(),
    };

    beforeEach(() => {
        vi.clearAllMocks();
    });

    describe('confirmPayment', () => {
        it('should return error if SDK not ready', async () => {
            const checkoutComponentRef = { current: null };
            const paymentMethodTypeRef = { current: 'card' as const };

            const { result } = renderHook(() =>
                usePaymentMethodsCallbacks({
                    basket: mockBasket,
                    paymentConfig: mockPaymentConfig,
                    checkoutComponentRef,
                    paymentMethodTypeRef,
                })
            );

            const confirmResult = await result.current.confirmPayment();

            expect(confirmResult.success).toBe(false);
            expect(confirmResult.error).toBe('paymentMethods.errorInitializing');
        });

        it('should return error if basket not available', async () => {
            const checkoutComponentRef = { current: mockCheckoutComponent };
            const paymentMethodTypeRef = { current: 'card' as const };

            const { result } = renderHook(() =>
                usePaymentMethodsCallbacks({
                    basket: null,
                    paymentConfig: mockPaymentConfig,
                    checkoutComponentRef,
                    paymentMethodTypeRef,
                })
            );

            const confirmResult = await result.current.confirmPayment();

            expect(confirmResult.success).toBe(false);
            expect(confirmResult.error).toBe('paymentMethods.errorBasketUnavailable');
        });

        it('should call SDK confirm with billing and shipping details', async () => {
            const checkoutComponentRef = { current: mockCheckoutComponent };
            const paymentMethodTypeRef = { current: 'card' as const };

            mockCheckoutComponent.confirm.mockResolvedValue({
                responseCode: 0,
            });

            const { result } = renderHook(() =>
                usePaymentMethodsCallbacks({
                    basket: mockBasket,
                    paymentConfig: mockPaymentConfig,
                    checkoutComponentRef,
                    paymentMethodTypeRef,
                })
            );

            await result.current.confirmPayment();

            expect(mockCheckoutComponent.confirm).toHaveBeenCalledWith(
                null,
                expect.objectContaining({
                    email: 'test@example.com',
                    name: 'John Doe',
                }),
                expect.objectContaining({
                    name: 'John Doe',
                })
            );
        });

        it('should return success with orderNo when payment succeeds', async () => {
            const checkoutComponentRef = { current: mockCheckoutComponent };
            const paymentMethodTypeRef = { current: 'card' as const };

            mockStrategyCreateIntent.mockResolvedValue({
                sdkResult: { client_secret: 'cs_test_secret', id: 'pi_ref_123' },
                order: { orderNo: 'ORDER-789' },
            });
            mockCheckoutComponent.confirm.mockResolvedValue({
                responseCode: 0,
            });

            const { result } = renderHook(() =>
                usePaymentMethodsCallbacks({
                    basket: mockBasket,
                    paymentConfig: mockPaymentConfig,
                    checkoutComponentRef,
                    paymentMethodTypeRef,
                })
            );

            await result.current.createIntent();
            const confirmResult = await result.current.confirmPayment();

            expect(confirmResult.success).toBe(true);
            expect(confirmResult.orderNo).toBe('ORDER-789');
        });

        it('should return error when SDK returns non-success code', async () => {
            const checkoutComponentRef = { current: mockCheckoutComponent };
            const paymentMethodTypeRef = { current: 'card' as const };

            mockCheckoutComponent.confirm.mockResolvedValue({
                responseCode: 1,
                data: { error: 'Card declined' },
            });

            const { result } = renderHook(() =>
                usePaymentMethodsCallbacks({
                    basket: mockBasket,
                    paymentConfig: mockPaymentConfig,
                    checkoutComponentRef,
                    paymentMethodTypeRef,
                })
            );

            const confirmResult = await result.current.confirmPayment();

            expect(confirmResult.success).toBe(false);
            expect(confirmResult.error).toContain('Card declined');
        });

        it('should handle SDK confirm throwing error', async () => {
            const checkoutComponentRef = { current: mockCheckoutComponent };
            const paymentMethodTypeRef = { current: 'card' as const };

            mockCheckoutComponent.confirm.mockRejectedValue(new Error('Network error'));

            const { result } = renderHook(() =>
                usePaymentMethodsCallbacks({
                    basket: mockBasket,
                    paymentConfig: mockPaymentConfig,
                    checkoutComponentRef,
                    paymentMethodTypeRef,
                })
            );

            const confirmResult = await result.current.confirmPayment();

            expect(confirmResult.success).toBe(false);
            expect(confirmResult.error).toBe('Network error');
        });
    });

    describe('createIntent', () => {
        it('should throw error if basket not available', async () => {
            const checkoutComponentRef = { current: mockCheckoutComponent };
            const paymentMethodTypeRef = { current: 'card' as const };

            const { result } = renderHook(() =>
                usePaymentMethodsCallbacks({
                    basket: null,
                    paymentConfig: mockPaymentConfig,
                    checkoutComponentRef,
                    paymentMethodTypeRef,
                })
            );

            await expect(result.current.createIntent()).rejects.toThrow('Basket is not available');
        });

        it('should throw error if payment config not resolved', async () => {
            const checkoutComponentRef = { current: mockCheckoutComponent };
            const paymentMethodTypeRef = { current: 'card' as const };

            const { result } = renderHook(() =>
                usePaymentMethodsCallbacks({
                    basket: mockBasket,
                    paymentConfig: null,
                    checkoutComponentRef,
                    paymentMethodTypeRef,
                })
            );

            await expect(result.current.createIntent()).rejects.toThrow('Payment configuration is not resolved');
        });

        it('should delegate to gateway strategy createIntent', async () => {
            const mockOrder = { orderNo: 'ORDER-456' };
            const mockSdkResult = { client_secret: 'cs_test_secret', id: 'pi_ref_123' };
            mockStrategyCreateIntent.mockResolvedValue({
                sdkResult: mockSdkResult,
                order: mockOrder,
            });

            const checkoutComponentRef = { current: mockCheckoutComponent };
            const paymentMethodTypeRef = { current: 'card' as const };

            const { result } = renderHook(() =>
                usePaymentMethodsCallbacks({
                    basket: mockBasket,
                    paymentConfig: mockPaymentConfig,
                    checkoutComponentRef,
                    paymentMethodTypeRef,
                })
            );

            const intentResult = await result.current.createIntent();

            expect(mockStrategyCreateIntent).toHaveBeenCalledWith({
                basket: mockBasket,
                paymentMethodType: 'card',
                paymentConfig: mockPaymentConfig,
                origin: expect.any(String),
            });
            // Consumer forwards the SDK payload opaquely.
            expect(intentResult).toBe(mockSdkResult);
        });

        it('forwards Adyen strategy sdkResult opaquely to the SDK', async () => {
            const mockSdkResult = {
                pspReference: 'psp-123',
                guid: 'pref-adyen-1',
                resultCode: 'Authorised',
            };
            mockStrategyCreateIntent.mockResolvedValue({
                sdkResult: mockSdkResult,
                order: { orderNo: 'ORDER-ADYEN-1' },
            });

            const checkoutComponentRef = { current: mockCheckoutComponent };
            const paymentMethodTypeRef = { current: 'card' as const };

            const { result } = renderHook(() =>
                usePaymentMethodsCallbacks({
                    basket: mockBasket,
                    paymentConfig: mockPaymentConfig,
                    checkoutComponentRef,
                    paymentMethodTypeRef,
                })
            );

            const intentResult = await result.current.createIntent();

            expect(intentResult).toBe(mockSdkResult);
        });
    });

    describe('Adyen end-to-end through confirmPayment', () => {
        it('should return success with orderNo when Adyen payment confirms', async () => {
            const checkoutComponentRef = { current: mockCheckoutComponent };
            const paymentMethodTypeRef = { current: 'card' as const };

            mockStrategyCreateIntent.mockResolvedValue({
                sdkResult: {
                    pspReference: 'psp-456',
                    guid: 'pref-adyen-1',
                    resultCode: 'Authorised',
                },
                order: { orderNo: 'ORDER-ADYEN-2' },
            });
            mockCheckoutComponent.confirm.mockResolvedValue({
                responseCode: 0,
            });

            const { result } = renderHook(() =>
                usePaymentMethodsCallbacks({
                    basket: mockBasket,
                    paymentConfig: mockPaymentConfig,
                    checkoutComponentRef,
                    paymentMethodTypeRef,
                })
            );

            await result.current.createIntent();
            const confirmResult = await result.current.confirmPayment();

            expect(confirmResult.success).toBe(true);
            expect(confirmResult.orderNo).toBe('ORDER-ADYEN-2');
        });

        it('should return error when Adyen confirm fails (e.g. 3DS required)', async () => {
            const checkoutComponentRef = { current: mockCheckoutComponent };
            const paymentMethodTypeRef = { current: 'card' as const };

            mockStrategyCreateIntent.mockResolvedValue({
                sdkResult: {
                    pspReference: 'psp-789',
                    guid: 'pref-adyen-1',
                    resultCode: 'IdentifyShopper',
                    action: { type: 'redirect', url: 'https://adyen.test/3ds' },
                },
                order: { orderNo: 'ORDER-ADYEN-3' },
            });
            mockCheckoutComponent.confirm.mockResolvedValue({
                responseCode: 1,
                data: { error: 'Additional authentication required' },
            });

            const { result } = renderHook(() =>
                usePaymentMethodsCallbacks({
                    basket: mockBasket,
                    paymentConfig: mockPaymentConfig,
                    checkoutComponentRef,
                    paymentMethodTypeRef,
                })
            );

            await result.current.createIntent();
            const confirmResult = await result.current.confirmPayment();

            expect(confirmResult.success).toBe(false);
            expect(confirmResult.error).toBe('Additional authentication required');
        });
    });
});
