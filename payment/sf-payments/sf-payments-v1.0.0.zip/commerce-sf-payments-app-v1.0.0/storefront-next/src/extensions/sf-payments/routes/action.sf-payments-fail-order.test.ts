/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { describe, test, expect, vi, beforeEach } from 'vitest';
import type { RouterContextProvider } from 'react-router';
import { action } from './action.sf-payments-fail-order';
import { attemptFailOrder } from '../lib/api/order-mutations.server';

vi.mock('../lib/api/order-mutations.server', () => ({
    attemptFailOrder: vi.fn(),
}));

vi.mock('@/lib/logger.server', () => ({
    getLogger: vi.fn(() => ({ info: vi.fn(), error: vi.fn() })),
}));

const mockContext = { get: vi.fn(), set: vi.fn() } as unknown as RouterContextProvider;

// react-router's data() returns { type, data, init } — not a native Response.
function statusOf(result: unknown): number | undefined {
    return (result as { init?: { status?: number } })?.init?.status;
}

function makeRequest(fields: Record<string, string>, method = 'POST') {
    const form = new FormData();
    for (const [k, v] of Object.entries(fields)) form.set(k, v);
    const canHaveBody = method !== 'GET' && method !== 'HEAD';
    return new Request('https://shop.example/action/sf-payments-fail-order', {
        method,
        ...(canHaveBody && { body: form }),
    });
}

beforeEach(() => {
    vi.clearAllMocks();
});

describe('action.sf-payments-fail-order', () => {
    test('returns 405 for non-POST requests', async () => {
        const result = await action({ request: makeRequest({}, 'GET'), context: mockContext, params: {} } as any);
        expect(statusOf(result)).toBe(405);
    });

    test('returns 400 when orderNo is missing', async () => {
        const result = await action({ request: makeRequest({}), context: mockContext, params: {} } as any);
        expect(statusOf(result)).toBe(400);
    });

    test('calls attemptFailOrder with the orderNo and returns basketRecovered=true', async () => {
        vi.mocked(attemptFailOrder).mockResolvedValue(true);

        const result = await action({
            request: makeRequest({ orderNo: 'o1', flow: 'sheet' }),
            context: mockContext,
            params: {},
        } as any);

        expect(attemptFailOrder).toHaveBeenCalledWith(mockContext, 'o1');
        expect(result).toEqual({ success: true, basketRecovered: true });
    });

    test('returns basketRecovered=false when attemptFailOrder returns false', async () => {
        vi.mocked(attemptFailOrder).mockResolvedValue(false);

        const result = await action({
            request: makeRequest({ orderNo: 'o1' }),
            context: mockContext,
            params: {},
        } as any);

        expect(result).toEqual({ success: true, basketRecovered: false });
    });

    test('returns 500 when attemptFailOrder throws', async () => {
        vi.mocked(attemptFailOrder).mockRejectedValue(new Error('SCAPI down'));

        const result = await action({
            request: makeRequest({ orderNo: 'o1' }),
            context: mockContext,
            params: {},
        } as any);

        expect(statusOf(result)).toBe(500);
    });
});
