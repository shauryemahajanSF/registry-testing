/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

'use client';

import { Loader2 } from 'lucide-react';
import { useTranslation } from 'react-i18next';

export interface ExpressProcessingOverlayProps {
    /** Whether to render the overlay. */
    isProcessing: boolean;
}

/**
 * Full-viewport overlay shown while an express payment is mid-confirm.
 * Mounted inside ExpressButtons; the in-page block during the
 * wallet-authorize → navigate window. Distinct from the
 * `_checkout.payment-processing` route, which handles the redirect-return
 * path for PayPal.
 */
export default function ExpressProcessingOverlay({ isProcessing }: ExpressProcessingOverlayProps) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { t } = useTranslation('extSfPayments' as any);

    if (!isProcessing) {
        return null;
    }

    return (
        <div
            role="status"
            aria-live="polite"
            data-testid="sf-payments-express-processing-overlay"
            className="fixed inset-0 z-50 flex flex-col items-center justify-center gap-3 bg-background/80">
            <Loader2 className="h-10 w-10 animate-spin text-primary" aria-hidden="true" />
            <span className="text-sm text-foreground">{t('expressProcessing.label')}</span>
        </div>
    );
}
