/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

'use client';

import type { FetcherWithComponents } from 'react-router';
import type { ShopperOrders } from '@/scapi';

type Order = ShopperOrders.schemas['Order'];
type ActionResponse<T> = ({ success: true } & T) | { success: false; error?: string };
type CreateOrderResponse = ActionResponse<{ order: Order; orderNo?: string }>;

interface SubmitCreateOrderArgs {
    orderForm: FormData;
    fetcher: FetcherWithComponents<CreateOrderResponse>;
    awaitCreateOrder: () => Promise<CreateOrderResponse | undefined>;
    skipPostOrderRevalidation?: boolean;
}

/**
 * Submit `/action/sf-payments-create-order` and return the created order.
 *
 * When `skipPostOrderRevalidation` is true, uses a plain `fetch` so React
 * Router's post-action loader revalidation doesn't re-run loaders (the cart
 * loader would otherwise re-fetch and return an empty basket because SCAPI
 * consumed it during order creation, tearing down the subtree mid-flow).
 *
 * Returns `{ order, orderNo? }`. `orderNo` is read by PayPal's onApprove;
 * Stripe/Adyen ignore it.
 */
export async function submitCreateOrder({
    orderForm,
    fetcher,
    awaitCreateOrder,
    skipPostOrderRevalidation,
}: SubmitCreateOrderArgs): Promise<{ order: Order; orderNo?: string }> {
    if (skipPostOrderRevalidation) {
        const res = await fetch('/action/sf-payments-create-order', { method: 'POST', body: orderForm });
        // Try to parse the body, but tolerate non-JSON responses (e.g., a 502
        // from an upstream proxy returning HTML). Without this, res.json()
        // throws a SyntaxError and the real HTTP status is lost.
        let json: CreateOrderResponse | undefined;
        try {
            json = (await res.json()) as CreateOrderResponse;
        } catch {
            // Body wasn't JSON; status-based error below.
        }
        if (!res.ok) {
            const errMsg = json?.success === false ? json.error : undefined;
            throw new Error(errMsg || `create-order failed (${res.status})`);
        }
        return assertCreateOrderSuccess(json);
    }
    void fetcher.submit(orderForm, {
        method: 'POST',
        action: '/action/sf-payments-create-order',
    });
    return assertCreateOrderSuccess(await awaitCreateOrder());
}

function assertCreateOrderSuccess(result: CreateOrderResponse | undefined): { order: Order; orderNo?: string } {
    if (!result) {
        throw new Error('create-order failed');
    }
    if (result.success !== true) {
        throw new Error(result.error || 'create-order failed');
    }
    return { order: result.order, orderNo: result.orderNo };
}
