/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 */
import { describe, it, expect } from 'vitest'
import { getLocaleDerivedCountryCode } from './sf-payments-country'

describe('getLocaleDerivedCountryCode', () => {
    it('extracts the country subtag from a language-region locale', () => {
        expect(getLocaleDerivedCountryCode('en-US')).toBe('US')
        expect(getLocaleDerivedCountryCode('fr-FR')).toBe('FR')
        expect(getLocaleDerivedCountryCode('de-DE')).toBe('DE')
        expect(getLocaleDerivedCountryCode('ja-JP')).toBe('JP')
        expect(getLocaleDerivedCountryCode('zh-HK')).toBe('HK')
    })

    it('uppercases a lowercase country subtag', () => {
        expect(getLocaleDerivedCountryCode('en-gb')).toBe('GB')
        expect(getLocaleDerivedCountryCode('pt-br')).toBe('BR')
    })

    it('throws when the locale has no region subtag', () => {
        // Language-only locales like "en" or "fr" are rejected rather than
        // silently defaulting, matching the loud-failure pattern used by the
        // site-context middleware for locale misconfiguration.
        expect(() => getLocaleDerivedCountryCode('en')).toThrow(/region subtag/)
        expect(() => getLocaleDerivedCountryCode('fr')).toThrow(/region subtag/)
    })

    it('throws when the input is an empty string', () => {
        expect(() => getLocaleDerivedCountryCode('')).toThrow(/region subtag/)
    })

    it('error message includes the offending locale and points at the config fix', () => {
        expect(() => getLocaleDerivedCountryCode('de')).toThrow(/"de"/)
        expect(() => getLocaleDerivedCountryCode('de')).toThrow(/supportedLocales/)
    })
})
