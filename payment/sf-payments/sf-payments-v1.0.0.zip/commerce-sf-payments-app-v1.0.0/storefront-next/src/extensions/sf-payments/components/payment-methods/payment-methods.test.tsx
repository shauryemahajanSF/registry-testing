/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { describe, it, expect, vi, beforeAll, beforeEach, afterEach } from 'vitest';
import { render, screen, waitFor, act } from '@testing-library/react';
import { type PropsWithChildren } from 'react';
import i18next from 'i18next';
import sfPaymentsTranslations from '../../locales/en-US/translations.json';
import SFPaymentsProvider, { useSFPaymentsContext } from '../../providers/sf-payments-provider';
import PaymentMethods from './index';

beforeAll(() => {
    if (!i18next.hasResourceBundle('en-US', 'extSfPayments')) {
        i18next.addResourceBundle('en-US', 'extSfPayments', sfPaymentsTranslations);
    }
    if (!i18next.hasResourceBundle('en-GB', 'extSfPayments')) {
        i18next.addResourceBundle('en-GB', 'extSfPayments', sfPaymentsTranslations);
    }
});

// --- Mocks ---

const mockMetadata = { version: '1.0' };
const mockPaymentConfig = {
    zoneId: 'default',
    paymentMethods: [{ paymentMethodType: 'card', accountId: 'acct_1', paymentModes: ['direct'] }],
    paymentMethodSetAccounts: [{ accountId: 'acct_1', vendor: 'Stripe', gatewayId: 'gw1', isLive: false }],
};
const mockCheckoutComponent = {
    updateAmount: vi.fn(),
    destroy: vi.fn(),
};

// Stable sfp instance shared between the provider and test assertions.
// Must be a plain object (not created inside a mock factory) so tests can
// inspect the same checkout spy that the component receives.
const mockSfpInstance = {
    checkout: vi.fn(() => mockCheckoutComponent),
};

vi.mock('@salesforce/storefront-next-runtime/config', () => ({
    useConfig: vi.fn(() => ({
        sfPayments: {
            enabled: true,
            sdkUrl: 'https://example.com/sfp.js',
            metadataUrl: 'https://example.com/metadata.json',
        },
    })),
}));

vi.mock('@salesforce/storefront-next-runtime/site-context', () => ({
    useSite: vi.fn(() => ({
        currency: 'USD',
        locale: { id: 'en-US' },
    })),
}));

vi.mock('@/providers/basket', () => ({
    useBasket: vi.fn(() => ({ orderTotal: 99.99, currency: 'USD' })),
}));

vi.mock('@/hooks/use-navigate', () => ({
    useNavigate: vi.fn(() => vi.fn()),
}));

vi.mock('../../hooks/use-sf-payments-shopper-config', () => ({
    fetchShopperConfig: vi.fn(() => Promise.resolve({ SalesforcePaymentsAllowed: true })),
    useShopperConfigField: vi.fn(() => ({ value: false, loading: false })),
}));

vi.mock('../../lib/sf-payments-sdk-loader', () => ({
    loadScript: vi.fn(() => Promise.resolve()),
}));

vi.mock('../../hooks/use-sf-payments-metadata', () => ({
    fetchMetadata: vi.fn(() => Promise.resolve({ metadata: mockMetadata })),
}));

vi.mock('../../hooks/use-sf-payments-config', () => ({
    useSFPaymentsConfig: vi.fn(() => ({
        config: mockPaymentConfig,
        accounts: mockPaymentConfig.paymentMethodSetAccounts,
        loading: false,
        error: null,
    })),
}));

vi.mock('../../lib/sf-payments-country', () => ({
    getLocaleDerivedCountryCode: vi.fn(() => 'US'),
}));

vi.mock('./use-payment-methods-callbacks', () => ({
    usePaymentMethodsCallbacks: vi.fn(() => ({
        createIntent: vi.fn(),
        confirmPayment: vi.fn(() => Promise.resolve({ success: true, orderNo: 'ORDER-123' })),
    })),
}));

vi.mock('../../providers/sf-payments-provider', async (importOriginal) => {
    const actual = await importOriginal<typeof import('../../providers/sf-payments-provider')>();
    return {
        ...actual,
        useSFPaymentsContext: vi.fn(() => ({
            enabled: true,
            sfp: mockSfpInstance,
            metadata: { version: '1.0' },
            metadataLoading: false,
        })),
    };
});

import { useConfig } from '@salesforce/storefront-next-runtime/config';
import { useBasket } from '@/providers/basket';
import { useSFPaymentsConfig } from '../../hooks/use-sf-payments-config';
import { loadScript } from '../../lib/sf-payments-sdk-loader';
import { usePaymentMethodsCallbacks } from './use-payment-methods-callbacks';

// --- Helpers ---

const wrapper = ({ children }: PropsWithChildren) => <SFPaymentsProvider>{children}</SFPaymentsProvider>;

function renderPaymentMethods() {
    return render(<PaymentMethods />, { wrapper });
}

describe('PaymentMethods', () => {
    beforeEach(() => {
        vi.clearAllMocks();
        vi.mocked(useConfig).mockReturnValue({
            sfPayments: {
                enabled: true,
                sdkUrl: 'https://example.com/sfp.js',
                metadataUrl: 'https://example.com/metadata.json',
            },
        } as any);
        vi.mocked(useBasket).mockReturnValue({ orderTotal: 99.99, currency: 'USD' } as any);
        vi.mocked(useSFPaymentsConfig).mockReturnValue({
            config: mockPaymentConfig,
            accounts: mockPaymentConfig.paymentMethodSetAccounts,
            loading: false,
            error: null,
        });
        vi.mocked(useSFPaymentsContext).mockReturnValue({
            enabled: true,
            sfp: mockSfpInstance,
            metadata: { version: '1.0' },
            metadataLoading: false,
        } as any);
        vi.mocked(loadScript).mockImplementation(() => {
            (window as any).SFPayments = function () {
                return mockSfpInstance;
            };
            return Promise.resolve();
        });
        mockSfpInstance.checkout.mockClear();
        mockCheckoutComponent.updateAmount.mockClear();
        mockCheckoutComponent.destroy.mockClear();
    });

    afterEach(() => {
        vi.restoreAllMocks();
        delete (window as any).SFPayments;
    });

    it('returns null when enabled is false and not loading', async () => {
        vi.mocked(useSFPaymentsContext).mockReturnValue({
            enabled: false,
            sfp: null,
            metadata: null,
            metadataLoading: false,
        } as any);

        const { container } = renderPaymentMethods();

        await waitFor(() => {
            expect(container.firstChild).toBeNull();
        });
    });

    it('shows loading state while metadataLoading is true', () => {
        vi.mocked(useSFPaymentsContext).mockReturnValue({
            enabled: true,
            sfp: null,
            metadata: null,
            metadataLoading: true,
        } as any);

        renderPaymentMethods();

        expect(screen.getByText('Loading payment options...')).toBeDefined();
    });

    it('shows loading state while paymentConfigLoading is true', () => {
        vi.mocked(useSFPaymentsConfig).mockReturnValue({
            config: null,
            accounts: [],
            loading: true,
            error: null,
        });

        renderPaymentMethods();

        expect(screen.getByText('Loading payment options...')).toBeDefined();
    });

    it('shows error message when paymentConfigError is set', () => {
        vi.mocked(useSFPaymentsConfig).mockReturnValue({
            config: null,
            accounts: [],
            loading: false,
            error: 'Zone not found',
        });

        renderPaymentMethods();

        expect(screen.getByText('Zone not found')).toBeDefined();
    });

    it('renders the container div when all deps are ready', async () => {
        renderPaymentMethods();

        await waitFor(() => {
            expect(screen.getByTestId('sf-payments-checkout')).toBeDefined();
        });
    });

    it('calls sfp.checkout() once when sfp + metadata + paymentConfig are ready', async () => {
        renderPaymentMethods();

        await waitFor(() => {
            expect(screen.getByTestId('sf-payments-checkout')).toBeDefined();
        });

        expect(mockSfpInstance.checkout).toHaveBeenCalledTimes(1);
    });

    it('does not remount sfp.checkout() when basket.orderTotal changes', async () => {
        const { rerender } = render(<PaymentMethods />, { wrapper });

        await waitFor(() => {
            expect(screen.getByTestId('sf-payments-checkout')).toBeDefined();
        });

        const checkoutCallsBefore = mockSfpInstance.checkout.mock.calls.length;

        // Simulate basket total update
        vi.mocked(useBasket).mockReturnValue({ orderTotal: 120.0, currency: 'USD' } as any);
        rerender(<PaymentMethods />);

        await waitFor(() => {
            expect(mockCheckoutComponent.updateAmount).toHaveBeenCalledWith(120.0);
        });

        // checkout() should not have been called again
        expect(mockSfpInstance.checkout.mock.calls.length).toBe(checkoutCallsBefore);
    });

    it('calls updateAmount when basket.orderTotal changes', async () => {
        const { rerender } = renderPaymentMethods();

        await waitFor(() => {
            expect(screen.getByTestId('sf-payments-checkout')).toBeDefined();
        });

        vi.mocked(useBasket).mockReturnValue({ orderTotal: 150.0, currency: 'USD' } as any);
        rerender(<PaymentMethods />);

        await waitFor(() => {
            expect(mockCheckoutComponent.updateAmount).toHaveBeenCalledWith(150.0);
        });
    });

    it('calls destroy() when unmounted', async () => {
        const { unmount } = renderPaymentMethods();

        await waitFor(() => {
            expect(screen.getByTestId('sf-payments-checkout')).toBeDefined();
        });

        act(() => {
            unmount();
        });

        expect(mockCheckoutComponent.destroy).toHaveBeenCalledTimes(1);
    });

    it('tracks paymentMethodType on sfp:paymentmethodselected event', async () => {
        renderPaymentMethods();

        await waitFor(() => {
            expect(screen.getByTestId('sf-payments-checkout')).toBeDefined();
        });

        const container = screen.getByTestId('sf-payments-checkout');
        act(() => {
            container.dispatchEvent(
                new CustomEvent('sfp:paymentmethodselected', {
                    detail: { paymentMethodType: 'card' },
                    bubbles: true,
                })
            );
        });

        // No assertion on the ref directly — verifying no errors thrown is sufficient
        // for this layer. Integration tests will verify gateway routing.
    });

    it('passes correct paymentRequest to sfp.checkout()', async () => {
        renderPaymentMethods();

        await waitFor(() => {
            expect(screen.getByTestId('sf-payments-checkout')).toBeDefined();
        });

        // checkout(metadata, paymentMethodSet, config, paymentRequest, element)
        const [, , , paymentRequest] = mockSfpInstance.checkout.mock.calls[0] as unknown[];
        expect(paymentRequest).toMatchObject({
            amount: 99.99,
            currency: 'USD',
            country: 'US',
            locale: 'en-US',
        });
    });

    it('renders a Place Order button when SDK is mounted', async () => {
        renderPaymentMethods();

        await waitFor(() => {
            expect(screen.getByTestId('sf-payments-place-order')).toBeDefined();
        });

        expect(screen.getByTestId('sf-payments-place-order').textContent).toBe('Place Order');
    });

    it('calls confirmPayment when Place Order button is clicked', async () => {
        const mockConfirmPayment = vi.fn(() => Promise.resolve({ success: true, orderNo: 'ORDER-123' }));
        vi.mocked(usePaymentMethodsCallbacks).mockReturnValue({
            createIntent: vi.fn(),
            confirmPayment: mockConfirmPayment,
        });

        const { rerender } = renderPaymentMethods();

        await waitFor(() => {
            expect(screen.getByTestId('sf-payments-place-order')).toBeDefined();
        });

        // Trigger a re-render so the ref read picks up the SDK mount
        vi.mocked(useBasket).mockReturnValue({ orderTotal: 100.0, currency: 'USD' } as any);
        rerender(<PaymentMethods />);

        act(() => {
            screen.getByTestId('sf-payments-place-order').click();
        });

        await waitFor(() => {
            expect(mockConfirmPayment).toHaveBeenCalledTimes(1);
        });
    });

    it('shows error message when confirmPayment fails', async () => {
        const mockConfirmPayment = vi.fn(() => Promise.resolve({ success: false, error: 'Card declined' }));
        vi.mocked(usePaymentMethodsCallbacks).mockReturnValue({
            createIntent: vi.fn(),
            confirmPayment: mockConfirmPayment,
        });

        const { rerender } = renderPaymentMethods();

        await waitFor(() => {
            expect(screen.getByTestId('sf-payments-place-order')).toBeDefined();
        });

        // Trigger a re-render so the ref read picks up the SDK mount
        vi.mocked(useBasket).mockReturnValue({ orderTotal: 100.0, currency: 'USD' } as any);
        rerender(<PaymentMethods />);

        act(() => {
            screen.getByTestId('sf-payments-place-order').click();
        });

        await waitFor(() => {
            expect(screen.getByText('Card declined')).toBeDefined();
        });
    });

    it('works with Adyen payment config (vendor: Adyen)', async () => {
        vi.mocked(useSFPaymentsConfig).mockReturnValue({
            config: {
                zoneId: 'default',
                paymentMethods: [{ paymentMethodType: 'card', accountId: 'acct_adyen', paymentModes: ['direct'] }],
                paymentMethodSetAccounts: [
                    { accountId: 'acct_adyen', vendor: 'Adyen', gatewayId: 'gw_adyen', isLive: false },
                ],
            },
            accounts: [{ accountId: 'acct_adyen', vendor: 'Adyen', gatewayId: 'gw_adyen', isLive: false }],
            loading: false,
            error: null,
        });

        renderPaymentMethods();

        await waitFor(() => {
            expect(screen.getByTestId('sf-payments-checkout')).toBeDefined();
        });

        expect(mockSfpInstance.checkout).toHaveBeenCalledTimes(1);

        const [, paymentMethodSet] = mockSfpInstance.checkout.mock.calls[0] as unknown[];
        expect(paymentMethodSet).toMatchObject({
            paymentMethods: [{ paymentMethodType: 'card', accountId: 'acct_adyen' }],
            paymentMethodSetAccounts: [
                expect.objectContaining({ accountId: 'acct_adyen', vendor: 'Adyen', gatewayId: 'acct_adyen' }),
            ],
        });
    });
});
