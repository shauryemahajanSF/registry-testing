/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { describe, test, expect, vi, beforeEach } from 'vitest';

// React 19 production builds (loaded by vitest here) don't expose `act`,
// which makes @testing-library/react's renderHook crash. We don't need
// React's render machinery for this test — the hook returns plain functions
// + refs on first call. Stub useRef/useEffect/useState so we can call the
// hook as a regular function and exercise its returned callbacks.
vi.mock('react', () => {
    const refs: Array<{ current: unknown }> = [];
    let refIdx = 0;
    return {
        useRef: <T>(initial: T) => {
            if (refs[refIdx] === undefined) refs[refIdx] = { current: initial };
            return refs[refIdx++];
        },
        useEffect: (fn: () => void) => fn(),
        useState: <T>(initial: T) => [initial, () => undefined] as const,
        useCallback: <T>(fn: T) => fn,
        useMemo: <T>(fn: () => T) => fn(),
        // Reset ref counter between hook invocations within a single test.
        __resetRefs: () => {
            refs.length = 0;
            refIdx = 0;
        },
    };
});

// eslint-disable-next-line import/no-namespace
import * as ReactMock from 'react';
import { useExpressCallbacks, type SdkExpressOptions } from './use-express-callbacks';
import type { ExpressButtonsProps } from './index';
import type { PaymentConfig } from '../../lib/api/types';
import type { GatewayStrategy } from '../../lib/gateways/types';

// --- Mocks for storefront-next host hooks the callbacks file imports.

vi.mock('react-router', () => ({
    useFetcher: vi.fn(() => ({ submit: vi.fn(), state: 'idle', data: undefined })),
}));

vi.mock('react-i18next', () => ({
    useTranslation: () => ({ t: (key: string) => key }),
}));

vi.mock('@/hooks/use-navigate', () => ({
    useNavigate: () => vi.fn(),
}));

vi.mock('@/components/toast', () => ({
    useToast: () => ({ addToast: vi.fn() }),
}));

vi.mock('../../hooks/use-fetcher-promise', () => ({
    useFetcherPromise: vi.fn(() => vi.fn()),
}));

vi.mock('../../hooks/use-sf-payments-failure-recovery', () => ({
    useSFPaymentsFailureRecovery: () => ({ failAndRecover: vi.fn() }),
}));

const selectStrategy = vi.fn();
vi.mock('../../hooks/gateways/use-select-gateway-strategy', () => ({
    useSelectGatewayStrategy: () => selectStrategy,
}));

const paymentConfig: PaymentConfig = {
    zoneId: 'z1',
    paymentMethods: [{ paymentMethodType: 'paypal', accountId: 'acct_paypal' }],
    paymentMethodSetAccounts: [{ accountId: 'acct_paypal', vendor: 'PayPal' }],
};

function makeProps(overrides: Partial<ExpressButtonsProps> = {}): ExpressButtonsProps {
    return {
        prepareBasket: vi.fn().mockResolvedValue({ basketId: 'b1' }),
        initialAmount: 50,
        currency: 'USD',
        countryCode: 'US',
        ...overrides,
    };
}

// useRef/useEffect/etc. are stubbed via vi.mock above, so calling the hook
// outside a render tree is safe here — disable the rule for this helper.
/* eslint-disable react-hooks/rules-of-hooks */
function renderCallbacks(propsOverrides: Partial<ExpressButtonsProps> = {}) {
    (ReactMock as unknown as { __resetRefs: () => void }).__resetRefs();
    const startExpressProcessing = vi.fn();
    const endExpressProcessing = vi.fn();
    const props = makeProps(propsOverrides);
    const sdkExpressOptionsRef = { current: { returnUrl: 'https://x.test/return' } };

    const result = {
        current: useExpressCallbacks({
            props,
            paymentConfig,
            sdkExpressOptionsRef: sdkExpressOptionsRef as { current: SdkExpressOptions | null },
            startExpressProcessing,
            endExpressProcessing,
        }),
    };

    return { result, props, startExpressProcessing, endExpressProcessing };
}
/* eslint-enable react-hooks/rules-of-hooks */

beforeEach(() => {
    selectStrategy.mockReset();
});

describe('useExpressCallbacks - waitForBasketPreparation (via createIntent)', () => {
    test('PayPal: lazy-preps basket on createIntent when prep was not started in onClick', async () => {
        const prepareBasket = vi.fn().mockResolvedValue({ basketId: 'lazy-prep-basket' });
        // PayPal-style strategy: prepareBasketOnClick=false, defines onApprove.
        const strategy: GatewayStrategy = {
            prepareBasketOnClick: false,
            createIntent: vi.fn().mockResolvedValue({ sdkResult: { id: 'pref-1' } }),
            onPayerApprove: vi.fn(),
            onApprove: vi.fn(),
        };
        selectStrategy.mockReturnValue(strategy);

        const { result } = renderCallbacks({ prepareBasket });

        await result.current.callbacks.onClick('paypal');
        // onClick should not have started prep for PayPal.
        expect(prepareBasket).not.toHaveBeenCalled();

        await result.current.callbacks.createIntent({});
        // createIntent should have triggered the lazy prep.
        expect(prepareBasket).toHaveBeenCalledTimes(1);
        // And the strategy was given the prepared basket.
        const args = (strategy.createIntent as ReturnType<typeof vi.fn>).mock.calls[0][0];
        expect(args.basket).toEqual({ basketId: 'lazy-prep-basket' });
    });

    test('Stripe/Adyen: awaits the in-flight prep started by onClick (no second prep)', async () => {
        const prepareBasket = vi.fn().mockResolvedValue({ basketId: 'eager-prep-basket' });
        const strategy: GatewayStrategy = {
            prepareBasketOnClick: true,
            createIntent: vi.fn().mockResolvedValue({ sdkResult: { id: 'pref-1' } }),
            onPayerApprove: vi.fn(),
        };
        selectStrategy.mockReturnValue(strategy);

        const { result } = renderCallbacks({ prepareBasket });

        await result.current.callbacks.onClick('card');
        expect(prepareBasket).toHaveBeenCalledTimes(1);

        await result.current.callbacks.createIntent({});
        // No additional prep — the existing in-flight promise was awaited.
        expect(prepareBasket).toHaveBeenCalledTimes(1);
    });

    test('returns immediately when basket is already populated (no extra prepareBasket call)', async () => {
        const prepareBasket = vi.fn().mockResolvedValue({ basketId: 'eager-prep-basket' });
        const strategy: GatewayStrategy = {
            prepareBasketOnClick: true,
            createIntent: vi.fn().mockResolvedValue({ sdkResult: { id: 'pref-1' } }),
            onPayerApprove: vi.fn(),
        };
        selectStrategy.mockReturnValue(strategy);

        const { result } = renderCallbacks({ prepareBasket });

        await result.current.callbacks.onClick('card');
        await result.current.callbacks.createIntent({});
        await result.current.callbacks.createIntent({});
        // First prep ran once; second createIntent reused expressBasket.current.
        expect(prepareBasket).toHaveBeenCalledTimes(1);
    });
});

describe('useExpressCallbacks - onPaymentApprove', () => {
    test('PayPal: calls strategy.onApprove to create the order, then would navigate', async () => {
        const prepareBasket = vi.fn().mockResolvedValue({ basketId: 'b1' });
        const onApprove = vi.fn().mockResolvedValue({ order: { orderNo: 'o-1' }, orderNo: 'o-1' });
        const strategy: GatewayStrategy = {
            prepareBasketOnClick: false,
            createIntent: vi.fn().mockResolvedValue({ sdkResult: { id: 'pref-1' } }),
            onPayerApprove: vi.fn().mockImplementation(({ basket }) => Promise.resolve(basket)),
            onApprove,
        };
        selectStrategy.mockReturnValue(strategy);

        const { result } = renderCallbacks({ prepareBasket });

        await result.current.callbacks.onClick('paypal');
        await result.current.callbacks.createIntent({});
        await result.current.callbacks.onPayerApprove({}, {});

        result.current.eventHandlers.onPaymentApprove(new Event('sfp:paymentapprove'));
        // Allow the queued async finalize() to settle.
        await Promise.resolve();
        await Promise.resolve();

        expect(onApprove).toHaveBeenCalledTimes(1);
        const approveArgs = onApprove.mock.calls[0][0];
        expect(approveArgs.basket).toEqual({ basketId: 'b1' });
        expect(approveArgs.paymentMethodType).toBe('paypal');
    });

    test('Stripe/Adyen: skips strategy.onApprove when strategy does not define it', async () => {
        const prepareBasket = vi.fn().mockResolvedValue({ basketId: 'b1' });
        // Note: order is created in createIntent for these gateways. We simulate
        // that by having the strategy return an order; the callbacks file stores
        // it in orderRef, which short-circuits the new onApprove path.
        const strategy: GatewayStrategy = {
            prepareBasketOnClick: true,
            createIntent: vi.fn().mockResolvedValue({
                sdkResult: { id: 'pi_1' },
                order: { orderNo: 'o-stripe' },
            }),
            onPayerApprove: vi.fn().mockImplementation(({ basket }) => Promise.resolve(basket)),
            // onApprove intentionally not defined.
        };
        selectStrategy.mockReturnValue(strategy);

        const { result } = renderCallbacks({ prepareBasket });

        await result.current.callbacks.onClick('card');
        await result.current.callbacks.createIntent({});

        result.current.eventHandlers.onPaymentApprove(new Event('sfp:paymentapprove'));
        await Promise.resolve();
        await Promise.resolve();

        // Nothing to assert against onApprove (it doesn't exist) — but the
        // handler should not have thrown, and no strategy onApprove call happened.
        expect((strategy.createIntent as ReturnType<typeof vi.fn>).mock.calls.length).toBe(1);
    });

    test('catch path: clears isPaymentInProgress and calls endExpressProcessing when onApprove rejects', async () => {
        const prepareBasket = vi.fn().mockResolvedValue({ basketId: 'b1' });
        const strategy: GatewayStrategy = {
            prepareBasketOnClick: false,
            createIntent: vi.fn().mockResolvedValue({ sdkResult: { id: 'pref-1' } }),
            onPayerApprove: vi.fn().mockImplementation(({ basket }) => Promise.resolve(basket)),
            onApprove: vi.fn().mockRejectedValue(new Error('create-order failed')),
        };
        selectStrategy.mockReturnValue(strategy);

        const { result, endExpressProcessing } = renderCallbacks({ prepareBasket });

        await result.current.callbacks.onClick('paypal');
        await result.current.callbacks.createIntent({});
        await result.current.callbacks.onPayerApprove({}, {});

        result.current.eventHandlers.onPaymentApprove(new Event('sfp:paymentapprove'));
        await Promise.resolve();
        await Promise.resolve();

        expect(endExpressProcessing).toHaveBeenCalled();
        expect(result.current.isPaymentInProgress.current).toBe(false);
    });
});
