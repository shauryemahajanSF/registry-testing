/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

'use client';

import React, { useEffect, useRef } from 'react';
import { useSite } from '@salesforce/storefront-next-runtime/site-context';
import type { ShopperBasketsV2 } from '@salesforce/storefront-next-runtime/scapi';
import { useSFPaymentsContext } from '../../providers/sf-payments-provider';
import { useSFPaymentsConfig } from '../../hooks/use-sf-payments-config';
import { useShopperConfigField } from '../../hooks/use-sf-payments-shopper-config';
import { buildExpressPaymentReturnUrl, EXPRESS_PAY_NOW } from '../../lib/sf-payments-utils';
import { buildTheme } from '../../lib/sf-payments-theme';
import { useExpressCallbacks, type SdkExpressOptions } from './use-express-callbacks';

type Basket = ShopperBasketsV2.schemas['Basket'];

export interface ExpressButtonsProps {
    /** Async function that returns a basket to use for the express payment flow.
     *  On PDP: creates a temporary basket and adds the current product.
     *  On checkout/cart: returns the existing main basket. */
    prepareBasket: () => Promise<Basket>;
    /** Display amount before prepareBasket resolves (product price on PDP, basket total on checkout) */
    initialAmount: number;
    /** Transaction currency for this payment — sourced by the consumer from
     *  basket/product/site as appropriate. */
    currency: string;
    /** Transaction country code for this payment — sourced by the consumer from
     *  billing address or a locale-derived fallback. */
    countryCode: string;
    /** EXPRESS_PAY_NOW (0, default) for checkout/cart, EXPRESS_BUY_NOW (1) for PDP */
    usage?: number;
    expressButtonLayout?: 'horizontal' | 'vertical';
    maximumButtonCount?: number;
    /** Called when SDK confirms which payment methods rendered — useful for conditional
     *  UI such as showing/hiding an "Express Checkout" heading on the checkout page. */
    onPaymentMethodsRendered?: () => void;
    /** Called after payment completes, before navigation — useful for closing modals/drawers
     *  (e.g. mini-cart). */
    onExpressPaymentCompleted?: () => void;
    /** CSS class applied to the outer container div */
    className?: string;
}

/**
 * Express buttons — renders Apple Pay / Google Pay / PayPal buttons via the SF Payments SDK.
 *
 * Consumes two hooks:
 *   - `useSFPaymentsContext()` for SDK-lifecycle state (enabled, metadata, sfp).
 *   - `useSFPaymentsConfig({ currency, countryCode })` for per-transaction
 *     payment configuration (gateway accounts, payment methods).
 *
 * `paymentRequest` values (currency, country, locale) come from props + site
 * context. The component does not read transaction values from provider
 * context — that separation lets multiple concurrent consumers use different
 * currencies/countries without stale-cache surprises.
 */
export default function ExpressButtons(props: ExpressButtonsProps) {
    const {
        currency,
        countryCode,
        usage = EXPRESS_PAY_NOW,
        expressButtonLayout,
        maximumButtonCount,
    } = props;

    const { enabled, sfp, metadata, metadataLoading } = useSFPaymentsContext();
    const {
        config: paymentConfig,
        loading: paymentConfigLoading,
        error: paymentConfigError,
    } = useSFPaymentsConfig({ currency, countryCode });
    // Defer SDK initialization until shopper config is loaded — binding with a
    // default (`?? false`) during the loading window risks a fast-click flow
    // running with the wrong capture mode. After loading resolves, fall back
    // to `false` (SCAPI's default for an unset/missing field) only if the
    // value is genuinely undefined.
    const { value: cardCaptureAutomaticRaw, loading: shopperConfigLoading } =
        useShopperConfigField<boolean>('cardCaptureAutomatic');
    const cardCaptureAutomatic = cardCaptureAutomaticRaw ?? false;
    const { locale } = useSite();
    const localeId = locale.id;

    const containerRef = useRef<HTMLDivElement>(null);
    // Mutable options object passed to sfp.express — createIntent updates returnUrl
    // in-place after order creation so the SDK has the order-specific URL before
    // calling its redirect-based payment confirmation.
    const sdkExpressOptionsRef = useRef<SdkExpressOptions | null>(null);

    const { callbacks, eventHandlers, isPaymentInProgress, expressComponentRef } = useExpressCallbacks({
        props,
        paymentConfig,
        sdkExpressOptionsRef,
    });

    useEffect(() => {
        if (!sfp || !metadata || !paymentConfig || shopperConfigLoading || !containerRef.current) {
            return;
        }

        if (isPaymentInProgress.current && expressComponentRef.current) {
            return;
        }

        if (expressComponentRef.current) {
            expressComponentRef.current.destroy();
            expressComponentRef.current = null;
        }

        const paymentMethodSet = {
            paymentMethods: paymentConfig.paymentMethods,
            paymentMethodSetAccounts: paymentConfig.paymentMethodSetAccounts ?? [],
        };

        // Build a mutable options object and share it with the callbacks via ref.
        // createIntent will update returnUrl in-place after order creation.
        const expressOptions: SdkExpressOptions = {
            shippingAddressRequired: true,
            emailAddressRequired: true,
            billingAddressRequired: true,
            phoneNumberRequired: true,
            useManualCapture: !cardCaptureAutomatic,
            maximumButtonCount,
            // Base URL — updated with orderNo/zoneId/type inside createIntent.
            returnUrl: buildExpressPaymentReturnUrl({ origin: window.location.origin }),
        };
        sdkExpressOptionsRef.current = expressOptions;

        const config = {
            actions: callbacks,
            options: expressOptions,
            theme: buildTheme({ expressButtonLayout }),
        };

        const paymentRequest = {
            amount: props.initialAmount,
            currency,
            country: countryCode,
            locale: localeId,
        };
        const paymentElement = document.createElement('div');
        containerRef.current.replaceChildren(paymentElement);

        paymentElement.addEventListener('sfp:paymentmethodsrendered', eventHandlers.onPaymentMethodsRendered);
        paymentElement.addEventListener('sfp:paymenterror', eventHandlers.onPaymentError as unknown as EventListener);
        paymentElement.addEventListener('sfp:paymentcancel', eventHandlers.onCancel as unknown as EventListener);
        paymentElement.addEventListener(
            'sfp:paymentapprove',
            eventHandlers.onPaymentApprove as unknown as EventListener
        );

        expressComponentRef.current = sfp.express(
            metadata,
            paymentMethodSet,
            config,
            paymentRequest,
            paymentElement,
            usage
        );

        return () => {
            if (!isPaymentInProgress.current) {
                expressComponentRef.current?.destroy();
                expressComponentRef.current = null;
            }
        };
        // `shopperConfigLoading` is what actually triggers the bind — it
        // flips false once we know the merchant's capture mode.
        // `cardCaptureAutomatic` is listed because the effect reads it
        // (eslint requires it); both values change together so it doesn't
        // cause extra re-binds.
    }, [sfp, metadata, paymentConfig, shopperConfigLoading, cardCaptureAutomatic]);

    if (!enabled && !paymentConfigLoading) {
        return null;
    }

    if (paymentConfigLoading || metadataLoading || shopperConfigLoading) {
        // TODO: pending translation
        return (
            <div className="py-4 text-center text-sm text-muted-foreground">Loading payment options...</div>
        );
    }

    if (paymentConfigError) {
        // TODO: pending translation
        return (
            <div className="p-3 rounded-lg bg-destructive/10 text-destructive text-sm text-center">
                {paymentConfigError}
            </div>
        );
    }

    return <div ref={containerRef} className={props.className} data-testid="sf-payments-express" />;
}
