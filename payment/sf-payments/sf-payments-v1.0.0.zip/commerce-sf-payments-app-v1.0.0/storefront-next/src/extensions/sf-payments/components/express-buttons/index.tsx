/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { useSite } from '@salesforce/storefront-next-runtime/site-context';
import type { ShopperBasketsV2 } from '@/scapi';
import { useSFPaymentsContext } from '../../providers/sf-payments-provider';
import { useSFPaymentsConfig } from '../../hooks/use-sf-payments-config';
import { useShopperConfigField, SHOPPER_CONFIG_DEFAULTS } from '../../hooks/use-sf-payments-shopper-config';
import { buildPaymentProcessingUrl, EXPRESS_PAY_NOW } from '../../lib/sf-payments-utils';
import { buildTheme } from '../../lib/sf-payments-theme';
import { useExpressCallbacks, type SdkExpressOptions } from './use-express-callbacks';
import ExpressProcessingOverlay from '../express-processing-overlay';

type Basket = ShopperBasketsV2.schemas['Basket'];

export interface ExpressButtonsProps {
    /** Async function that returns a basket to use for the express payment flow.
     *  On PDP: creates a temporary basket and adds the current product.
     *  On checkout/cart: returns the existing main basket. */
    prepareBasket: () => Promise<Basket>;
    /** Display amount before prepareBasket resolves (product price on PDP, basket total on checkout) */
    initialAmount: number;
    /** Transaction currency for this payment — sourced by the consumer from
     *  basket/product/site as appropriate. */
    currency: string;
    /** Transaction country code for this payment — sourced by the consumer from
     *  billing address or a locale-derived fallback. */
    countryCode: string;
    /** EXPRESS_PAY_NOW (0, default) for checkout/cart, EXPRESS_BUY_NOW (1) for PDP */
    usage?: number;
    expressButtonLayout?: 'horizontal' | 'vertical';
    maximumButtonCount?: number;
    /** Called when SDK confirms which payment methods rendered — useful for conditional
     *  UI such as showing/hiding an "Express Checkout" heading on the checkout page. */
    onPaymentMethodsRendered?: () => void;
    /** Called after payment completes, before navigation — useful for closing modals/drawers
     *  (e.g. mini-cart). */
    onExpressPaymentCompleted?: () => void;
    /** CSS class applied to the outer container div */
    className?: string;
    /** Submit create-order via plain `fetch` instead of `useFetcher`, bypassing
     *  React Router's automatic post-action loader revalidation. Set on surfaces
     *  (e.g. cart) whose loader returns an empty basket after order creation and
     *  would otherwise tear down this subtree mid-flow. */
    skipPostOrderRevalidation?: boolean;
}

/**
 * Express buttons — renders Apple Pay / Google Pay / PayPal buttons via the SF Payments SDK.
 *
 * Consumes two hooks:
 *   - `useSFPaymentsContext()` for SDK-lifecycle state (enabled, metadata, sfp).
 *   - `useSFPaymentsConfig({ currency, countryCode })` for per-transaction
 *     payment configuration (gateway accounts, payment methods).
 *
 * `paymentRequest` values (currency, country, locale) come from props + site
 * context. The component does not read transaction values from provider
 * context — that separation lets multiple concurrent consumers use different
 * currencies/countries without stale-cache surprises.
 */
export default function ExpressButtons(props: ExpressButtonsProps) {
    const { currency, countryCode, usage = EXPRESS_PAY_NOW, expressButtonLayout, maximumButtonCount } = props;

    const { enabled, sfp, metadata, metadataLoading } = useSFPaymentsContext();
    const [isExpressProcessing, setIsExpressProcessing] = useState(false);
    const startExpressProcessing = useCallback(() => setIsExpressProcessing(true), []);
    const endExpressProcessing = useCallback(() => setIsExpressProcessing(false), []);
    const {
        config: paymentConfig,
        loading: paymentConfigLoading,
        error: paymentConfigError,
    } = useSFPaymentsConfig({ currency, countryCode });
    // Defer SDK initialization until shopper config is loaded — binding during the
    // loading window risks a fast-click flow running with the wrong capture mode.
    const { value: cardCaptureAutomatic, loading: shopperConfigLoading } = useShopperConfigField(
        'cardCaptureAutomatic',
        SHOPPER_CONFIG_DEFAULTS.cardCaptureAutomatic
    );
    const { locale } = useSite();
    const localeId = locale.id;

    const containerRef = useRef<HTMLDivElement>(null);
    // Mutable options object passed to sfp.express.
    const sdkExpressOptionsRef = useRef<SdkExpressOptions | null>(null);

    const { callbacks, eventHandlers, isPaymentInProgress, expressComponentRef } = useExpressCallbacks({
        props,
        paymentConfig,
        sdkExpressOptionsRef,
        startExpressProcessing,
        endExpressProcessing,
    });

    useEffect(() => {
        if (!sfp || !metadata || !paymentConfig || shopperConfigLoading || !containerRef.current) {
            return;
        }

        if (isPaymentInProgress.current && expressComponentRef.current) {
            return;
        }

        if (expressComponentRef.current) {
            expressComponentRef.current.destroy();
            expressComponentRef.current = null;
        }

        const paymentMethodSet = {
            paymentMethods: paymentConfig.paymentMethods,
            paymentMethodSetAccounts: paymentConfig.paymentMethodSetAccounts ?? [],
        };

        const expressOptions: SdkExpressOptions = {
            shippingAddressRequired: true,
            emailAddressRequired: true,
            billingAddressRequired: true,
            phoneNumberRequired: true,
            useManualCapture: !cardCaptureAutomatic,
            maximumButtonCount,
            returnUrl: buildPaymentProcessingUrl({ origin: window.location.origin }),
        };
        sdkExpressOptionsRef.current = expressOptions;

        const config = {
            actions: callbacks,
            options: expressOptions,
            theme: buildTheme({ expressButtonLayout }),
        };

        const paymentRequest = {
            amount: props.initialAmount,
            currency,
            country: countryCode,
            locale: localeId,
        };
        const paymentElement = document.createElement('div');
        containerRef.current.replaceChildren(paymentElement);

        paymentElement.addEventListener('sfp:paymentmethodsrendered', eventHandlers.onPaymentMethodsRendered);
        paymentElement.addEventListener('sfp:paymenterror', eventHandlers.onPaymentError);
        paymentElement.addEventListener('sfp:paymentcancel', eventHandlers.onCancel);
        paymentElement.addEventListener('sfp:paymentapprove', eventHandlers.onPaymentApprove);

        expressComponentRef.current = sfp.express(
            metadata,
            paymentMethodSet,
            config,
            paymentRequest,
            paymentElement,
            usage
        );

        return () => {
            // eslint-disable-next-line react-hooks/exhaustive-deps
            if (!isPaymentInProgress.current) {
                expressComponentRef.current?.destroy();
                expressComponentRef.current = null;
            }
        };
        // `shopperConfigLoading` is what actually triggers the bind — it
        // flips false once we know the merchant's capture mode.
        // `cardCaptureAutomatic` is listed because the effect reads it
        // (eslint requires it); both values change together so it doesn't
        // cause extra re-binds.
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [sfp, metadata, paymentConfig, shopperConfigLoading, cardCaptureAutomatic]);

    if (!enabled && !paymentConfigLoading) {
        return null;
    }

    if (paymentConfigLoading || metadataLoading || shopperConfigLoading) {
        // TODO: pending translation
        return <div className="py-4 text-center text-sm text-muted-foreground">Loading payment options...</div>;
    }

    if (paymentConfigError) {
        // TODO: pending translation
        return (
            <div className="p-3 rounded-lg bg-destructive/10 text-destructive text-sm text-center">
                {paymentConfigError}
            </div>
        );
    }

    // PayPal's button iframes use high z-indexes and don't create their own
    // stacking context, so they can paint over overlays like the mini-cart.
    // `isolate` scopes them by giving this container its own stacking context.
    const containerClass = ['isolate', props.className].filter(Boolean).join(' ');

    return (
        <>
            <div ref={containerRef} className={containerClass} data-testid="sf-payments-express" />
            <ExpressProcessingOverlay isProcessing={isExpressProcessing} />
        </>
    );
}
