/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

/**
 * Shared basket SCAPI operations for SF Payments.
 *
 * Each function is a plain async function that takes the React Router context
 * as its first argument — no hooks, no component coupling. Functions are
 * callable from action-route handlers, server-side helpers, and tests.
 *
 * Placement-agnostic by design: functions take a `basketId` or `Basket` and
 * do not know whether the basket is temporary (PDP express) or persistent
 * (checkout/sheet).
 *
 * Functions marked with `@remarks Express-only` are used only by the PDP
 * express flow and should not be called from the payment sheet.
 */

import type { RouterContextProvider } from 'react-router';
import { ApiError, type ShopperBasketsV2, type ShopperCustomers } from '@salesforce/storefront-next-runtime/scapi';
import { createApiClients } from '@/lib/api-clients.server';
import { addPaymentInstrumentToBasket, removePaymentInstrumentFromBasket } from '@/lib/api/basket.server';
import { getLogger } from '@/lib/logger.server';
import { createPaymentInstrumentBody, getSFPaymentsInstrument, type PaymentMethodType } from '../sf-payments-utils';
import type { PaymentConfig } from './types';

type Basket = ShopperBasketsV2.schemas['Basket'];
type OrderAddress = ShopperBasketsV2.schemas['OrderAddress'];
type ProductItem = Pick<ShopperBasketsV2.schemas['ProductItem'], 'productId' | 'quantity' | 'inventoryId'>;

const DEFAULT_SHIPMENT_ID = 'me';

/**
 * Create a temporary basket.
 *
 * @remarks Express-only — temp baskets support the PDP "Buy Now" flow and must
 *   not leak into sheet/checkout code. The sheet flow always uses the main basket.
 */
export async function createTemporaryBasket(context: Readonly<RouterContextProvider>): Promise<Basket> {
    const clients = createApiClients(context);
    const { data: basket } = await clients.shopperBasketsV2.createBasket({
        params: { query: { temporary: true } },
        body: {},
    });
    return basket;
}

/**
 * Add a product item to the given basket.
 *
 * Unlike `/action/cart-item-add` this bypasses basket middleware — callers pass
 * an explicit `basketId` so temporary baskets (which are not the main basket)
 * can be mutated without affecting the shopper's cart.
 */
export async function addItemToBasket(
    context: Readonly<RouterContextProvider>,
    basketId: string,
    productItem: ProductItem
): Promise<Basket> {
    const clients = createApiClients(context);
    const { data: basket } = await clients.shopperBasketsV2.addItemToBasket({
        params: { path: { basketId } },
        body: [
            {
                productId: productItem.productId,
                quantity: productItem.quantity,
                ...(productItem.inventoryId ? { inventoryId: productItem.inventoryId } : {}),
                shipmentId: DEFAULT_SHIPMENT_ID,
            },
        ],
    });
    return basket;
}

/**
 * Delete a basket by id.
 *
 * Silently tolerates 404 because "basket is gone" is the desired end state
 * for delete — often the case when multiple cleanup paths run after a
 * cancelled flow. All other errors propagate to the caller.
 *
 * This 404 tolerance is specific to delete's idempotent semantics and is not
 * a convention for other helpers in this file. The update/create helpers let
 * SCAPI errors bubble up unchanged; error translation is the action route's
 * responsibility (matches the storefront's `src/lib/api/basket.ts` pattern).
 */
export async function deleteBasket(context: Readonly<RouterContextProvider>, basketId: string): Promise<void> {
    const clients = createApiClients(context);
    try {
        // SCAPI's deleteBasket does not accept a `locale` query param, but the
        // storefront-next client auto-injects locale as a global param. Passing
        // `locale: undefined` overrides the global default and is dropped by the
        // default query serializer before the request is issued.
        await clients.shopperBasketsV2.deleteBasket({
            params: { path: { basketId }, query: { locale: undefined } as never },
        });
    } catch (error) {
        if (error instanceof ApiError && error.status === 404) {
            return;
        }
        throw error;
    }
}

/**
 * Update the shipping address for a basket shipment.
 */
export async function updateShippingAddressForShipment(
    context: Readonly<RouterContextProvider>,
    basketId: string,
    shipmentId: string,
    address: OrderAddress,
    useAsBilling: boolean = false
): Promise<Basket> {
    const clients = createApiClients(context);
    const { data: basket } = await clients.shopperBasketsV2.updateShippingAddressForShipment({
        params: {
            path: { basketId, shipmentId },
            query: { useAsBilling },
        },
        body: address,
    });
    return basket;
}

/**
 * Update the billing address on a basket.
 */
export async function updateBillingAddressForBasket(
    context: Readonly<RouterContextProvider>,
    basketId: string,
    address: OrderAddress
): Promise<Basket> {
    const clients = createApiClients(context);
    const { data: basket } = await clients.shopperBasketsV2.updateBillingAddressForBasket({
        params: { path: { basketId } },
        body: address,
    });
    return basket;
}

/**
 * Update the shipping method for a basket shipment.
 */
export async function updateShippingMethodForShipment(
    context: Readonly<RouterContextProvider>,
    basketId: string,
    shipmentId: string,
    methodId: string
): Promise<Basket> {
    const clients = createApiClients(context);
    const { data: basket } = await clients.shopperBasketsV2.updateShippingMethodForShipment({
        params: { path: { basketId, shipmentId } },
        body: { id: methodId },
    });
    return basket;
}

/**
 * Fetch the set of shipping methods applicable to a basket shipment.
 *
 * Used by express flows after an address change to refresh the method list —
 * the applicable set can change with the destination (e.g., expedited only to
 * certain regions).
 */
export async function getShippingMethodsForShipment(
    context: Readonly<RouterContextProvider>,
    basketId: string,
    shipmentId: string
): Promise<ShopperBasketsV2.schemas['ShippingMethodResult']> {
    const clients = createApiClients(context);
    const { data } = await clients.shopperBasketsV2.getShippingMethodsForShipment({
        params: { path: { basketId, shipmentId } },
    });
    return data;
}

/**
 * If the basket's currently-selected shipping method is no longer applicable
 * (e.g., address changed and the old method isn't in the new applicable list),
 * switch to the merchant-configured `defaultShippingMethodId` when it appears
 * in the applicable list, otherwise fall back to the first applicable method.
 * Returns the basket unchanged if the current method is still valid or no
 * applicable method exists.
 *
 * Express flows invoke this after `onShippingAddressChange` refetches
 * applicable shipping methods. Honors `defaultShippingMethodId` from the
 * SCAPI response when present — that field exists precisely so the
 * merchant-configured default is preferred over picking the first applicable
 * method blindly.
 */
export async function validateAndUpdateShippingMethod(
    context: Readonly<RouterContextProvider>,
    basket: Basket,
    updatedShippingMethods: {
        applicableShippingMethods: Array<{ id: string }>;
        defaultShippingMethodId?: string;
    },
    shipmentId: string = DEFAULT_SHIPMENT_ID
): Promise<Basket> {
    if (!basket.basketId) {
        throw new Error('Basket is missing a basketId');
    }
    const { applicableShippingMethods, defaultShippingMethodId } = updatedShippingMethods;
    const currentId = basket.shipments?.[0]?.shippingMethod?.id;
    const stillApplicable = currentId ? applicableShippingMethods.some((m) => m.id === currentId) : false;
    if (stillApplicable) {
        return basket;
    }
    const defaultApplicable = defaultShippingMethodId
        ? applicableShippingMethods.find((m) => m.id === defaultShippingMethodId)
        : undefined;
    const next = defaultApplicable ?? applicableShippingMethods[0];
    if (!next) {
        return basket;
    }
    return updateShippingMethodForShipment(context, basket.basketId, shipmentId, next.id);
}

/**
 * Fetch the set of baskets associated with the shopper that have
 * `temporaryBasket === true`. Works for both guest and registered shoppers —
 * SCAPI's `getCustomerBaskets` accepts either token, and `customerId` is the
 * guest customer id for guests. Returns an empty array if the shopper has no
 * baskets.
 *
 * @remarks Express-only — only meaningful for the PDP temp-basket cleanup sweep.
 */
export async function getCustomerTemporaryBaskets(
    context: Readonly<RouterContextProvider>,
    customerId: string
): Promise<Array<ShopperCustomers.schemas['Basket']>> {
    const clients = createApiClients(context);
    const { data } = await clients.shopperCustomers.getCustomerBaskets({
        params: { path: { customerId } },
    });
    return (data?.baskets ?? []).filter((b) => b.temporaryBasket);
}

/**
 * Sweep orphaned temporary baskets from prior abandoned attempts.
 *
 * Called before creating a fresh temp basket in the PDP express flow. A 404
 * on any individual delete is ignored.
 *
 * @remarks Express-only — there is nothing to sweep in the sheet flow.
 */
export async function cleanupTemporaryBaskets(
    context: Readonly<RouterContextProvider>,
    customerId: string
): Promise<void> {
    const tempBaskets = await getCustomerTemporaryBaskets(context, customerId);
    if (tempBaskets.length === 0) {
        return;
    }
    const ids = tempBaskets.map((b) => b.basketId as string);
    const logger = getLogger(context);
    // Per-basket tolerance: one basket's delete failure must not block the
    // others. `deleteBasket` already swallows 404s, so anything reaching this
    // catch is a real failure worth logging.
    await Promise.all(
        ids.map((id) =>
            deleteBasket(context, id).catch((error) => {
                logger.warn('[sf-payments] failed to delete temp basket', {
                    basketId: id,
                    ...(error instanceof ApiError ? error.toJSON() : { message: String(error) }),
                });
            })
        )
    );
    logger.info('[sf-payments] swept orphaned temp baskets', { count: ids.length, customerId });
}

/**
 * Ensure a Salesforce Payments instrument is attached to the basket.
 *
 * If the basket already has a SF Payments instrument, returns the basket
 * unchanged. Otherwise adds a new one using
 * {@link createPaymentInstrumentBody} to build the request body.
 *
 * The `paymentMethodId: 'Salesforce Payments'` convention is honored by
 * `createPaymentInstrumentBody`.
 *
 * @remarks Callers should set the shipping address and shipping method on the
 *   basket before invoking this — `orderTotal` is only populated once shipping
 *   + tax are calculated, and the PI amount is what the gateway authorizes.
 *   Calling this pre-shipping falls back to `productSubTotal`, which under-
 *   authorizes the final order.
 */
export async function ensurePaymentInstrumentInBasket(
    context: Readonly<RouterContextProvider>,
    basket: Basket,
    paymentMethodType: PaymentMethodType,
    paymentConfig: PaymentConfig,
    paymentData?: Record<string, unknown>
): Promise<Basket> {
    if (!basket.basketId) {
        throw new Error('Basket is missing a basketId');
    }
    if (getSFPaymentsInstrument(basket)) {
        return basket;
    }
    if (!paymentConfig.zoneId) {
        throw new Error('Payment config is missing a zoneId');
    }
    const amount = basket.orderTotal ?? basket.productSubTotal;
    if (typeof amount !== 'number') {
        throw new Error('Basket has no orderTotal or productSubTotal to authorize');
    }
    const body = createPaymentInstrumentBody({
        amount,
        paymentMethodType,
        zoneId: paymentConfig.zoneId,
        paymentData,
        paymentMethods: paymentConfig.paymentMethods,
        paymentMethodSetAccounts: paymentConfig.paymentMethodSetAccounts,
    });
    return addPaymentInstrumentToBasket(
        context,
        basket.basketId,
        body as unknown as ShopperBasketsV2.schemas['OrderPaymentInstrument']
    );
}

/**
 * Cleanup after an express payment is cancelled or fails before order creation.
 *
 * - If the order was already created, the basket has been consumed — no-op.
 * - Otherwise removes the SF Payments instrument (if present) and deletes the
 *   basket. Intended for temp baskets only — do not invoke on the main basket.
 *
 * @remarks Express-only — the sheet's cancel path removes the PI from the main
 *   basket but never deletes it.
 */
export async function cleanupExpressBasket(
    context: Readonly<RouterContextProvider>,
    basket: Basket | null | undefined,
    orderWasCreated: boolean
): Promise<void> {
    if (orderWasCreated || !basket?.basketId) {
        return;
    }
    const logger = getLogger(context);
    const pi = getSFPaymentsInstrument(basket);
    if (pi?.paymentInstrumentId) {
        try {
            await removePaymentInstrumentFromBasket(context, basket.basketId, pi.paymentInstrumentId);
        } catch (error) {
            // Best-effort — failure to remove the PI shouldn't block the cancel
            // flow, but log it so it shows up when triaging.
            logger.warn('[sf-payments] failed to remove PI during express cleanup', {
                basketId: basket.basketId,
                paymentInstrumentId: pi.paymentInstrumentId,
                ...(error instanceof ApiError ? error.toJSON() : { message: String(error) }),
            });
        }
    }
    try {
        await deleteBasket(context, basket.basketId);
    } catch (error) {
        // deleteBasket already swallows 404; anything reaching here is a real
        // failure. Log and swallow so the cancel flow completes.
        logger.warn('[sf-payments] failed to delete temp basket during express cleanup', {
            basketId: basket.basketId,
            ...(error instanceof ApiError ? error.toJSON() : { message: String(error) }),
        });
    }
}
