/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { describe, test, expect, vi, beforeEach, afterEach } from 'vitest'
import { buildTheme } from './sf-payments-theme'

const MOCK_CSS_VARS: Record<string, string> = {
    '--foreground': '#000000',
    '--destructive': '#ef4444',
    '--muted-foreground': '#6b6b6b',
    '--background': '#ffffff',
    '--primary': '#000000',
    '--primary-foreground': '#ffffff',
    '--input': '#e8e8e8',
    '--font-sans': 'Sen, -apple-system, sans-serif',
}

const mockGetComputedStyle = () => ({
    getPropertyValue: (name: string) => MOCK_CSS_VARS[name] ?? '',
})

describe('buildTheme', () => {
    beforeEach(() => {
        vi.spyOn(window, 'getComputedStyle').mockReturnValue(
            mockGetComputedStyle() as unknown as CSSStyleDeclaration
        )
    })

    afterEach(() => {
        vi.restoreAllMocks()
    })

    describe('designTokens', () => {
        test('reads all tokens from CSS custom properties', () => {
            const theme = buildTheme()

            expect(theme.designTokens).toEqual({
                'color-text-default': '#000000',
                'color-text-error': '#ef4444',
                'color-text-placeholder': '#6b6b6b',
                'color-text-weak': '#6b6b6b',
                'color-background': '#ffffff',
                'color-brand': '#000000',
                'color-text-brand-primary': '#ffffff',
                'color-text-inverse': '#ffffff',
                'color-border-input': '#e8e8e8',
                'font-family': 'Sen, -apple-system, sans-serif',
            })
        })

        test('reads from document.documentElement', () => {
            buildTheme()

            expect(window.getComputedStyle).toHaveBeenCalledWith(document.documentElement)
        })

        test('returns empty strings when CSS vars are not set', () => {
            vi.spyOn(window, 'getComputedStyle').mockReturnValue({
                getPropertyValue: () => '',
            } as unknown as CSSStyleDeclaration)

            const theme = buildTheme()

            expect(theme.designTokens['color-brand']).toBe('')
            expect(theme.designTokens['color-text-default']).toBe('')
        })

        test('trims whitespace from CSS var values', () => {
            vi.spyOn(window, 'getComputedStyle').mockReturnValue({
                getPropertyValue: () => '  #000000  ',
            } as unknown as CSSStyleDeclaration)

            const theme = buildTheme()

            expect(theme.designTokens['color-brand']).toBe('#000000')
        })
    })

    describe('expressButtons', () => {
        test('defaults to vertical layout', () => {
            const theme = buildTheme()

            expect(theme.expressButtons.buttonLayout).toBe('vertical')
        })

        test('passes through expressButtonLayout option', () => {
            const theme = buildTheme({ expressButtonLayout: 'horizontal' })

            expect(theme.expressButtons.buttonLayout).toBe('horizontal')
        })

        test('buttonHeight is 44 — same as pwa-kit', () => {
            const theme = buildTheme()

            expect(theme.expressButtons.buttonHeight).toBe(44)
        })
    })

    describe('SSR guard', () => {
        test('returns empty strings for all designTokens when window is undefined', () => {
            const originalWindow = global.window
            // @ts-expect-error simulate SSR
            delete global.window

            const theme = buildTheme()

            Object.values(theme.designTokens).forEach((value) => {
                expect(value).toBe('')
            })

            global.window = originalWindow
        })
    })

    describe('options', () => {
        test('handles undefined options', () => {
            const theme = buildTheme(undefined)

            expect(theme.expressButtons.buttonLayout).toBe('vertical')
        })

        test('handles empty options object', () => {
            const theme = buildTheme({})

            expect(theme.expressButtons.buttonLayout).toBe('vertical')
        })

        test('multiple calls return independent objects', () => {
            const theme1 = buildTheme()
            const theme2 = buildTheme()

            expect(theme1).toEqual(theme2)
            expect(theme1).not.toBe(theme2)
            expect(theme1.designTokens).not.toBe(theme2.designTokens)
            expect(theme1.expressButtons).not.toBe(theme2.expressButtons)
        })
    })
})
