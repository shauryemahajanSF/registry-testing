/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

import type { ShopperBasketsV2, ShopperOrders } from '@salesforce/storefront-next-runtime/scapi'
/**
 * Payment gateway types supported by SF Payments.
 */
export type PaymentGateway = 'stripe' | 'adyen' | 'paypal'

/**
 * Payment method types (aligned with SCAPI payment method types).
 */
export type PaymentMethodType =
    | 'card'
    | 'paypal'
    | 'venmo'
    | 'applepay'
    | 'googlepay'
    | 'amazon_pay'
    | 'sepa_debit'
    | 'klarna'
    | 'ideal'
    | 'afterpay'
    | 'bancontact'

/**
 * Express payment usage modes — passed by surface wrappers (PDP, cart, checkout)
 * to ExpressButtons and PaymentSheet via props.
 */
export const EXPRESS_PAY_NOW = 0
export const EXPRESS_BUY_NOW = 1

/**
 * Payment method type constants
 */
export const PAYMENT_METHOD_TYPES = {
    CARD: 'card',
    PAYPAL: 'paypal',
    VENMO: 'venmo',
    APPLE_PAY: 'applepay',
    GOOGLE_PAY: 'googlepay',
    AMAZON_PAY: 'amazon_pay',
    SEPA_DEBIT: 'sepa_debit',
    KLARNA: 'klarna',
    IDEAL: 'ideal',
    AFTERPAY: 'afterpay',
    BANCONTACT: 'bancontact'
} as const

/**
 * Payment gateway constants
 */
export const PAYMENT_GATEWAYS = {
    STRIPE: 'stripe',
    ADYEN: 'adyen',
    PAYPAL: 'paypal'
} as const

/**
 * SDK confirm response codes. The SDK uses a ResponseCode enum internally
 * but does not export it, so consumers define their own constants.
 */
export const SDK_RESPONSE_CODE = {
    SUCCESS: 0,
    FAILURE: 1,
} as const

/**
 * Setup future usage constants (for Stripe saved payments)
 */
export const SETUP_FUTURE_USAGE = {
    ON_SESSION: 'on_session',
    OFF_SESSION: 'off_session'
} as const

/**
 * Returns the first Salesforce Payments instrument found in a basket or order.
 *
 * Note on the return type: SCAPI models both `Basket.paymentInstruments` and
 * `Order.paymentInstruments` as arrays of `OrderPaymentInstrument`, so we
 * reuse that schema for both halves of the union.
 */
export function getSFPaymentsInstrument(
    basketOrOrder: ShopperBasketsV2.schemas['Basket'] | ShopperOrders.schemas['Order']
): ShopperBasketsV2.schemas['OrderPaymentInstrument'] | ShopperOrders.schemas['OrderPaymentInstrument'] | undefined {
    return basketOrOrder?.paymentInstruments?.find(
        (pi) => pi.paymentMethodId === 'Salesforce Payments'
    )
}

/**
 * Returns the client secret from a payment instrument (e.g. Stripe PaymentIntent client_secret).
 */
export function getClientSecret(
    paymentInstrument: ShopperBasketsV2.schemas['OrderPaymentInstrument'] | ShopperOrders.schemas['OrderPaymentInstrument']
): string | undefined {
    return (paymentInstrument as any)?.paymentReference?.gatewayProperties?.stripe?.clientSecret
}

/**
 * Address transformation interface
 */
interface AddressDetails {
    name?: string
    address: {
        line1: string
        line2?: string
        city: string
        state?: string
        postalCode: string
        country: string
    }
    phone?: string
}

interface TransformedAddress {
    firstName: string | null
    lastName: string | null
    address1: string
    address2?: string | null
    city: string
    stateCode?: string
    postalCode: string
    countryCode: string
    phone?: string | null
}

/**
 * Transform billing and shipping address details from payment provider format to basket format.
 */
export function transformAddressDetails(
    billingDetails?: AddressDetails,
    shippingDetails?: AddressDetails
): { billingAddress: TransformedAddress; shippingAddress: TransformedAddress } {
    const transformSingleAddress = (addressDetails: AddressDetails): TransformedAddress => {
        const address: TransformedAddress = {
            firstName: null,
            lastName: null,
            address1: addressDetails.address.line1,
            address2: addressDetails.address.line2 || null,
            city: addressDetails.address.city,
            stateCode: addressDetails.address.state,
            postalCode: addressDetails.address.postalCode,
            countryCode: addressDetails.address.country,
            phone: addressDetails.phone || null
        }

        if (addressDetails.name) {
            const names = addressDetails.name.split(' ')
            address.firstName = names.slice(0, -1).join(' ')
            address.lastName = names.slice(-1).join(' ')
        }

        return address
    }

    // For PayPal/Venmo, billing address might not be available or incomplete
    // Use shipping address as billing address if billing details are missing or incomplete
    const billingAddr = billingDetails?.address
    const hasBillingDetails = billingDetails?.name && billingAddr?.city
    const billingSource = hasBillingDetails ? billingDetails : shippingDetails

    if (!shippingDetails) {
        throw new Error('Shipping details are required')
    }

    return {
        billingAddress: transformSingleAddress(billingSource!),
        shippingAddress: transformSingleAddress(shippingDetails)
    }
}

/**
 * Privacy-shielded partial address the SDK emits in `onShippingAddressChange`.
 * Wallets (Google Pay / Apple Pay) redact name + street line until approval, so
 * only city / region / postal / country are present, and the keys are snake_case.
 */
export interface ExpressShippingAddressPartial {
    city?: string
    state?: string
    postal_code?: string
    country?: string
}

/**
 * Map the SDK's partial shipping-change payload to SCAPI's `OrderAddress`
 * shape. Skips name/line1 (not supplied pre-approval) and keeps the mapping
 * explicit so unexpected keys don't leak into the SCAPI request and trip its
 * strict decoder (rejects unknown properties with 400).
 */
export function transformExpressShippingAddressPartial(
    partial: ExpressShippingAddressPartial
): { city?: string; stateCode?: string; postalCode?: string; countryCode?: string } {
    return {
        city: partial.city,
        stateCode: partial.state,
        postalCode: partial.postal_code,
        countryCode: partial.country
    }
}

/**
 * Transform shipping methods from API format to express payment format.
 */
export function transformShippingMethods(
    shippingMethods: Array<{ id: string; name: string; description?: string; price: number }>,
    _basket: ShopperBasketsV2.schemas['Basket'],
    selectedId: string | null = null,
    sortSelected: boolean = true
): Array<{ id: string; name: string; classOfService?: string; amount: string }> {
    const methods = shippingMethods.map((method) => ({
        id: method.id,
        name: method.name,
        classOfService: method.description,
        amount: method.price?.toString()
    }))

    if (sortSelected && selectedId) {
        methods.sort((m1, m2) => {
            if (m1.id === selectedId) return -1
            if (m2.id === selectedId) return 1
            return 0
        })
    }

    return methods
}

/**
 * Get the currently selected shipping method ID from basket or fallback to default.
 */
export function getSelectedShippingMethodId(
    basket: ShopperBasketsV2.schemas['Basket'],
    defaultShippingMethodId?: string
): string | undefined {
    return basket.shipments?.[0]?.shippingMethod?.id || defaultShippingMethodId
}

/**
 * Validates current shipping method is still applicable.
 */
export function isShippingMethodValid(
    currentBasket: ShopperBasketsV2.schemas['Basket'],
    updatedShippingMethods: { applicableShippingMethods: Array<{ id: string }> }
): boolean {
    const currentShippingMethodId = currentBasket.shipments?.[0]?.shippingMethod?.id
    if (!currentShippingMethodId) return false

    return updatedShippingMethods.applicableShippingMethods.some(
        (method) => method.id === currentShippingMethodId
    )
}

/**
 * Checks if the payment method type uses PayPal to render and complete payments
 */
export function isPayPalPaymentMethodType(paymentMethodType: string): boolean {
    return (
        paymentMethodType === PAYMENT_METHOD_TYPES.PAYPAL ||
        paymentMethodType === PAYMENT_METHOD_TYPES.VENMO
    )
}

/**
 * Payment method configuration interfaces
 */
interface PaymentMethod {
    paymentMethodType: string
    accountId: string
}

interface PaymentMethodSetAccount {
    accountId: string
    vendor: string
}

/**
 * Finds the payment account/gateway for a given payment method type.
 */
export function findPaymentAccount(
    paymentMethods: PaymentMethod[] | undefined,
    paymentMethodSetAccounts: PaymentMethodSetAccount[] | undefined,
    paymentMethodType: string
): PaymentMethodSetAccount | null {
    if (!paymentMethodSetAccounts || !Array.isArray(paymentMethodSetAccounts)) {
        return null
    }

    // Find payment method by type to get its accountId
    const paymentMethod = paymentMethods?.find((pm) => pm.paymentMethodType === paymentMethodType)
    if (!paymentMethod || !paymentMethod.accountId) {
        return null
    }

    // Find account by accountId
    return (
        paymentMethodSetAccounts.find((account) => account.accountId === paymentMethod.accountId) ||
        null
    )
}

/**
 * Determines the gateway name from payment method type and payment method set accounts.
 */
export function getGatewayFromPaymentMethod(
    paymentMethodType: string,
    paymentMethods: PaymentMethod[] | undefined,
    paymentMethodSetAccounts: PaymentMethodSetAccount[] | undefined
): PaymentGateway | null {
    const account = findPaymentAccount(paymentMethods, paymentMethodSetAccounts, paymentMethodType)
    if (!account) {
        return null
    }

    const vendor = account.vendor?.toLowerCase()
    if (vendor === PAYMENT_GATEWAYS.STRIPE) {
        return PAYMENT_GATEWAYS.STRIPE
    } else if (vendor === PAYMENT_GATEWAYS.ADYEN) {
        return PAYMENT_GATEWAYS.ADYEN
    } else if (vendor === PAYMENT_GATEWAYS.PAYPAL) {
        return PAYMENT_GATEWAYS.PAYPAL
    }

    return null
}

/**
 * Creates a payment instrument body for Salesforce Payments (for basket or order).
 */
interface CreatePaymentInstrumentBodyParams {
    amount: number
    paymentMethodType: PaymentMethodType
    zoneId: string
    shippingPreference?: string
    paymentData?: any
    storePaymentMethod?: boolean
    futureUsageOffSession?: boolean
    paymentMethods?: PaymentMethod[]
    paymentMethodSetAccounts?: PaymentMethodSetAccount[]
    isPostRequest?: boolean
}

export function createPaymentInstrumentBody({
    amount,
    paymentMethodType,
    zoneId,
    shippingPreference,
    paymentData = null,
    storePaymentMethod = false,
    futureUsageOffSession = false,
    paymentMethods = [],
    paymentMethodSetAccounts = [],
    isPostRequest = false
}: CreatePaymentInstrumentBodyParams): ShopperBasketsV2.schemas['BasketPaymentInstrumentRequest'] {
    if (!zoneId) {
        throw new Error('Cannot build a payment instrument body without a zoneId')
    }
    const paymentReferenceRequest: any = {
        paymentMethodType: paymentMethodType,
        zoneId
    }

    const gateway = getGatewayFromPaymentMethod(
        paymentMethodType,
        paymentMethods,
        paymentMethodSetAccounts
    )

    if (gateway === PAYMENT_GATEWAYS.PAYPAL && shippingPreference !== undefined && shippingPreference !== null) {
        paymentReferenceRequest.gateway = PAYMENT_GATEWAYS.PAYPAL
        paymentReferenceRequest.gatewayProperties = {
            paypal: {
                shippingPreference
            }
        }
    }

    if (!isPostRequest && gateway === PAYMENT_GATEWAYS.STRIPE) {
        const stripeGatewayProperties: Record<string, unknown> = {}

        if (storePaymentMethod) {
            stripeGatewayProperties.setupFutureUsage = futureUsageOffSession
                ? SETUP_FUTURE_USAGE.OFF_SESSION
                : SETUP_FUTURE_USAGE.ON_SESSION
        }
        if (paymentData?.returnUrl) {
            stripeGatewayProperties.returnUrl = paymentData.returnUrl
        }

        if (Object.keys(stripeGatewayProperties).length > 0) {
            paymentReferenceRequest.gateway = PAYMENT_GATEWAYS.STRIPE
            paymentReferenceRequest.gatewayProperties = {
                stripe: stripeGatewayProperties
            }
        }
    }

    if (!isPostRequest && gateway === PAYMENT_GATEWAYS.ADYEN) {
        paymentReferenceRequest.gateway = PAYMENT_GATEWAYS.ADYEN
        paymentReferenceRequest.gatewayProperties = {
            adyen: {
                ...(paymentData && {
                    paymentMethod: paymentData.paymentMethod,
                    returnUrl: paymentData.returnUrl,
                    origin: paymentData.origin,
                    lineItems: paymentData.lineItems,
                    billingDetails: paymentData.billingDetails
                }),
                ...(storePaymentMethod && { storePaymentMethod: true })
            }
        }
    }

    return {
        paymentMethodId: 'Salesforce Payments',
        amount: amount,
        paymentReferenceRequest: paymentReferenceRequest
    } as ShopperBasketsV2.schemas['BasketPaymentInstrumentRequest']
}

/**
 * Maps express payment method type to underlying payment type.
 * For example, Apple Pay via Stripe uses 'card' as the payment method type.
 */
export function getExpressPaymentMethodType(
    type: string,
    paymentMethods: PaymentMethod[],
    paymentMethodSetAccounts: PaymentMethodSetAccount[]
): PaymentMethodType {
    const gateway = getGatewayFromPaymentMethod(type, paymentMethods, paymentMethodSetAccounts)

    // Stripe uses 'card' for Apple Pay / Google Pay
    if (gateway === PAYMENT_GATEWAYS.STRIPE && (type === PAYMENT_METHOD_TYPES.APPLE_PAY || type === PAYMENT_METHOD_TYPES.GOOGLE_PAY)) {
        return PAYMENT_METHOD_TYPES.CARD
    }

    return type as PaymentMethodType
}

/**
 * Build the redirect return URL for the SF Payments SDK `config.options.returnUrl`.
 *
 * Called twice per express session:
 *  1. At SDK initialization — omit orderNo/zoneId/type to get the base URL.
 *  2. Inside `createIntent` after order creation — pass all params to get the
 *     order-specific URL the SDK will use during redirect-based payment confirmation.
 */
export function buildExpressPaymentReturnUrl({
    origin,
    orderNo,
    zoneId,
    type,
}: {
    origin: string
    orderNo?: string
    zoneId?: string
    type?: string
}): string {
    const params = new URLSearchParams()
    if (orderNo !== undefined) params.set('orderNo', orderNo)
    if (type !== undefined) params.set('type', type)
    if (zoneId !== undefined) params.set('zoneId', zoneId)
    const qs = params.toString()
    return qs
        ? `${origin}/checkout/payment-processing?${qs}`
        : `${origin}/checkout/payment-processing`
}

/**
 * Shape returned to the SF Payments SDK from `onShippingAddressChange` and
 * `onShippingMethodChange` callbacks.
 */
export interface ExpressCallbackData {
    total: string
    shippingMethods: ReturnType<typeof transformShippingMethods>
    selectedShippingMethod: ReturnType<typeof transformShippingMethods>[number] | undefined
    lineItems: Array<{ name: string; amount: string }>
}

/**
 * Localized labels for the line items emitted to the SDK. Callers pass strings
 * that are already translated for the shopper's locale — this helper is pure
 * and does no i18n on its own.
 */
export interface ExpressCallbackLabels {
    subtotal: string
    shipping: string
    tax: string
}

/**
 * Build the payload passed back to the SF Payments SDK from express shipping
 * callbacks (address change, method change).
 *
 * Pure function — computes the line-item breakdown, selected-method echo, and
 * total from a basket + applicable shipping methods. Throws if basket total is
 * missing or non-positive (the SDK rejects the callback otherwise).
 */
export function buildExpressCallbackData(
    basket: ShopperBasketsV2.schemas['Basket'],
    shippingMethodsResult: { applicableShippingMethods: Array<{ id: string; name: string; description?: string; price: number }> },
    labels: ExpressCallbackLabels
): ExpressCallbackData {
    const selectedId = getSelectedShippingMethodId(basket)
    const methods = transformShippingMethods(
        shippingMethodsResult.applicableShippingMethods,
        basket,
        selectedId ?? null,
        true
    )
    const selected = methods.find((m) => m.id === selectedId) ?? methods[0]

    const total = basket.orderTotal ?? basket.productSubTotal
    if (typeof total !== 'number' || !Number.isFinite(total) || total <= 0) {
        throw new Error('Invalid basket total amount')
    }

    // Subtotal line item is product subtotal so total === subtotal + shipping + tax.
    // Using `total` here would double-count shipping + tax against the top-line total
    // and cause wallets (Google Pay / Apple Pay) to reject the payload.
    const subtotal = basket.productSubTotal ?? total
    const lineItems: Array<{ name: string; amount: string }> = [
        { name: labels.subtotal, amount: subtotal.toString() }
    ]
    if (basket.shippingTotal) {
        lineItems.push({ name: labels.shipping, amount: basket.shippingTotal.toString() })
    }
    if (basket.taxTotal) {
        lineItems.push({ name: labels.tax, amount: basket.taxTotal.toString() })
    }

    return { total: total.toString(), shippingMethods: methods, selectedShippingMethod: selected, lineItems }
}
