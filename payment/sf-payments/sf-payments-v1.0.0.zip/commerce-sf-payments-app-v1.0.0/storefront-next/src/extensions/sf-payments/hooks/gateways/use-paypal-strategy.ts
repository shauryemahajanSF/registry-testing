/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

'use client';

/**
 * PayPal gateway strategy hook.
 *
 * Flow: onClick skips prep (PayPal's SDK races) → createIntent preps basket
 * lazily, removes stale PI, adds fresh PI (no order) → onPayerApprove pushes
 * addresses → onApprove creates commerce order + patches PI.
 *
 * `prepareBasketOnClick` is `false` — PayPal's SDK creates its PayPal-side
 * order on button click before `createIntent` fires, and prepping earlier
 * would race it.
 */

import type { GatewayStrategy } from '../../lib/gateways/types';

export function usePaypalStrategy(): GatewayStrategy {
    // Placeholder bodies — real SCAPI orchestration to follow in a later task.
    return {
        prepareBasketOnClick: false,
        onPayerApprove: () => Promise.reject<never>(new Error('usePaypalStrategy.onPayerApprove: not yet implemented')),
        createIntent: () => Promise.reject(new Error('usePaypalStrategy.createIntent: not yet implemented')),
        onApprove: () => Promise.reject(new Error('usePaypalStrategy.onApprove: not yet implemented')),
    };
}
