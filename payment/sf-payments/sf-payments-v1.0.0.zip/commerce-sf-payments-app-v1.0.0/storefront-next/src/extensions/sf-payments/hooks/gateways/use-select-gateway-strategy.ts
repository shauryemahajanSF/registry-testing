/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

'use client';

/**
 * Gateway strategy selector hook.
 *
 * Runs all three per-gateway strategy hooks unconditionally (Rules of Hooks)
 * and returns a plain selector function. Callers invoke `selectStrategy(type,
 * paymentConfig)` inside event handlers — the selector maps the SDK's
 * paymentMethodType ('card' / 'applepay' / 'googlepay' / 'paypal') plus the
 * merchant's payment configuration onto the correct vendor (Stripe / Adyen /
 * PayPal) and returns that strategy. Throws on misconfiguration (no matching
 * `paymentMethodSetAccounts.vendor`) so callers don't have to guard for null;
 * this is an invariant violation, not a normal control-flow case.
 */

import { useCallback } from 'react';
import { PAYMENT_GATEWAYS, getGatewayFromPaymentMethod } from '../../lib/sf-payments-utils';
import type { PaymentConfig } from '../../lib/api/types';
import type { GatewayStrategy } from '../../lib/gateways/types';
import { useStripeStrategy } from './use-stripe-strategy';
import { useAdyenStrategy } from './use-adyen-strategy';
import { usePaypalStrategy } from './use-paypal-strategy';

export type SelectGatewayStrategy = (paymentMethodType: string, paymentConfig: PaymentConfig) => GatewayStrategy;

export function useSelectGatewayStrategy(): SelectGatewayStrategy {
    const stripe = useStripeStrategy();
    const adyen = useAdyenStrategy();
    const paypal = usePaypalStrategy();

    return useCallback<SelectGatewayStrategy>(
        (paymentMethodType, paymentConfig) => {
            const gateway = getGatewayFromPaymentMethod(
                paymentMethodType,
                paymentConfig?.paymentMethods,
                paymentConfig?.paymentMethodSetAccounts
            );

            switch (gateway) {
                case PAYMENT_GATEWAYS.STRIPE:
                    return stripe;
                case PAYMENT_GATEWAYS.ADYEN:
                    return adyen;
                case PAYMENT_GATEWAYS.PAYPAL:
                    return paypal;
                default:
                    throw new Error(`No gateway strategy for paymentMethodType=${paymentMethodType}`);
            }
        },
        [stripe, adyen, paypal]
    );
}
