/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { beforeEach, describe, expect, test, vi } from 'vitest';
import type { RouterContextProvider } from 'react-router';
import { action } from './action.sf-payments-create-order';
import { createOrderAndUpdatePayment } from '../lib/api/order-mutations.server';

vi.mock('../lib/api/order-mutations.server', () => ({
    createOrderAndUpdatePayment: vi.fn(),
}));

vi.mock('@/lib/logger.server', () => ({
    getLogger: vi.fn(() => ({ error: vi.fn(), info: vi.fn() })),
}));

const mockContext = { get: vi.fn(), set: vi.fn() } as unknown as RouterContextProvider;

const paymentConfig = {
    zoneId: 'z1',
    paymentMethods: [{ paymentMethodType: 'card', accountId: 'acct_1' }],
    paymentMethodSetAccounts: [{ accountId: 'acct_1', vendor: 'Stripe' }],
};

function makeRequest(fields: Record<string, string>, method = 'POST') {
    const form = new FormData();
    for (const [k, v] of Object.entries(fields)) form.set(k, v);
    const canHaveBody = method !== 'GET' && method !== 'HEAD';
    return new Request('https://shop.example/action/sf-payments-create-order', {
        method,
        ...(canHaveBody && { body: form }),
    });
}

beforeEach(() => {
    vi.clearAllMocks();
});

describe('action.sf-payments-create-order', () => {
    test('forwards SPM flags as false when omitted', async () => {
        vi.mocked(createOrderAndUpdatePayment).mockResolvedValue({ orderNo: 'o-1' } as never);

        await action({
            request: makeRequest({
                basketId: 'b1',
                paymentMethodType: 'card',
                paymentConfig: JSON.stringify(paymentConfig),
                origin: 'https://example.com',
            }),
            context: mockContext,
            params: {},
        } as any);

        expect(createOrderAndUpdatePayment).toHaveBeenCalledWith(
            mockContext,
            expect.objectContaining({
                basketId: 'b1',
                paymentMethodType: 'card',
                storePaymentMethod: false,
                futureUsageOffSession: false,
            })
        );
    });

    test('forwards SPM flags as true when set in form data', async () => {
        vi.mocked(createOrderAndUpdatePayment).mockResolvedValue({ orderNo: 'o-1' } as never);

        await action({
            request: makeRequest({
                basketId: 'b1',
                paymentMethodType: 'card',
                paymentConfig: JSON.stringify(paymentConfig),
                origin: 'https://example.com',
                storePaymentMethod: 'true',
                futureUsageOffSession: 'true',
            }),
            context: mockContext,
            params: {},
        } as any);

        expect(createOrderAndUpdatePayment).toHaveBeenCalledWith(
            mockContext,
            expect.objectContaining({
                basketId: 'b1',
                paymentMethodType: 'card',
                storePaymentMethod: true,
                futureUsageOffSession: true,
            })
        );
    });
});
