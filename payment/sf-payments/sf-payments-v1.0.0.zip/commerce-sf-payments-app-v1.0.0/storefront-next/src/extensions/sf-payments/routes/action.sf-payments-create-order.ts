/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

import { type ActionFunctionArgs, data } from 'react-router';
import { ApiError } from '@/scapi';
import { getLogger } from '@/lib/logger.server';
import { withRevalidateTags } from '@/lib/revalidation/tags';
import { CHECKOUT_PAYMENT_COMPLETE_TAG } from '../lib/constants';
import { createOrderAndUpdatePayment, type OrderCreationError } from '../lib/api/order-mutations.server';
import type { PaymentConfig } from '../lib/api/types';
import type { PaymentMethodType } from '../lib/sf-payments-utils';

/**
 * Create a commerce order from a basket and patch its SF Payments instrument.
 *
 * The server builds the 3DS `returnUrl` using `origin` + the newly created
 * `orderNo` — the client can't build it ahead of time because `orderNo` only
 * exists after `createOrder` runs.
 *
 * On partial failure (order created but PI patch fails), the response carries
 * `orderNo` so the client can invoke `/sf-payments-fail-order` for recovery.
 *
 * POST body (FormData — matches storefront-next's useFetcher convention;
 * complex values are JSON-stringified into individual fields):
 *   basketId: string (required)
 *   paymentMethodType: string (required)
 *   paymentConfig: JSON-stringified PaymentConfig (required)
 *   origin: string (required)  — e.g. "https://example.com"
 *   paymentData: JSON-stringified Record<string, unknown> (optional) — gateway-specific (Adyen)
 *   storePaymentMethod: 'true' (optional) — shopper opted in to saving this payment method
 *   futureUsageOffSession: 'true' (optional) — Stripe setup_future_usage off_session toggle
 */
export async function action({ request, context }: ActionFunctionArgs) {
    if (request.method !== 'POST') {
        return data({ success: false, error: 'Method not allowed' }, { status: 405 });
    }

    const logger = getLogger(context);
    try {
        const formData = await request.formData();
        const basketId = formData.get('basketId')?.toString();
        const paymentMethodType = formData.get('paymentMethodType')?.toString() as PaymentMethodType | undefined;
        const paymentConfigRaw = formData.get('paymentConfig')?.toString();
        const origin = formData.get('origin')?.toString();
        const paymentDataRaw = formData.get('paymentData')?.toString();

        if (!basketId || !paymentMethodType || !paymentConfigRaw || !origin) {
            return data(
                {
                    success: false,
                    error: 'basketId, paymentMethodType, paymentConfig, and origin are required',
                },
                { status: 400 }
            );
        }

        const paymentConfig = JSON.parse(paymentConfigRaw) as PaymentConfig;
        const paymentData = paymentDataRaw ? (JSON.parse(paymentDataRaw) as Record<string, unknown>) : undefined;
        const storePaymentMethod = formData.get('storePaymentMethod') === 'true';
        const futureUsageOffSession = formData.get('futureUsageOffSession') === 'true';

        const order = await createOrderAndUpdatePayment(context, {
            basketId,
            paymentMethodType,
            paymentConfig,
            origin,
            paymentData,
            storePaymentMethod,
            futureUsageOffSession,
        });
        return withRevalidateTags({ success: true, order }, [CHECKOUT_PAYMENT_COMPLETE_TAG]);
    } catch (error) {
        const orderNo = (error as OrderCreationError)?.orderNo;
        const isApiError = error instanceof ApiError;
        logger.error('[sf-payments] create-order failed', {
            orderNo,
            ...(isApiError ? error.toJSON() : { message: String(error) }),
        });
        return data(
            {
                success: false,
                error: isApiError ? error.body?.detail || error.message : String(error),
                orderNo,
            },
            { status: isApiError ? error.status : 500 }
        );
    }
}
