/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

'use client';

import { useEffect, useRef, type RefObject } from 'react';
import { useFetcher } from 'react-router';
import { useNavigate } from '@/hooks/use-navigate';
import type { ShopperBasketsV2, ShopperOrders } from '@salesforce/storefront-next-runtime/scapi';
import type { ExpressButtonsProps } from './index';
import { useSelectGatewayStrategy } from '../../hooks/gateways/use-select-gateway-strategy';
import { useFetcherPromise } from '../../hooks/use-fetcher-promise';
import type { PaymentConfig } from '../../lib/api/types';
import type { SdkIntentPayload } from '../../lib/gateways/types';
import {
    buildExpressPaymentReturnUrl,
    transformExpressShippingAddressPartial,
    type ExpressShippingAddressPartial,
    type PaymentMethodType,
} from '../../lib/sf-payments-utils';

type Basket = ShopperBasketsV2.schemas['Basket'];
type Order = ShopperOrders.schemas['Order'];

type ActionOk<T> = { success: true } & T;
type ActionResponse<T> = ActionOk<T> | { success: false; error?: string };

interface ShippingCallbackData {
    total: string;
    shippingMethods: Array<{ id: string; name: string; classOfService?: string; amount: string }>;
    selectedShippingMethod?: { id: string; name: string; classOfService?: string; amount: string };
    lineItems: Array<{ name: string; amount: string }>;
}

type UpdateShippingAddressResponse = ActionResponse<{ basket: Basket; callbackData: ShippingCallbackData }>;
type UpdateShippingMethodResponse = ActionResponse<{ basket: Basket; callbackData: ShippingCallbackData }>;
type CleanupBasketResponse = ActionResponse<Record<string, never>>;

// Hard-coded English defaults; localized labels land once the i18n locale-aggregator
// follow-up resolves and `useTranslation('extSfPayments')` is wired here.
const EXPRESS_LABELS = {
    subtotal: 'Subtotal',
    shipping: 'Shipping',
    tax: 'Tax',
};

/** Mutable SDK options object shared with the parent component via ref. */
export interface SdkExpressOptions {
    returnUrl: string;
    [key: string]: unknown;
}

interface UseExpressCallbacksOptions {
    props: ExpressButtonsProps;
    /** Resolved payment configuration — used to map paymentMethodType → gateway strategy. */
    paymentConfig: PaymentConfig | null;
    /**
     * Ref to the mutable options object passed to `sfp.express(config.options)`.
     * `createIntent` writes the order-specific `returnUrl` here after order creation.
     * The SDK reads options during payment confirmation, so this ref lets us update
     * the same options object without re-binding the express component.
     */
    sdkExpressOptionsRef: RefObject<SdkExpressOptions | null>;
}

/** SDK callback object passed to `onShippingAddressChange` / `onShippingMethodChange`. */
interface ShippingChangeCallback {
    updateShippingAddress: (payload: ShippingCallbackData | { errors: string[] }) => void;
    updateShippingMethod: (payload: ShippingCallbackData | { errors: string[] }) => void;
}

/** Payload the SDK dispatches with `sfp:paymentmethodsrendered`. */
interface PaymentMethodsRenderedEvent extends Event {
    detail?: { rendered?: unknown[] };
}

interface ExpressCallbacksResult {
    callbacks: {
        onClick: (type: string) => Promise<{ amount: string; shippingRates: unknown[] }>;
        onShippingAddressChange: (shippingAddress: unknown, callback: ShippingChangeCallback) => Promise<void>;
        onShippingMethodChange: (shippingMethod: unknown, callback: ShippingChangeCallback) => Promise<void>;
        createIntent: (paymentData?: Record<string, unknown>) => Promise<SdkIntentPayload>;
        onPayerApprove: (billingDetails: unknown, shippingDetails: unknown) => Promise<void>;
    };
    eventHandlers: {
        onCancel: () => void;
        onPaymentError: () => void;
        onPaymentApprove: () => void;
        onPaymentMethodsRendered: (e: PaymentMethodsRenderedEvent) => void;
    };
    isPaymentInProgress: React.RefObject<boolean>;
    // SDK instance handle — typed at the consumer boundary as `any` until the SF
    // Payments SDK ships (or we publish a hand-written shim of) a real type for
    // the `sfp.express(...)` return value.
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    expressComponentRef: React.RefObject<any>;
}

function assertSuccess<T extends { success: boolean; error?: string }>(
    result: T | undefined,
    fallbackMessage: string
): Extract<T, { success: true }> {
    if (!result) {
        throw new Error(fallbackMessage);
    }
    if (result.success !== true) {
        throw new Error(result.error || fallbackMessage);
    }
    return result as Extract<T, { success: true }>;
}

export function useExpressCallbacks({
    props,
    paymentConfig,
    sdkExpressOptionsRef,
}: UseExpressCallbacksOptions): ExpressCallbacksResult {
    const {
        prepareBasket,
        initialAmount,
        onPaymentMethodsRendered: onPaymentMethodsRenderedProp,
        onExpressPaymentCompleted,
    } = props;

    const navigate = useNavigate();
    const selectStrategy = useSelectGatewayStrategy();

    // The SDK invokes our `onShippingAddressChange` / `onShippingMethodChange`
    // callbacks and passes in a `callback` object with an `updateShippingAddress`
    // / `updateShippingMethod` method. The SDK is NOT awaiting our return value —
    // it's awaiting an internal promise that we resolve by calling that method.
    // Until we call it (or its timeout fires), the wallet sheet (Apple Pay /
    // Google Pay) shows a calculating state to the shopper. Each callback needs
    // to POST to one of our action routes, await the response, and then call
    // `callback.updateShippingAddress(...)` to unblock the SDK.
    //
    // React Router's `useFetcher()` is the standard way to call an action route
    // without a full navigation, but it's reactive: you submit, then React
    // rerenders as `fetcher.state` moves `submitting → idle` and `fetcher.data`
    // populates. There's no built-in `await fetcher.submit()`.
    //
    // `useFetcherPromise()` (ported from storefront-next) bridges that gap by
    // watching the fetcher's state and resolving a promise when it returns to
    // `idle`. So the pattern below is: one fetcher per route (each has its own
    // response shape and only one request can be in-flight at a time), and one
    // matching `awaitX()` we call after `submit()` to get a real promise back.
    const shippingAddressFetcher = useFetcher<UpdateShippingAddressResponse>();
    const shippingMethodFetcher = useFetcher<UpdateShippingMethodResponse>();
    const cleanupFetcher = useFetcher<CleanupBasketResponse>();

    const awaitShippingAddress = useFetcherPromise(shippingAddressFetcher, 'update-shipping-address failed');
    const awaitShippingMethod = useFetcherPromise(shippingMethodFetcher, 'update-shipping-method failed');
    const awaitCleanup = useFetcherPromise(cleanupFetcher, 'cleanup-basket failed');

    // --- Mutable state owned by this hook ---
    // The SDK callbacks below are bound once per `paymentConfig` change (see
    // bind-effect deps in `express-buttons/index.tsx`); inside a single
    // checkout/PDP session the callbacks otherwise close over their bind-time
    // values. That's intentional — once a shopper clicks, the in-flight guard
    // prevents re-bind from disrupting the flow.
    //
    // `prepareBasketRef` is the one exception: on PDP, picking a different
    // variant changes `prepareBasket` (it captures `productId`/`quantity`) but
    // does NOT change `paymentConfig`, so the SDK isn't re-bound. We keep a
    // ref so the click handler still calls the latest `prepareBasket`.
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const expressComponentRef = useRef<any>(null);
    const expressBasket = useRef<Basket | null>(null);
    const orderRef = useRef<Order | null>(null);
    const prepareBasketPromise = useRef<Promise<Basket> | null>(null);
    const paymentMethodTypeRef = useRef<PaymentMethodType>('card');
    const isPaymentInProgress = useRef(false);

    const prepareBasketRef = useRef(prepareBasket);
    useEffect(() => {
        prepareBasketRef.current = prepareBasket;
    }, [prepareBasket]);

    const waitForBasketPreparation = async () => {
        if (prepareBasketPromise.current) {
            expressBasket.current = await prepareBasketPromise.current;
            prepareBasketPromise.current = null;
        }
    };

    // --- SDK action callbacks ---

    /**
     * paymentConfig is guaranteed non-null inside SDK callbacks: the component
     * gates SDK initialization on it, so callbacks cannot fire before it resolves.
     */
    const requireConfig = (): PaymentConfig => {
        if (!paymentConfig) {
            throw new Error('paymentConfig is not resolved');
        }
        return paymentConfig;
    };

    const onClick = (type: string) => {
        isPaymentInProgress.current = true;
        paymentMethodTypeRef.current = type as PaymentMethodType;

        const strategy = selectStrategy(type, requireConfig());
        if (strategy.prepareBasketOnClick) {
            const promise = prepareBasketRef.current();
            prepareBasketPromise.current = promise;
            promise
                .then((basket) => {
                    expressBasket.current = basket;
                })
                .catch((e) => {
                    prepareBasketPromise.current = null;
                    // eslint-disable-next-line no-console -- diagnostic until logger vs toast is decided
                    console.error('[sf-payments] prepareBasket failed:', e);
                });
        }

        return Promise.resolve({
            amount: initialAmount.toString(),
            shippingRates: [] as unknown[],
        });
    };

    const onShippingAddressChange = async (shippingAddress: unknown, callback: ShippingChangeCallback) => {
        try {
            await waitForBasketPreparation();
            const basketId = expressBasket.current?.basketId;
            if (!basketId) {
                throw new Error('Basket not ready');
            }

            const scapiAddress = transformExpressShippingAddressPartial(
                shippingAddress as ExpressShippingAddressPartial
            );
            const form = new FormData();
            form.set('basketId', basketId);
            form.set('shippingAddress', JSON.stringify(scapiAddress));
            form.set('labels', JSON.stringify(EXPRESS_LABELS));
            void shippingAddressFetcher.submit(form, {
                method: 'POST',
                action: '/action/sf-payments-update-shipping-address',
            });
            const result = assertSuccess(await awaitShippingAddress(), 'update-shipping-address failed');
            expressBasket.current = result.basket;
            callback.updateShippingAddress(result.callbackData);
        } catch (e) {
            // eslint-disable-next-line no-console -- diagnostic until logger vs toast is decided
            console.error('[sf-payments] onShippingAddressChange failed:', e);
            callback.updateShippingAddress({ errors: ['shipping_address_unavailable'] });
        }
    };

    const onShippingMethodChange = async (shippingMethod: unknown, callback: ShippingChangeCallback) => {
        try {
            await waitForBasketPreparation();
            const basketId = expressBasket.current?.basketId;
            if (!basketId) {
                throw new Error('Basket not ready');
            }
            const methodId = (shippingMethod as { id?: string } | null | undefined)?.id;
            if (!methodId) {
                throw new Error('shippingMethod.id is required');
            }

            const form = new FormData();
            form.set('basketId', basketId);
            form.set('methodId', methodId);
            form.set('labels', JSON.stringify(EXPRESS_LABELS));
            void shippingMethodFetcher.submit(form, {
                method: 'POST',
                action: '/action/sf-payments-update-shipping-method',
            });
            const result = assertSuccess(await awaitShippingMethod(), 'update-shipping-method failed');
            expressBasket.current = result.basket;
            callback.updateShippingMethod(result.callbackData);
        } catch (e) {
            // eslint-disable-next-line no-console -- diagnostic until logger vs toast is decided
            console.error('[sf-payments] onShippingMethodChange failed:', e);
            callback.updateShippingMethod({ errors: ['shipping_method_unavailable'] });
        }
    };

    const createIntent = async (paymentData?: Record<string, unknown>): Promise<SdkIntentPayload> => {
        await waitForBasketPreparation();
        if (!expressBasket.current) {
            throw new Error('Basket not ready');
        }

        const config = requireConfig();
        const strategy = selectStrategy(paymentMethodTypeRef.current, config);
        const { sdkResult, order } = await strategy.createIntent({
            basket: expressBasket.current,
            paymentMethodType: paymentMethodTypeRef.current,
            paymentConfig: config,
            origin: window.location.origin,
            paymentData,
        });

        if (order) {
            orderRef.current = order;
            // Update returnUrl with order-specific details used by redirect-capable
            // methods. The SDK reads config.options.returnUrl during confirmation, so
            // mutating sdkExpressOptionsRef.current here arrives in time.
            const orderNo = order.orderNo;
            const zoneId = config.zoneId ?? undefined;
            if (sdkExpressOptionsRef.current && orderNo) {
                sdkExpressOptionsRef.current.returnUrl = buildExpressPaymentReturnUrl({
                    origin: window.location.origin,
                    orderNo,
                    zoneId,
                    type: paymentMethodTypeRef.current,
                });
            }
        }

        return sdkResult;
    };

    const onPayerApprove = async (billingDetails: unknown, shippingDetails: unknown) => {
        await waitForBasketPreparation();
        if (!expressBasket.current) {
            throw new Error('Basket not ready');
        }

        const config = requireConfig();
        const strategy = selectStrategy(paymentMethodTypeRef.current, config);
        if (!strategy.onPayerApprove) {
            // Adyen omits onPayerApprove by design — addresses arrive via createIntent.
            return;
        }

        const updatedBasket = await strategy.onPayerApprove({
            basket: expressBasket.current,
            paymentMethodType: paymentMethodTypeRef.current,
            paymentConfig: config,
            shippingAddress: shippingDetails as Record<string, unknown> | undefined,
            billingAddress: billingDetails as Record<string, unknown> | undefined,
        });
        expressBasket.current = updatedBasket;
    };

    // --- DOM event handlers ---

    const runCleanup = (orderWasCreated: boolean) => {
        const basket = expressBasket.current;
        if (!basket) return;
        const form = new FormData();
        form.set('basket', JSON.stringify(basket));
        form.set('orderWasCreated', orderWasCreated ? 'true' : 'false');
        void cleanupFetcher.submit(form, {
            method: 'POST',
            action: '/action/sf-payments-cleanup-basket',
        });
        void awaitCleanup().catch((e) => {
            // eslint-disable-next-line no-console -- diagnostic until logger vs toast is decided
            console.error('[sf-payments] cleanup-basket failed:', e);
        });
    };

    const onCancel = () => {
        isPaymentInProgress.current = false;
        runCleanup(Boolean(orderRef.current));
        expressBasket.current = null;
        orderRef.current = null;
        prepareBasketPromise.current = null;
    };

    const onPaymentError = () => {
        isPaymentInProgress.current = false;
        // attemptFailOrder is a later concern; for now just clean up the basket.
        runCleanup(Boolean(orderRef.current));
        expressBasket.current = null;
        orderRef.current = null;
        prepareBasketPromise.current = null;
    };

    const onPaymentApprove = () => {
        isPaymentInProgress.current = false;
        onExpressPaymentCompleted?.();
        const orderNo = orderRef.current?.orderNo;
        expressBasket.current = null;
        orderRef.current = null;
        prepareBasketPromise.current = null;
        if (orderNo) {
            void navigate(`/order-confirmation/${orderNo}`);
        } else {
            // eslint-disable-next-line no-console -- diagnostic until logger vs toast is decided
            console.error('[sf-payments] paymentapprove fired but no order was captured');
        }
    };

    const onPaymentMethodsRendered = (e: PaymentMethodsRenderedEvent) => {
        // SDK fires this even when zero buttons rendered (browser/region doesn't
        // support any configured method). Skip the consumer callback in that case
        // so they don't reveal an "Express Checkout" heading over empty space.
        if (onPaymentMethodsRenderedProp && (e.detail?.rendered?.length ?? 0) > 0) {
            onPaymentMethodsRenderedProp();
        }
    };

    return {
        callbacks: {
            onClick,
            onShippingAddressChange,
            onShippingMethodChange,
            createIntent,
            onPayerApprove,
        },
        eventHandlers: {
            onCancel,
            onPaymentError,
            onPaymentApprove,
            onPaymentMethodsRendered,
        },
        isPaymentInProgress,
        expressComponentRef,
    };
}
