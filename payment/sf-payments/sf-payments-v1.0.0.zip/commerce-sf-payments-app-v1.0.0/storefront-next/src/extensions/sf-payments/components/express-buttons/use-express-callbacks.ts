/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

'use client';

import { useEffect, useRef, type RefObject } from 'react';
import { useFetcher } from 'react-router';
import { useTranslation } from 'react-i18next';
import { useNavigate } from '@/hooks/use-navigate';
import { useToast } from '@/components/toast';
import type { ShopperBasketsV2, ShopperOrders } from '@/scapi';
import type { ExpressButtonsProps } from './index';
import { useSelectGatewayStrategy } from '../../hooks/gateways/use-select-gateway-strategy';
import { useFetcherPromise } from '../../hooks/use-fetcher-promise';
import { useSFPaymentsFailureRecovery } from '../../hooks/use-sf-payments-failure-recovery';
import type { PaymentConfig } from '../../lib/api/types';
import type { SdkIntentPayload } from '../../lib/gateways/types';
import {
    EXPRESS_BUY_NOW,
    buildPaymentProcessingUrl,
    transformExpressShippingAddressPartial,
    type ExpressShippingAddressPartial,
    type PaymentMethodType,
} from '../../lib/sf-payments-utils';

type Basket = ShopperBasketsV2.schemas['Basket'];
type Order = ShopperOrders.schemas['Order'];

type ActionOk<T> = { success: true } & T;
type ActionResponse<T> = ActionOk<T> | { success: false; error?: string };

interface ShippingCallbackData {
    total: string;
    shippingMethods: Array<{ id: string; name: string; classOfService?: string; amount: string }>;
    selectedShippingMethod?: { id: string; name: string; classOfService?: string; amount: string };
    lineItems: Array<{ name: string; amount: string }>;
}

type UpdateShippingAddressResponse = ActionResponse<{ basket: Basket; callbackData: ShippingCallbackData }>;
type UpdateShippingMethodResponse = ActionResponse<{ basket: Basket; callbackData: ShippingCallbackData }>;
type CleanupBasketResponse = ActionResponse<Record<string, never>>;

// Hard-coded English defaults; localized labels land once the i18n locale-aggregator
// follow-up resolves and `useTranslation('extSfPayments' as any)` is wired here.
const EXPRESS_LABELS = {
    subtotal: 'Subtotal',
    shipping: 'Shipping',
    tax: 'Tax',
};

// Failure toasts fire while the express processing overlay is still up (or
// right as it tears down). Toasts in storefront-next render centered, so they
// sit behind the overlay until it clears — default 5s expires before the
// shopper can read them. 8s leaves enough time post-clear.
const EXPRESS_TOAST_DURATION_MS = 8000;

/** Mutable SDK options object shared with the parent component via ref. */
export interface SdkExpressOptions {
    returnUrl: string;
    [key: string]: unknown;
}

export interface ExpressComponent {
    destroy(): void;
}

interface UseExpressCallbacksOptions {
    props: ExpressButtonsProps;
    /** Resolved payment configuration — used to map paymentMethodType → gateway strategy. */
    paymentConfig: PaymentConfig | null;
    /**
     * Ref to the mutable options object passed to `sfp.express(config.options)`.
     * `createIntent` writes the order-specific `returnUrl` here after order creation.
     * The SDK reads options during payment confirmation, so this ref lets us update
     * the same options object without re-binding the express component.
     */
    sdkExpressOptionsRef: RefObject<SdkExpressOptions | null>;
    /** Show the express-pay processing overlay. */
    startExpressProcessing: () => void;
    /** Hide the express-pay processing overlay. */
    endExpressProcessing: () => void;
}

/** SDK callback object passed to `onShippingAddressChange` / `onShippingMethodChange`. */
interface ShippingChangeCallback {
    updateShippingAddress: (payload: ShippingCallbackData | { errors: string[] }) => void;
    updateShippingMethod: (payload: ShippingCallbackData | { errors: string[] }) => void;
}

/** Payload the SDK dispatches with `sfp:paymentmethodsrendered`. */
interface PaymentMethodsRenderedEvent extends Event {
    detail?: { rendered?: unknown[] };
}

interface ExpressCallbacksResult {
    callbacks: {
        onClick: (type: string) => Promise<{ amount: string; shippingRates: unknown[] }>;
        onShippingAddressChange: (shippingAddress: unknown, callback: ShippingChangeCallback) => Promise<void>;
        onShippingMethodChange: (shippingMethod: unknown, callback: ShippingChangeCallback) => Promise<void>;
        createIntent: (paymentData?: Record<string, unknown>) => Promise<SdkIntentPayload>;
        onPayerApprove: (billingDetails: unknown, shippingDetails: unknown) => Promise<void>;
    };
    eventHandlers: {
        onCancel: EventListener;
        onPaymentError: EventListener;
        onPaymentApprove: EventListener;
        onPaymentMethodsRendered: (e: PaymentMethodsRenderedEvent) => void;
    };
    isPaymentInProgress: React.RefObject<boolean>;
    expressComponentRef: React.RefObject<ExpressComponent | null>;
}

function assertSuccess<T extends { success: boolean; error?: string }>(
    result: T | undefined,
    fallbackMessage: string
): Extract<T, { success: true }> {
    if (!result) {
        throw new Error(fallbackMessage);
    }
    if (result.success !== true) {
        throw new Error(result.error || fallbackMessage);
    }
    return result as Extract<T, { success: true }>;
}

export function useExpressCallbacks({
    props,
    paymentConfig,
    sdkExpressOptionsRef,
    startExpressProcessing,
    endExpressProcessing,
}: UseExpressCallbacksOptions): ExpressCallbacksResult {
    const {
        prepareBasket,
        initialAmount,
        onPaymentMethodsRendered: onPaymentMethodsRenderedProp,
        onExpressPaymentCompleted,
    } = props;

    const navigate = useNavigate();

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { t } = useTranslation('extSfPayments' as any);
    const { addToast } = useToast();
    const selectStrategy = useSelectGatewayStrategy();
    const { failAndRecover } = useSFPaymentsFailureRecovery();
    // Reset in onClick so each new payment attempt earns a fresh recovery slot.
    const failOrderCalledRef = useRef(false);

    // Each shipping callback POSTs to an action route and resolves the SDK
    // callback so the wallet's calculating-state clears. `useFetcher` is reactive,
    // so `useFetcherPromise` adapts it to a real awaitable — one fetcher per
    // route (each has its own response shape and one in-flight request).
    const shippingAddressFetcher = useFetcher<UpdateShippingAddressResponse>();
    const shippingMethodFetcher = useFetcher<UpdateShippingMethodResponse>();
    const cleanupFetcher = useFetcher<CleanupBasketResponse>();

    const awaitShippingAddress = useFetcherPromise(shippingAddressFetcher, 'update-shipping-address failed');
    const awaitShippingMethod = useFetcherPromise(shippingMethodFetcher, 'update-shipping-method failed');
    const awaitCleanup = useFetcherPromise(cleanupFetcher, 'cleanup-basket failed');

    // SDK callbacks are bound once per `paymentConfig` change. `prepareBasketRef`
    // is the exception: on PDP, switching variants changes `prepareBasket` but
    // not `paymentConfig`, so the SDK isn't re-bound — the ref captures the
    // latest function for the click handler.
    const expressComponentRef = useRef<ExpressComponent | null>(null);
    const expressBasket = useRef<Basket | null>(null);
    const orderRef = useRef<Order | null>(null);
    const prepareBasketPromise = useRef<Promise<Basket> | null>(null);
    const paymentMethodTypeRef = useRef<PaymentMethodType>('card');
    const isPaymentInProgress = useRef(false);

    const prepareBasketRef = useRef(prepareBasket);
    useEffect(() => {
        prepareBasketRef.current = prepareBasket;
    }, [prepareBasket]);

    // Awaits in-flight basket prep, or kicks one off if the gateway didn't
    // prepare in onClick. Either way the basket is ready when this resolves.
    const waitForBasketPreparation = async () => {
        if (expressBasket.current) return;
        if (!prepareBasketPromise.current) {
            prepareBasketPromise.current = prepareBasketRef.current();
        }
        expressBasket.current = await prepareBasketPromise.current;
        prepareBasketPromise.current = null;
    };

    // --- SDK action callbacks ---

    /**
     * paymentConfig is guaranteed non-null inside SDK callbacks: the component
     * gates SDK initialization on it, so callbacks cannot fire before it resolves.
     */
    const requireConfig = (): PaymentConfig => {
        if (!paymentConfig) {
            throw new Error('paymentConfig is not resolved');
        }
        return paymentConfig;
    };

    const onClick = (type: string) => {
        isPaymentInProgress.current = true;
        failOrderCalledRef.current = false;
        paymentMethodTypeRef.current = type as PaymentMethodType;

        const strategy = selectStrategy(type, requireConfig());
        if (strategy.prepareBasketOnClick) {
            const promise = prepareBasketRef.current();
            prepareBasketPromise.current = promise;
            promise
                .then((basket) => {
                    expressBasket.current = basket;
                })
                .catch(() => {
                    prepareBasketPromise.current = null;
                    addToast(t('error.prepare_basket'), 'error');
                });
        }
        return Promise.resolve({
            amount: initialAmount.toString(),
            shippingRates: [] as unknown[],
        });
    };

    const onShippingAddressChange = async (shippingAddress: unknown, callback: ShippingChangeCallback) => {
        try {
            await waitForBasketPreparation();
            const basketId = expressBasket.current?.basketId;
            if (!basketId) {
                throw new Error('Basket not ready');
            }

            const scapiAddress = transformExpressShippingAddressPartial(
                shippingAddress as ExpressShippingAddressPartial
            );
            const form = new FormData();
            form.set('basketId', basketId);
            form.set('shippingAddress', JSON.stringify(scapiAddress));
            form.set('labels', JSON.stringify(EXPRESS_LABELS));
            if (paymentConfig) {
                form.set('paymentMethodType', paymentMethodTypeRef.current);
                form.set('paymentConfig', JSON.stringify(paymentConfig));
            }
            void shippingAddressFetcher.submit(form, {
                method: 'POST',
                action: '/action/sf-payments-update-shipping-address',
            });
            const result = assertSuccess(await awaitShippingAddress(), 'update-shipping-address failed');
            expressBasket.current = result.basket;
            callback.updateShippingAddress(result.callbackData);
        } catch {
            callback.updateShippingAddress({ errors: ['shipping_address_unavailable'] });
        }
    };

    const onShippingMethodChange = async (shippingMethod: unknown, callback: ShippingChangeCallback) => {
        try {
            await waitForBasketPreparation();
            const basketId = expressBasket.current?.basketId;
            if (!basketId) {
                throw new Error('Basket not ready');
            }
            const methodId = (shippingMethod as { id?: string } | null)?.id;
            if (!methodId) {
                throw new Error('shippingMethod.id is required');
            }

            const form = new FormData();
            form.set('basketId', basketId);
            form.set('methodId', methodId);
            form.set('labels', JSON.stringify(EXPRESS_LABELS));
            if (paymentConfig) {
                form.set('paymentMethodType', paymentMethodTypeRef.current);
                form.set('paymentConfig', JSON.stringify(paymentConfig));
            }
            void shippingMethodFetcher.submit(form, {
                method: 'POST',
                action: '/action/sf-payments-update-shipping-method',
            });
            const result = assertSuccess(await awaitShippingMethod(), 'update-shipping-method failed');
            expressBasket.current = result.basket;
            callback.updateShippingMethod(result.callbackData);
        } catch {
            callback.updateShippingMethod({ errors: ['shipping_method_unavailable'] });
        }
    };

    const createIntent = async (paymentData?: Record<string, unknown>): Promise<SdkIntentPayload> => {
        await waitForBasketPreparation();
        if (!expressBasket.current) {
            throw new Error('Basket not ready');
        }

        const config = requireConfig();
        const strategy = selectStrategy(paymentMethodTypeRef.current, config);
        // If pre-strategy work gets added here in the future and the shopper is
        // already waiting on it, paint the overlay before that work instead of
        // relying on onProcessingStarted from inside the strategy.
        try {
            const { sdkResult, order } = await strategy.createIntent({
                basket: expressBasket.current,
                paymentMethodType: paymentMethodTypeRef.current,
                paymentConfig: config,
                baseUrl: window.location.origin,
                paymentData,
                onProcessingStarted: startExpressProcessing,
                skipPostOrderRevalidation: props.skipPostOrderRevalidation,
            });

            if (order) {
                orderRef.current = order;
                // Update returnUrl with order-specific details used by redirect-capable
                // methods. The SDK reads config.options.returnUrl during confirmation, so
                // mutating sdkExpressOptionsRef.current here arrives in time.
                const orderNo = order.orderNo;
                const zoneId = config.zoneId ?? undefined;
                if (sdkExpressOptionsRef.current && orderNo) {
                    sdkExpressOptionsRef.current.returnUrl = buildPaymentProcessingUrl({
                        origin: window.location.origin,
                        orderNo,
                        zoneId,
                        type: paymentMethodTypeRef.current,
                    });
                }
            }

            return sdkResult;
        } catch (error) {
            // Defensive clear if the SDK fails to fire sfp:paymenterror after rejection.
            endExpressProcessing();
            throw error;
        }
    };

    const onPayerApprove = async (billingDetails: unknown, shippingDetails: unknown) => {
        await waitForBasketPreparation();
        if (!expressBasket.current) {
            throw new Error('Basket not ready');
        }

        const config = requireConfig();
        const strategy = selectStrategy(paymentMethodTypeRef.current, config);
        if (!strategy.onPayerApprove) {
            // Adyen omits onPayerApprove by design — addresses arrive via createIntent.
            return;
        }
        // If pre-strategy work gets added here in the future and the shopper is
        // already waiting on it, paint the overlay before that work instead of
        // relying on onProcessingStarted from inside the strategy.
        try {
            const updatedBasket = await strategy.onPayerApprove({
                basket: expressBasket.current,
                paymentMethodType: paymentMethodTypeRef.current,
                paymentConfig: config,
                shippingAddress: shippingDetails as Record<string, unknown> | undefined,
                billingAddress: billingDetails as Record<string, unknown> | undefined,
                onProcessingStarted: startExpressProcessing,
            });
            expressBasket.current = updatedBasket;
        } catch (error) {
            // Defensive clear if the SDK fails to fire sfp:paymenterror after rejection.
            endExpressProcessing();
            throw error;
        }
    };

    // --- DOM event handlers ---

    const runCleanup = (orderWasCreated: boolean) => {
        const basket = expressBasket.current;
        if (!basket) {
            return;
        }
        const form = new FormData();
        form.set('basket', JSON.stringify(basket));
        form.set('orderWasCreated', orderWasCreated ? 'true' : 'false');
        void cleanupFetcher.submit(form, {
            method: 'POST',
            action: '/action/sf-payments-cleanup-basket',
        });
        void awaitCleanup().catch(() => {
            /* best-effort — no recovery needed */
        });
    };

    const onCancel: EventListener = () => {
        isPaymentInProgress.current = false;
        endExpressProcessing();
        // Cleanup deletes the basket — only safe on PDP where the basket is temporary.
        // On cart/checkout the main basket must survive a cancel.
        if (props.usage === EXPRESS_BUY_NOW) {
            runCleanup(Boolean(orderRef.current));
        }
        expressBasket.current = null;
        orderRef.current = null;
        prepareBasketPromise.current = null;
        // Informational notice (not an error): the shopper deliberately closed the
        // wallet without paying. Reassures that nothing was charged.
        addToast(t('expressButtons.cancelNotice'), 'info');
    };

    const onPaymentError: EventListener = () => {
        isPaymentInProgress.current = false;
        const orderNo = orderRef.current?.orderNo;
        // Cleanup deletes the basket — only safe on PDP where the basket is temporary.
        if (props.usage === EXPRESS_BUY_NOW) {
            runCleanup(Boolean(orderRef.current));
        }
        expressBasket.current = null;
        orderRef.current = null;
        prepareBasketPromise.current = null;
        // Idempotent re-entry: createIntent / onPayerApprove also call endExpressProcessing
        // in their catch blocks, which then triggers sfp:paymenterror. Skip the recovery
        // work the second time through.
        if (failOrderCalledRef.current) {
            endExpressProcessing();
            return;
        }
        failOrderCalledRef.current = true;
        if (!orderNo) {
            // SDK error before order creation — nothing to fail, show generic payment error.
            endExpressProcessing();
            addToast(t('error.process_payment'), 'error', { duration: EXPRESS_TOAST_DURATION_MS });
            if (props.usage !== EXPRESS_BUY_NOW) {
                void navigate('/cart');
            }
            return;
        }
        // Keep overlay up while we fail the order + recover the basket so the
        // shopper still has a "something is happening" signal during the few
        // seconds of recovery work. .finally() guarantees the flag clears even
        // if failAndRecover rejects.
        void failAndRecover(orderNo, 'express')
            .then(({ basketRecovered }) => {
                addToast(t(basketRecovered ? 'error.fail_order' : 'error.order_recovery_failed'), 'error', {
                    duration: EXPRESS_TOAST_DURATION_MS,
                });
                if (props.usage !== EXPRESS_BUY_NOW) {
                    void navigate('/cart');
                }
            })
            .finally(() => {
                endExpressProcessing();
            });
    };

    const onPaymentApprove: EventListener = () => {
        // When a strategy defines onApprove, it's responsible for creating the
        // commerce order here (after wallet approval). Otherwise the order
        // already exists on orderRef.current from createIntent and we just
        // navigate.
        void (async () => {
            try {
                if (!orderRef.current && expressBasket.current) {
                    const config = requireConfig();
                    const strategy = selectStrategy(paymentMethodTypeRef.current, config);
                    if (strategy.onApprove) {
                        const result = await strategy.onApprove({
                            basket: expressBasket.current,
                            paymentMethodType: paymentMethodTypeRef.current,
                            paymentConfig: config,
                            baseUrl: window.location.origin,
                            skipPostOrderRevalidation: props.skipPostOrderRevalidation,
                        });
                        const order = (result as { order?: Order })?.order;
                        if (order) orderRef.current = order;
                    }
                }
                const orderNo = orderRef.current?.orderNo;
                isPaymentInProgress.current = false;
                onExpressPaymentCompleted?.();
                expressBasket.current = null;
                orderRef.current = null;
                prepareBasketPromise.current = null;
                // Defensive guard: stay on current page rather than navigate to /undefined.
                if (!orderNo) {
                    endExpressProcessing();
                    return;
                }
                void navigate(`/order-confirmation/${orderNo}`);
            } catch {
                isPaymentInProgress.current = false;
                endExpressProcessing();
            }
        })();
    };

    const onPaymentMethodsRendered = (e: PaymentMethodsRenderedEvent) => {
        // Only call onPaymentMethodsRendered when one or more buttons are rendered.
        if (!onPaymentMethodsRenderedProp || !e.detail?.rendered?.length) return;
        onPaymentMethodsRenderedProp();
    };

    return {
        callbacks: {
            onClick,
            onShippingAddressChange,
            onShippingMethodChange,
            createIntent,
            onPayerApprove,
        },
        eventHandlers: {
            onCancel,
            onPaymentError,
            onPaymentApprove,
            onPaymentMethodsRendered,
        },
        isPaymentInProgress,
        expressComponentRef,
    };
}
