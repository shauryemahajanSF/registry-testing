/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

import type { LoaderFunctionArgs } from 'react-router'
import { createApiClients } from '@/lib/api-clients.server'
import { getConfig } from '@salesforce/storefront-next-runtime/config'
import { siteContext } from '@salesforce/storefront-next-runtime/site-context'
import type { AppConfig } from '@/types/config'

/**
 * Server-side resource route that fetches site-wide configurations
 * from the Shopper Configurations SCAPI.
 *
 * Returns the full configuration map as-is — no server-side filtering.
 * Consumers (hooks/components) pick the keys they need.
 *
 * Known payment-related keys:
 * - SalesforcePaymentsAllowed (boolean)
 * - cardCaptureAutomatic (boolean)
 * - futureUsageOffSession (boolean)
 *
 * GET /resource/sf-payments-shopper-config
 */
export async function loader({ context }: LoaderFunctionArgs) {
    try {
        const clients = createApiClients(context)
        const config = getConfig<AppConfig>(context)
        const siteCtx = context.get(siteContext)
        if (!siteCtx) {
            return Response.json({ error: 'Site context is not available' }, { status: 500 })
        }

        const { data } = await clients.shopperConfigurations.getConfigurations({
            params: {
                path: { organizationId: config.commerce.api.organizationId },
                query: { siteId: siteCtx.site.id }
            }
        })

        const configurations = data?.configurations ?? []

        const configMap: Record<string, unknown> = {}
        for (const config of configurations) {
            configMap[config.id] = config.value
        }

        return Response.json(configMap)
    } catch (error) {
        console.error('Failed to fetch shopper configurations:', error)

        return Response.json(
            {
                error: 'Failed to fetch configurations',
                details: error instanceof Error ? error.message : 'Unknown error'
            },
            { status: 500 }
        )
    }
}
