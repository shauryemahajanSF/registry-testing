/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

'use client';

import { useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useSite } from '@salesforce/storefront-next-runtime/site-context';
import { useBasket } from '@/providers/basket';
import { useNavigate } from '@/hooks/use-navigate';
import { useSFPaymentsContext } from '../../providers/sf-payments-provider';
import { useSFPaymentsConfig, type PaymentMethodSetAccount } from '../../hooks/use-sf-payments-config';
import { useShopperConfigField } from '../../hooks/use-sf-payments-shopper-config';
import { getLocaleDerivedCountryCode } from '../../lib/sf-payments-country';
import { getGatewayFromPaymentMethod, type PaymentGateway, type PaymentMethodType } from '../../lib/sf-payments-utils';
import { buildTheme } from '../../lib/sf-payments-theme';
import { usePaymentMethodsCallbacks, type SFPCheckoutComponent } from './use-payment-methods-callbacks';

/**
 * PaymentMethods — mounts the SF Payments SDK checkout surface on the Payment step.
 *
 * Registered at the `sfcc.checkout.payment.paymentMethods` UITarget, replacing the
 * OOTB CreditCardInputFields when the CAP is installed.
 *
 * This component handles the full payment flow: SDK initialization, order creation via
 * createIntent callback, and payment confirmation via confirmPayment.
 *
 * The component lives inside <ToggleCardEdit> in payment.tsx, which unmounts its
 * children when editing is false — no step-state check is needed here; mounting
 * is the gate.
 */
export default function PaymentMethods() {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { t } = useTranslation('extSfPayments' as any);
    const { enabled, sfp, metadata, metadataLoading } = useSFPaymentsContext();
    const basket = useBasket();
    const { locale } = useSite();
    const navigate = useNavigate();
    const [confirmError, setConfirmError] = useState<string | null>(null);
    const [isSubmitting, setIsSubmitting] = useState(false);

    const currency = basket?.currency ?? '';
    const countryCode = getLocaleDerivedCountryCode(locale.id);

    const {
        config: paymentConfig,
        loading: paymentConfigLoading,
        error: paymentConfigError,
    } = useSFPaymentsConfig({ currency, countryCode });

    const { value: cardCaptureAutomaticRaw, loading: shopperConfigLoading } =
        useShopperConfigField<boolean>('cardCaptureAutomatic');
    const cardCaptureAutomatic = cardCaptureAutomaticRaw ?? false;

    const containerRef = useRef<HTMLDivElement>(null);
    const checkoutComponent = useRef<SFPCheckoutComponent | null>(null);

    const paymentMethodType = useRef<PaymentMethodType | ''>('');

    const gateway = useRef<PaymentGateway | null>(null);

    const { createIntent, confirmPayment } = usePaymentMethodsCallbacks({
        basket,
        paymentConfig,
        checkoutComponentRef: checkoutComponent,
        paymentMethodTypeRef: paymentMethodType,
    });

    // ToggleCardEdit unmounts this component when editing is false, so no step-state guard is needed.
    useEffect(() => {
        if (!sfp || !metadata || !paymentConfig || shopperConfigLoading || !containerRef.current) return;
        if (checkoutComponent.current) return;

        // sfp.checkout(metadata, paymentMethodSet, config, paymentRequest, element)
        const paymentMethodSet = {
            paymentMethods: paymentConfig.paymentMethods,
            // SDK requires gatewayId on each account — map from accountId (SCAPI field name)
            paymentMethodSetAccounts: (paymentConfig.paymentMethodSetAccounts ?? []).map(
                (account: PaymentMethodSetAccount) => ({ ...account, gatewayId: account.accountId })
            ),
        };
        const config = {
            theme: buildTheme(),
            actions: {
                createIntent,
            },
            options: {
                savedPaymentMethods: [],
                useManualCapture: !cardCaptureAutomatic,
                returnUrl: `${window.location.origin}/checkout/payment-processing`,
            },
        };
        const paymentRequest = {
            amount: basket?.orderTotal,
            currency,
            country: countryCode,
            locale: locale.id,
        };
        // Create a fresh inner element — the SDK renders into it directly
        const paymentElement = document.createElement('div');
        containerRef.current.replaceChildren(paymentElement);
        checkoutComponent.current = sfp.checkout(metadata, paymentMethodSet, config, paymentRequest, paymentElement);

        const el = containerRef.current;
        const onMethodSelected = (e: Event) => {
            const detail = (e as CustomEvent).detail;
            const methodType = detail?.selectedPaymentMethod || detail?.paymentMethodType;
            if (methodType) {
                paymentMethodType.current = methodType;
                gateway.current = getGatewayFromPaymentMethod(
                    methodType,
                    paymentConfig.paymentMethods,
                    paymentConfig.paymentMethodSetAccounts
                );
            }
        };
        el.addEventListener('sfp:paymentmethodselected', onMethodSelected);

        return () => {
            el.removeEventListener('sfp:paymentmethodselected', onMethodSelected);
            checkoutComponent.current?.destroy();
            checkoutComponent.current = null;
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps -- sfp/metadata/paymentConfig/shopperConfig are the mount triggers; basket/currency/locale snapshot at mount time is correct for the checkout surface
    }, [sfp, metadata, paymentConfig, shopperConfigLoading, cardCaptureAutomatic]);

    useEffect(() => {
        if (checkoutComponent.current && basket?.orderTotal != null) {
            checkoutComponent.current.updateAmount(basket.orderTotal);
        }
    }, [basket?.orderTotal]);

    const handlePlaceOrder = async () => {
        setConfirmError(null);
        setIsSubmitting(true);
        try {
            const result = await confirmPayment();
            if (result.success && result.orderNo) {
                void navigate(`/order-confirmation/${result.orderNo}`);
                return;
            }
            setConfirmError(result.error || t('paymentMethods.errorConfirmationFailed'));
        } catch (error) {
            const message = error instanceof Error ? error.message : t('paymentMethods.errorConfirmationFailed');
            setConfirmError(message);
        } finally {
            setIsSubmitting(false);
        }
    };

    if (!basket?.currency) {
        return null;
    }

    if (!enabled && !metadataLoading) {
        return null;
    }

    if (metadataLoading || paymentConfigLoading) {
        return <div className="py-4 text-center text-sm text-muted-foreground">{t('paymentMethods.loading')}</div>;
    }

    if (paymentConfigError) {
        return (
            <div className="p-3 rounded-lg bg-destructive/10 text-destructive text-sm text-center">
                {paymentConfigError}
            </div>
        );
    }

    return (
        <div data-testid="sf-payments-checkout">
            <div ref={containerRef} />
            {/* Temporary button for isolated testing — will be removed once checkout
                team ships the generic payment submission hook contract. */}
            <div className="mt-4 space-y-2">
                {confirmError && (
                    <div className="p-2 rounded bg-destructive/10 text-destructive text-sm text-center">
                        {confirmError}
                    </div>
                )}
                <button
                    type="button"
                    onClick={() => void handlePlaceOrder()}
                    disabled={isSubmitting || !checkoutComponent.current}
                    className="w-full rounded bg-primary px-4 py-2 text-primary-foreground disabled:opacity-50"
                    data-testid="sf-payments-place-order">
                    {isSubmitting ? t('paymentMethods.processing') : t('paymentMethods.placeOrder')}
                </button>
            </div>
        </div>
    );
}
