/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import type { ReactNode } from 'react';
import { describe, test, expect } from 'vitest';
import { renderHook } from '@testing-library/react';
import { createMemoryRouter, RouterProvider } from 'react-router';
import { useSelectGatewayStrategy } from './use-select-gateway-strategy';
import { useStripeStrategy } from './use-stripe-strategy';
import { useAdyenStrategy } from './use-adyen-strategy';
import { usePaypalStrategy } from './use-paypal-strategy';
import type { PaymentConfig } from '../../lib/api/types';

/**
 * Strategy hooks call `useFetcher`, which needs a data router context. Wrap
 * `renderHook` with a minimal in-memory router so the hooks mount cleanly.
 */
function renderStrategyHook<T>(hook: () => T) {
    return renderHook(hook, {
        wrapper: ({ children }: { children: ReactNode }) => {
            const router = createMemoryRouter([{ path: '/', element: children }], { initialEntries: ['/'] });
            return <RouterProvider router={router} />;
        },
    });
}

const paymentConfig: PaymentConfig = {
    zoneId: 'z1',
    paymentMethods: [
        { paymentMethodType: 'card', accountId: 'acct_scheme' },
        { paymentMethodType: 'applepay', accountId: 'acct_scheme' },
        { paymentMethodType: 'googlepay', accountId: 'acct_scheme' },
        { paymentMethodType: 'paypal', accountId: 'acct_paypal' },
    ],
    paymentMethodSetAccounts: [
        { accountId: 'acct_scheme', vendor: 'Stripe' },
        { accountId: 'acct_paypal', vendor: 'PayPal' },
    ],
};

describe('useSelectGatewayStrategy', () => {
    test('returns the Stripe strategy shape when scheme account is a Stripe vendor', () => {
        const { result } = renderStrategyHook(() => useSelectGatewayStrategy());
        const selected = result.current('card', paymentConfig);
        expect(selected?.prepareBasketOnClick).toBe(true);
        expect(selected).toHaveProperty('onPayerApprove');
        expect('onApprove' in (selected ?? {})).toBe(false);
    });

    test('returns the Adyen strategy shape when scheme account is an Adyen vendor', () => {
        const adyenConfig: PaymentConfig = {
            ...paymentConfig,
            paymentMethodSetAccounts: [
                { accountId: 'acct_scheme', vendor: 'Adyen' },
                { accountId: 'acct_paypal', vendor: 'PayPal' },
            ],
        };
        const { result } = renderStrategyHook(() => useSelectGatewayStrategy());
        const selected = result.current('card', adyenConfig);
        expect(selected?.prepareBasketOnClick).toBe(true);
        expect('onPayerApprove' in (selected ?? {})).toBe(false);
        expect('onApprove' in (selected ?? {})).toBe(false);
    });

    test('returns the PayPal strategy shape for the paypal payment method', () => {
        const { result } = renderStrategyHook(() => useSelectGatewayStrategy());
        const selected = result.current('paypal', paymentConfig);
        expect(selected?.prepareBasketOnClick).toBe(false);
        expect(selected).toHaveProperty('onApprove');
    });

    test('throws when paymentMethodType has no matching method', () => {
        const { result } = renderStrategyHook(() => useSelectGatewayStrategy());
        expect(() => result.current('unknown', paymentConfig)).toThrow(/No gateway strategy/);
    });

    test('throws when vendor is not one of Stripe/Adyen/PayPal', () => {
        const unknownVendor: PaymentConfig = {
            ...paymentConfig,
            paymentMethodSetAccounts: [
                { accountId: 'acct_scheme', vendor: 'MysteryVendor' },
                { accountId: 'acct_paypal', vendor: 'PayPal' },
            ],
        };
        const { result } = renderStrategyHook(() => useSelectGatewayStrategy());
        expect(() => result.current('card', unknownVendor)).toThrow(/No gateway strategy/);
    });

    test('throws when paymentMethodSetAccounts is missing', () => {
        const { result } = renderStrategyHook(() => useSelectGatewayStrategy());
        expect(() => result.current('card', { zoneId: 'z1', paymentMethods: paymentConfig.paymentMethods })).toThrow(
            /No gateway strategy/
        );
    });

    test('throws when paymentMethods is missing', () => {
        const { result } = renderStrategyHook(() => useSelectGatewayStrategy());
        expect(() =>
            result.current('card', {
                zoneId: 'z1',
                paymentMethodSetAccounts: paymentConfig.paymentMethodSetAccounts,
            })
        ).toThrow(/No gateway strategy/);
    });

    test('vendor match is case-insensitive', () => {
        const mixedCase: PaymentConfig = {
            ...paymentConfig,
            paymentMethodSetAccounts: [
                { accountId: 'acct_scheme', vendor: 'STRIPE' },
                { accountId: 'acct_paypal', vendor: 'paypal' },
            ],
        };
        const { result } = renderStrategyHook(() => useSelectGatewayStrategy());
        expect(result.current('card', mixedCase)?.prepareBasketOnClick).toBe(true);
        expect(result.current('paypal', mixedCase)?.prepareBasketOnClick).toBe(false);
    });
});

describe('per-gateway strategy hook shapes', () => {
    test('useStripeStrategy: prepareBasketOnClick=true, has onPayerApprove+createIntent, no onApprove', () => {
        const { result } = renderStrategyHook(() => useStripeStrategy());
        expect(result.current.prepareBasketOnClick).toBe(true);
        expect(result.current).toHaveProperty('onPayerApprove', expect.any(Function));
        expect(result.current).toHaveProperty('createIntent', expect.any(Function));
        expect('onApprove' in result.current).toBe(false);
    });

    test('useAdyenStrategy: prepareBasketOnClick=true, only createIntent (addresses arrive via paymentData)', () => {
        const { result } = renderStrategyHook(() => useAdyenStrategy());
        expect(result.current.prepareBasketOnClick).toBe(true);
        expect(result.current).toHaveProperty('createIntent', expect.any(Function));
        expect('onPayerApprove' in result.current).toBe(false);
        expect('onApprove' in result.current).toBe(false);
    });

    test('usePaypalStrategy: prepareBasketOnClick=false, has onPayerApprove+createIntent+onApprove', () => {
        const { result } = renderStrategyHook(() => usePaypalStrategy());
        expect(result.current.prepareBasketOnClick).toBe(false);
        expect(result.current).toHaveProperty('onPayerApprove', expect.any(Function));
        expect(result.current).toHaveProperty('createIntent', expect.any(Function));
        expect(result.current).toHaveProperty('onApprove', expect.any(Function));
    });
});
