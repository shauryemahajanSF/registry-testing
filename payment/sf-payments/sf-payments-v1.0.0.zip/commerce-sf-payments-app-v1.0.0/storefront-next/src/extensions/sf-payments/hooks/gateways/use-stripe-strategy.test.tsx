/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { describe, test, expect, vi, beforeEach } from 'vitest';
import { renderHook } from '@testing-library/react';
import { useStripeStrategy } from './use-stripe-strategy';
import type { PaymentConfig } from '../../lib/api/types';

const submitSpies = {
    push: vi.fn(),
    ensure: vi.fn(),
    create: vi.fn(),
};

const promiseResolvers = {
    push: vi.fn(),
    ensure: vi.fn(),
    create: vi.fn(),
};

vi.mock('react-router', () => ({
    useFetcher: vi.fn(),
}));

vi.mock('../use-fetcher-promise', () => ({
    useFetcherPromise: vi.fn(),
}));

import { useFetcher } from 'react-router';
import { useFetcherPromise } from '../use-fetcher-promise';

const paymentConfig: PaymentConfig = {
    zoneId: 'z1',
    paymentMethods: [
        { paymentMethodType: 'card', accountId: 'acct_stripe' },
        { paymentMethodType: 'applepay', accountId: 'acct_stripe' },
    ],
    paymentMethodSetAccounts: [{ accountId: 'acct_stripe', vendor: 'Stripe' }],
};

const baseBasket = {
    basketId: 'b1',
    paymentInstruments: [
        {
            paymentMethodId: 'Salesforce Payments',
            paymentInstrumentId: 'opi-1',
            paymentReference: { paymentReferenceId: 'pref-1' },
        },
    ],
};

const baseOrder = {
    orderNo: 'o-1',
    paymentInstruments: [
        {
            paymentMethodId: 'Salesforce Payments',
            paymentInstrumentId: 'opi-1',
            paymentReference: {
                paymentReferenceId: 'pref-1',
                gatewayProperties: {
                    stripe: { clientSecret: 'cs_test_123' },
                },
            },
        },
    ],
};

beforeEach(() => {
    submitSpies.push.mockReset();
    submitSpies.ensure.mockReset();
    submitSpies.create.mockReset();
    promiseResolvers.push.mockReset();
    promiseResolvers.ensure.mockReset();
    promiseResolvers.create.mockReset();

    // Stripe creates fetchers in order: ensure, push, create. Match that here
    // so each spy lines up with the right action route.
    const fetchers = [
        { submit: submitSpies.ensure, state: 'idle', data: undefined },
        { submit: submitSpies.push, state: 'idle', data: undefined },
        { submit: submitSpies.create, state: 'idle', data: undefined },
    ];
    let fetcherIdx = 0;
    vi.mocked(useFetcher).mockImplementation(() => fetchers[fetcherIdx++] as unknown as ReturnType<typeof useFetcher>);

    const resolvers = [promiseResolvers.ensure, promiseResolvers.push, promiseResolvers.create];
    let resolverIdx = 0;
    vi.mocked(useFetcherPromise).mockImplementation(
        () => resolvers[resolverIdx++] as unknown as ReturnType<typeof useFetcherPromise>
    );
});

describe('useStripeStrategy', () => {
    test('returned shape: prepareBasketOnClick=true, has onPayerApprove + createIntent, no onApprove', () => {
        const { result } = renderHook(() => useStripeStrategy());

        expect(result.current.prepareBasketOnClick).toBe(true);
        expect(result.current).toHaveProperty('onPayerApprove', expect.any(Function));
        expect(result.current).toHaveProperty('createIntent', expect.any(Function));
        expect('onApprove' in result.current).toBe(false);
    });

    test('onPayerApprove: pushes addresses then ensures PI, returns the ensured basket', async () => {
        promiseResolvers.push.mockResolvedValue({ success: true, basket: baseBasket });
        promiseResolvers.ensure.mockResolvedValue({ success: true, basket: baseBasket });

        const { result } = renderHook(() => useStripeStrategy());
        if (!result.current.onPayerApprove) throw new Error('Stripe strategy is missing onPayerApprove');
        const updatedBasket = await result.current.onPayerApprove({
            basket: baseBasket,
            paymentMethodType: 'applepay',
            paymentConfig,
            shippingAddress: {
                name: 'Jane Doe',
                address: { line1: '1 Main', city: 'NYC', postalCode: '10001', country: 'US' },
            },
            billingAddress: {
                name: 'Jane Doe',
                address: { line1: '1 Main', city: 'NYC', postalCode: '10001', country: 'US' },
            },
        });

        // push-addresses called first with the basketId
        expect(submitSpies.push).toHaveBeenCalledWith(
            expect.any(FormData),
            expect.objectContaining({
                method: 'POST',
                action: '/action/sf-payments-push-addresses',
            })
        );

        // ensure-pi called next; Stripe maps 'applepay' → 'card' on the PI request.
        expect(submitSpies.ensure).toHaveBeenCalledWith(
            expect.any(FormData),
            expect.objectContaining({
                method: 'POST',
                action: '/action/sf-payments-ensure-pi',
            })
        );
        const ensureForm = submitSpies.ensure.mock.calls[0][0] as FormData;
        expect(ensureForm.get('paymentMethodType')).toBe('card');
        expect(ensureForm.get('paymentData')).toBeNull();

        expect(updatedBasket).toBe(baseBasket);
    });

    test('createIntent: submits create-order and returns { client_secret, id, order }', async () => {
        promiseResolvers.ensure.mockResolvedValue({ success: true, basket: baseBasket });
        promiseResolvers.create.mockResolvedValue({ success: true, order: baseOrder });

        const { result } = renderHook(() => useStripeStrategy());
        const intent = await result.current.createIntent({
            basket: baseBasket,
            paymentMethodType: 'applepay',
            paymentConfig,
            baseUrl: 'https://example.com',
        });

        expect(submitSpies.create).toHaveBeenCalledWith(
            expect.any(FormData),
            expect.objectContaining({
                method: 'POST',
                action: '/action/sf-payments-create-order',
            })
        );

        // Stripe maps applepay → card on the create-order request.
        const createForm = submitSpies.create.mock.calls[0][0] as FormData;
        expect(createForm.get('paymentMethodType')).toBe('card');
        expect(createForm.get('basketId')).toBe('b1');
        expect(createForm.get('origin')).toBe('https://example.com');
        expect(createForm.get('paymentData')).toBeNull();
        expect(createForm.get('storePaymentMethod')).toBeNull();
        expect(createForm.get('futureUsageOffSession')).toBeNull();

        expect(intent).toEqual({
            sdkResult: {
                client_secret: 'cs_test_123',
                id: 'pref-1',
            },
            order: baseOrder,
        });
    });

    test('createIntent forwards SPM flags when provided', async () => {
        promiseResolvers.ensure.mockResolvedValue({ success: true, basket: baseBasket });
        promiseResolvers.create.mockResolvedValue({ success: true, order: baseOrder });

        const { result } = renderHook(() => useStripeStrategy());
        await result.current.createIntent({
            basket: baseBasket,
            paymentMethodType: 'card',
            paymentConfig,
            baseUrl: 'https://example.com',
            storePaymentMethod: true,
            futureUsageOffSession: true,
        });

        const createForm = submitSpies.create.mock.calls[0][0] as FormData;
        expect(createForm.get('storePaymentMethod')).toBe('true');
        expect(createForm.get('futureUsageOffSession')).toBe('true');
    });

    test('onPayerApprove throws when push-addresses returns success: false', async () => {
        promiseResolvers.push.mockResolvedValue({ success: false, error: 'address invalid' });

        const { result } = renderHook(() => useStripeStrategy());
        if (!result.current.onPayerApprove) throw new Error('Stripe strategy is missing onPayerApprove');
        await expect(
            result.current.onPayerApprove({
                basket: baseBasket,
                paymentMethodType: 'card',
                paymentConfig,
                shippingAddress: { name: 'X', address: { line1: '1', city: 'NYC', postalCode: '0', country: 'US' } },
            })
        ).rejects.toThrow('address invalid');
    });

    test('createIntent with skipPostOrderRevalidation: posts via plain fetch, skips createOrder fetcher', async () => {
        promiseResolvers.ensure.mockResolvedValue({ success: true, basket: baseBasket });
        const fetchSpy = vi.spyOn(global, 'fetch').mockResolvedValue({
            ok: true,
            json: () => Promise.resolve({ success: true, order: baseOrder }),
        } as Response);

        try {
            const { result } = renderHook(() => useStripeStrategy());
            await result.current.createIntent({
                basket: baseBasket,
                paymentMethodType: 'card',
                paymentConfig,
                baseUrl: 'https://example.com',
                skipPostOrderRevalidation: true,
            });

            expect(fetchSpy).toHaveBeenCalledWith(
                '/action/sf-payments-create-order',
                expect.objectContaining({ method: 'POST', body: expect.any(FormData) })
            );
            expect(submitSpies.create).not.toHaveBeenCalled();
        } finally {
            fetchSpy.mockRestore();
        }
    });

    test('createIntent throws when the order is missing a paymentReferenceId', async () => {
        const orderWithoutRef = {
            orderNo: 'o-1',
            paymentInstruments: [
                {
                    paymentMethodId: 'Salesforce Payments',
                    paymentInstrumentId: 'opi-1',
                    paymentReference: {},
                },
            ],
        };
        promiseResolvers.ensure.mockResolvedValue({ success: true, basket: baseBasket });
        promiseResolvers.create.mockResolvedValue({ success: true, order: orderWithoutRef });

        const { result } = renderHook(() => useStripeStrategy());
        await expect(
            result.current.createIntent({
                basket: baseBasket,
                paymentMethodType: 'card',
                paymentConfig,
                baseUrl: 'https://example.com',
            })
        ).rejects.toThrow(/paymentReferenceId/);
    });
});
