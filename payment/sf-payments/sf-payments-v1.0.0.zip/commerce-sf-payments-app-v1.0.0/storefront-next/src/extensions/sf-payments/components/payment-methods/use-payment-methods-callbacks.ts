/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

'use client';

import { useCallback, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import type { ShopperBasketsV2, ShopperOrders } from '@/scapi';
import { useSelectGatewayStrategy } from '../../hooks/gateways/use-select-gateway-strategy';
import { useSFPaymentsFailureRecovery } from '../../hooks/use-sf-payments-failure-recovery';
import type { PaymentConfig } from '../../lib/api/types';
import type { SdkIntentPayload } from '../../lib/gateways/types';
import { findPaymentAccount, SDK_RESPONSE_CODE, type PaymentMethodType } from '../../lib/sf-payments-utils';

/**
 * Gateway-specific payload forwarded from the SF Payments SDK to createIntent.
 *
 * - Stripe: SDK calls createIntent() with no arguments — this will be undefined.
 * - Adyen: SDK passes encrypted card data (paymentMethod), origin, returnUrl,
 *   browserInfo, billingDetails, shippingDetails.
 *
 * Intentionally opaque (Record<string, unknown>) because the SDK is the source
 * of truth for each gateway's shape, and new gateways can be added without
 * touching this type. Gateway-specific narrowing happens inside each strategy.
 */
type SdkPaymentData = Record<string, unknown>;

/**
 * Callback that appends query params to the SDK config's returnUrl.
 * The component owns the config mutation; the hook only declares what params it needs.
 */
export type UpdateReturnUrlParams = (params: Record<string, string>) => void;

export interface SFPCheckoutComponent {
    confirm: (
        data: null,
        billingDetails: Record<string, unknown>,
        shippingDetails: Record<string, unknown>
    ) => Promise<{ responseCode: number; data?: { error?: string } }>;
    updateAmount: (amount: number) => void;
    destroy: () => void;
    selectedPaymentMethod?: { paymentMethodType: PaymentMethodType };
}

type Basket = ShopperBasketsV2.schemas['Basket'];
type Order = ShopperOrders.schemas['Order'];

interface UsePaymentMethodsCallbacksOptions {
    /** Current basket from checkout */
    basket: Basket | null | undefined;
    /** Resolved payment configuration */
    paymentConfig: PaymentConfig | null | undefined;
    /** Ref to the SDK checkout component instance */
    checkoutComponentRef: React.MutableRefObject<SFPCheckoutComponent | null>;
    /** Ref to the currently selected payment method type */
    paymentMethodTypeRef: React.MutableRefObject<PaymentMethodType | ''>;
    /**
     * Whether the shopper opted in to saving the payment method. A ref so
     * createIntent stays stable when the checkbox toggles — no callback re-creation.
     */
    storePaymentMethodRef: React.MutableRefObject<boolean>;
    /** Whether the gateway should store the payment method for off-session use. Must match the SDK's futureUsageOffSession option. */
    futureUsageOffSession: boolean;
    /** Resolved site prefix (e.g. "/RefArch/en-US") for building the return URL. */
    sitePrefix: string;
    /** Appends query params to the SDK config's returnUrl without exposing the config. */
    updateReturnUrl: UpdateReturnUrlParams;
}

export interface ConfirmPaymentResult {
    success: boolean;
    orderNo?: string;
    error?: string;
    basketRecovered?: boolean;
}

interface PaymentMethodsCallbacksResult {
    createIntent: (paymentData?: SdkPaymentData) => Promise<SdkIntentPayload>;
    confirmPayment: () => Promise<ConfirmPaymentResult>;
    /**
     * Event handler for `sfp:paymentapprove`. When the active strategy defines
     * `onApprove`, it finalizes the commerce order and resolves with the
     * orderNo for the caller to navigate. Strategies without `onApprove`
     * short-circuit and rely on the existing Place Order path.
     */
    onPaymentApprove: () => Promise<{ orderNo?: string; error?: string }>;
}

/**
 * Payment methods callbacks hook for the checkout sheet flow.
 *
 * Provides createIntent and confirmPayment callbacks for the SF Payments SDK.
 * Unlike express callbacks, this hook:
 * - Uses the main basket (no temp basket creation)
 * - No address callbacks (billing/shipping already set via checkout forms)
 * - Manual confirm required (not automatic)
 *
 * Follows the 4-layer architecture: Component → Callbacks → Gateway Strategy → Action Routes.
 * This hook delegates to the shared gateway strategies rather than calling action routes directly.
 */
export function usePaymentMethodsCallbacks({
    basket,
    paymentConfig,
    checkoutComponentRef,
    paymentMethodTypeRef,
    storePaymentMethodRef,
    futureUsageOffSession,
    sitePrefix,
    updateReturnUrl,
}: UsePaymentMethodsCallbacksOptions): PaymentMethodsCallbacksResult {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { t } = useTranslation('extSfPayments' as any);
    const selectStrategy = useSelectGatewayStrategy();
    const { failAndRecover } = useSFPaymentsFailureRecovery();

    const orderRef = useRef<Order | null>(null);
    const failOrderCalledRef = useRef(false);

    /**
     * createIntent callback — called by SDK when shopper submits payment.
     * Delegates to the shared gateway strategy and forwards its SDK-shaped
     * payload to the SDK; captures the order (when present) for navigation.
     */
    const createIntent = useCallback(
        async (paymentData?: SdkPaymentData): Promise<SdkIntentPayload> => {
            if (!paymentConfig) {
                throw new Error('Payment configuration is not resolved');
            }
            if (!basket || !basket.basketId) {
                throw new Error('Basket is not available');
            }

            const selectedMethod = checkoutComponentRef.current?.selectedPaymentMethod;
            let paymentMethodType: PaymentMethodType;
            if (selectedMethod?.paymentMethodType) {
                paymentMethodType = selectedMethod.paymentMethodType;
            } else if (paymentMethodTypeRef.current) {
                paymentMethodType = paymentMethodTypeRef.current;
            } else {
                throw new Error('No payment method type selected');
            }

            const strategy = selectStrategy(paymentMethodType, paymentConfig);

            const { sdkResult, order } = await strategy.createIntent({
                basket,
                paymentMethodType,
                paymentConfig,
                baseUrl: window.location.origin + sitePrefix,
                paymentData,
                storePaymentMethod: storePaymentMethodRef.current,
                futureUsageOffSession,
                // Sheet flow: address is already on the basket from the
                // checkout form. Tell PayPal to use that address and not
                // invite the shopper to change it in the popup.
                shippingPreference: 'SET_PROVIDED_ADDRESS',
            });

            if (order) {
                orderRef.current = order;
            }

            if (order?.orderNo) {
                const params: Record<string, string> = { orderNo: order.orderNo };
                const account = findPaymentAccount(
                    paymentConfig.paymentMethods,
                    paymentConfig.paymentMethodSetAccounts,
                    paymentMethodType
                );
                if (account?.vendor) {
                    params.vendor = account.vendor;
                }
                updateReturnUrl(params);
            }

            return sdkResult;
        },
        [
            basket,
            paymentConfig,
            checkoutComponentRef,
            paymentMethodTypeRef,
            storePaymentMethodRef,
            futureUsageOffSession,
            sitePrefix,
            updateReturnUrl,
            selectStrategy,
        ]
    );

    /**
     * confirmPayment - manually called when place order button is clicked.
     * Calls SDK confirm method and returns result for navigation.
     */
    const confirmPayment = useCallback(async (): Promise<ConfirmPaymentResult> => {
        failOrderCalledRef.current = false;

        if (!checkoutComponentRef.current) {
            return { success: false, error: t('paymentMethods.errorInitializing') };
        }

        if (!basket || !basket.basketId) {
            return { success: false, error: t('paymentMethods.errorBasketUnavailable') };
        }

        const billingDetails: Record<string, unknown> = {};
        if (basket.customerInfo?.email) {
            billingDetails.email = basket.customerInfo.email;
        }
        if (basket.billingAddress) {
            const addr = basket.billingAddress;
            billingDetails.phone = addr.phone;
            billingDetails.name = addr.fullName;
            billingDetails.address = {
                line1: addr.address1,
                line2: addr.address2,
                city: addr.city,
                state: addr.stateCode,
                postalCode: addr.postalCode,
                country: addr.countryCode,
            };
        }

        const shippingDetails: Record<string, unknown> = {};
        if (basket.shipments?.[0]?.shippingAddress) {
            const addr = basket.shipments[0].shippingAddress;
            shippingDetails.name = addr.fullName;
            shippingDetails.address = {
                line1: addr.address1,
                line2: addr.address2,
                city: addr.city,
                state: addr.stateCode,
                postalCode: addr.postalCode,
                country: addr.countryCode,
            };
        }

        try {
            const result = await checkoutComponentRef.current.confirm(null, billingDetails, shippingDetails);

            if (result.responseCode !== SDK_RESPONSE_CODE.SUCCESS) {
                if (failOrderCalledRef.current) {
                    return { success: false, error: result.data?.error || t('paymentMethods.errorConfirmationFailed') };
                }
                failOrderCalledRef.current = true;
                const recovery = await failAndRecover(orderRef.current?.orderNo ?? '', 'sheet');
                return {
                    success: false,
                    error: result.data?.error || t('paymentMethods.errorConfirmationFailed'),
                    basketRecovered: recovery.basketRecovered,
                };
            }

            const orderNo = orderRef.current?.orderNo;
            if (!orderNo) {
                return { success: false, error: t('paymentMethods.errorOrderMissing') };
            }

            orderRef.current = null;
            return { success: true, orderNo };
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : t('paymentMethods.errorConfirmationFailed');
            if (failOrderCalledRef.current) {
                return { success: false, error: errorMessage };
            }
            failOrderCalledRef.current = true;
            const recovery = await failAndRecover(orderRef.current?.orderNo ?? '', 'sheet');
            return {
                success: false,
                error: errorMessage,
                basketRecovered: recovery.basketRecovered,
            };
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps -- basket is read off the closure but `confirmPayment` is invoked synchronously from Place Order; rebinding on every basket update would defeat the stable-callback design
    }, [checkoutComponentRef, failAndRecover, t]);

    /**
     * Sheet `sfp:paymentapprove` handler. When the active strategy defines
     * `onApprove`, it owns the post-approval order creation and we surface
     * the resulting orderNo. Otherwise this no-ops and the existing Place
     * Order path stays in charge of finalization.
     */
    const onPaymentApprove = useCallback(async (): Promise<{ orderNo?: string; error?: string }> => {
        // Re-entry guard: SDK can fire `sfp:paymentapprove` twice on rare
        // network/double-tap edge cases. If we already have an order, surface
        // the existing orderNo instead of creating a duplicate.
        if (orderRef.current?.orderNo) {
            return { orderNo: orderRef.current.orderNo };
        }
        if (!paymentConfig || !basket?.basketId) {
            return { error: t('paymentMethods.errorBasketUnavailable') };
        }
        const paymentMethodType =
            checkoutComponentRef.current?.selectedPaymentMethod?.paymentMethodType || paymentMethodTypeRef.current;
        if (!paymentMethodType) {
            // Should never happen — the SDK only fires sfp:paymentapprove after
            // a method was selected. Treat as a confirmation/approval failure.
            return { error: t('paymentMethods.errorConfirmationFailed') };
        }
        const strategy = selectStrategy(paymentMethodType, paymentConfig);
        if (!strategy.onApprove) {
            // Strategy doesn't define onApprove — caller handles finalization.
            return {};
        }
        try {
            const result = await strategy.onApprove({
                basket,
                paymentMethodType,
                paymentConfig,
                baseUrl: window.location.origin + sitePrefix,
            });
            const order = (result as { order?: Order })?.order;
            if (order) orderRef.current = order;
            const orderNo = order?.orderNo ?? (result as { orderNo?: string })?.orderNo;
            if (!orderNo) return { error: t('paymentMethods.errorOrderMissing') };
            return { orderNo };
        } catch (error) {
            return { error: error instanceof Error ? error.message : String(error) };
        }
    }, [basket, paymentConfig, paymentMethodTypeRef, checkoutComponentRef, selectStrategy, sitePrefix, t]);

    return {
        createIntent,
        confirmPayment,
        onPaymentApprove,
    };
}
