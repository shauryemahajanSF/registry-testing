/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

'use client';

import { useCallback, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import type { ShopperBasketsV2, ShopperOrders } from '@salesforce/storefront-next-runtime/scapi';
import { useSelectGatewayStrategy } from '../../hooks/gateways/use-select-gateway-strategy';
import type { PaymentConfig } from '../../lib/api/types';
import type { SdkIntentPayload } from '../../lib/gateways/types';
import { SDK_RESPONSE_CODE, type PaymentMethodType } from '../../lib/sf-payments-utils';

/**
 * Gateway-specific payload forwarded from the SF Payments SDK to createIntent.
 *
 * - Stripe: SDK calls createIntent() with no arguments — this will be undefined.
 * - Adyen: SDK passes encrypted card data (paymentMethod), origin, returnUrl,
 *   browserInfo, billingDetails, shippingDetails.
 *
 * Intentionally opaque (Record<string, unknown>) because the SDK is the source
 * of truth for each gateway's shape, and new gateways can be added without
 * touching this type. Gateway-specific narrowing happens inside each strategy.
 */
type SdkPaymentData = Record<string, unknown>;

export interface SFPCheckoutComponent {
    confirm: (
        data: null,
        billingDetails: Record<string, unknown>,
        shippingDetails: Record<string, unknown>
    ) => Promise<{ responseCode: number; data?: { error?: string } }>;
    updateAmount: (amount: number) => void;
    destroy: () => void;
    selectedPaymentMethod?: { paymentMethodType: PaymentMethodType };
}

type Basket = ShopperBasketsV2.schemas['Basket'];
type Order = ShopperOrders.schemas['Order'];

interface UsePaymentMethodsCallbacksOptions {
    /** Current basket from checkout */
    basket: Basket | null | undefined;
    /** Resolved payment configuration */
    paymentConfig: PaymentConfig | null | undefined;
    /** Ref to the SDK checkout component instance */
    checkoutComponentRef: React.MutableRefObject<SFPCheckoutComponent | null>;
    /** Ref to the currently selected payment method type */
    paymentMethodTypeRef: React.MutableRefObject<PaymentMethodType | ''>;
}

interface ConfirmPaymentResult {
    success: boolean;
    orderNo?: string;
    error?: string;
}

interface PaymentMethodsCallbacksResult {
    createIntent: (paymentData?: SdkPaymentData) => Promise<SdkIntentPayload>;
    confirmPayment: () => Promise<ConfirmPaymentResult>;
}

/**
 * Payment methods callbacks hook for the checkout sheet flow.
 *
 * Provides createIntent and confirmPayment callbacks for the SF Payments SDK.
 * Unlike express callbacks, this hook:
 * - Uses the main basket (no temp basket creation)
 * - No address callbacks (billing/shipping already set via checkout forms)
 * - Manual confirm required (not automatic)
 *
 * Follows the 4-layer architecture: Component → Callbacks → Gateway Strategy → Action Routes.
 * This hook delegates to the shared gateway strategies rather than calling action routes directly.
 */
export function usePaymentMethodsCallbacks({
    basket,
    paymentConfig,
    checkoutComponentRef,
    paymentMethodTypeRef,
}: UsePaymentMethodsCallbacksOptions): PaymentMethodsCallbacksResult {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { t } = useTranslation('extSfPayments' as any);
    const selectStrategy = useSelectGatewayStrategy();

    const orderRef = useRef<Order | null>(null);

    /**
     * createIntent callback — called by SDK when shopper submits payment.
     * Delegates to the shared gateway strategy and forwards its SDK-shaped
     * payload to the SDK; captures the order (when present) for navigation.
     */
    const createIntent = useCallback(
        async (paymentData?: SdkPaymentData): Promise<SdkIntentPayload> => {
            if (!paymentConfig) {
                throw new Error('Payment configuration is not resolved');
            }
            if (!basket || !basket.basketId) {
                throw new Error('Basket is not available');
            }

            const selectedMethod = checkoutComponentRef.current?.selectedPaymentMethod;
            let paymentMethodType: PaymentMethodType;
            if (selectedMethod?.paymentMethodType) {
                paymentMethodType = selectedMethod.paymentMethodType;
            } else if (paymentMethodTypeRef.current) {
                paymentMethodType = paymentMethodTypeRef.current;
            } else {
                throw new Error('No payment method type selected');
            }

            const strategy = selectStrategy(paymentMethodType, paymentConfig);

            const { sdkResult, order } = await strategy.createIntent({
                basket,
                paymentMethodType,
                paymentConfig,
                origin: window.location.origin,
                paymentData,
            });

            if (order) {
                orderRef.current = order;
            }

            return sdkResult;
        },
        [basket, paymentConfig, checkoutComponentRef, paymentMethodTypeRef, selectStrategy]
    );

    /**
     * confirmPayment - manually called when place order button is clicked.
     * Calls SDK confirm method and returns result for navigation.
     */
    const confirmPayment = useCallback(async (): Promise<ConfirmPaymentResult> => {
        if (!checkoutComponentRef.current) {
            return { success: false, error: t('paymentMethods.errorInitializing') };
        }

        if (!basket || !basket.basketId) {
            return { success: false, error: t('paymentMethods.errorBasketUnavailable') };
        }

        const billingDetails: Record<string, unknown> = {};
        if (basket.customerInfo?.email) {
            billingDetails.email = basket.customerInfo.email;
        }
        if (basket.billingAddress) {
            const addr = basket.billingAddress;
            billingDetails.phone = addr.phone;
            billingDetails.name = addr.fullName;
            billingDetails.address = {
                line1: addr.address1,
                line2: addr.address2,
                city: addr.city,
                state: addr.stateCode,
                postalCode: addr.postalCode,
                country: addr.countryCode,
            };
        }

        const shippingDetails: Record<string, unknown> = {};
        if (basket.shipments?.[0]?.shippingAddress) {
            const addr = basket.shipments[0].shippingAddress;
            shippingDetails.name = addr.fullName;
            shippingDetails.address = {
                line1: addr.address1,
                line2: addr.address2,
                city: addr.city,
                state: addr.stateCode,
                postalCode: addr.postalCode,
                country: addr.countryCode,
            };
        }

        try {
            const result = await checkoutComponentRef.current.confirm(null, billingDetails, shippingDetails);

            if (result.responseCode !== SDK_RESPONSE_CODE.SUCCESS) {
                // W-22455675: call failOrder to transition order to failed state
                return {
                    success: false,
                    error: result.data?.error || t('paymentMethods.errorConfirmationFailed'),
                };
            }

            const orderNo = orderRef.current?.orderNo;
            if (!orderNo) {
                return { success: false, error: t('paymentMethods.errorOrderMissing') };
            }

            orderRef.current = null;
            return { success: true, orderNo };
        } catch (error) {
            // W-22455675: call failOrder to transition order to failed state
            const message = error instanceof Error ? error.message : t('paymentMethods.errorConfirmationFailed');
            return { success: false, error: message };
        }
    }, [basket, checkoutComponentRef, t]);

    return {
        createIntent,
        confirmPayment,
    };
}
