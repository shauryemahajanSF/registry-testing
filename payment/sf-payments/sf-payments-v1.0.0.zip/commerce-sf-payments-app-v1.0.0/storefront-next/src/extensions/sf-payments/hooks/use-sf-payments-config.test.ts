/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 */
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import { renderHook, waitFor } from '@testing-library/react'

const mockConfig = {
    zoneId: 'default',
    paymentMethodSetAccounts: [{ accountId: 'acct_1', vendor: 'Stripe', gatewayId: 'gw1', isLive: false }],
    paymentMethods: [{ paymentMethodType: 'card', accountId: 'acct_1', paymentModes: ['direct'] }]
}

describe('fetchPaymentConfig', () => {
    let fetchPaymentConfig: typeof import('./use-sf-payments-config').fetchPaymentConfig

    beforeEach(async () => {
        vi.resetModules()
        vi.spyOn(globalThis, 'fetch').mockImplementation(() =>
            Promise.resolve(new Response(JSON.stringify(mockConfig)))
        )
        const mod = await import('./use-sf-payments-config')
        fetchPaymentConfig = mod.fetchPaymentConfig
    })

    afterEach(() => {
        vi.restoreAllMocks()
    })

    it('fetches payment config with currency and countryCode', async () => {
        const result = await fetchPaymentConfig('USD', 'US')
        expect(result).toEqual(mockConfig)
        expect(globalThis.fetch).toHaveBeenCalledWith(
            expect.stringContaining('/resource/sf-payments-config?currency=USD&countryCode=US')
        )
    })

    it('omits countryCode param when empty', async () => {
        await fetchPaymentConfig('EUR', '')
        const url = vi.mocked(globalThis.fetch).mock.calls[0][0] as string
        expect(url).toContain('currency=EUR')
        expect(url).not.toContain('countryCode')
    })

    it('returns the same in-flight promise for same currency:countryCode key (dedupe)', async () => {
        const promise1 = fetchPaymentConfig('GBP', 'GB')
        const promise2 = fetchPaymentConfig('GBP', 'GB')
        expect(promise1).toBe(promise2)
        expect(globalThis.fetch).toHaveBeenCalledTimes(1)
    })

    it('returns cached resolved promise on subsequent calls for the same key (cache hit)', async () => {
        await fetchPaymentConfig('GBP', 'GB')
        expect(globalThis.fetch).toHaveBeenCalledTimes(1)

        // Second call after the first resolves should reuse the cached promise
        // rather than firing a new request.
        const result = await fetchPaymentConfig('GBP', 'GB')
        expect(result).toEqual(mockConfig)
        expect(globalThis.fetch).toHaveBeenCalledTimes(1)
    })

    it('fetches separately for different currency:countryCode keys', async () => {
        await fetchPaymentConfig('CAD', 'CA')
        await fetchPaymentConfig('AUD', 'AU')
        expect(globalThis.fetch).toHaveBeenCalledTimes(2)
    })

    it('preserves both cache entries — re-requesting the first key does not refetch', async () => {
        // Establishes that the cache is multi-entry (not 1-slot LRU): adding a
        // second key does not evict the first.
        await fetchPaymentConfig('CAD', 'CA')
        await fetchPaymentConfig('AUD', 'AU')
        await fetchPaymentConfig('CAD', 'CA')
        expect(globalThis.fetch).toHaveBeenCalledTimes(2)
    })

    it('clears the failed entry so the next call retries', async () => {
        vi.mocked(globalThis.fetch).mockRejectedValueOnce(new Error('Network error'))

        await expect(fetchPaymentConfig('JPY', 'JP')).rejects.toThrow('Network error')

        vi.mocked(globalThis.fetch).mockImplementation(() =>
            Promise.resolve(new Response(JSON.stringify(mockConfig)))
        )
        const result = await fetchPaymentConfig('JPY', 'JP')
        expect(result).toEqual(mockConfig)
        expect(globalThis.fetch).toHaveBeenCalledTimes(2)
    })

    it('throws on non-OK response with error from body', async () => {
        vi.mocked(globalThis.fetch).mockImplementation(() =>
            Promise.resolve(new Response(JSON.stringify({ error: 'Zone not found' }), { status: 404 }))
        )
        await expect(fetchPaymentConfig('XXX', 'XX')).rejects.toThrow('Zone not found')
    })
})

describe('useSFPaymentsConfig', () => {
    let useSFPaymentsConfig: typeof import('./use-sf-payments-config').useSFPaymentsConfig

    beforeEach(async () => {
        vi.resetModules()
        vi.spyOn(globalThis, 'fetch').mockImplementation(() =>
            Promise.resolve(new Response(JSON.stringify(mockConfig)))
        )
        const mod = await import('./use-sf-payments-config')
        useSFPaymentsConfig = mod.useSFPaymentsConfig
    })

    afterEach(() => {
        vi.restoreAllMocks()
    })

    it('fetches config on mount with the provided currency and countryCode', async () => {
        const { result } = renderHook(() =>
            useSFPaymentsConfig({ currency: 'USD', countryCode: 'US' })
        )

        expect(result.current.loading).toBe(true)

        await waitFor(() => {
            expect(result.current.loading).toBe(false)
        })

        expect(result.current.config).toEqual(mockConfig)
        expect(result.current.accounts).toEqual(mockConfig.paymentMethodSetAccounts)
        expect(result.current.error).toBeNull()
        expect(globalThis.fetch).toHaveBeenCalledWith(
            expect.stringContaining('currency=USD&countryCode=US')
        )
    })

    it('surfaces error as string when fetch fails', async () => {
        vi.mocked(globalThis.fetch).mockRejectedValueOnce(new Error('Boom'))

        const { result } = renderHook(() =>
            useSFPaymentsConfig({ currency: 'EUR', countryCode: 'DE' })
        )

        await waitFor(() => {
            expect(result.current.loading).toBe(false)
        })

        expect(result.current.config).toBeNull()
        expect(result.current.accounts).toEqual([])
        expect(result.current.error).toBe('Boom')
    })

    it('refetches when currency or countryCode changes', async () => {
        const { result, rerender } = renderHook(
            ({ currency, countryCode }: { currency: string; countryCode: string }) =>
                useSFPaymentsConfig({ currency, countryCode }),
            { initialProps: { currency: 'USD', countryCode: 'US' } }
        )

        await waitFor(() => {
            expect(result.current.loading).toBe(false)
        })
        expect(globalThis.fetch).toHaveBeenCalledTimes(1)

        rerender({ currency: 'EUR', countryCode: 'DE' })

        await waitFor(() => {
            expect(result.current.loading).toBe(false)
        })
        expect(globalThis.fetch).toHaveBeenCalledTimes(2)
    })

    it('does not refetch when re-rendered with the same key (cache hit)', async () => {
        const { result, rerender } = renderHook(
            ({ currency, countryCode }: { currency: string; countryCode: string }) =>
                useSFPaymentsConfig({ currency, countryCode }),
            { initialProps: { currency: 'GBP', countryCode: 'GB' } }
        )

        await waitFor(() => {
            expect(result.current.loading).toBe(false)
        })
        expect(globalThis.fetch).toHaveBeenCalledTimes(1)

        rerender({ currency: 'GBP', countryCode: 'GB' })

        await waitFor(() => {
            expect(result.current.loading).toBe(false)
        })
        expect(globalThis.fetch).toHaveBeenCalledTimes(1)
    })

    it('does not fire a fetch when currency is empty', async () => {
        const { result } = renderHook(() =>
            useSFPaymentsConfig({ currency: '', countryCode: 'US' })
        )

        await waitFor(() => {
            expect(result.current.loading).toBe(false)
        })
        expect(result.current.config).toBeNull()
        expect(globalThis.fetch).not.toHaveBeenCalled()
    })
})
