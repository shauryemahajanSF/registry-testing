/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { describe, test, expect, vi, beforeEach } from 'vitest';
import { renderHook } from '@testing-library/react';
import { useAdyenStrategy } from './use-adyen-strategy';
import type { PaymentConfig } from '../../lib/api/types';

const submitSpies = {
    push: vi.fn(),
    ensure: vi.fn(),
    create: vi.fn(),
};

const promiseResolvers = {
    push: vi.fn(),
    ensure: vi.fn(),
    create: vi.fn(),
};

vi.mock('react-router', () => ({
    useFetcher: vi.fn(),
}));

vi.mock('../use-fetcher-promise', () => ({
    useFetcherPromise: vi.fn(),
}));

import { useFetcher } from 'react-router';
import { useFetcherPromise } from '../use-fetcher-promise';

const paymentConfig: PaymentConfig = {
    zoneId: 'z1',
    paymentMethods: [{ paymentMethodType: 'card', accountId: 'acct_adyen' }],
    paymentMethodSetAccounts: [{ accountId: 'acct_adyen', vendor: 'Adyen' }],
};

const baseBasket = {
    basketId: 'b1',
    paymentInstruments: [
        {
            paymentMethodId: 'Salesforce Payments',
            paymentInstrumentId: 'opi-1',
            paymentReference: { paymentReferenceId: 'pref-1' },
        },
    ],
};

const orderWithAdyenIntent = {
    orderNo: 'o-1',
    paymentInstruments: [
        {
            paymentMethodId: 'Salesforce Payments',
            paymentInstrumentId: 'opi-1',
            paymentReference: {
                paymentReferenceId: 'pref-1',
                gatewayProperties: {
                    adyen: {
                        adyenPaymentIntent: {
                            id: 'psp-123',
                            resultCode: 'IdentifyShopper',
                            adyenPaymentIntentAction: { type: 'redirect', url: 'https://adyen.test/3ds' },
                        },
                    },
                },
            },
        },
    ],
};

beforeEach(() => {
    submitSpies.push.mockReset();
    submitSpies.ensure.mockReset();
    submitSpies.create.mockReset();
    promiseResolvers.push.mockReset();
    promiseResolvers.ensure.mockReset();
    promiseResolvers.create.mockReset();

    // Adyen creates fetchers in order: push, ensure, create.
    const fetchers = [
        { submit: submitSpies.push, state: 'idle', data: undefined },
        { submit: submitSpies.ensure, state: 'idle', data: undefined },
        { submit: submitSpies.create, state: 'idle', data: undefined },
    ];
    let fetcherIdx = 0;
    vi.mocked(useFetcher).mockImplementation(() => fetchers[fetcherIdx++] as unknown as ReturnType<typeof useFetcher>);

    const resolvers = [promiseResolvers.push, promiseResolvers.ensure, promiseResolvers.create];
    let resolverIdx = 0;
    vi.mocked(useFetcherPromise).mockImplementation(
        () => resolvers[resolverIdx++] as unknown as ReturnType<typeof useFetcherPromise>
    );
});

describe('useAdyenStrategy', () => {
    test('returned shape: prepareBasketOnClick=true, only createIntent (no onPayerApprove or onApprove)', () => {
        const { result } = renderHook(() => useAdyenStrategy());

        expect(result.current.prepareBasketOnClick).toBe(true);
        expect(result.current).toHaveProperty('createIntent', expect.any(Function));
        expect('onPayerApprove' in result.current).toBe(false);
        expect('onApprove' in result.current).toBe(false);
    });

    test('createIntent with paymentData.shippingDetails: pushes addresses, ensures PI, creates order', async () => {
        promiseResolvers.push.mockResolvedValue({ success: true, basket: baseBasket });
        promiseResolvers.ensure.mockResolvedValue({ success: true, basket: baseBasket });
        promiseResolvers.create.mockResolvedValue({ success: true, order: orderWithAdyenIntent });

        const paymentData = {
            shippingDetails: {
                name: 'Jane Doe',
                address: { line1: '1 Main', city: 'NYC', postalCode: '10001', country: 'US' },
            },
            billingDetails: {
                name: 'Jane Doe',
                address: { line1: '1 Main', city: 'NYC', postalCode: '10001', country: 'US' },
            },
            paymentMethod: { type: 'card' },
        };

        const { result } = renderHook(() => useAdyenStrategy());
        const intent = await result.current.createIntent({
            basket: baseBasket,
            paymentMethodType: 'card',
            paymentConfig,
            origin: 'https://example.com',
            paymentData,
        });

        // All three action routes called, in order.
        expect(submitSpies.push).toHaveBeenCalledWith(
            expect.any(FormData),
            expect.objectContaining({ method: 'POST', action: '/action/sf-payments-push-addresses' })
        );
        expect(submitSpies.ensure).toHaveBeenCalledWith(
            expect.any(FormData),
            expect.objectContaining({ method: 'POST', action: '/action/sf-payments-ensure-pi' })
        );
        expect(submitSpies.create).toHaveBeenCalledWith(
            expect.any(FormData),
            expect.objectContaining({ method: 'POST', action: '/action/sf-payments-create-order' })
        );

        // create-order forwards paymentData so the server-side PI body picks up Adyen fields.
        const createForm = submitSpies.create.mock.calls[0][0] as FormData;
        expect(createForm.get('paymentMethodType')).toBe('card');
        expect(createForm.get('basketId')).toBe('b1');
        expect(createForm.get('origin')).toBe('https://example.com');
        expect(createForm.get('paymentData')).toBe(JSON.stringify(paymentData));

        // Returned sdkResult carries the Adyen-namespace fields read off the order's PI.
        expect(intent).toEqual({
            sdkResult: {
                pspReference: 'psp-123',
                guid: 'pref-1',
                resultCode: 'IdentifyShopper',
                action: { type: 'redirect', url: 'https://adyen.test/3ds' },
            },
            order: orderWithAdyenIntent,
        });
    });

    test('createIntent without shippingDetails: skips push-addresses, still ensures PI and creates order', async () => {
        promiseResolvers.ensure.mockResolvedValue({ success: true, basket: baseBasket });
        promiseResolvers.create.mockResolvedValue({ success: true, order: orderWithAdyenIntent });

        const { result } = renderHook(() => useAdyenStrategy());
        await result.current.createIntent({
            basket: baseBasket,
            paymentMethodType: 'card',
            paymentConfig,
            origin: 'https://example.com',
            paymentData: { paymentMethod: { type: 'card' } },
        });

        expect(submitSpies.push).not.toHaveBeenCalled();
        expect(submitSpies.ensure).toHaveBeenCalledTimes(1);
        expect(submitSpies.create).toHaveBeenCalledTimes(1);
    });

    test('createIntent throws when ensure-pi returns success: false', async () => {
        promiseResolvers.ensure.mockResolvedValue({ success: false, error: 'pi creation rejected' });

        const { result } = renderHook(() => useAdyenStrategy());
        await expect(
            result.current.createIntent({
                basket: baseBasket,
                paymentMethodType: 'card',
                paymentConfig,
                origin: 'https://example.com',
            })
        ).rejects.toThrow('pi creation rejected');
    });

    test('createIntent throws when the order is missing a paymentReferenceId', async () => {
        const orderWithoutRef = {
            orderNo: 'o-1',
            paymentInstruments: [
                {
                    paymentMethodId: 'Salesforce Payments',
                    paymentInstrumentId: 'opi-1',
                    paymentReference: {},
                },
            ],
        };
        promiseResolvers.ensure.mockResolvedValue({ success: true, basket: baseBasket });
        promiseResolvers.create.mockResolvedValue({ success: true, order: orderWithoutRef });

        const { result } = renderHook(() => useAdyenStrategy());
        await expect(
            result.current.createIntent({
                basket: baseBasket,
                paymentMethodType: 'card',
                paymentConfig,
                origin: 'https://example.com',
            })
        ).rejects.toThrow(/paymentReferenceId/);
    });
});
