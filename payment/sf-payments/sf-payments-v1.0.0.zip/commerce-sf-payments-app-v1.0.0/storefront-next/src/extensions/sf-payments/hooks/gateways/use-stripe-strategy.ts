/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

'use client';

/**
 * Stripe gateway strategy hook.
 *
 * Flow for Stripe in the express path:
 *   1. onClick preps the basket (prepareBasketOnClick=true).
 *   2. SDK fires onPayerApprove with wallet-provided billing + shipping details.
 *      - push shipping + billing addresses onto the basket
 *      - add the SF Payments payment instrument
 *   3. SDK fires createIntent.
 *      - ensure PI (idempotent — no-op if already added in onPayerApprove)
 *      - create commerce order + patch PI on the order
 *      - return `{ client_secret, id }` read from the order's PI
 *
 * Flow for Stripe in the payment-sheet/checkout path:
 *   1. No onPayerApprove (addresses already on basket from checkout forms).
 *   2. SDK fires createIntent.
 *      - ensure PI (first time — adds the SF Payments instrument)
 *      - create commerce order + patch PI on the order
 *      - return `{ client_secret, id }` read from the order's PI
 *
 * Action routes are invoked via React Router's `useFetcher()` + FormData +
 * `useFetcherPromise` adapter. Each fetcher is instantiated without a `key`
 * so the hook's state stays local to this consumer.
 */

import { useCallback } from 'react';
import { useFetcher } from 'react-router';
import type { ShopperBasketsV2, ShopperOrders } from '@/scapi';
import { useFetcherPromise } from '../use-fetcher-promise';
import {
    getClientSecret,
    getExpressPaymentMethodType,
    getSFPaymentsInstrument,
    transformAddressDetails,
} from '../../lib/sf-payments-utils';
import type { CreateIntentArgs, CreateIntentResult, GatewayStrategy, PayerApproveArgs } from '../../lib/gateways/types';
import { submitCreateOrder } from './submit-create-order';

type Basket = ShopperBasketsV2.schemas['Basket'];
type Order = ShopperOrders.schemas['Order'];
type ActionResponse<T> = ({ success: true } & T) | { success: false; error?: string };

type EnsurePiResponse = ActionResponse<{ basket: Basket }>;
type PushAddressesResponse = ActionResponse<{ basket: Basket }>;
type CreateOrderResponse = ActionResponse<{ order: Order; orderNo?: string }>;

/**
 * Stripe SDK's createIntent payload. Local to this strategy — the
 * GatewayStrategy contract returns this as opaque `SdkIntentPayload`, so
 * consumers can't read fields off it.
 */
interface StripeSdkIntentPayload {
    client_secret?: string;
    /** SF Payments paymentReferenceId; the Stripe SDK reads it as `id`. */
    id: string;
    /** Mirrors the PI's setup_future_usage so Stripe Elements matches it on confirm. */
    setup_future_usage?: string;
}

/** Stripe-namespace shape on a SF Payments PI's `paymentReference`. */
interface StripePaymentReference {
    gatewayProperties?: { stripe?: { setupFutureUsage?: string } };
}

/** Narrow a settled action-route response to its success branch. */
function assertSuccess<T extends { success: boolean; error?: string }>(
    result: T | undefined,
    fallbackMessage: string
): Extract<T, { success: true }> {
    if (!result) {
        throw new Error(fallbackMessage);
    }
    if (result.success !== true) {
        throw new Error(result.error || fallbackMessage);
    }
    return result as Extract<T, { success: true }>;
}

export function useStripeStrategy(): GatewayStrategy {
    const ensurePiFetcher = useFetcher<EnsurePiResponse>();
    const pushAddressesFetcher = useFetcher<PushAddressesResponse>();
    const createOrderFetcher = useFetcher<CreateOrderResponse>();

    const awaitEnsurePi = useFetcherPromise(ensurePiFetcher, 'ensure-pi failed');
    const awaitPushAddresses = useFetcherPromise(pushAddressesFetcher, 'push-addresses failed');
    const awaitCreateOrder = useFetcherPromise(createOrderFetcher, 'create-order failed');

    const onPayerApprove = useCallback(
        async (args: PayerApproveArgs): Promise<Basket> => {
            const { basket, paymentMethodType, paymentConfig, billingAddress, shippingAddress, onProcessingStarted } =
                args;
            if (!basket.basketId) {
                throw new Error('Stripe onPayerApprove: basket is missing a basketId');
            }
            // Wallet has authorized; addresses are about to flow into the basket.
            // Signal "processing started" before any network work begins.
            onProcessingStarted?.();

            // Stripe rejects wallet-derived types like 'googlepay' / 'applepay' on the
            // PI request — it expects 'card'. Map at the strategy boundary so all
            // downstream actions (ensure-pi, create-order) see the gateway-correct type.
            const stripePaymentMethodType = getExpressPaymentMethodType(
                paymentMethodType,
                paymentConfig.paymentMethods ?? [],
                paymentConfig.paymentMethodSetAccounts ?? []
            );

            // The SDK's billing/shipping details aren't guaranteed to have the
            // same shape transformAddressDetails expects; cast at the boundary.
            // Wallets may omit billing — fall back to shipping like Adyen strategy.
            const effectiveBilling = billingAddress || shippingAddress;
            const { billingAddress: billing, shippingAddress: shipping } = transformAddressDetails(
                effectiveBilling as Parameters<typeof transformAddressDetails>[0],
                shippingAddress as Parameters<typeof transformAddressDetails>[1]
            );

            const pushForm = new FormData();
            pushForm.set('basketId', basket.basketId);
            pushForm.set('shippingAddress', JSON.stringify(shipping));
            pushForm.set('billingAddress', JSON.stringify(billing));
            void pushAddressesFetcher.submit(pushForm, {
                method: 'POST',
                action: '/action/sf-payments-push-addresses',
            });
            const pushed = assertSuccess(await awaitPushAddresses(), 'push-addresses failed');

            const ensureForm = new FormData();
            ensureForm.set('basket', JSON.stringify(pushed.basket));
            ensureForm.set('paymentMethodType', stripePaymentMethodType);
            ensureForm.set('paymentConfig', JSON.stringify(paymentConfig));
            void ensurePiFetcher.submit(ensureForm, {
                method: 'POST',
                action: '/action/sf-payments-ensure-pi',
            });
            const ensured = assertSuccess(await awaitEnsurePi(), 'ensure-pi failed');

            return ensured.basket;
        },
        [pushAddressesFetcher, ensurePiFetcher, awaitPushAddresses, awaitEnsurePi]
    );

    const createIntent = useCallback(
        async (args: CreateIntentArgs): Promise<CreateIntentResult> => {
            const {
                basket,
                paymentMethodType,
                paymentConfig,
                baseUrl,
                storePaymentMethod,
                futureUsageOffSession,
                skipPostOrderRevalidation,
            } = args;
            if (!basket.basketId) {
                throw new Error('Stripe createIntent: basket is missing a basketId');
            }

            const stripePaymentMethodType = getExpressPaymentMethodType(
                paymentMethodType,
                paymentConfig.paymentMethods ?? [],
                paymentConfig.paymentMethodSetAccounts ?? []
            );

            // Ensure the SF Payments PI is attached. Idempotent — for express this
            // is a no-op (already added in onPayerApprove); for the payment-sheet/
            // checkout flow this is the first (and only) time it's called.
            const ensureForm = new FormData();
            ensureForm.set('basket', JSON.stringify(basket));
            ensureForm.set('paymentMethodType', stripePaymentMethodType);
            ensureForm.set('paymentConfig', JSON.stringify(paymentConfig));
            void ensurePiFetcher.submit(ensureForm, {
                method: 'POST',
                action: '/action/sf-payments-ensure-pi',
            });
            assertSuccess(await awaitEnsurePi(), 'ensure-pi failed');

            const orderForm = new FormData();
            orderForm.set('basketId', basket.basketId);
            orderForm.set('paymentMethodType', stripePaymentMethodType);
            orderForm.set('paymentConfig', JSON.stringify(paymentConfig));
            orderForm.set('origin', baseUrl);
            if (storePaymentMethod) {
                orderForm.set('storePaymentMethod', 'true');
                if (futureUsageOffSession) {
                    orderForm.set('futureUsageOffSession', 'true');
                }
            }

            const ordered = await submitCreateOrder({
                orderForm,
                fetcher: createOrderFetcher,
                awaitCreateOrder,
                skipPostOrderRevalidation,
            });

            const pi = getSFPaymentsInstrument(ordered.order);
            const paymentReferenceId = (pi as { paymentReference?: { paymentReferenceId?: string } } | undefined)
                ?.paymentReference?.paymentReferenceId;
            if (!paymentReferenceId) {
                throw new Error('Stripe createIntent: order is missing a paymentReferenceId');
            }
            const stripeGatewayProps = (pi as { paymentReference?: StripePaymentReference } | undefined)
                ?.paymentReference?.gatewayProperties?.stripe;
            const sdkResult: StripeSdkIntentPayload = {
                client_secret: pi ? getClientSecret(pi) : undefined,
                id: paymentReferenceId,
                ...(stripeGatewayProps?.setupFutureUsage && {
                    setup_future_usage: stripeGatewayProps.setupFutureUsage,
                }),
            };
            return { sdkResult, order: ordered.order };
        },
        [ensurePiFetcher, createOrderFetcher, awaitEnsurePi, awaitCreateOrder]
    );

    return {
        prepareBasketOnClick: true,
        onPayerApprove,
        createIntent,
    };
}
