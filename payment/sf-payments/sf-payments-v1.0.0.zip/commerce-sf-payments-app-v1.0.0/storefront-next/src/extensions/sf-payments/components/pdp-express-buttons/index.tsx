/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

'use client';

import { useCallback } from 'react';
import { useFetcher } from 'react-router';
import { useSite } from '@salesforce/storefront-next-runtime/site-context';
import type { ShopperBasketsV2 } from '@/scapi';
import { useProductView } from '@/providers/product-view';
import { useCurrentVariant } from '@/hooks/product/use-current-variant';
import ExpressButtons from '../express-buttons';
import { useFetcherPromise } from '../../hooks/use-fetcher-promise';
import { EXPRESS_BUY_NOW } from '../../lib/sf-payments-utils';
import { getLocaleDerivedCountryCode } from '../../lib/sf-payments-country';

type Basket = ShopperBasketsV2.schemas['Basket'];

type CreateExpressBasketResponse = { success: true; basket: Basket } | { success: false; error?: string };

/**
 * PDP-specific wrapper for ExpressButtons.
 *
 * Registered at the `sfcc.pdp.payments.expressCheckout` target. Provides a `prepareBasket`
 * that creates a temporary basket and adds the current product/variant to it.
 * Renders buttons with "Buy Now" labels in a vertical layout.
 */
export default function PDPExpressButtons() {
    const { product, canAddToCart, quantity, isMasterOrVariantProduct } = useProductView();
    const currentVariant = useCurrentVariant({ product });
    const { locale, currency: siteCurrency } = useSite();

    const productToUse = isMasterOrVariantProduct ? currentVariant : product;
    // `currentVariant` uses `productId`; base `product` uses `id`. Mirrors the idiom in
    // use-product-actions.ts so the union doesn't need to be narrowed on the combined value.
    const productId = currentVariant?.productId || product.id;
    const initialAmount = productToUse?.price ?? product.price ?? 0;

    // Use the resolved site currency (cookie → locale.preferredCurrency → site default).
    // This is what the storefront's basket middleware reprices the basket to, so binding
    // Elements to anything else risks a client/server currency mismatch on the PI.
    const currency = siteCurrency;

    // No basket on PDP — derive country from locale. Consumers with a basket
    // (cart/checkout/payment sheet) should source countryCode from the billing address
    // instead and only fall back to this when the address isn't set.
    const countryCode = getLocaleDerivedCountryCode(locale.id);

    // Action-route mutations go through `useFetcher` so the request flows through
    // React Router's framework path (locale prefix, middleware, typed response).
    // `useFetcherPromise` adapts the fetcher's reactive state into an awaitable
    // promise we can call from inside the SDK callback.
    const createBasketFetcher = useFetcher<CreateExpressBasketResponse>();
    const awaitCreateBasket = useFetcherPromise(createBasketFetcher, 'create-express-basket failed');

    const prepareBasket = useCallback(async () => {
        if (!productId) {
            throw new Error('Unable to determine product ID');
        }

        const form = new FormData();
        form.set('productId', productId);
        form.set('quantity', String(quantity));
        // Pass the currency the client is binding Elements to so the temp basket
        // and PI are priced in the same currency.
        form.set('currency', currency);
        void createBasketFetcher.submit(form, {
            method: 'POST',
            action: '/action/sf-payments-create-express-basket',
        });

        const result = await awaitCreateBasket();
        if (!result || result.success !== true) {
            throw new Error(result?.error || 'Failed to prepare basket');
        }
        return result.basket;
    }, [productId, quantity, currency, createBasketFetcher, awaitCreateBasket]);

    if (!canAddToCart) {
        return null;
    }

    return (
        <ExpressButtons
            prepareBasket={prepareBasket}
            initialAmount={initialAmount}
            currency={currency}
            countryCode={countryCode}
            usage={EXPRESS_BUY_NOW}
            expressButtonLayout="vertical"
            maximumButtonCount={2}
        />
    );
}
