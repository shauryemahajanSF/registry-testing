/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { describe, test, expect, vi, beforeEach } from 'vitest';
import type { RouterContextProvider } from 'react-router';
import { loader } from './payment-processing';
import { attemptFailOrder } from '../../lib/api/order-mutations.server';
import { getLogger } from '@/lib/logger.server';

vi.mock('../../lib/api/order-mutations.server', () => ({
    attemptFailOrder: vi.fn().mockResolvedValue(true),
}));

vi.mock('@/lib/logger.server', () => ({
    getLogger: vi.fn(() => ({
        warn: vi.fn(),
        info: vi.fn(),
        error: vi.fn(),
    })),
}));

vi.mock('@/hooks/use-navigate', () => ({ useNavigate: vi.fn() }));
vi.mock('../../providers/sf-payments-provider', () => ({ useSFPaymentsContext: vi.fn() }));

const mockContext = {
    get: vi.fn(),
    set: vi.fn(),
} as unknown as RouterContextProvider;

function makeArgs(params: Record<string, string>) {
    const url = new URL('https://shop.example/checkout/payment-processing');
    for (const [k, v] of Object.entries(params)) {
        url.searchParams.set(k, v);
    }
    return {
        request: new Request(url.toString()),
        context: mockContext,
        params: {},
    } as any;
}

beforeEach(() => {
    vi.clearAllMocks();
});

describe('loader — Stripe success', () => {
    test('returns success state with orderNo', async () => {
        const result = await loader(makeArgs({ orderNo: 'o1', redirect_status: 'succeeded' }));

        expect(result).toEqual({ state: 'success', orderNo: 'o1' });
    });

    test('does not call attemptFailOrder', async () => {
        await loader(makeArgs({ orderNo: 'o1', redirect_status: 'succeeded' }));

        expect(attemptFailOrder).not.toHaveBeenCalled();
    });
});

describe('loader — Stripe failure', () => {
    test('calls attemptFailOrder and returns error state for redirect_status=failed', async () => {
        const result = await loader(makeArgs({ orderNo: 'o1', redirect_status: 'failed' }));

        expect(attemptFailOrder).toHaveBeenCalledWith(mockContext, 'o1');
        expect(result).toEqual({ state: 'error' });
    });

    test('calls attemptFailOrder and returns error state for redirect_status=canceled', async () => {
        const result = await loader(makeArgs({ orderNo: 'o1', redirect_status: 'canceled' }));

        expect(attemptFailOrder).toHaveBeenCalledWith(mockContext, 'o1');
        expect(result).toEqual({ state: 'error' });
    });

    test('calls attemptFailOrder for unknown redirect_status', async () => {
        const result = await loader(makeArgs({ orderNo: 'o1', redirect_status: 'requires_action' }));

        expect(attemptFailOrder).toHaveBeenCalledWith(mockContext, 'o1');
        expect(result).toEqual({ state: 'error' });
    });
});

describe('loader — abandoned (no redirect_status)', () => {
    test('calls attemptFailOrder and returns error state', async () => {
        const result = await loader(makeArgs({ orderNo: 'o1' }));

        expect(attemptFailOrder).toHaveBeenCalledWith(mockContext, 'o1');
        expect(result).toEqual({ state: 'error' });
    });

    test('logs reason=abandoned', async () => {
        const mockWarn = vi.fn();
        vi.mocked(getLogger).mockReturnValue({ warn: mockWarn, info: vi.fn(), error: vi.fn() } as any);

        await loader(makeArgs({ orderNo: 'o1' }));

        expect(mockWarn).toHaveBeenCalledWith(
            '[sf-payments] payment-processing: non-success return',
            expect.objectContaining({ redirectStatus: 'abandoned' })
        );
    });
});

describe('loader — timeout (processing state)', () => {
    test('returns loading state without calling attemptFailOrder', async () => {
        const result = await loader(makeArgs({ orderNo: 'o1', redirect_status: 'processing' }));

        expect(result).toEqual({ state: 'loading', orderNo: 'o1' });
        expect(attemptFailOrder).not.toHaveBeenCalled();
    });
});

describe('loader — missing orderNo', () => {
    test('redirects to /checkout', async () => {
        const result = await loader(makeArgs({ redirect_status: 'succeeded' }));

        expect(result).toBeInstanceOf(Response);
        expect((result as Response).status).toBe(302);
        expect((result as Response).headers.get('Location')).toBe('/checkout');
    });

    test('does not call attemptFailOrder', async () => {
        await loader(makeArgs({}));

        expect(attemptFailOrder).not.toHaveBeenCalled();
    });
});

describe('loader — vendor=Stripe redirect (delegated to sfp.handleRedirect)', () => {
    test('returns gateway-redirect state for succeeded status', async () => {
        const result = await loader(makeArgs({ orderNo: 'o1', redirect_status: 'succeeded', vendor: 'Stripe' }));

        expect(result).toEqual({ state: 'gateway-redirect', orderNo: 'o1', vendor: 'Stripe' });
        expect(attemptFailOrder).not.toHaveBeenCalled();
    });

    test('returns gateway-redirect state for processing status', async () => {
        const result = await loader(makeArgs({ orderNo: 'o1', redirect_status: 'processing', vendor: 'Stripe' }));

        expect(result).toEqual({ state: 'gateway-redirect', orderNo: 'o1', vendor: 'Stripe' });
        expect(attemptFailOrder).not.toHaveBeenCalled();
    });

    test('calls attemptFailOrder and returns error state when redirect_status is absent', async () => {
        const result = await loader(makeArgs({ orderNo: 'o1', vendor: 'Stripe' }));

        expect(attemptFailOrder).toHaveBeenCalledWith(mockContext, 'o1');
        expect(result).toEqual({ state: 'error' });
    });

    test('calls attemptFailOrder and returns error state for redirect_status=failed', async () => {
        const result = await loader(makeArgs({ orderNo: 'o1', redirect_status: 'failed', vendor: 'Stripe' }));

        expect(attemptFailOrder).toHaveBeenCalledWith(mockContext, 'o1');
        expect(result).toEqual({ state: 'error' });
    });

    test('calls attemptFailOrder and returns error state for redirect_status=canceled', async () => {
        const result = await loader(makeArgs({ orderNo: 'o1', redirect_status: 'canceled', vendor: 'Stripe' }));

        expect(attemptFailOrder).toHaveBeenCalledWith(mockContext, 'o1');
        expect(result).toEqual({ state: 'error' });
    });
});
