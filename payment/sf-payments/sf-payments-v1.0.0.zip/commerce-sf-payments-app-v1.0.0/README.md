# SF Payments

Salesforce Payments integration for Storefront Next storefronts. Replaces
the out-of-the-box payment UI with gateway-integrated components that
support standard checkout, express checkout (Apple Pay, Google Pay, PayPal
Express), and 3D Secure flows via the unified `sfp.js` SDK.

Supported gateways: Stripe, Adyen, PayPal.

## What This App Installs

- **Storefront Next UI extension** registered at host UITargets:
  - PDP, cart, mini-cart, and checkout — express payment buttons
  - Checkout — payment-methods sheet
- **No cartridges or IMPEX data** — all configuration is platform-managed
  via Salesforce Payments and delivered to the storefront over SCAPI.

## Requirements

- Storefront Next storefront (minimum version 1.0.0)
- Salesforce Payments enabled on your Commerce Cloud org
- At least one configured gateway account (Stripe, Adyen, or PayPal)

## Post-Install Setup

After installation, complete the tasks in the **Complete Your Setup**
checklist in Business Manager (also viewable via `b2c cap tasks sf-payments`):

1. **Connect a Merchant Account** — configure Adyen, Stripe, and/or PayPal
   merchant accounts under Salesforce Payments.
2. **Configure Checkout Payment Methods** — define which payment methods
   appear during the standard checkout flow.
3. **Configure Express Checkout Payment Methods** — define which payment
   methods appear on express checkout surfaces (PDP, cart, mini-cart).

## Verifying the Install

Once the tasks above are complete:

1. Open your storefront and add an item to the cart.
2. Confirm express payment buttons render on the cart and mini-cart.
3. Proceed to checkout and confirm the payment-methods sheet loads with
   your configured methods.

If components don't render, check the storefront browser console for
`sf-payments` errors and confirm that the SCAPI Shopper Payments endpoints
return your gateway configuration.

## Uninstall

`b2c cap uninstall sf-payments --domain payment --site <site-id>` removes
the UI extension. Gateway accounts and Salesforce Payments configuration
are not modified — manage those independently via Business Manager.

## Support

See [developer.salesforce.com](https://developer.salesforce.com/).
