# CDS Shipping Commerce App

Source repository for the CDS Shipping Commerce App Package (CAP).

The app implements B2C Commerce shipping hooks for CDS delivery estimates:

- `sfcc.app.shipping.estimate` for Shopper Delivery Estimates on PDP.
- `sfcc.app.shipping.quote` for checkout shipping-method delivery windows.
- `sfcc.app.shipping.calculate` for persisting CDS delivery metadata on shipments during calculation.

## Expected Layout

The app source should be kept under:

```text
commerce-cds-shipping-app-v1.0.0/
```

The generated CAP archive should be created outside source control as:

```text
cds-shipping-v1.0.0.zip
```

## Local Tests

```bash
cd commerce-cds-shipping-app-v1.0.0/cartridges/site_cartridges/int_cds_shipping
npm install
npm test
```

## BM Setup Summary

After installing the CAP:

- Configure `cds.shipping.api` with the CDS API base URL.
- Configure `cds.accountmanager.oauth` with Account Manager client ID and secret.
- Configure CDS site preferences imported from `impex/install/sites/SITEID/preferences.xml`.
- Map shipping methods with `cdsShippingCarrier` and `cdsMethodName`.

