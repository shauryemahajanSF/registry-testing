# Zenkraft Shipping Rates

Dynamic real-time shipping rate calculation for Salesforce B2C Commerce via the `sfcc.app.shipping.calculate` Commerce App hook.

## Overview

This app replaces static, pre-configured SFCC shipping rate tables with dynamic quotes retrieved from an external carrier/rate provider. It implements the `sfcc.app.shipping.calculate` shipment-level hook, which the platform invokes during:

- `GET /baskets/{basket_id}/shipments/{shipment_id}/shipping-methods` — called with all applicable shipping methods to populate the rate chooser.
- `dw.order.calculate` (basket calculation) — called with only the currently selected shipping method to price the shipment shipping line item.

When the hook is registered and the `ShippingAppHooksEnabled` toggle is on, it takes precedence over the legacy `dw.order.calculateShipping` hook and the native `ShippingMgr` path. Returning `null`/empty falls back to the existing legacy/native pricing path.

## Features

- Shipment-level `sfcc.app.shipping.calculate` implementation returning `ShippingRateResult` quotes
- Dual-path support: rate-all-methods (GET) and rate-selected-only (calculate)
- Provider abstraction via a `zenkraft.rates.api` service wrapper with pluggable carrier mapping
- Rate markup support (flat amount or percent) per shipping method
- Graceful fallback: returns empty result on provider errors so the platform can fall through to native pricing

## Prerequisites

- Salesforce Commerce Cloud B2C Commerce instance with Commerce Apps enabled
- `ShippingAppHooksEnabled` feature toggle available (enabled automatically on app install)
- API credentials for your shipping rate provider

## Installation

1. Download the app ZIP from the Commerce App Registry
2. Import via Business Manager > Merchant Tools > Commerce Apps
3. Add `int_zenkraft_rates` to the cartridge path for each target site
4. Import `impex/install/meta/system-objecttype-extensions.xml` to add the ShippingMethod custom attributes
5. Configure the `zenkraft.rates.api` service credentials
6. Populate `zenkraftID`, `zenkraftCarrierCode`, and (optionally) markup fields on each Shipping Method

## Configuration

### Service Credentials

1. Navigate to Administration > Operations > Services
2. Find the `zenkraft.rates.api` service
3. Configure:
   - **URL:** your provider rate endpoint (e.g., `https://api.zenkraft.com/rate`)
   - **User/API Key:** provided by your rate provider
   - **Password/Secret:** provided by your rate provider

### Shipping Method Mapping

For every Shipping Method that should be rated dynamically, set these custom attributes:

- `zenkraftID` — provider-side method identifier used to match returned rates
- `zenkraftCarrierCode` — carrier code (e.g., `ups`, `fedex`)
- `zenkraftServiceCode` — carrier service code
- `zenkraftRateMarkupType` — `Amount` or `Percent` (optional)
- `zenkraftRateMarkup` — numeric markup value (optional)

## Post-Installation Checklist

- [ ] Import impex meta and services XML
- [ ] Configure `zenkraft.rates.api` credentials
- [ ] Set `ShippingAppHooksEnabled` toggle (handled by install)
- [ ] Map each Shipping Method to its provider ID
- [ ] Place a test basket and verify rates come from the provider (check custom log `zenkraft-rates`)

## Testing

```bash
cd cartridges/site_cartridges/int_zenkraft_rates
npm install
npm test
```

## Support

- Docs: https://www.zenkraft.com/docs

## Changelog

### v1.0.0
- Initial release implementing `sfcc.app.shipping.calculate`
