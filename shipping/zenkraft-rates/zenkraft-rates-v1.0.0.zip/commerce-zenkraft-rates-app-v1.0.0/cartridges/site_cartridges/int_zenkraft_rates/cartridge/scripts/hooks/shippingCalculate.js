'use strict';

/**
 * sfcc.app.shipping.calculate
 *
 * Returns dynamic shipping rates for a shipment. Invoked twice in the
 * platform lifecycle:
 *  1. GET /baskets/{id}/shipments/{id}/shipping-methods - called with all
 *     applicable shipping methods to populate the rate chooser.
 *  2. dw.order.calculate (basket calculate) - called with only the currently
 *     selected shipping method to price the standard shipping line item.
 *
 * The implementation maps each requested dw.order.ShippingMethod to a
 * provider-side identifier (custom.zenkraftID), calls the provider once
 * per shipment for the requested method set, and returns a
 * ShippingRateResult with method-level rates.
 *
 * Returning null or an empty shippingMethods list lets the platform fall
 * through to the existing legacy/native pricing path.
 *
 * @param {dw.order.Shipment} shipment
 * @param {dw.order.LineItemCtnr} lineItemCtnr
 * @param {dw.util.List} shippingMethods
 * @returns {Object} ShippingRateResult-shaped object
 */
function calculate(shipment, lineItemCtnr, shippingMethods) {
    var Logger = require('dw/system/Logger');
    var logger = Logger.getLogger('zenkraft-rates', 'shippingCalculate');

    var rateHelper = require('*/cartridge/scripts/helpers/rateHelper');

    try {
        if (!shipment || !shippingMethods || shippingMethods.size() === 0) {
            logger.info('Empty input - falling through to native path');
            return { shippingMethods: [] };
        }

        var currencyCode = lineItemCtnr ? lineItemCtnr.getCurrencyCode() : null;

        var quoteRequest = rateHelper.buildQuoteRequest(shipment, lineItemCtnr, shippingMethods);
        if (!quoteRequest) {
            logger.info('No mappable shipping methods for shipment {0} - falling through', shipment.UUID);
            return { shippingMethods: [] };
        }

        var providerResult = rateHelper.fetchRates(quoteRequest);
        if (!providerResult || !providerResult.success) {
            logger.warn(
                'Provider rate call failed for shipment {0}: {1} - falling through',
                shipment.UUID,
                providerResult ? providerResult.error : 'no response'
            );
            return { shippingMethods: [] };
        }

        var methodRates = rateHelper.mapProviderRatesToMethods(
            providerResult.data,
            shippingMethods,
            currencyCode
        );

        logger.info(
            'Returning {0} rate(s) for shipment {1}',
            methodRates.length,
            shipment.UUID
        );

        return { shippingMethods: methodRates };
    } catch (e) {
        logger.error('sfcc.app.shipping.calculate failed: {0}', e.message);
        return { shippingMethods: [] };
    }
}

exports.calculate = calculate;
