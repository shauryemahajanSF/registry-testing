'use strict';

// Mock implementation - returns sample rates without calling the real provider.
// Replace with a LocalServiceRegistry-backed call once credentials are available.

var SAMPLE_PRICES = {
    GROUND: 5.99,
    STANDARD: 7.99,
    TWO_DAY: 14.99,
    EXPRESS: 19.99,
    OVERNIGHT: 29.99
};

var DEFAULT_SAMPLE_PRICE = 9.99;

function priceForMethod(mapped) {
    var key = mapped.serviceCode || mapped.externalId || mapped.shippingMethodId;
    if (key && SAMPLE_PRICES[String(key).toUpperCase()] != null) {
        return SAMPLE_PRICES[String(key).toUpperCase()];
    }
    return DEFAULT_SAMPLE_PRICE;
}

/**
 * Mock provider rate call. Returns a sample rate for each requested method,
 * preserving the externalId so rateHelper.mapProviderRatesToMethods can match it.
 * @param {Object} params - Rate request payload from rateHelper.buildQuoteRequest
 * @returns {Object} { success, data, error, errorCode }
 */
function call(params) {
    var requested = (params && params.requestedMethods) || [];
    var currencyCode = (params && params.currencyCode) || 'USD';

    var rates = [];
    for (var i = 0; i < requested.length; i++) {
        var m = requested[i];
        rates.push({
            shippingMethodId: m.shippingMethodId,
            externalId: m.externalId,
            price: priceForMethod(m),
            currencyCode: currencyCode
        });
    }

    return {
        success: true,
        data: { rates: rates }
    };
}

module.exports = {
    call: call
};
