'use strict';

/**
 * Helpers for sfcc.app.shipping.calculate.
 *
 * Responsibilities:
 *  - translate a shipment + method list into a provider rate request
 *  - call the provider via the service wrapper
 *  - map provider-returned rates back to the requested ShippingMethod ids
 *  - apply optional per-method markup (Amount or Percent)
 */

function toNumber(value) {
    if (value === null || value === undefined || value === '') {
        return 0;
    }
    var n = Number(value);
    return isNaN(n) ? 0 : n;
}

function applyMarkup(basePrice, markupType, markupValue) {
    if (!markupType || markupValue === null || markupValue === undefined) {
        return basePrice;
    }
    var markup = toNumber(markupValue);
    if (markup === 0) {
        return basePrice;
    }
    if (markupType === 'Percent') {
        return basePrice + (basePrice * (markup / 100));
    }
    return basePrice + markup;
}

function readMethodCustom(method, attr) {
    try {
        return method.custom[attr];
    } catch (e) {
        return null;
    }
}

/**
 * Build a provider-agnostic quote request.
 * Returns null if no shipping methods have a mapped zenkraftID.
 */
function buildQuoteRequest(shipment, lineItemCtnr, shippingMethods) {
    var mapped = [];
    var iter = shippingMethods.iterator();
    while (iter.hasNext()) {
        var method = iter.next();
        var externalId = readMethodCustom(method, 'zenkraftID');
        if (externalId) {
            mapped.push({
                shippingMethodId: method.ID,
                externalId: externalId,
                carrierCode: readMethodCustom(method, 'zenkraftCarrierCode'),
                serviceCode: readMethodCustom(method, 'zenkraftServiceCode')
            });
        }
    }

    if (mapped.length === 0) {
        return null;
    }

    var shippingAddress = shipment.getShippingAddress();
    var destination = null;
    if (shippingAddress) {
        destination = {
            address1: shippingAddress.address1,
            address2: shippingAddress.address2,
            city: shippingAddress.city,
            stateCode: shippingAddress.stateCode,
            postalCode: shippingAddress.postalCode,
            countryCode: shippingAddress.countryCode ? shippingAddress.countryCode.value : null
        };
    }

    var items = [];
    var productLineItems = shipment.getProductLineItems().iterator();
    while (productLineItems.hasNext()) {
        var pli = productLineItems.next();
        items.push({
            productId: pli.productID,
            quantity: pli.quantityValue,
            price: pli.basePrice ? pli.basePrice.value : 0,
            weight: readMethodCustom(pli, 'weight')
        });
    }

    return {
        shipmentUUID: shipment.UUID,
        currencyCode: lineItemCtnr ? lineItemCtnr.getCurrencyCode() : null,
        destination: destination,
        items: items,
        requestedMethods: mapped
    };
}

function fetchRates(quoteRequest) {
    var service = require('*/cartridge/scripts/services/shippingRatesService');
    return service.call(quoteRequest);
}

/**
 * Map provider-returned rates back to the requested ShippingMethods.
 * Provider is expected to return { rates: [{ externalId | shippingMethodId, price, currencyCode }] }.
 * Returns an array of { shippingMethodId, price, currencyCode }.
 */
function mapProviderRatesToMethods(providerData, shippingMethods, currencyCode) {
    var out = [];
    if (!providerData || !providerData.rates) {
        return out;
    }

    var providerByExternalId = {};
    var providerByMethodId = {};
    for (var i = 0; i < providerData.rates.length; i++) {
        var r = providerData.rates[i];
        if (r.externalId) {
            providerByExternalId[r.externalId] = r;
        }
        if (r.shippingMethodId) {
            providerByMethodId[r.shippingMethodId] = r;
        }
    }

    var iter = shippingMethods.iterator();
    while (iter.hasNext()) {
        var method = iter.next();
        var externalId = readMethodCustom(method, 'zenkraftID');
        var match = (externalId && providerByExternalId[externalId]) || providerByMethodId[method.ID];
        if (!match) {
            continue;
        }

        var price = toNumber(match.price);
        var markupType = readMethodCustom(method, 'zenkraftRateMarkupType');
        if (markupType && typeof markupType === 'object' && 'value' in markupType) {
            markupType = markupType.value;
        }
        var markupValue = readMethodCustom(method, 'zenkraftRateMarkup');
        price = applyMarkup(price, markupType, markupValue);

        out.push({
            shippingMethodId: method.ID,
            price: price,
            currencyCode: match.currencyCode || currencyCode
        });
    }

    return out;
}

module.exports = {
    buildQuoteRequest: buildQuoteRequest,
    fetchRates: fetchRates,
    mapProviderRatesToMethods: mapProviderRatesToMethods,
    applyMarkup: applyMarkup
};
