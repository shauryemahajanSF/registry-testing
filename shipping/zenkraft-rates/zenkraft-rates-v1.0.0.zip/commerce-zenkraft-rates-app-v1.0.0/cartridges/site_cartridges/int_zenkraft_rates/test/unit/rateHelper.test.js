'use strict';

var proxyquire = require('proxyquire').noCallThru();

function makeMethod(id, custom) {
    return {
        ID: id,
        custom: custom || {}
    };
}

function makeList(items) {
    return {
        size: function () { return items.length; },
        iterator: function () {
            var i = 0;
            return {
                hasNext: function () { return i < items.length; },
                next: function () { return items[i++]; }
            };
        }
    };
}

describe('rateHelper', function () {
    var rateHelper;

    beforeEach(function () {
        rateHelper = proxyquire(
            '../../cartridge/scripts/helpers/rateHelper',
            {
                '*/cartridge/scripts/services/shippingRatesService': {
                    call: function () { return { success: true, data: { rates: [] } }; }
                }
            }
        );
    });

    describe('applyMarkup', function () {
        test('returns base price when no markup configured', function () {
            expect(rateHelper.applyMarkup(10, null, null)).toBe(10);
            expect(rateHelper.applyMarkup(10, 'Amount', 0)).toBe(10);
        });

        test('adds flat amount', function () {
            expect(rateHelper.applyMarkup(10, 'Amount', 2.5)).toBe(12.5);
        });

        test('adds percent of base', function () {
            expect(rateHelper.applyMarkup(10, 'Percent', 15)).toBeCloseTo(11.5);
        });
    });

    describe('buildQuoteRequest', function () {
        test('returns null when no method has a zenkraftID', function () {
            var shipment = {
                UUID: 'abc',
                getShippingAddress: function () { return null; },
                getProductLineItems: function () { return makeList([]); }
            };
            var methods = makeList([makeMethod('STANDARD', {})]);
            expect(rateHelper.buildQuoteRequest(shipment, null, methods)).toBeNull();
        });

        test('includes only mapped methods in requestedMethods', function () {
            var shipment = {
                UUID: 'abc',
                getShippingAddress: function () { return null; },
                getProductLineItems: function () { return makeList([]); }
            };
            var methods = makeList([
                makeMethod('STANDARD', { zenkraftID: 'std-1' }),
                makeMethod('EXPRESS', {})
            ]);
            var req = rateHelper.buildQuoteRequest(shipment, { getCurrencyCode: function () { return 'USD'; } }, methods);
            expect(req).not.toBeNull();
            expect(req.requestedMethods).toHaveLength(1);
            expect(req.requestedMethods[0].shippingMethodId).toBe('STANDARD');
            expect(req.requestedMethods[0].externalId).toBe('std-1');
        });
    });

    describe('mapProviderRatesToMethods', function () {
        test('maps externalId rates back to method ids and applies markup', function () {
            var methods = makeList([
                makeMethod('STANDARD', { zenkraftID: 'std-1', zenkraftRateMarkupType: 'Amount', zenkraftRateMarkup: 1 }),
                makeMethod('EXPRESS', { zenkraftID: 'exp-1' })
            ]);
            var providerData = {
                rates: [
                    { externalId: 'std-1', price: 9.99, currencyCode: 'USD' },
                    { externalId: 'exp-1', price: 19.99, currencyCode: 'USD' }
                ]
            };
            var out = rateHelper.mapProviderRatesToMethods(providerData, methods, 'USD');
            expect(out).toHaveLength(2);
            expect(out[0]).toEqual({ shippingMethodId: 'STANDARD', price: 10.99, currencyCode: 'USD' });
            expect(out[1]).toEqual({ shippingMethodId: 'EXPRESS', price: 19.99, currencyCode: 'USD' });
        });

        test('skips methods with no matching provider rate', function () {
            var methods = makeList([
                makeMethod('STANDARD', { zenkraftID: 'std-1' }),
                makeMethod('EXPRESS', { zenkraftID: 'exp-1' })
            ]);
            var providerData = { rates: [{ externalId: 'std-1', price: 5, currencyCode: 'USD' }] };
            var out = rateHelper.mapProviderRatesToMethods(providerData, methods, 'USD');
            expect(out).toHaveLength(1);
            expect(out[0].shippingMethodId).toBe('STANDARD');
        });
    });
});
