'use strict';

var Money = require('dw/value/Money');
var givexHelper = require('*/cartridge/scripts/helpers/givexHelper');

/**
 * Return deterministic mock responses while this CAP has no provider integration.
 * @param {dw.extensions.payments.PaymentInstrumentBalanceRequestWO} request
 * @returns {dw.value.Money}
 */
exports.getBalance = function (request) {
    try {
        var cardNumber = givexHelper.extractCredentials(request).cardNumber;
        var balances = {
            '7777111122223333': 20,
            '8888111122223333': 50,
            '9999111122223333': 250
        };

        if (cardNumber === '1111111122223333') {
            throw new Error('INVALID');
        }
        if (cardNumber === '2222111122223333') {
            throw new Error('EXPIRED');
        }
        if (cardNumber === '3333111122223333') {
            throw new Error('ZERO_BALANCE');
        }
        if (cardNumber === '4444111122223333') {
            throw new Error('INACTIVE');
        }
        if (cardNumber === '5555111122223333') {
            throw new Error('CURRENCY_MISMATCH');
        }
        if (cardNumber && Object.prototype.hasOwnProperty.call(balances, cardNumber)) {
            return new Money(balances[cardNumber], 'USD');
        }

        throw new Error('INVALID');
    } catch (e) {
        throw e;
    }
};
