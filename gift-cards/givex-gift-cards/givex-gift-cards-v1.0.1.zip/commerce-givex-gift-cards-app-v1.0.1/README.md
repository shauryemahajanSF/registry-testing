# Givex Gift Cards

Full-stack mock Commerce App that demonstrates external stored-value gift cards in Salesforce B2C Commerce checkout, including Storefront Next apply / applied UI.

## What it does

### Backend (Script API hooks)

| Hook | Purpose |
|------|---------|
| `sfcc.app.giftcard.getBalance` | Returns a fixed $20 USD balance (Balance API and Apply) |
| `sfcc.app.giftcard.capture` | Returns success at order creation |
| `sfcc.app.giftcard.refund` | Returns success when a later payment fails |
| `sfcc.app.giftcard.checkConnectionHealth` | Checkout Hub connection badge |

The platform owns Apply allocation (`min(balance, remaining order total)`), payment-instrument masking, and capture/refund timing. This mock app makes no provider calls.

### Storefront Next UI

| Target | Component |
|--------|-----------|
| `sfcc.cart.giftCards.apply` | Accordion form to enter card number / PIN and apply |
| `sfcc.orderSummary.giftCards.applied` | Applied gift-card rows with amount and remove |

Apply / remove call extension action routes that create or delete a `COMMERCE_APP_GIFT_CARD` payment instrument via Shopper Baskets. No amount is sent on apply — the platform allocates it after `getBalance`.

## Architecture

- Cartridge: `int_givex_giftcards`
- Service: `givex.giftcards.api` (included as a future provider-integration template; unused by the mock hooks)
- Domain: `gift-cards`
- Storefront extension: `storefront-next/src/extensions/givex-gift-cards/`

## Installation

1. Install the app from Commerce Apps / Checkout Hub.
2. Optional: set PAN validation preferences under **Givex Gift Cards** site preferences, and/or mirror them in storefront config under `extension.givexGiftCards` (`panPattern`, `panMinLength`, `panMaxLength`, `panLuhnEnabled`).
3. Use the mock test cards below to check a balance, apply a card, and exercise the mixed-tender checkout flow.

## Mock test cards

| Card number | Balance result |
|-------------|----------------|
| `1111111122223333` | INVALID |
| `2222111122223333` | EXPIRED |
| `3333111122223333` | ZERO_BALANCE |
| `4444111122223333` | INACTIVE |
| `5555111122223333` | CURRENCY_MISMATCH |
| `7777111122223333` | $20 USD |
| `8888111122223333` | $50 USD |
| `9999111122223333` | $250 USD |

## Future provider integration

The installed `givex.giftcards.api` service and `givex.giftcards.credential` are unused by this mock. A real provider integration should replace the fixed balance and success hooks with Service Framework calls, then configure the service credential with provider-issued values.

## Development

```bash
cd cartridges/site_cartridges/int_givex_giftcards
npm install
npm test
```

Storefront extension unit tests live under `storefront-next/src/extensions/givex-gift-cards/tests/`.

## Packaging

From the registry repo root, use `/package-app` (or the `package-app` skill) to rebuild the ZIP and SHA-256 after any source change.
